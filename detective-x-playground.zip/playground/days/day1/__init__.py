"""Day 1 - Python Foundations: Academy lessons and the Detective X Street Division."""

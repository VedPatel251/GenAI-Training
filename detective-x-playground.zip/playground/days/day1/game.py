"""Detective X — vertical slice content (Day 1 division).

SKILLS reuse lessons from lessons.py (this package) by id.
Each case step runs with one evidence variant preloaded. The checker runs the
trainee's code against EVERY variant, so only code that reasons from the
evidence passes. Tests compute the expected answer from the evidence itself.
"""

TITLE = "Detective X"
DIVISION = "Day 1 · Street Division"

# Spread over the whole 8-day course: finishing Day 1 (~6,000 XP) reaches Senior Detective.
RANKS = [
    (0, "Cadet"),
    (400, "Constable"),
    (1500, "Detective"),
    (4000, "Senior Detective"),
    (9000, "Inspector"),
    (18000, "Chief Inspector"),
    (30000, "Commissioner"),
]

XP = {"lesson": 10, "skill": 30, "tutorial": 20, "small": 50, "medium": 120, "big": 300, "exam": 200, "capstone": 250}

FRAGMENTS_TOTAL = 16   # X fragments across the whole course (Day 1 holds 4); the final case needs them all

# Skills in teaching order. Each skill's lessons come from lessons.py, and a case may only
# use syntax from the skills it lists (and the skills before them).
SKILLS = [
    {"id": "orientation", "title": "Orientation", "badge": "Bureau ID card",
     "tagline": "How the Bureau works, and how to set up Python on your own machine.",
     "lessons": ["welcome", "install-python", "first-program"]},
    {"id": "field-notes", "title": "Field notes", "badge": "Notebook",
     "tagline": "print, comments, variables and numbers: writing down what you find.",
     "lessons": ["print-comments", "variables", "numbers"]},
    {"id": "text", "title": "Reading text", "badge": "Magnifying glass",
     "tagline": "Strings: cleaning up statements, notes and messages.",
     "lessons": ["strings-basics"]},
    {"id": "logic", "title": "Deduction", "badge": "Scales of justice",
     "tagline": "True, False, comparisons and if / elif / else: drawing conclusions.",
     "lessons": ["booleans", "if-else"]},
    {"id": "lists", "title": "Lists and loops", "badge": "Case binder",
     "tagline": "Keep many records in order and check every one of them with for and while.",
     "lessons": ["lists-basics", "for-loops", "while-loops"]},
    {"id": "records", "title": "Records", "badge": "Index cards",
     "tagline": "Dictionaries: look things up by name instead of by position.",
     "lessons": ["dicts-basics"]},
    {"id": "functions", "title": "Procedures", "badge": "Rubber stamp",
     "tagline": "Functions: write a procedure once, run it on every case.",
     "lessons": ["functions-basics"]},
    {"id": "errors", "title": "Damage control", "badge": "First-aid kit",
     "tagline": "Read error messages and survive bad data with try / except.",
     "lessons": ["errors-basics"]},
    {"id": "toolkit", "title": "Field kit", "badge": "Toolbox",
     "tagline": "Modules, dates, tuples, None and virtual environments.",
     "lessons": ["modules-basics", "tuples-none", "python-setup"]},
    {"id": "identity", "title": "Identity checks", "badge": "ID scanner",
     "tagline": "Types, is vs ==, the float trap and truthiness.",
     "lessons": ["dynamic-typing", "is-vs-eq", "float-trap", "truthiness"]},
    {"id": "forensic-text", "title": "Forensic text", "badge": "Typewriter",
     "tagline": "Slicing, split and join, and f-string formatting for reports.",
     "lessons": ["strings", "f-strings"]},
    {"id": "collections", "title": "Evidence collections", "badge": "Evidence bags",
     "tagline": "Sets, copies, Counter, defaultdict, loop tricks and match / case.",
     "lessons": ["containers", "dicts", "loops", "control-flow"]},
    {"id": "function-craft", "title": "Procedure craft", "badge": "Signet ring",
     "tagline": "Argument types, the mutable default trap, scope and closures.",
     "lessons": ["arguments", "mutable-default", "scope"]},
    {"id": "functional", "title": "Functional tools", "badge": "Lens kit",
     "tagline": "Functions as values, lambda, sorted(key=), map / filter / reduce, comprehensions.",
     "lessons": ["first-class", "map-filter-reduce", "comprehensions"]},
    {"id": "decorators", "title": "Wiretaps", "badge": "Headphones",
     "tagline": "Decorators: wrap a function to log, time or count it.",
     "lessons": ["decorators"]},
    {"id": "streams", "title": "Surveillance streams", "badge": "Reel-to-reel",
     "tagline": "Generators and context managers: process data one piece at a time.",
     "lessons": ["generators", "context-managers"]},
    {"id": "classes", "title": "Case files", "badge": "Filing cabinet",
     "tagline": "Classes, objects, properties, class and static methods.",
     "lessons": ["classes", "properties"]},
    {"id": "inheritance", "title": "Chain of command", "badge": "Org chart",
     "tagline": "Inheritance, abstract base classes and composition.",
     "lessons": ["inheritance-abc", "composition"]},
    {"id": "dunders", "title": "Native evidence", "badge": "Master key",
     "tagline": "Dunder methods: make your objects work with len, in, [], print and ==.",
     "lessons": ["dunders", "eq-hash"]},
    {"id": "dataclasses", "title": "Standard forms", "badge": "Carbon copy",
     "tagline": "Dataclasses, __post_init__ validation and frozen value objects.",
     "lessons": ["dataclasses", "frozen"]},
    {"id": "project", "title": "Project craft", "badge": "Blueprint",
     "tagline": "Type hints, your own exceptions, files and JSON, packages and command-line programs.",
     "lessons": ["type-hints", "custom-exceptions", "files-json", "modules-packages", "cli-programs"]},
]

CASES = [
    # ------------------------------------------------------------------ tutorial
    {
        "id": "coffee-thief",
        "tier": "tutorial",
        "title": "The Coffee Thief",
        "teaser": "Someone keeps raiding the Bureau's coffee. Your first case.",
        "skills": ["orientation"],
        "story": "Welcome to the Bureau, Cadet. Your first case is small but personal: every night, someone steals the good coffee from the 3rd-floor kitchen.\n\nThe hallway camera reads ID badges. Forensics has already loaded its record into a **variable** called `camera_name`. A variable is a labelled box that holds a value; you will learn all about them in the Field notes skill.\n\nAt the Bureau we never type an answer we *think* is right. We write code that reads the evidence, so the same code works on every case file.",
        "suspects": [
            {"name": "the night janitor", "note": "Has keys to every floor."},
            {"name": "the intern", "note": "Drinks four cups a day."},
            {"name": "the Chief", "note": "Claims to only drink tea."},
        ],
        "variants": [
            'camera_name = "Inspector Rao"\ncups_missing = 3\n',
            'camera_name = "Officer Mehta"\ncups_missing = 5\n',
            'camera_name = "Clerk Fernandes"\ncups_missing = 2\n',
        ],
        "steps": [
            {
                "question": "**Goal:** name the coffee thief.\n\n**You have:** `camera_name`, the name the camera read from the badge. It is text, for example `\"Officer Shah\"`.\n\n**Write** one line of code that prints `Thief:` and then the name in `camera_name`.\n- Use the variable `camera_name`, not the name itself. The name is different in every case file.\n- Print only this one line.\n\n**Example:** if `camera_name` holds `\"Officer Shah\"`, your program prints `Thief: Officer Shah`.",
                "starter": 'print("Thief:", ...)\n',
                "solution": 'print("Thief:", camera_name)\n',
                "tests": '''expected = "Thief: " + camera_name
assert __output__.strip() == expected, f"expected the line {expected!r}, you printed {__output__.strip()!r}"''',
                "tips": [
                    "Replace the `...` with the variable name `camera_name`. No quotes around it: quotes would print the word itself.",
                    'The whole line is `print("Thief:", camera_name)`.',
                ],
                "reveal": "The camera never lies. Caught red-handed with a thermos. The coffee is safe, and you have learned the Bureau's first rule: **read the evidence with code**.",
            },
        ],
        "closing": "Case closed. The Chief is impressed, and slightly embarrassed that the culprit was on their own staff. Your badge is ready. Real cases are waiting on the board.",
    },
    # ------------------------------------------------------------------ small
    {
        "id": "ransom-note",
        "tier": "small",
        "title": "The Ransom Note",
        "teaser": "Three scraps of paper, one kidnapper, one demand.",
        "skills": ["field-notes"],
        "story": "A shipping heir has vanished, and this morning a ransom note arrived, torn into three scraps. The lab has typed each scrap into a variable. They have also worked out the order from the tear marks: **scrap 2, then scrap 3, then scrap 1**.\n\nThe note also says how the money must be delivered. Read it carefully.",
        "suspects": [
            {"name": "the chauffeur", "note": "Last to see the heir."},
            {"name": "the business rival", "note": "Lost a contract to the family last month."},
        ],
        "variants": [
            'scrap_1 = "AT MIDNIGHT"\nscrap_2 = "BRING THE MONEY"\nscrap_3 = "TO PIER 9"\nbills = 400\nbill_value = 500\nenvelopes = 3\n',
            'scrap_1 = "BEFORE DAWN"\nscrap_2 = "LEAVE THE CASE"\nscrap_3 = "UNDER THE CLOCK TOWER"\nbills = 250\nbill_value = 2000\nenvelopes = 4\n',
            'scrap_1 = "ON FRIDAY"\nscrap_2 = "DROP THE BAG"\nscrap_3 = "AT THE OLD MILL"\nbills = 900\nbill_value = 100\nenvelopes = 7\n',
        ],
        "steps": [
            {
                "question": "**Goal:** read the ransom note in the right order.\n\n**You have:** three text variables, `scrap_1`, `scrap_2` and `scrap_3`. For example `scrap_2 = \"SEND THE KEYS\"`.\n\n**Write** one `print` that shows the whole note on **one line**:\n- the scraps in this order: `scrap_2`, then `scrap_3`, then `scrap_1`\n- one space between the scraps (`print` adds it for you when you separate values with commas)\n- print nothing else\n\n**Example:** if `scrap_2 = \"SEND THE KEYS\"`, `scrap_3 = \"TO THE GATE\"` and `scrap_1 = \"AT NOON\"`, the output is `SEND THE KEYS TO THE GATE AT NOON`.",
                "starter": "# print the scraps in the right order\n",
                "solution": "print(scrap_2, scrap_3, scrap_1)\n",
                "tests": '''expected = f"{scrap_2} {scrap_3} {scrap_1}"
assert __output__.strip() == expected, f"the note should read {expected!r}, you printed {__output__.strip()!r}"''',
                "tips": [
                    "`print` can take several values separated by commas, and puts a space between them.",
                    "`print(scrap_2, scrap_3, scrap_1)`",
                ],
                "reveal": "The demand is clear. Now the money: the kidnapper wants it in used bills.",
            },
            {
                "notes": "How the ransom adds up:\n- total money = number of bills × value of one bill\n- money in one envelope = total ÷ number of envelopes, in **whole** rupees (any leftover rupees are dropped)",
                "question": "**Goal:** work out how much money the kidnapper wants, and how much goes in each envelope.\n\n**You have:** three whole numbers:\n- `bills`: how many bills\n- `bill_value`: rupees per bill\n- `envelopes`: how many envelopes\n\n**Write** two variables (see the field notes):\n- `ransom_total`: the total in rupees\n- `per_envelope`: the rupees in one envelope, as a **whole number** (like `166`, not `166.66`)\n\n**Then** print both. The starter already does this.\n\n**Example:** with `bills = 10`, `bill_value = 50` and `envelopes = 3`, `ransom_total` is `500` and `per_envelope` is `166`.",
                "starter": "ransom_total = ...\nper_envelope = ...\n\nprint(ransom_total, per_envelope)\n",
                "solution": "ransom_total = bills * bill_value\nper_envelope = ransom_total // envelopes\n\nprint(ransom_total, per_envelope)\n",
                "tests": '''assert ransom_total == bills * bill_value, f"ransom_total should be bills x bill_value = {bills * bill_value}, got {ransom_total!r}"
assert per_envelope == (bills * bill_value) // envelopes, f"per_envelope should be {(bills * bill_value) // envelopes} (whole rupees), got {per_envelope!r}"''',
                "tips": [
                    "Multiply with `*`. For division that keeps only the whole part, Python has `//`: `7 // 2` is `3`.",
                    "`ransom_total = bills * bill_value` and `per_envelope = ransom_total // envelopes`.",
                ],
                "reveal": "The amounts match a withdrawal the business rival made yesterday, to the rupee.",
            },
        ],
        "closing": "Case closed. The heir was found safe at the pier, and the rival's bank records did the rest. Precise arithmetic catches careless criminals.",
    },
    {
        "id": "missing-minutes",
        "tier": "small",
        "title": "The Missing Minutes",
        "teaser": "The vault camera went dark. For how long, exactly?",
        "skills": ["field-notes"],
        "story": "Last night the camera covering the bank vault went dark. The security system only logs the gap in **seconds**, in a variable called `gap_seconds`.\n\nThe night guard says they were gone for \"a few minutes\". The jury will want minutes and seconds.",
        "suspects": [
            {"name": "the night guard", "note": "Says the outage was short."},
            {"name": "the electrician", "note": "Was rewiring the floor above."},
        ],
        "variants": [
            "gap_seconds = 2537\n",
            "gap_seconds = 754\n",
            "gap_seconds = 3600\n",
        ],
        "steps": [
            {
                "notes": "There are **60 seconds** in a minute. For example, 125 seconds is 2 whole minutes (2 × 60 = 120) and 5 seconds left over.",
                "question": "**Goal:** turn the length of the camera gap into minutes and seconds.\n\n**You have:** `gap_seconds`, a whole number of seconds (for example `125`).\n\n**Write** two variables:\n- `minutes`: the number of **whole** minutes in `gap_seconds`\n- `seconds`: the seconds left over after taking out those minutes (always 0 to 59)\n\n**Then** print them in exactly this form, and nothing else: `<minutes> min <seconds> s`. The starter's `print` line already does this.\n\n**Example:** `gap_seconds = 125` gives `minutes = 2` and `seconds = 5`, and the output `2 min 5 s`.",
                "starter": "minutes = ...\nseconds = ...\n\nprint(minutes, \"min\", seconds, \"s\")\n",
                "solution": "minutes = gap_seconds // 60\nseconds = gap_seconds % 60\n\nprint(minutes, \"min\", seconds, \"s\")\n",
                "tests": '''assert minutes == gap_seconds // 60, f"minutes should be {gap_seconds // 60}, got {minutes!r}"
assert seconds == gap_seconds % 60, f"seconds should be {gap_seconds % 60}, got {seconds!r}"
assert __output__.strip() == f"{gap_seconds // 60} min {gap_seconds % 60} s", "print them as: <minutes> min <seconds> s"''',
                "tips": [
                    "Divide by 60 with `//` to get the whole part, and use `%` to get what is left over: `125 % 60` is `5`.",
                    "`minutes = gap_seconds // 60` and `seconds = gap_seconds % 60`.",
                ],
                "reveal": "Not \"a few minutes\". More than enough time to empty a safe-deposit box. The guard's story falls apart.",
            },
        ],
        "closing": "Case closed. Faced with the exact numbers, the night guard admitted to leaving the door propped open for an accomplice.",
    },
    {
        "id": "typed-confession",
        "tier": "small",
        "title": "The Typed Confession",
        "teaser": "A messy statement that has to go in the official report.",
        "skills": ["text"],
        "story": "A witness typed their statement on a broken typewriter: stray spaces, random CAPITALS. The court only accepts clean statements in the official format.\n\nThe statement is in `statement` and the witness's name is in `witness`.",
        "suspects": [
            {"name": "the witness", "note": "Nervous, but cooperative."},
        ],
        "variants": [
            'statement = "   i was AT the DOCKS until NINE   "\nwitness = "harbour master"\n',
            'statement = "  The VAN was BLUE and had no plates "\nwitness = "flower seller"\n',
            'statement = "    nobody LEFT the Theatre before the encore  "\nwitness = "usher"\n',
        ],
        "steps": [
            {
                "question": "**Goal:** clean up the witness statement.\n\n**You have:** `statement`, the messy text, for example `\"  The DOG barked  \"`.\n\n**Write** a variable `clean`: the statement with the spaces at the start and the end removed, and every letter in lower case. The spaces between words stay as they are.\n\n**Then** print `clean`. The starter already does this.\n\n**Example:** `\"  The DOG barked  \"` becomes `\"the dog barked\"`.",
                "starter": "clean = ...\nprint(clean)\n",
                "solution": "clean = statement.strip().lower()\nprint(clean)\n",
                "tests": '''assert clean == statement.strip().lower(), f"clean should be {statement.strip().lower()!r}, got {clean!r}"''',
                "tips": [
                    "Two methods: `.strip()` removes outer spaces and `.lower()` lowercases.",
                    "Chain them: `statement.strip().lower()`.",
                ],
                "reveal": "Readable at last. Now put it in the court's format.",
            },
            {
                "question": "**Goal:** write the statement in the court's official format.\n\n**You have:**\n- `clean`, the cleaned statement (the starter makes it for you)\n- `witness`, the witness's name in lower case, for example `\"night porter\"`\n\n**Write** two variables:\n- `report`: an f-string of the form `Statement of <NAME>: <clean statement>`, with the name in UPPER CASE. There is one space after `of` and one after the colon.\n- `length`: the number of characters in `clean` (spaces count too), as a whole number\n\n**Then** print both. The starter already does this.\n\n**Example:** with `witness = \"night porter\"` and `clean = \"the dog barked\"`, `report` is `\"Statement of NIGHT PORTER: the dog barked\"` and `length` is `14`.",
                "starter": "clean = statement.strip().lower()\n\nreport = ...\nlength = ...\nprint(report)\nprint(length)\n",
                "solution": 'clean = statement.strip().lower()\n\nreport = f"Statement of {witness.upper()}: {clean}"\nlength = len(clean)\nprint(report)\nprint(length)\n',
                "tests": '''_clean = statement.strip().lower()
_expected = f"Statement of {witness.upper()}: {_clean}"
assert report == _expected, f"report should be {_expected!r}, got {report!r}"
assert length == len(_clean), f"length should be {len(_clean)}, got {length!r}"''',
                "tips": [
                    "Inside an f-string you can call methods: `{witness.upper()}`.",
                    '`report = f"Statement of {witness.upper()}: {clean}"` and `length = len(clean)`.',
                ],
                "reveal": "Filed. The clean statement puts the witness somewhere they couldn't have seen the crime from.",
            },
        ],
        "closing": "Case closed. Clean evidence holds up in court; messy evidence gets thrown out.",
    },
    {
        "id": "fingerprint-match",
        "tier": "small",
        "title": "Fingerprint Match",
        "teaser": "The lab needs a verdict on a print from the crime scene.",
        "skills": ["logic"],
        "story": "A print was lifted from a broken window. The lab compared it with the suspect's and counted the `matching_points`. They also noted whether the print is `smudged`.\n\nThe Bureau has strict rules for turning those numbers into a verdict.",
        "suspects": [
            {"name": "the window cleaner", "note": "Has a reason to touch every window."},
        ],
        "variants": [
            "matching_points = 9\nsmudged = False\n",
            "matching_points = 14\nsmudged = False\n",
            "matching_points = 5\nsmudged = False\n",
            "matching_points = 13\nsmudged = True\n",
            "matching_points = 12\nsmudged = False\n",
            "matching_points = 8\nsmudged = False\n",
        ],
        "steps": [
            {
                "notes": "Bureau rules for a fingerprint verdict:\n- A smudged print must be **retaken**, whatever the score.\n- **12 or more** matching points: **match**.\n- **8 to 11** points: **partial**.\n- **Fewer than 8** points: **no match**.",
                "question": "**Goal:** give the lab's verdict on the print.\n\n**You have:**\n- `matching_points`, a whole number, for example `10`\n- `smudged`, either `True` or `False`\n\n**Write** a variable `verdict` that holds exactly one of these four texts, in lower case as shown: `\"retake\"`, `\"match\"`, `\"partial\"` or `\"no match\"`. Follow the field notes:\n- check `smudged` first: a smudged print is `\"retake\"` even with a high score\n- exactly 12 points is `\"match\"`, and exactly 8 points is `\"partial\"`\n\n**Then** print `verdict`. The starter already does this.\n\n**Example:** `matching_points = 10` and `smudged = False` gives `\"partial\"`. `matching_points = 15` and `smudged = True` gives `\"retake\"`.",
                "starter": "# set verdict here\n\nprint(verdict)\n",
                "solution": 'if smudged:\n    verdict = "retake"\nelif matching_points >= 12:\n    verdict = "match"\nelif matching_points >= 8:\n    verdict = "partial"\nelse:\n    verdict = "no match"\n\nprint(verdict)\n',
                "tests": '''if smudged:
    _exp = "retake"
elif matching_points >= 12:
    _exp = "match"
elif matching_points >= 8:
    _exp = "partial"
else:
    _exp = "no match"
assert verdict == _exp, f"with matching_points = {matching_points} and smudged = {smudged}, the verdict should be {_exp!r}, got {verdict!r}"''',
                "tips": [
                    "Start with `if smudged:` because it wins over any score.",
                    "Then `elif matching_points >= 12:`, `elif matching_points >= 8:` and `else:`.",
                ],
                "reveal": "The verdict is in the file. The window cleaner's lawyer is already calling.",
            },
        ],
        "closing": "Case closed. Clear rules, applied the same way every time: that is how a deduction holds up.",
    },
    {
        "id": "guest-list",
        "tier": "small",
        "title": "The Guest List",
        "teaser": "A gala, a stolen necklace, and two lists that don't agree.",
        "skills": ["lists"],
        "story": "At last night's gala a diamond necklace disappeared. The host has the list of `invited` guests, and the doorman has the `signed` guestbook of everyone who actually came in.\n\nWhoever was invited but never signed in was not where they were supposed to be. And the doorman swears that **exactly one** person got in without an invitation.",
        "suspects": [
            {"name": "the guests who never signed", "note": "Where were they?"},
            {"name": "the gatecrasher", "note": "Not on any list."},
        ],
        "variants": [
            'invited = ["Asha", "Ravi", "Meera", "Kabir", "Zoya", "Vikram"]\nsigned = ["Ravi", "Zoya", "Asha", "Dev", "Vikram"]\n',
            'invited = ["Leela", "Arjun", "Nisha", "Omar", "Priya"]\nsigned = ["Omar", "Sam", "Leela", "Priya"]\n',
            'invited = ["Tara", "Ishaan", "Rhea", "Yusuf", "Anika", "Neel", "Maya"]\nsigned = ["Neel", "Tara", "Maya", "Rhea", "Farhan"]\n',
        ],
        "steps": [
            {
                "question": "**Goal:** find the invited guests who never signed in.\n\n**You have:** two lists of names (strings):\n- `invited`: everyone on the invitation list, for example `[\"Ana\", \"Ben\", \"Cy\"]`\n- `signed`: everyone who signed the guestbook, for example `[\"Cy\", \"Ana\"]`\n\n**Write** a list `missing`, using a `for` loop over `invited`:\n- it holds every name in `invited` that is **not** in `signed`\n- in the same order as `invited`\n\n**Then** print `missing`. The starter already does this.\n\n**Example:** with the two lists above, `missing` is `[\"Ben\"]`.",
                "starter": "missing = []\n# loop over invited here\n\nprint(missing)\n",
                "solution": "missing = []\nfor guest in invited:\n    if guest not in signed:\n        missing.append(guest)\n\nprint(missing)\n",
                "tests": '''_exp = [g for g in invited if g not in signed]
assert missing == _exp, f"missing should be {_exp}, got {missing}"''',
                "tips": [
                    "`not in` is the opposite of `in`: `guest not in signed` is True when the guest never signed.",
                    "Inside `for guest in invited:` write `if guest not in signed:` and then `missing.append(guest)`.",
                ],
                "reveal": "Two names. Two people with no alibi for the hour the necklace vanished.",
            },
            {
                "question": "**Goal:** find the gatecrasher, the one person who signed in without an invitation.\n\n**You have:** the same two lists, `invited` and `signed`. Exactly one name in `signed` is not in `invited`.\n\n**Write** a variable `gatecrasher` that holds that one name as text: a string like `\"Dan\"`, not a list like `[\"Dan\"]`. Loop over `signed` to find it.\n\n**Then** print `gatecrasher`. The starter already does this.\n\n**Example:** with `invited = [\"Ana\", \"Ben\"]` and `signed = [\"Ben\", \"Dan\", \"Ana\"]`, `gatecrasher` is `\"Dan\"`.",
                "starter": "gatecrasher = None\n# loop over signed here\n\nprint(gatecrasher)\n",
                "solution": "gatecrasher = None\nfor name in signed:\n    if name not in invited:\n        gatecrasher = name\n\nprint(gatecrasher)\n",
                "tests": '''_exp = [n for n in signed if n not in invited][0]
assert gatecrasher == _exp, f"gatecrasher should be {_exp!r}, got {gatecrasher!r}"''',
                "tips": [
                    "The same pattern as before, but loop over `signed` and check `not in invited`.",
                    "When you find the name, store it: `gatecrasher = name`.",
                ],
                "reveal": "The gatecrasher was carrying a jeweller's loupe. Interesting.",
            },
        ],
        "closing": "Case closed. The gatecrasher and one of the missing guests were working together. Comparing two lists, one name at a time, cracked it.",
    },
    # ------------------------------------------------------------------ medium
    {
        "id": "library-heist",
        "tier": "medium",
        "title": "The Library Heist",
        "teaser": "A priceless folio is gone. The checkout log knows who took it.",
        "skills": ["field-notes", "text", "logic", "lists"],
        "story": "The Grand Library's rarest book, **Folio 1623**, has been replaced with a fake. The checkout system records every movement in four lists of the same length. Line `i` of the log is: `times[i]`, `names[i]`, `actions[i]` (`\"out\"` or `\"in\"`) and `items[i]`.\n\nTimes are written `\"HH:MM\"`, so the log is already in time order.\n\nThe head librarian adds one detail that matters: *\"A return only counts if the same person who took the book out brings it back. Anyone else 'returning' it is handing in a forgery.\"*",
        "suspects": [
            {"name": "the archivist", "note": "Handles the folio for restoration."},
            {"name": "the visiting scholar", "note": "Requested the folio three times this month."},
            {"name": "the volunteer", "note": "New, eager, and always near the rare-books desk."},
        ],
        "variants": [
            'times = ["18:02", "18:15", "18:40", "19:05", "19:30", "20:10", "20:45"]\n'
            'names = ["Archivist Iyer", "Scholar Novak", "Scholar Novak", "Volunteer Das", "Archivist Iyer", "Volunteer Das", "Scholar Novak"]\n'
            'actions = ["out", "out", "in", "out", "in", "out", "in"]\n'
            'items = ["Atlas", "Folio 1623", "Folio 1623", "Folio 1623", "Atlas", "Map Box", "Folio 1623"]\n',

            'times = ["17:50", "18:20", "18:55", "19:10", "19:45", "20:30"]\n'
            'names = ["Scholar Novak", "Archivist Iyer", "Scholar Novak", "Archivist Iyer", "Volunteer Das", "Archivist Iyer"]\n'
            'actions = ["out", "out", "in", "in", "out", "out"]\n'
            'items = ["Folio 1623", "Atlas", "Folio 1623", "Atlas", "Map Box", "Folio 1623"]\n',

            'times = ["18:00", "18:30", "19:00", "19:20", "19:55", "20:15", "20:50", "21:05"]\n'
            'names = ["Volunteer Das", "Volunteer Das", "Scholar Novak", "Archivist Iyer", "Archivist Iyer", "Volunteer Das", "Volunteer Das", "Archivist Iyer"]\n'
            'actions = ["out", "in", "out", "out", "in", "in", "out", "in"]\n'
            'items = ["Folio 1623", "Folio 1623", "Folio 1623", "Atlas", "Atlas", "Folio 1623", "Map Box", "Map Box"]\n',
        ],
        "steps": [
            {
                "question": "**Goal:** list everyone who handled the folio.\n\n**You have:** four lists of the same length. Position `i` in each list describes one log line:\n- `times[i]`: the time as text, like `\"18:15\"`\n- `names[i]`: who it was, like `\"Scholar Novak\"`\n- `actions[i]`: `\"out\"` or `\"in\"`\n- `items[i]`: which item, like `\"Folio 1623\"`\n\n**Write** a list `folio_people`:\n- the name from every log line whose item is exactly `\"Folio 1623\"` (both `\"out\"` and `\"in\"` lines count)\n- in log order (the order of the lists)\n- each name only **once**: if a name is already in the list, don't add it again\n\n**Then** print `folio_people`. The starter already does this.\n\n**Example:** with `names = [\"Bo\", \"Ann\", \"Bo\", \"Cy\"]` and `items = [\"Folio 1623\", \"Folio 1623\", \"Folio 1623\", \"Atlas\"]`, `folio_people` is `[\"Bo\", \"Ann\"]`.",
                "starter": "folio_people = []\nfor i in range(len(items)):\n    # look at items[i] and names[i] here\n    ...\n\nprint(folio_people)\n",
                "solution": 'folio_people = []\nfor i in range(len(items)):\n    if items[i] == "Folio 1623":\n        if names[i] not in folio_people:\n            folio_people.append(names[i])\n\nprint(folio_people)\n',
                "tests": '''_exp = []
for _i in range(len(items)):
    if items[_i] == "Folio 1623" and names[_i] not in _exp:
        _exp.append(names[_i])
assert folio_people == _exp, f"folio_people should be {_exp}, got {folio_people}"''',
                "tips": [
                    "`range(len(items))` gives every line number `i`, so `items[i]` and `names[i]` belong to the same log line.",
                    'Inside the loop: `if items[i] == "Folio 1623":` and then, only if `names[i] not in folio_people`, append it.',
                ],
                "reveal": "Everyone on that list touched the folio yesterday. One of them walked out with the real one.",
            },
            {
                "question": "**Goal:** find when the folio was last seen in the log.\n\n**You have:** the same four lists: `times`, `names`, `actions` and `items`. The log is in time order, so a later position means a later time.\n\n**Write** a variable `last_seen`: the time (the text from `times`, like `\"20:45\"`) of the **last** log line whose item is `\"Folio 1623\"`.\n\n**Then** print `last_seen`. The starter already does this.\n\n**Example:** with `times = [\"09:00\", \"09:30\", \"10:00\"]` and `items = [\"Folio 1623\", \"Folio 1623\", \"Atlas\"]`, `last_seen` is `\"09:30\"`.",
                "starter": "last_seen = None\n# loop over the log here\n\nprint(last_seen)\n",
                "solution": 'last_seen = None\nfor i in range(len(items)):\n    if items[i] == "Folio 1623":\n        last_seen = times[i]\n\nprint(last_seen)\n',
                "tests": '''_exp = [times[_i] for _i in range(len(items)) if items[_i] == "Folio 1623"][-1]
assert last_seen == _exp, f"last_seen should be {_exp!r}, got {last_seen!r}"''',
                "tips": [
                    "Loop over every line. Each time the item is the folio, overwrite `last_seen` with that line's time.",
                    "After the loop, `last_seen` holds the time from the last matching line, because later lines overwrite earlier ones.",
                ],
                "reveal": "After that time, the folio never shows up in the log again.",
            },
            {
                "notes": "How the library tracks a book:\n- When someone takes the book **out**, they are now holding it.\n- A return (**in**) only counts if it is made by the **same person** who is holding the book. After that, nobody is holding it.\n- A return by anyone else is a forgery: the real book stays with the person who took it out.\n- Whoever still holds the folio at the end of the log is the thief.",
                "question": "**Goal:** name the thief: the person still holding the real folio at the end of the log.\n\n**You have:** the same four lists, and a starter that already loops over the log and picks out the folio lines.\n\n**Write** the inside of that `if`, using the variable `holder`. It starts as `None`, meaning nobody holds the folio. On each `\"Folio 1623\"` line:\n- if `actions[i]` is `\"out\"`: set `holder` to `names[i]`\n- if `actions[i]` is `\"in\"` **and** `names[i]` equals `holder`: set `holder` back to `None`\n- if it is `\"in\"` by someone else: change nothing\n\n**Then** after the loop, `culprit` must hold the final `holder` (the starter already writes `culprit = holder`).\n\n**Example:** folio lines `Ann out`, then `Bo in`: `culprit` is `\"Ann\"` (Bo's return is forged). Folio lines `Ann out`, `Ann in`, `Bo out`: `culprit` is `\"Bo\"`.",
                "starter": "holder = None\nfor i in range(len(items)):\n    if items[i] == \"Folio 1623\":\n        ...\n\nculprit = holder\nprint(\"The thief is\", culprit)\n",
                "solution": 'holder = None\nfor i in range(len(items)):\n    if items[i] == "Folio 1623":\n        if actions[i] == "out":\n            holder = names[i]\n        elif actions[i] == "in" and names[i] == holder:\n            holder = None\n\nculprit = holder\nprint("The thief is", culprit)\n',
                "tests": '''_h = None
for _i in range(len(items)):
    if items[_i] == "Folio 1623":
        if actions[_i] == "out":
            _h = names[_i]
        elif actions[_i] == "in" and names[_i] == _h:
            _h = None
assert culprit == _h, f"on this log the thief is {_h!r}, but your code says {culprit!r}. Remember: a return by someone else doesn't count."''',
                "tips": [
                    'Inside the folio check: `if actions[i] == "out": holder = names[i]`.',
                    'Then `elif actions[i] == "in" and names[i] == holder: holder = None`. A forged return by someone else leaves `holder` unchanged.',
                ],
                "reveal": "The log doesn't lie: the folio went out and never came back with the person who took it. And on the empty shelf, someone has drawn a small chalk **X**.",
            },
        ],
        "closing": "Case closed. The real Folio 1623 was found in the thief's locker. But the chalk X on the shelf bothers the Chief: *\"I've seen that mark before. Open a file. Call it X.\"*",
        "fragment": "A chalk X on shelf 7, drawn with the left hand.",
    },
]

# ----------------------------------------------------------------------
# More cases live in their own files so they can be written and checked
# separately. Each module exports CASES (a list in the same format).
# ----------------------------------------------------------------------
import importlib as _importlib

for _mod in ("cases_small", "cases_medium", "cases_big", "cases_project", "cases_final"):
    _full = f"{__package__}.{_mod}"
    try:
        CASES.extend(_importlib.import_module(_full).CASES)
    except ModuleNotFoundError as _e:
        if _e.name != _full:
            raise

# ----------------------------------------------------------------------
# Progression rules on top of skills.
# A case listed here also needs earlier cases closed: "cases" by id, and
# "mediums" = how many medium cases (that use only this case's skills) must be closed.
# This keeps the top of the board earned, not just read.
# ----------------------------------------------------------------------
UNLOCKS = {
    "grand-library-murder": {"cases": [], "mediums": 1},
    "midnight-express": {"cases": ["grand-library-murder"], "mediums": 4},
    "museum-masquerade": {"cases": ["midnight-express"], "mediums": 10},
    "detective-exam": {"cases": ["museum-masquerade"], "mediums": 0},
}
for _c in CASES:
    if _c["id"] in UNLOCKS:
        _c["requires"] = UNLOCKS[_c["id"]]

# XP = a base for the tier + a bonus for the code the trainee actually writes
# (solution lines that are not already in the starter). Computed by build_game.py.
XP_BASE = {"tutorial": 20, "small": 40, "medium": 80, "big": 200, "exam": 250, "capstone": 300}
XP_PER_LINE = 4

# ----------------------------------------------------------------------
# Day 1 is split into three chapters. Each skill belongs to one chapter;
# a case belongs to the chapter of its latest skill. Each chapter ends with
# its murder mystery (and chapter 3 with the exam and the field operation).
# ----------------------------------------------------------------------
CHAPTERS = [
    {"id": "rookie", "title": "Street Rookie", "number": 1,
     "tagline": "Python basics: values, text, decisions, lists, records, functions and errors.",
     "skills": ["orientation", "field-notes", "text", "logic", "lists", "records", "functions", "errors", "toolkit"],
     "finale": "grand-library-murder"},
    {"id": "detective", "title": "Detective", "number": 2,
     "tagline": "Pythonic tools: identity, text forensics, collections, functions as values, decorators, generators.",
     "skills": ["identity", "forensic-text", "collections", "function-craft", "functional", "decorators", "streams"],
     "finale": "midnight-express"},
    {"id": "inspector", "title": "Inspector", "number": 3,
     "tagline": "Modelling the world: classes, inheritance, dunders and dataclasses.",
     "skills": ["classes", "inheritance", "dunders", "dataclasses", "project"],
     "finale": "museum-masquerade"},
]

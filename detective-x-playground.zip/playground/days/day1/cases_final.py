"""Detective X — the Day 1 finale: the Detective Exam and the BookVault field operation (Q21).

These cases have no code steps:
  - tier "exam": a `quiz` (multiple choice) with a `pass_mark`.
  - tier "capstone": `local` cards (run on your own machine) and a `checklist` the trainee ticks off.
"""
from . import lessons as _L

_by_id = {l["id"]: l for l in _L.LESSONS}
_ALL_SKILLS = [
    "orientation", "field-notes", "text", "logic", "lists", "records", "functions", "errors", "toolkit",
    "identity", "forensic-text", "collections", "function-craft", "functional", "decorators", "streams",
    "classes", "inheritance", "dunders", "dataclasses", "project",
]

_EXTRA_QUESTIONS = [
    {
        "q": "`a = [1, 2]` and `b = [1, 2]`. What do `a == b` and `a is b` give?",
        "options": ["True, True", "True, False", "False, False", "False, True"],
        "answer": 1,
        "why": "Equal values, but two different list objects. Use `is` only for `None` and other singletons.",
    },
    {
        "q": "Why is `def add(note, notebook=[])` a bug?",
        "options": [
            "Lists can't be default values",
            "The default list is created once and shared by every call",
            "It makes the function slower",
            "Python forbids two parameters",
        ],
        "answer": 1,
        "why": "Defaults are evaluated when `def` runs. Use `None` and create the list inside the function.",
    },
    {
        "q": "You wrote `__eq__` on a class. What must you also write so instances work in sets?",
        "options": ["`__repr__`", "`__hash__`", "`__len__`", "`__init__`"],
        "answer": 1,
        "why": "Defining `__eq__` sets `__hash__` to None. Equal objects must have equal hashes.",
    },
    {
        "q": "Why does a module end with `if __name__ == \"__main__\": main()`?",
        "options": [
            "It makes the program run faster",
            "So `main()` runs when the file is run directly, but not when another file imports it",
            "Python refuses to run files without it",
            "It hides `main()` from other modules",
        ],
        "answer": 1,
        "why": "`__name__` is `\"__main__\"` only for the file being run. Imports (from tests or other modules) stay silent.",
    },
]

CASES = [
    {
        "id": "detective-exam",
        "tier": "exam",
        "title": "The Detective Exam",
        "teaser": "Thirteen questions stand between you and your detective's badge.",
        "skills": _ALL_SKILLS,
        "story": _by_id["recap"]["idea"],
        "suspects": [{"name": "you", "note": "Ready for promotion?"}],
        "quiz": _by_id["knowledge-check"]["quiz"] + _EXTRA_QUESTIONS,
        "pass_mark": 10,
        "closing": "Exam passed. The Chief pins the detective's badge on your coat: *\"The street division is yours. Watch out for chalk marks.\"*",
    },
    {
        "id": "undercover-bookvault",
        "tier": "capstone",
        "title": "Undercover at BookVault",
        "teaser": "Build the library's system from the inside. X has been hiding messages in it.",
        "skills": _ALL_SKILLS,
        "story": "The chalk X keeps appearing near libraries. The Chief has arranged a cover job for you: **you are the new developer at BookVault**, a small library. Build their catalogue system, and keep your eyes open.\n\nThis is a field operation on your own computer: a real Python package with several files and a command-line tool. Every skill from the Academy goes into it. It is also the official **assignment Q21**, and Day 2 builds on exactly this project, so keep it clean.\n\n**Requirements**\n- `items.py`: `LibraryItem` ABC + `Book`, `AudioBook`, `Magazine`, using dataclasses where they fit.\n- `members.py`: `Member` (frozen dataclass) and `Loan`.\n- `library.py`: `Library` with `__len__`, `__iter__`, `__contains__`, `__getitem__`, `__repr__`, `__str__`, `__call__`.\n- `exceptions.py`: `BookVaultError` + `ItemNotFoundError`, `ItemUnavailableError`, `UnknownMemberError`.\n- `cli.py`: loads `books.json` and supports list, search, borrow, return and overdue, using `argparse` or `match / case`.\n\nNo pytest yet: plain asserts and `main()` demos. Tick each item below when it really works, then file your report.",
        "suspects": [{"name": "X", "note": "Somewhere in the stacks."}],
        "local": _by_id["deliverable"]["local"],
        "checklist": [
            "The package layout exists, including `data/books.json` in the sample format (each record has a `\"type\"` field), and `uv pip install -e .` (or `pip install -e .`) works inside a venv",
            "`items.py`: the LibraryItem ABC and three subclasses (dataclasses where appropriate), each with its own `describe()`",
            "`members.py`: a frozen `Member` dataclass and a `Loan` dataclass",
            "`library.py`: `len`, `for`, `in`, `[]`, `print` and calling the library all work",
            "`exceptions.py`: four custom exceptions, raised with helpful messages",
            "`python -m bookvault.cli list` and `search` print the catalogue",
            "`borrow`, `return` and `overdue` work, and bad input gives a clear error instead of a traceback",
            "No `# TODO` comments left anywhere",
        ],
        "closing": "Report filed. BookVault runs on your code now, and in its logs you notice a borrower ID that is just the letter **X**. Day 2 starts here: the Forensics Lab will teach you to debug, test and speed up this exact system.",
    },
]

"""Detective X: the three big murder mysteries of Day 1.

Same format as game.CASES. Each step runs against every evidence
variant, and every variant has a different murderer, so only code that
reasons from the evidence passes. Steps are independent: when a step needs a
helper from an earlier step, its starter already contains it.
"""

ALL_SKILLS = [
    "orientation", "field-notes", "text", "logic", "lists", "records", "functions",
    "errors", "toolkit", "identity", "forensic-text", "collections", "function-craft",
    "functional", "decorators", "streams", "classes", "inheritance", "dunders", "dataclasses",
]

# ======================================================================
# 1. Murder at the Grand Library
# ======================================================================

_LIB_IN_WINDOW = '''def people_in_window():
    start, end = death_window
    found = []
    for entry in wing_log:
        if entry["time"] >= start and entry["time"] <= end:
            if entry["name"] not in found:
                found.append(entry["name"])
    return found


def is_liar(name):
    wing_names = []
    for entry in wing_log:
        wing_names.append(entry["name"])
    text = statements.get(name, "").strip().lower()
    return "never entered the wing" in text and name in wing_names


def has_alibi(name):
    try:
        partner = alibis[name]
        return alibis[partner] == name
    except KeyError:
        return False
'''

GRAND_LIBRARY = {
    "id": "grand-library-murder",
    "tier": "big",
    "title": "Murder at the Grand Library",
    "teaser": "The head librarian is found dead in the locked rare-books wing. Six people were still around.",
    "skills": ["orientation", "field-notes", "text", "logic", "lists", "records", "functions", "errors", "toolkit"],
    "story": (
        "The Grand Library again. This morning the cleaners found **Mrs. Sushila Menon**, the head librarian, "
        "dead in the rare-books wing. The wing was locked from the inside, and only a staff badge opens its door.\n\n"
        "The evidence locker holds everything the Bureau collected:\n"
        "- `guestbook`: everyone who signed in, with `\"in\"` and `\"out\"` times. `\"out\"` is `None` if they never signed out.\n"
        "- `wing_log`: every badge that opened the rare-books door, in time order.\n"
        "- `death_window`: the coroner's window for the time of death, as a tuple `(start, end)`.\n"
        "- `statements`: what each person told the police, typed up exactly as they said it.\n"
        "- `alibis`: who each person says they were **with** at the time of death.\n"
        "- `diary`: the victim's diary, as `(date, name, note)` tuples, and `tonight`, the date of the murder.\n\n"
        "All times are text like `\"21:05\"`, always with two digits. That means you can compare them directly: "
        "`\"21:05\" < \"21:30\"` is `True`."
    ),
    "suspects": [
        {"name": "Arjun Mehta", "note": "A regular reader. Owes the library a lot in fines."},
        {"name": "Clara Novak", "note": "Visiting scholar who wanted the rare maps."},
        {"name": "Dev Iyer", "note": "The archivist. Has a staff badge."},
        {"name": "Fatima Sheikh", "note": "Night cleaner. Has a staff badge."},
        {"name": "Hugo Laurent", "note": "A wealthy donor with a temper."},
        {"name": "Priya Nair", "note": "Assistant librarian. Locks up every night."},
    ],
    "variants": [
        '''from datetime import date

closing_time = "20:00"
death_window = ("21:00", "22:00")
tonight = date(2026, 3, 14)

guestbook = [
    {"name": "Arjun Mehta", "in": "17:10", "out": "19:45"},
    {"name": "Clara Novak", "in": "18:00", "out": None},
    {"name": "Dev Iyer", "in": "16:30", "out": "22:40"},
    {"name": "Fatima Sheikh", "in": "19:00", "out": "23:00"},
    {"name": "Hugo Laurent", "in": "18:20", "out": "21:50"},
    {"name": "Priya Nair", "in": "09:00", "out": "20:00"},
]

wing_log = [
    {"time": "19:20", "name": "Priya Nair"},
    {"time": "20:35", "name": "Hugo Laurent"},
    {"time": "21:10", "name": "Clara Novak"},
    {"time": "21:25", "name": "Dev Iyer"},
    {"time": "21:40", "name": "Fatima Sheikh"},
    {"time": "22:15", "name": "Hugo Laurent"},
]

statements = {
    "Arjun Mehta": "I left before closing, I swear.",
    "Clara Novak": "  I NEVER entered the wing tonight.  ",
    "Dev Iyer": "I never entered the wing. I was cataloguing in the basement.",
    "Fatima Sheikh": "I cleaned the wing at about half past nine.",
    "Hugo Laurent": "I Never Entered The Wing after dinner.",
    "Priya Nair": "I locked up the front desk at eight.",
}

alibis = {
    "Clara Novak": "Hugo Laurent",
    "Hugo Laurent": "Clara Novak",
    "Fatima Sheikh": "Dev Iyer",
    "Dev Iyer": "Arjun Mehta",
}

diary = [
    (date(2026, 2, 20), "Arjun Mehta", "argued about overdue fines"),
    (date(2026, 3, 8), "Dev Iyer", "refused his request for a pay rise"),
    (date(2026, 3, 12), "Clara Novak", "denied her access to the rare maps"),
    (date(2026, 3, 1), "Hugo Laurent", "turned down his donation"),
]
''',
        '''from datetime import date

closing_time = "20:00"
death_window = ("20:30", "21:30")
tonight = date(2026, 5, 2)

guestbook = [
    {"name": "Arjun Mehta", "in": "17:00", "out": None},
    {"name": "Clara Novak", "in": "18:30", "out": "22:10"},
    {"name": "Dev Iyer", "in": "08:45", "out": "19:30"},
    {"name": "Fatima Sheikh", "in": "19:00", "out": "22:30"},
    {"name": "Hugo Laurent", "in": "18:00", "out": "20:45"},
    {"name": "Priya Nair", "in": "09:00", "out": "21:15"},
]

wing_log = [
    {"time": "18:50", "name": "Dev Iyer"},
    {"time": "20:40", "name": "Arjun Mehta"},
    {"time": "20:55", "name": "Clara Novak"},
    {"time": "21:05", "name": "Priya Nair"},
    {"time": "21:20", "name": "Arjun Mehta"},
    {"time": "21:45", "name": "Fatima Sheikh"},
]

statements = {
    "Arjun Mehta": "  I NEVER entered the wing, ask anyone.",
    "Clara Novak": "I never entered the wing. I was in the reading room.",
    "Dev Iyer": "I went home early.",
    "Fatima Sheikh": "I never entered the wing before ten.",
    "Hugo Laurent": "I was in the cafe until it closed.",
    "Priya Nair": "I checked the wing's thermostat around nine.",
}

alibis = {
    "Arjun Mehta": "Hugo Laurent",
    "Hugo Laurent": "Arjun Mehta",
    "Clara Novak": "Priya Nair",
    "Priya Nair": "Dev Iyer",
    "Fatima Sheikh": "Hugo Laurent",
}

diary = [
    (date(2026, 4, 30), "Clara Novak", "caught her tearing a page from an atlas"),
    (date(2026, 4, 10), "Priya Nair", "gave her a warning for lateness"),
    (date(2026, 4, 25), "Arjun Mehta", "argued about a lost book"),
    (date(2026, 4, 24), "Hugo Laurent", "refused to name a reading room after him"),
]
''',
        '''from datetime import date

closing_time = "21:00"
death_window = ("21:30", "22:30")
tonight = date(2026, 9, 19)

guestbook = [
    {"name": "Arjun Mehta", "in": "18:00", "out": "21:40"},
    {"name": "Clara Novak", "in": "17:30", "out": "20:50"},
    {"name": "Dev Iyer", "in": "10:00", "out": None},
    {"name": "Fatima Sheikh", "in": "20:00", "out": "23:30"},
    {"name": "Hugo Laurent", "in": "19:15", "out": None},
    {"name": "Priya Nair", "in": "09:00", "out": "21:05"},
]

wing_log = [
    {"time": "20:10", "name": "Clara Novak"},
    {"time": "21:35", "name": "Dev Iyer"},
    {"time": "21:50", "name": "Hugo Laurent"},
    {"time": "22:05", "name": "Fatima Sheikh"},
    {"time": "22:20", "name": "Dev Iyer"},
    {"time": "22:50", "name": "Arjun Mehta"},
]

statements = {
    "Arjun Mehta": "I never entered the wing until the alarm went off.",
    "Clara Novak": "  I NEVER ENTERED THE WING.  ",
    "Dev Iyer": "I went into the wing twice to fetch maps.",
    "Fatima Sheikh": "I mopped the wing corridor after ten.",
    "Hugo Laurent": "I never entered the wing; I was on the phone in the lobby.",
    "Priya Nair": "I never entered the wing tonight.",
}

alibis = {
    "Dev Iyer": "Arjun Mehta",
    "Arjun Mehta": "Clara Novak",
    "Fatima Sheikh": "Priya Nair",
    "Priya Nair": "Fatima Sheikh",
    "Hugo Laurent": "Dev Iyer",
}

diary = [
    (date(2026, 9, 15), "Hugo Laurent", "exposed his fake donation papers"),
    (date(2026, 9, 2), "Dev Iyer", "argued about the map archive"),
    (date(2026, 9, 18), "Fatima Sheikh", "complained about the cleaning"),
    (date(2026, 8, 30), "Clara Novak", "turned down her research visa letter"),
]
''',
    ],
    "steps": [
        {
            "notes": "**Closing time.** `closing_time` is when the library locks its doors, e.g. `\"20:00\"`.\n\nA guest **stayed late** if either:\n- their `\"out\"` time is `None` (they never signed out), or\n- their `\"out\"` time is **later** than `closing_time`. Signing out exactly at closing time does not count.\n\n**Times** are text like `\"21:05\"`, always with two digits, so comparing them as text gives the right answer: `\"21:05\" > \"20:00\"` is `True`.",
            "question": "**Goal:** find everyone who was still in the library after it closed.\n\n**You have:**\n- `guestbook`, a list of dictionaries, one per guest, e.g. `{\"name\": \"Arjun Mehta\", \"in\": \"17:10\", \"out\": \"19:45\"}`. `\"out\"` can be `None`.\n- `closing_time`, a time as text, e.g. `\"20:00\"`.\n\n**Write** a variable `after_closing` (the starter creates it as an empty list):\n- a list of names (strings), one for each guest who stayed late (see the field notes)\n- in the same order as `guestbook`\n\n**Then** print `after_closing` (the starter already does).\n\n**Example:** with `closing_time = \"20:00\"` and guests `A` (out `\"19:30\"`), `B` (out `None`), `C` (out `\"20:00\"`) and `D` (out `\"21:15\"`), `after_closing` is `[\"B\", \"D\"]`.",
            "starter": "after_closing = []\n# loop over guestbook here\n\nprint(after_closing)\n",
            "solution": 'after_closing = []\nfor guest in guestbook:\n    if guest["out"] is None or guest["out"] > closing_time:\n        after_closing.append(guest["name"])\n\nprint(after_closing)\n',
            "tests": '''_exp = [g["name"] for g in guestbook if g["out"] is None or g["out"] > closing_time]
assert after_closing == _exp, f"after_closing should be {_exp}, got {after_closing}"''',
            "tips": [
                "Each guest is a dictionary, so the sign-out time is `guest[\"out\"]`. Check `is None` **first**: Python cannot compare `None` with text.",
                'Inside `for guest in guestbook:` write `if guest["out"] is None or guest["out"] > closing_time:` and then `after_closing.append(guest["name"])`.',
            ],
            "reveal": "These people were still inside when the doors were locked. The murderer is one of them.",
        },
        {
            "notes": "**Death window.** `death_window` is a tuple `(start, end)` of two times, e.g. `(\"21:00\", \"22:00\")`. A badge swipe is **in the window** if its time is between `start` and `end`, **both included**: a swipe at exactly `start` or exactly `end` counts.\n\nTimes are two-digit text, so `>=` and `<=` compare them correctly.",
            "question": "**Goal:** find whose badge opened the rare-books wing while the victim was dying.\n\n**You have:**\n- `death_window`, a tuple `(start, end)`, e.g. `(\"21:00\", \"22:00\")`.\n- `wing_log`, a list of dictionaries in time order, e.g. `{\"time\": \"21:10\", \"name\": \"Clara Novak\"}`. The same person can appear more than once.\n\n**Write:**\n- `start` and `end`: unpack `death_window` into them with `start, end = death_window` (already in the starter).\n- `in_window`: a list of the names whose badge opened the wing in the window (see the field notes).\n- keep the order of `wing_log`.\n- list each name **once**, even if it swiped several times in the window.\n\n**Then** print them (the starter already does).\n\n**Example:** with window `(\"10:00\", \"11:00\")` and swipes `A` at `\"09:50\"`, `B` at `\"10:00\"`, `C` at `\"10:30\"`, `B` at `\"10:45\"` and `D` at `\"11:05\"`, `in_window` is `[\"B\", \"C\"]`.",
            "starter": "start, end = death_window\nin_window = []\n# loop over wing_log here\n\nprint(start, \"to\", end, in_window)\n",
            "solution": 'start, end = death_window\nin_window = []\nfor entry in wing_log:\n    if entry["time"] >= start and entry["time"] <= end:\n        if entry["name"] not in in_window:\n            in_window.append(entry["name"])\n\nprint(start, "to", end, in_window)\n',
            "tests": '''_s, _e = death_window
_exp = []
for _x in wing_log:
    if _s <= _x["time"] <= _e and _x["name"] not in _exp:
        _exp.append(_x["name"])
assert (start, end) == death_window, "start and end should come from death_window"
assert in_window == _exp, f"in_window should be {_exp}, got {in_window}"''',
            "tips": [
                "Times are text with two digits, so `entry[\"time\"] >= start and entry[\"time\"] <= end` works.",
                'Only append when `entry["name"] not in in_window`, so nobody is listed twice.',
            ],
            "reveal": "Several badges opened the wing while Mrs. Menon was dying. Being there is not a crime. Lying about it is suspicious.",
        },
        {
            "notes": "**What counts as a denial.** A statement **denies the wing** if, after cleaning it (remove spaces at both ends, then make it all lower case), it contains the exact words `never entered the wing`. Only this text check counts, so `\"I never entered the wing before ten.\"` is a denial too.\n\n**What counts as a liar.** A person is a liar if their statement denies the wing **and** their name appears **anywhere** in `wing_log`, at any time (not only during the death window).",
            "question": "**Goal:** catch the people who say they never went into the wing, although their badge did.\n\n**You have:**\n- `statements`, a dictionary from name to what they said, e.g. `{\"Clara Novak\": \"  I NEVER entered the wing tonight.  \"}`.\n- `wing_log`, as in step 2. The starter already builds `wing_names`, the list of every name in `wing_log`.\n\n**Write** a variable `liars`:\n- a list of the names (strings) of the liars (see the field notes)\n- in the same order as the keys of `statements`\n- someone whose statement does not deny the wing is never a liar, even if they were in the wing\n\n**Then** print `liars` (the starter already does).\n\n**Example:** with `statements = {\"A\": \" I NEVER Entered The Wing \", \"B\": \"I never entered the wing.\", \"C\": \"I was in the wing.\"}` and `wing_names = [\"A\", \"C\"]`, `liars` is `[\"A\"]`: B denies but never swiped, C swiped but did not deny.",
            "starter": "wing_names = []\nfor entry in wing_log:\n    wing_names.append(entry[\"name\"])\n\nliars = []\n# loop over statements.items() here\n\nprint(liars)\n",
            "solution": 'wing_names = []\nfor entry in wing_log:\n    wing_names.append(entry["name"])\n\nliars = []\nfor name, text in statements.items():\n    clean = text.strip().lower()\n    if "never entered the wing" in clean and name in wing_names:\n        liars.append(name)\n\nprint(liars)\n',
            "tests": '''_names = [_x["name"] for _x in wing_log]
_exp = [n for n, t in statements.items() if "never entered the wing" in t.strip().lower() and n in _names]
assert liars == _exp, f"liars should be {_exp}, got {liars}"''',
            "tips": [
                "Clean each statement first with `text.strip().lower()`, so `\"NEVER Entered\"` and `\"never entered\"` look the same.",
                'Loop with `for name, text in statements.items():` and append when `"never entered the wing" in clean and name in wing_names`.',
            ],
            "reveal": "The badge reader says otherwise. Somebody here is not telling the truth.",
        },
        {
            "notes": "**The last week** means from 7 days before `tonight` up to `tonight`, **both days included**. If `tonight` is 14 March, that is 7 March to 14 March.\n\nThe diary entries are **not** in date order.",
            "question": "**Goal:** find who clashed with the victim during the last week.\n\n**You have:**\n- `tonight`, the date of the murder, a `date` such as `date(2026, 3, 14)`.\n- `diary`, a list of tuples `(date, name, note)`, e.g. `(date(2026, 3, 8), \"Dev Iyer\", \"refused his request for a pay rise\")`.\n- The starter already imports `timedelta` from `datetime`.\n\n**Write:**\n- `week_ago`: the date 7 days before `tonight`, computed as `tonight - timedelta(days=7)`.\n- `recent`: a list of the **names** (not the whole tuples) of the diary entries dated from `week_ago` to `tonight`, both included (see the field notes).\n- keep the order of `diary` (do not sort).\n\n**Then** print them (the starter already does).\n\n**Example:** with `tonight = date(2026, 1, 10)`, `week_ago` is `date(2026, 1, 3)`. Diary entries dated 2 Jan (`\"A\"`), 9 Jan (`\"B\"`) and 3 Jan (`\"C\"`), in that order, give `recent == [\"B\", \"C\"]`.",
            "starter": "from datetime import timedelta\n\nweek_ago = ...\nrecent = []\n# loop over diary here\n\nprint(week_ago, recent)\n",
            "solution": "from datetime import timedelta\n\nweek_ago = tonight - timedelta(days=7)\nrecent = []\nfor when, name, note in diary:\n    if when >= week_ago and when <= tonight:\n        recent.append(name)\n\nprint(week_ago, recent)\n",
            "tests": '''from datetime import timedelta as _td
_wa = tonight - _td(days=7)
assert week_ago == _wa, f"week_ago should be {_wa}, got {week_ago!r}"
_exp = [n for d, n, _note in diary if _wa <= d <= tonight]
assert recent == _exp, f"recent should be {_exp}, got {recent}"''',
            "tips": [
                "Each diary entry is a tuple of three values. Unpack it in the loop: `for when, name, note in diary:`.",
                "Dates compare like numbers: `if when >= week_ago and when <= tonight:` then `recent.append(name)`.",
            ],
            "reveal": "A motive or two, written in the victim's own hand. Now let's see who can prove where they were.",
        },
        {
            "notes": "**What counts as an alibi.** `alibis[name]` is the person that `name` says they were with. An alibi is **confirmed** only if that partner says the same thing back: if A says they were with B, then B must say they were with A.\n- A says B, and B says A: both have a confirmed alibi.\n- A says B, but B says C: A's alibi is not confirmed.\n- A says B, but B is not in `alibis`: not confirmed.\n- A is not in `alibis` at all: no alibi.",
            "question": "**Goal:** check which alibis really hold up.\n\n**You have:** `alibis`, a dictionary from a person's name to the name of the person they say they were with, e.g. `{\"Clara Novak\": \"Hugo Laurent\", \"Hugo Laurent\": \"Clara Novak\", \"Dev Iyer\": \"Arjun Mehta\"}`. Not everyone is in it.\n\n**Write** a function `has_alibi(name)`:\n- `name` is a person's name (a string).\n- It returns `True` if their alibi is confirmed (see the field notes), otherwise `False`.\n- Look up the partner with `alibis[name]`, then check whether `alibis[partner] == name`.\n- Either lookup raises `KeyError` when a name is missing. Catch it with `try` / `except KeyError` and return `False`; the function must never crash.\n\n**Then** the starter prints `has_alibi` for every guest in `guestbook`; leave that as it is.\n\n**Example:** with the `alibis` above, `has_alibi(\"Clara Novak\")` is `True`, `has_alibi(\"Dev Iyer\")` is `False` (Arjun Mehta is not in `alibis`), and `has_alibi(\"Priya Nair\")` is `False` (she is not in it at all).",
            "starter": "def has_alibi(name):\n    ...  # your code here\n\nfor guest in guestbook:\n    print(guest[\"name\"], has_alibi(guest[\"name\"]))\n",
            "solution": 'def has_alibi(name):\n    try:\n        partner = alibis[name]\n        return alibis[partner] == name\n    except KeyError:\n        return False\n\nfor guest in guestbook:\n    print(guest["name"], has_alibi(guest["name"]))\n',
            "tests": '''for _g in guestbook:
    _n = _g["name"]
    _p = alibis.get(_n)
    _exp = _p is not None and alibis.get(_p) == _n
    _got = has_alibi(_n)
    assert _got == _exp, f"has_alibi({_n!r}) should be {_exp}, got {_got!r}"''',
            "tips": [
                "Look up the partner with `partner = alibis[name]`, then check what the partner says: `alibis[partner] == name`. Both lookups can fail, so put them inside `try:`.",
                "`try:` → `partner = alibis[name]` and `return alibis[partner] == name`; `except KeyError:` → `return False`.",
            ],
            "reveal": "Some alibis hold up. Others point at someone who says they were somewhere else entirely.",
        },
        {
            "notes": "**Who is the murderer.** The murderer is the **one** person for whom all three are true:\n- their badge opened the wing during the death window\n- they have **no** confirmed alibi\n- they lied about the wing (they denied it, but their badge is in the log)\n\nExactly one person fits on each set of evidence.",
            "question": "**Goal:** name the murderer.\n\n**You have:** the helpers from earlier steps, already written in the starter:\n- `people_in_window()` returns the list of names whose badge opened the wing during the death window (step 2).\n- `is_liar(name)` returns `True` if that person lied about the wing (step 3).\n- `has_alibi(name)` returns `True` if their alibi is confirmed (step 5).\n\n**Write** a variable `culprit`:\n- a string: the name of the person who fits all three rules in the field notes\n- check each name from `people_in_window()` with the two other functions\n\n**Then** print the accusation: the starter's last line already prints `culprit`, so keep it.\n\n**Example:** if `people_in_window()` gives `[\"A\", \"B\", \"C\"]`, A has a confirmed alibi, B has none but told the truth, and C has none and lied, then `culprit` is `\"C\"`.",
            "starter": _LIB_IN_WINDOW + "\nculprit = None\n# check everyone in people_in_window() here\n\nprint(\"The murderer is\", culprit)\n",
            "solution": _LIB_IN_WINDOW + "\nculprit = None\nfor name in people_in_window():\n    if not has_alibi(name) and is_liar(name):\n        culprit = name\n\nprint(\"The murderer is\", culprit)\n",
            "tests": '''_s, _e = death_window
_inw = []
for _x in wing_log:
    if _s <= _x["time"] <= _e and _x["name"] not in _inw:
        _inw.append(_x["name"])
_names = [_x["name"] for _x in wing_log]
def _liar(n):
    return "never entered the wing" in statements.get(n, "").strip().lower() and n in _names
def _alibi(n):
    _p = alibis.get(n)
    return _p is not None and alibis.get(_p) == n
_exp = [n for n in _inw if not _alibi(n) and _liar(n)]
assert culprit is not None, "culprit is still None: loop over people_in_window() and test each name"
assert culprit == _exp[0], "wrong person. The murderer was in the wing during the window, has no confirmed alibi AND lied about the wing. All three must be true."
assert str(culprit) in __output__, "print your accusation"''',
            "tips": [
                "Loop over `people_in_window()` and combine the two checks with `and`: `not has_alibi(name) and is_liar(name)`.",
                "`for name in people_in_window():` → `if not has_alibi(name) and is_liar(name):` → `culprit = name`.",
            ],
            "reveal": "In the wing at the fatal hour, no one to vouch for them, and a lie on the record. The handcuffs click. Under the victim's desk, the lab finds another chalk **X**.",
        },
    ],
    "closing": "Case closed. Faced with the badge log and a one-sided alibi, the murderer confessed: Mrs. Menon had found out about the stolen folio's buyer, and they panicked. But nobody can explain the chalk **X** under the desk. It was drawn with the left hand again, and this time a small letter **V** is scratched beside it.",
    "fragment": "A second chalk X, under the librarian's desk, with the letter V scratched beside it.",
}

# ======================================================================
# 2. The Midnight Express
# ======================================================================

_NIGHT = '''def night_minutes(t):
    # the train leaves at 22:00, so hours before noon belong to the next day
    h, m = t.split(":")
    h, m = int(h), int(m)
    if h < 12:
        h += 24
    return h * 60 + m
'''

_TIMELINE = _NIGHT + '''

entries = []
for line in messages:
    time, car, person, action = line.split("|")
    entries.append((time, car, person, action))
timeline = sorted(entries, key=lambda e: night_minutes(e[0]))
'''

_EVENTS_IN = '''

def events_in(car):
    for time, where, person, action in timeline:
        if where == car:
            yield (time, person, action)
'''

_CLASSIFY = '''

def classify(action):
    match action.split():
        case ["entered"] | ["left"]:
            return "movement"
        case ["ordered" | "made" | "served", _]:
            return "service"
        case ["argued", "with", *_]:
            return "quarrel"
        case _:
            return "other"
'''

_TRAIN_TEST_HELPERS = '''def _nm(t):
    _h, _m = t.split(":")
    _h, _m = int(_h), int(_m)
    if _h < 12:
        _h += 24
    return _h * 60 + _m
_tl = sorted([tuple(_l.split("|")) for _l in messages], key=lambda e: _nm(e[0]))
'''

MIDNIGHT_EXPRESS = {
    "id": "midnight-express",
    "tier": "big",
    "title": "The Midnight Express",
    "teaser": "A passenger is poisoned on the overnight train. The answer is hidden in a pile of scrambled messages.",
    "skills": ["orientation", "field-notes", "text", "logic", "lists", "records", "functions", "errors",
               "toolkit", "identity", "forensic-text", "collections", "function-craft", "functional",
               "decorators", "streams"],
    "story": (
        "The overnight express left the city at 22:00. Somewhere after midnight, a passenger (the `victim`) "
        "drank a cup of tea and collapsed. The doctor on board says: poison, added to the tea.\n\n"
        "The railway's staff app sends a short message for every event, but the messages arrived **scrambled**. "
        "Each one looks like `\"00:14|car 3|Mr. Bose|entered\"`: time, car, person and what happened, separated by `|`.\n\n"
        "You also have the ticket `manifest` (which car each person is booked in) and the `conductor_log`, "
        "which records when the victim's tea was **made** in the dining car and when it was **served**.\n\n"
        "Careful: the train runs through midnight, so `\"00:05\"` comes **after** `\"23:55\"`."
    ),
    "suspects": [
        {"name": "Mr. Bose", "note": "Businessman. Loud, and owes money to half the train."},
        {"name": "Ms. Tan", "note": "Journalist working on a story about a fraud."},
        {"name": "Dr. Okafor", "note": "The doctor on board. Has a medical bag."},
        {"name": "Mr. Silva", "note": "Retired chemist travelling alone."},
        {"name": "Miss Rao", "note": "Student heading home for the holidays."},
        {"name": "Waiter Gomes", "note": "Made and served the tea."},
    ],
    "variants": [
        '''victim = "Mrs. Kapoor"

manifest = {
    "Mrs. Kapoor": "car 3",
    "Mr. Bose": "car 2",
    "Ms. Tan": "car 3",
    "Dr. Okafor": "car 4",
    "Mr. Silva": "car 2",
    "Waiter Gomes": "crew",
}

conductor_log = {"tea made": "23:55", "tea served": "00:10"}

messages = [
    "00:10|car 3|Waiter Gomes|served tea",
    "23:20|car 3|Mr. Bose|argued with Mrs. Kapoor",
    "23:58|dining car|Mr. Bose|entered",
    "23:40|car 3|Mrs. Kapoor|ordered tea",
    "00:05|dining car|Ms. Tan|entered",
    "23:55|dining car|Waiter Gomes|made tea",
    "00:02|dining car|Mr. Bose|left",
    "23:30|car 3|Dr. Okafor|argued with Mrs. Kapoor",
    "23:45|dining car|Dr. Okafor|entered",
    "23:50|dining car|Dr. Okafor|left",
    "00:30|dining car|Mr. Silva|entered",
    "00:20|car 3|Mrs. Kapoor|collapsed",
    "22:50|dining car|Mr. Bose|entered",
    "23:05|dining car|Mr. Bose|left",
    "23:35|car 2|Mr. Silva|argued with Mr. Bose",
]
''',
        '''victim = "Mr. Silva"

manifest = {
    "Mr. Silva": "car 2",
    "Mr. Bose": "car 2",
    "Ms. Tan": "car 3",
    "Dr. Okafor": "car 4",
    "Miss Rao": "car 4",
    "Waiter Gomes": "crew",
}

conductor_log = {"tea made": "01:20", "tea served": "01:35"}

messages = [
    "01:35|car 2|Waiter Gomes|served tea",
    "00:50|car 2|Mr. Silva|ordered tea",
    "01:20|dining car|Waiter Gomes|made tea",
    "01:22|dining car|Dr. Okafor|entered",
    "01:25|dining car|Ms. Tan|entered",
    "01:31|dining car|Ms. Tan|left",
    "01:40|dining car|Dr. Okafor|left",
    "00:15|car 2|Ms. Tan|argued with Mr. Silva",
    "23:50|car 2|Mr. Bose|argued with Mr. Silva",
    "01:10|dining car|Mr. Bose|entered",
    "01:18|dining car|Mr. Bose|left",
    "23:30|dining car|Dr. Okafor|entered",
    "23:59|dining car|Dr. Okafor|left",
    "00:20|dining car|Dr. Okafor|entered",
    "01:50|car 2|Mr. Silva|collapsed",
]
''',
        '''victim = "Miss Rao"

manifest = {
    "Miss Rao": "car 4",
    "Mr. Bose": "car 2",
    "Ms. Tan": "car 3",
    "Dr. Okafor": "car 4",
    "Mr. Silva": "car 2",
    "Waiter Gomes": "crew",
}

conductor_log = {"tea made": "00:40", "tea served": "00:52"}

messages = [
    "00:52|car 4|Waiter Gomes|served tea",
    "00:30|car 4|Miss Rao|ordered tea",
    "00:40|dining car|Waiter Gomes|made tea",
    "00:44|dining car|Dr. Okafor|entered",
    "00:47|dining car|Dr. Okafor|left",
    "00:45|dining car|Mr. Silva|entered",
    "23:10|car 4|Dr. Okafor|argued with Miss Rao",
    "23:40|car 4|Ms. Tan|argued with Miss Rao",
    "00:20|dining car|Ms. Tan|entered",
    "00:35|dining car|Ms. Tan|left",
    "23:15|dining car|Ms. Tan|entered",
    "23:50|dining car|Ms. Tan|entered",
    "22:40|dining car|Mr. Silva|entered",
    "01:05|car 4|Miss Rao|collapsed",
    "00:58|car 4|Mr. Bose|asked for a blanket",
]
''',
    ],
    "steps": [
        {
            "notes": "**The overnight clock.** The train leaves at 22:00 and every event happens between 22:00 and the next morning. So `\"00:05\"` comes **after** `\"23:55\"`.\n\nTo put times in order, turn each one into minutes, and treat any hour **before 12** as the next day by adding 24 to the hour:\n- minutes = hour × 60 + minute\n- `\"23:55\"` → 23 × 60 + 55 = **1435**\n- `\"00:05\"` → hour 0 + 24 = 24, so 24 × 60 + 5 = **1445**\n\n**Messages** look like `\"00:14|car 3|Mr. Bose|entered\"`: time, car, person and action, separated by `|`.",
            "question": "**Goal:** put the scrambled messages back in the order they happened.\n\n**You have:** `messages`, a list of strings in random order, e.g. `[\"00:10|car 3|Waiter Gomes|served tea\", \"23:20|car 3|Mr. Bose|argued with Mrs. Kapoor\"]`.\n\n**Write** a function `night_minutes(t)`:\n- `t` is a time as text, `\"HH:MM\"`.\n- It returns a whole number (`int`) of minutes, counted as in the field notes.\n\n**Write** a variable `timeline`:\n- split every line of `messages` on `\"|\"` into a tuple of 4 strings `(time, car, person, action)`, and collect the tuples in the list `entries`\n- `timeline` is a **list** of those tuples, sorted by `night_minutes` of the time: `sorted(entries, key=lambda ...)`\n- sorting the plain text instead would put the after-midnight events first, which is wrong\n\n**Then** the starter prints the timeline; leave that as it is.\n\n**Example:** `night_minutes(\"23:55\")` is `1435`, `night_minutes(\"00:05\")` is `1445` and `night_minutes(\"11:59\")` is `2159`. The messages `[\"00:05|car 1|A|left\", \"23:55|car 1|A|entered\"]` give `timeline == [(\"23:55\", \"car 1\", \"A\", \"entered\"), (\"00:05\", \"car 1\", \"A\", \"left\")]`.",
            "starter": "def night_minutes(t):\n    ...  # \"23:55\" -> 1435, \"00:05\" -> 1445\n\n\nentries = []\n# split each line of messages and append a tuple here\n\ntimeline = []   # replace with sorted(...)\n\nfor e in timeline:\n    print(e[0], e[2], e[3])\n",
            "solution": _TIMELINE + "\nfor e in timeline:\n    print(e[0], e[2], e[3])\n",
            "tests": _TRAIN_TEST_HELPERS + '''assert night_minutes("23:55") == 23 * 60 + 55, "night_minutes('23:55') should be 1435"
assert night_minutes("00:05") == 24 * 60 + 5, "night_minutes('00:05') should be 1445: hours before 12 belong to the next day"
assert night_minutes("11:59") > night_minutes("22:00"), "11:59 in the morning comes after 22:00 the night before"
assert isinstance(timeline, list), "timeline should be a list: sorted(...) gives you one"
_naive = sorted([tuple(_l.split("|")) for _l in messages])
if timeline == _naive and _naive != _tl:
    raise AssertionError("close: you sorted the times as text, so the events after midnight came first. Use key=lambda e: night_minutes(e[0])")
assert timeline == _tl, f"timeline is not right yet. The first event should be {_tl[0]}, and every item a tuple (time, car, person, action)"''',
            "tips": [
                'In `night_minutes`: `h, m = t.split(":")`, convert both with `int()`, `if h < 12: h += 24`, then `return h * 60 + m`.',
                'Split with `time, car, person, action = line.split("|")` and append the tuple. Then `timeline = sorted(entries, key=lambda e: night_minutes(e[0]))`.',
            ],
            "reveal": "The night is back in order. The victim ordered tea, it was made in the dining car, it was served, and then they collapsed.",
        },
        {
            "question": "**Goal:** see everything that happened in one car, especially the victim's.\n\n**You have:**\n- `timeline` and `night_minutes`, already built in the starter (step 1). Each item of `timeline` is `(time, car, person, action)`, in the order things happened.\n- `victim`, the victim's name, e.g. `\"Mrs. Kapoor\"`.\n- `manifest`, a dictionary from each person's name to the car they are booked in, e.g. `{\"Mrs. Kapoor\": \"car 3\", \"Waiter Gomes\": \"crew\"}`.\n\n**Write** a generator function `events_in(car)`:\n- `car` is a car name, e.g. `\"dining car\"`.\n- It must use `yield` (not build and `return` a list), so calling it gives a generator.\n- For every event in `timeline` whose car equals `car`, in timeline order, it yields the tuple `(time, person, action)` (the car is left out).\n\n**Then** store:\n- `victim_car`: the victim's car, looked up in `manifest`\n- `victim_car_events`: `list(events_in(victim_car))`\n\n**Example:** if `timeline` is `[(\"23:00\", \"car 1\", \"A\", \"entered\"), (\"23:10\", \"car 2\", \"B\", \"left\"), (\"23:20\", \"car 1\", \"C\", \"made tea\")]`, then `list(events_in(\"car 1\"))` is `[(\"23:00\", \"A\", \"entered\"), (\"23:20\", \"C\", \"made tea\")]`.",
            "starter": _TIMELINE + "\n\ndef events_in(car):\n    ...  # yield (time, person, action) for every event in this car\n\nvictim_car = None\nvictim_car_events = []\n\nfor event in victim_car_events:\n    print(event)\n",
            "solution": _TIMELINE + _EVENTS_IN + "\nvictim_car = manifest[victim]\nvictim_car_events = list(events_in(victim_car))\n\nfor event in victim_car_events:\n    print(event)\n",
            "tests": _TRAIN_TEST_HELPERS + '''_g = events_in("dining car")
assert _g is not None and iter(_g) is _g, "events_in should be a generator: use yield inside it, not return"
assert victim_car == manifest[victim], f"victim_car should be {manifest[victim]!r}, got {victim_car!r}"
for _car in set(e[1] for e in _tl):
    _exp = [(e[0], e[2], e[3]) for e in _tl if e[1] == _car]
    _got = list(events_in(_car))
    assert _got == _exp, f"events_in({_car!r}) gave {_got}, expected {_exp}"
_exp = [(e[0], e[2], e[3]) for e in _tl if e[1] == manifest[victim]]
assert victim_car_events == _exp, f"victim_car_events should be {_exp}"''',
            "tips": [
                "A generator is a function with `yield` instead of `return`. Loop with `for time, where, person, action in timeline:` and only yield when `where == car`.",
                "`yield (time, person, action)` inside the `if`. Then `victim_car = manifest[victim]` and `victim_car_events = list(events_in(victim_car))`.",
            ],
            "reveal": "The victim's car tells a story: an argument or two before the tea arrived.",
        },
        {
            "notes": "A **dining-car visit** is an event whose car is exactly `\"dining car\"` and whose action is exactly `\"entered\"`. Leaving (`\"left\"`) and other actions there, like `\"made tea\"`, are not visits.",
            "question": "**Goal:** find out who kept going to the dining car.\n\n**You have:** `timeline`, already built in the starter (step 1): a list of `(time, car, person, action)` tuples. `Counter` is already imported.\n\n**Write:**\n- `dining_visits`: a `Counter` from each person's name to how many times they entered the dining car (see the field notes). People who never entered it are not in it.\n- `regular`: the name (a string) of the person with the most visits. `dining_visits.most_common(1)` gives a list like `[(\"A\", 3)]`; take the name out of it. If two people tie, use whoever `most_common(1)` gives.\n\n**Then** the starter prints both; leave that.\n\n**Example:** the events `(\"23:00\", \"dining car\", \"A\", \"entered\")`, `(\"23:05\", \"dining car\", \"A\", \"left\")`, `(\"23:10\", \"dining car\", \"B\", \"entered\")` and `(\"23:30\", \"dining car\", \"A\", \"entered\")` give `dining_visits == Counter({\"A\": 2, \"B\": 1})` and `regular == \"A\"`.",
            "starter": "from collections import Counter\n\n" + _TIMELINE + "\ndining_visits = ...\nregular = ...\n\nprint(dining_visits)\nprint(\"Regular:\", regular)\n",
            "solution": "from collections import Counter\n\n" + _TIMELINE + '\ndining_visits = Counter(person for time, car, person, action in timeline if car == "dining car" and action == "entered")\nregular = dining_visits.most_common(1)[0][0]\n\nprint(dining_visits)\nprint("Regular:", regular)\n',
            "tests": _TRAIN_TEST_HELPERS + '''from collections import Counter as _C
_exp = _C(e[2] for e in _tl if e[1] == "dining car" and e[3] == "entered")
assert isinstance(dining_visits, dict), "dining_visits should be a Counter"
assert dict(dining_visits) == dict(_exp), f"dining_visits should be {dict(_exp)}, got {dict(dining_visits)}"
assert regular == _exp.most_common(1)[0][0], f"regular should be {_exp.most_common(1)[0][0]!r}, got {regular!r}"''',
            "tips": [
                "`Counter(...)` can count the names straight from a generator expression: `Counter(person for time, car, person, action in timeline if ...)`.",
                'The condition is `car == "dining car" and action == "entered"`. Then `regular = dining_visits.most_common(1)[0][0]`.',
            ],
            "reveal": "Someone couldn't keep away from the dining car. Hungry, or watching the tea counter?",
        },
        {
            "notes": "**Kinds of action.** Split the action into words, then sort it into one of four kinds:\n- **movement**: exactly the one word `entered` or `left`\n- **service**: exactly two words, the first being `ordered`, `made` or `served` (e.g. `made tea`). A lone `ordered` is not service.\n- **quarrel**: starts with the words `argued with`, followed by anything (e.g. `argued with Mrs. Kapoor`)\n- **other**: everything else (e.g. `collapsed`, `asked for a blanket`)\n\nSomeone **quarrelled with the victim** if their action is a quarrel and the victim's name appears in the action text.",
            "question": "**Goal:** label every event, then list who argued with the victim.\n\n**You have:** `timeline` (step 1, already in the starter) and `victim`, the victim's name, e.g. `\"Mrs. Kapoor\"`.\n\n**Write** a function `classify(action)`:\n- `action` is the action text, e.g. `\"argued with Mrs. Kapoor\"`.\n- It returns one of the strings `\"movement\"`, `\"service\"`, `\"quarrel\"` or `\"other\"`, following the field notes.\n- Use `match action.split():` with one `case` per kind, and `case _:` last for `\"other\"`.\n\n**Write** a variable `victim_quarrels`:\n- the names of everyone who quarrelled with the victim (see the field notes)\n- each name only once, in a list sorted A to Z\n\n**Then** print `victim_quarrels` (the starter already does).\n\n**Example:** `classify(\"left\")` is `\"movement\"`, `classify(\"served tea\")` is `\"service\"`, `classify(\"ordered\")` is `\"other\"` and `classify(\"argued with Mr. X\")` is `\"quarrel\"`. If Z argued with the victim twice and A once, `victim_quarrels` is `[\"A\", \"Z\"]`.",
            "starter": _TIMELINE + "\n\ndef classify(action):\n    match action.split():\n        case _:\n            return \"other\"\n\nvictim_quarrels = ...\n\nprint(victim_quarrels)\n",
            "solution": _TIMELINE + _CLASSIFY + '\nvictim_quarrels = sorted({person for time, car, person, action in timeline if classify(action) == "quarrel" and victim in action})\n\nprint(victim_quarrels)\n',
            "tests": _TRAIN_TEST_HELPERS + '''for _a, _k in [("entered", "movement"), ("left", "movement"), ("ordered tea", "service"),
               ("made tea", "service"), ("served tea", "service"), ("argued with Mr. Nobody", "quarrel"),
               ("collapsed", "other"), ("asked for a blanket", "other"), ("ordered", "other")]:
    assert classify(_a) == _k, f"classify({_a!r}) should be {_k!r}, got {classify(_a)!r}"
_exp = sorted({e[2] for e in _tl if e[3].startswith("argued with") and victim in e[3]})
assert victim_quarrels == _exp, f"victim_quarrels should be {_exp}, got {victim_quarrels}"''',
            "tips": [
                'Patterns can offer choices with `|`: `case ["entered"] | ["left"]:`, `case ["ordered" | "made" | "served", _]:` and `case ["argued", "with", *_]:`.',
                '`victim_quarrels = sorted({person for time, car, person, action in timeline if classify(action) == "quarrel" and victim in action})`.',
            ],
            "reveal": "Two people quarrelled with the victim tonight. A quarrel is a motive, not proof.",
        },
        {
            "question": "**Goal:** keep a record of every procedure the investigation runs.\n\n**You have:** in the starter, `timeline` (step 1), `events_in(car)` (step 2), `classify(action)` (step 4), an empty list `audit_trail`, and `wraps` already imported from `functools`.\n\n**Write** a decorator `audited(fn)`:\n- it returns a new function (a wrapper) that accepts any arguments (`*args, **kwargs`)\n- each time the wrapper is called, it appends `fn.__name__` (a string like `\"classify\"`) to `audit_trail`, then calls `fn` and returns its result unchanged\n- put `@wraps(fn)` on the wrapper, so the decorated function keeps its own `__name__`\n\n**Then:**\n- put `@audited` above `def events_in` and above `def classify`\n- store `kinds`: a list with the `classify` result of each event in the victim's car, in order. Call `events_in(manifest[victim])` **once** and loop over it, calling `classify` once per event.\n- when you are done, `audit_trail` must hold `\"events_in\"` exactly once and `\"classify\"` once per event in the victim's car, so do not call either function anywhere else\n\n**Example:** if the victim's car has 3 events, `kinds` could be `[\"quarrel\", \"service\", \"other\"]` and `audit_trail` is then `[\"events_in\", \"classify\", \"classify\", \"classify\"]`.",
            "starter": "from functools import wraps\n\naudit_trail = []\n\ndef audited(fn):\n    ...  # your code here\n\n" + _TIMELINE + "\n\ndef events_in(car):\n    for time, where, person, action in timeline:\n        if where == car:\n            yield (time, person, action)\n\ndef classify(action):\n    match action.split():\n        case [\"entered\"] | [\"left\"]:\n            return \"movement\"\n        case [\"ordered\" | \"made\" | \"served\", _]:\n            return \"service\"\n        case [\"argued\", \"with\", *_]:\n            return \"quarrel\"\n        case _:\n            return \"other\"\n\nkinds = ...\nprint(kinds)\nprint(audit_trail)\n",
            "solution": "from functools import wraps\n\naudit_trail = []\n\ndef audited(fn):\n    @wraps(fn)\n    def wrapper(*args, **kwargs):\n        audit_trail.append(fn.__name__)\n        return fn(*args, **kwargs)\n    return wrapper\n\n" + _TIMELINE + "\n\n@audited\ndef events_in(car):\n    for time, where, person, action in timeline:\n        if where == car:\n            yield (time, person, action)\n\n@audited\ndef classify(action):\n    match action.split():\n        case [\"entered\"] | [\"left\"]:\n            return \"movement\"\n        case [\"ordered\" | \"made\" | \"served\", _]:\n            return \"service\"\n        case [\"argued\", \"with\", *_]:\n            return \"quarrel\"\n        case _:\n            return \"other\"\n\nkinds = [classify(action) for time, person, action in events_in(manifest[victim])]\nprint(kinds)\nprint(audit_trail)\n",
            "tests": _TRAIN_TEST_HELPERS + '''_vc = [e for e in _tl if e[1] == manifest[victim]]
assert len(kinds) == len(_vc), f"there are {len(_vc)} events in the victim's car, but kinds has {len(kinds)}"
assert audit_trail.count("events_in") == 1, "audit_trail should record events_in once"
assert audit_trail.count("classify") == len(_vc), f"classify ran {len(_vc)} times, but audit_trail recorded it {audit_trail.count('classify')} times"
assert classify.__name__ == "classify", "use @wraps(fn) so the wrapped function keeps its name"
_before = len(audit_trail)
@audited
def _probe(x):
    return x * 2
assert _probe(21) == 42, "the wrapper must return what the original function returns"
assert audit_trail[_before:] == ["_probe"], "each call should append the function's name to audit_trail"''',
            "tips": [
                "Inside `audited`, define `wrapper(*args, **kwargs)` decorated with `@wraps(fn)`, and `return wrapper` at the end.",
                "The wrapper body is two lines: `audit_trail.append(fn.__name__)` and `return fn(*args, **kwargs)`. Put `@audited` above both `def` lines, then `kinds = [classify(action) for time, person, action in events_in(manifest[victim])]`.",
            ],
            "reveal": "Every step of the investigation is now on the record. The defence can't say you skipped anything.",
        },
        {
            "notes": "**How the poison got in.** The tea was made at `conductor_log[\"tea made\"]` and served at `conductor_log[\"tea served\"]`. In between, it stood on the dining-car counter, and that is when the poison went in.\n\nThe poisoner is the person who:\n- had **any** event in the `\"dining car\"` **strictly after** the tea was made and **strictly before** it was served (an event at exactly either time does not count), and\n- quarrelled with the victim (an action that classifies as `\"quarrel\"` and names the victim).\n\nThe window can cross midnight, so compare times with `night_minutes`, not as text. Exactly one person fits.",
            "question": "**Goal:** name the poisoner.\n\n**You have:**\n- in the starter: `timeline` and `night_minutes(t)` (step 1), `events_in(car)` (step 2) and `classify(action)` (step 4)\n- `conductor_log`, a dictionary like `{\"tea made\": \"23:55\", \"tea served\": \"00:10\"}`\n- `victim`, the victim's name\n\n**Write** a variable `culprit`:\n- a string: the name of the one person who fits both rules in the field notes\n- one way: build a set of the people near the tea, a set of the people who quarrelled with the victim, and take the name that is in both (`&`)\n\n**Then** print the accusation: the starter's last line already prints `culprit`, so keep it.\n\n**Example:** tea made at `\"23:50\"`, served at `\"00:05\"`. A entered the dining car at `\"23:58\"`, B at `\"00:05\"` and C at `\"23:52\"`. A and B argued with the victim, C did not. Only A fits (B's event is not strictly before `\"00:05\"`, and C never argued), so `culprit` is `\"A\"`.",
            "starter": _TIMELINE + _EVENTS_IN + _CLASSIFY + "\n\n# your deduction here\n\nculprit = None\nprint(\"The poisoner is\", culprit)\n",
            "solution": _TIMELINE + _EVENTS_IN + _CLASSIFY + '\n\nmade = night_minutes(conductor_log["tea made"])\nserved = night_minutes(conductor_log["tea served"])\n\nnear_tea = {person for time, person, action in events_in("dining car") if made < night_minutes(time) < served}\nargued = {person for time, car, person, action in timeline if classify(action) == "quarrel" and victim in action}\nculprit = (near_tea & argued).pop()\n\nprint("The poisoner is", culprit)\n',
            "tests": _TRAIN_TEST_HELPERS + '''_mk, _sv = _nm(conductor_log["tea made"]), _nm(conductor_log["tea served"])
_near = {e[2] for e in _tl if e[1] == "dining car" and _mk < _nm(e[0]) < _sv}
_arg = {e[2] for e in _tl if e[3].startswith("argued with") and victim in e[3]}
_exp = _near & _arg
assert culprit is not None, "culprit is still None: find the person who fits both clues"
assert culprit in _exp, "wrong person. The poisoner was in the dining car while the tea waited (compare with night_minutes, because the window can cross midnight) AND argued with the victim."
assert str(culprit) in __output__, "print your accusation"''',
            "tips": [
                "Turn both conductor times into minutes with `night_minutes`. Build a set `near_tea` of people with an `events_in(\"dining car\")` event strictly between them, and a set `argued` of people whose action `classify`s as a quarrel that names the victim.",
                "The poisoner is in both sets: `culprit = (near_tea & argued).pop()`.",
            ],
            "reveal": "In the dining car while the tea stood unattended, and a grudge against the victim. The poisoner is led off at the next station. In their coat pocket: a railway timetable with a chalk **X** on it.",
        },
    ],
    "closing": "Case closed. The victim survives the night in hospital, and the poisoner's motive turns out to be money, as usual. But the timetable is not. A chalk **X** circles the **03:10** stop at **Vasco Junction**, and in the corner, the same small **V**. X isn't just leaving marks any more. X is keeping a schedule.",
    "fragment": "On a seized train timetable, a chalk X circles the 03:10 stop at Vasco Junction, signed with the same small V.",
}

# ======================================================================
# 3. The Masquerade at the Museum
# ======================================================================

_GUEST_ID = '''from dataclasses import dataclass, FrozenInstanceError


@dataclass(frozen=True)
class GuestId:
    value: str

    def __post_init__(self):
        clean = self.value.strip().upper().replace("-", "").replace(" ", "")
        object.__setattr__(self, "value", clean)


def clean_name(name):
    return name.strip().title()
'''

_GUEST = '''

class Guest:
    def __init__(self, name, guest_id):
        self.name = clean_name(name)
        self.guest_id = GuestId(guest_id)

    def __repr__(self):
        return f"Guest({self.name!r}, {self.guest_id.value!r})"

    def __eq__(self, other):
        if not isinstance(other, Guest):
            return NotImplemented
        return self.name == other.name and self.guest_id == other.guest_id

    def __hash__(self):
        return hash((self.name, self.guest_id))
'''

_EVIDENCE = '''from abc import ABC, abstractmethod


def clean_name(name):
    return name.strip().title()


class Evidence(ABC):
    weight = 0

    @abstractmethod
    def points_to(self):
        ...


class Fibre(Evidence):
    weight = 1

    def __init__(self, mask):
        self.mask = mask

    def points_to(self):
        for record in guest_records:
            if record["mask"] == self.mask:
                return clean_name(record["name"])
        return None


class Ticket(Evidence):
    weight = 2

    def __init__(self, number):
        self.number = number

    def points_to(self):
        return cloakroom.get(self.number)


class Witness(Evidence):
    weight = 3

    def __init__(self, saw):
        self.saw = saw

    def points_to(self):
        return clean_name(self.saw)
'''

_MAKE_CLUE = '''

def make_clue(d):
    match d:
        case {"kind": "fibre", "mask": mask}:
            return Fibre(mask)
        case {"kind": "ticket", "number": number}:
            return Ticket(number)
        case {"kind": "witness", "saw": saw}:
            return Witness(saw)
'''

_LOCKER = '''

class EvidenceLocker:
    def __init__(self, items):
        self.items = list(items)

    def __len__(self):
        return len(self.items)

    def __contains__(self, name):
        for item in self.items:
            if item.points_to() == name:
                return True
        return False

    def __getitem__(self, index):
        return self.items[index]


locker = EvidenceLocker(make_clue(c) for c in clues)
guest_names = sorted({clean_name(r["name"]) for r in guest_records})
'''

_SUSPECT = '''

class Suspect:
    def __init__(self, name, locker):
        self.name = name
        self.locker = locker

    @property
    def suspicion(self):
        total = 0
        for item in self.locker.items:
            if item.points_to() == self.name:
                total += item.weight
        return total
'''

_FIND_CLAIMANTS = '''

def find_claimants():
    guests = {Guest(r["name"], r["id"]) for r in guest_records}
    by_id = defaultdict(list)
    for g in guests:
        by_id[g.guest_id].append(g.name)
    for names in by_id.values():
        if len(names) > 1:
            return sorted(names)
    return []
'''

_MUSEUM_TEST_HELPERS = '''def _cn(n):
    return n.strip().title()
def _cid(v):
    return v.strip().upper().replace("-", "").replace(" ", "")
def _pt(c):
    if c["kind"] == "fibre":
        for _r in guest_records:
            if _r["mask"] == c["mask"]:
                return _cn(_r["name"])
        return None
    if c["kind"] == "ticket":
        return cloakroom.get(c["number"])
    return _cn(c["saw"])
_W = {"fibre": 1, "ticket": 2, "witness": 3}
_names = sorted({_cn(_r["name"]) for _r in guest_records})
_scores = {n: sum(_W[c["kind"]] for c in clues if _pt(c) == n) for n in _names}
_byid = {}
for _r in guest_records:
    _byid.setdefault(_cid(_r["id"]), set()).add(_cn(_r["name"]))
_stolen = [k for k, v in _byid.items() if len(v) > 1][0]
_claim = sorted(_byid[_stolen])
'''

MUSEUM = {
    "id": "museum-masquerade",
    "tier": "big",
    "title": "The Masquerade at the Museum",
    "teaser": "A curator is killed during a masked gala. One guest is wearing a stolen identity as well as a mask.",
    "skills": ALL_SKILLS,
    "story": (
        "The City Museum held a masked gala to open its new wing. Before midnight, the chief curator, "
        "**Dr. Elena Varga**, was found dead behind the locked doors of the archive.\n\n"
        "Every guest had to show an invitation with a guest id like `MX-0042`. Security typed the ids and names by hand, "
        "so `guest_records` is messy: the same guest appears more than once, with different spaces, capitals and dashes. "
        "But the Bureau has a tip: **one guest is an impostor** who copied someone else's invitation.\n\n"
        "You also have `clues`, the evidence found near the archive (mask fibres, cloakroom tickets and witness sightings), "
        "and `cloakroom`, the log that maps each cloakroom ticket number to the guest who used it.\n\n"
        "This case uses everything the Academy taught you. Build proper tools: classes, value objects and a searchable evidence locker."
    ),
    "suspects": [
        {"name": "Dr. Anjali Rao", "note": "Art historian and the curator's old rival."},
        {"name": "Mr. Kenji Mori", "note": "Collector who lent the museum its best piece."},
        {"name": "Ms. Zoe Adler", "note": "Insurance investigator, here 'for the canapes'."},
        {"name": "Mr. Farhan Qureshi", "note": "Restorer who was fired last month."},
        {"name": "Mrs. Lucia Romano", "note": "The museum's biggest donor."},
        {"name": "Mr. Vikram Sethi", "note": "Security consultant who designed the archive lock."},
        {"name": "Ms. Amara Okafor", "note": "Photographer covering the gala."},
        {"name": "Mr. Omar Haddad", "note": "Antiques dealer with a few too many receipts."},
    ],
    "variants": [
        '''guest_records = [
    {"id": "MX-0042", "name": "Dr. Anjali Rao", "mask": "fox"},
    {"id": "mx-0107", "name": "Mr. Kenji Mori", "mask": "owl"},
    {"id": "MX0019", "name": "Ms. Zoe Adler", "mask": "cat"},
    {"id": " mx0042", "name": "dr. anjali rao ", "mask": "fox"},
    {"id": "MX-0230", "name": "Mr. Farhan Qureshi", "mask": "stag"},
    {"id": "MX 0107", "name": "MR. KENJI MORI", "mask": "owl"},
    {"id": "Mx-0042", "name": "Mr. Vikram Sethi", "mask": "raven"},
    {"id": "MX-0088", "name": "Mrs. Lucia Romano", "mask": "swan"},
]

cloakroom = {9: "Mr. Kenji Mori", 14: "Mr. Vikram Sethi", 21: "Dr. Anjali Rao", 30: "Ms. Zoe Adler"}

clues = [
    {"kind": "fibre", "mask": "raven"},
    {"kind": "ticket", "number": 9},
    {"kind": "witness", "saw": " mr. kenji mori"},
    {"kind": "ticket", "number": 14},
    {"kind": "fibre", "mask": "fox"},
]
''',
        '''guest_records = [
    {"id": "mx-0019", "name": "Ms. Zoe Adler", "mask": "cat"},
    {"id": "MX-0042", "name": "Dr. Anjali Rao", "mask": "fox"},
    {"id": "MX-0107", "name": "Mr. Kenji Mori", "mask": "owl"},
    {"id": "MX 0019", "name": "Mr. Farhan Qureshi", "mask": "wolf"},
    {"id": " MX0019 ", "name": "MS. ZOE ADLER", "mask": "cat"},
    {"id": "mx-0230", "name": "Mr. Vikram Sethi", "mask": "raven"},
    {"id": "mx0107", "name": "mr. kenji mori", "mask": "owl"},
    {"id": "MX-0088", "name": "Mrs. Lucia Romano", "mask": "swan"},
    {"id": "MX-0311", "name": "Mr. Omar Haddad", "mask": "bear"},
]

cloakroom = {3: "Mr. Farhan Qureshi", 12: "Ms. Zoe Adler", 17: "Dr. Anjali Rao", 25: "Mr. Omar Haddad"}

clues = [
    {"kind": "witness", "saw": " dr. anjali rao"},
    {"kind": "fibre", "mask": "wolf"},
    {"kind": "ticket", "number": 3},
    {"kind": "ticket", "number": 17},
    {"kind": "fibre", "mask": "cat"},
    {"kind": "fibre", "mask": "stag"},
]
''',
        '''guest_records = [
    {"id": "MX-0107", "name": "Mr. Kenji Mori", "mask": "owl"},
    {"id": "mx-0230", "name": "Mr. Vikram Sethi", "mask": "raven"},
    {"id": "MX-0042", "name": "Dr. Anjali Rao", "mask": "fox"},
    {"id": "MX0230", "name": "MR. VIKRAM SETHI", "mask": "raven"},
    {"id": "mx 0107", "name": "Ms. Amara Okafor", "mask": "moth"},
    {"id": "MX-0088", "name": "Mrs. Lucia Romano", "mask": "swan"},
    {"id": "Mx-0019", "name": " ms. zoe adler", "mask": "cat"},
]

cloakroom = {5: "Mrs. Lucia Romano", 8: "Ms. Amara Okafor", 19: "Mr. Kenji Mori", 22: "Mr. Vikram Sethi"}

clues = [
    {"kind": "ticket", "number": 5},
    {"kind": "witness", "saw": "mrs. lucia romano "},
    {"kind": "fibre", "mask": "moth"},
    {"kind": "witness", "saw": "ms. amara okafor"},
    {"kind": "ticket", "number": 19},
    {"kind": "fibre", "mask": "swan"},
]
''',
    ],
    "steps": [
        {
            "notes": "**Guest ids.** Security typed the ids by hand, so one id can be written many ways: `\"MX-0042\"`, `\" mx0042\"` and `\"Mx 0042\"` are all the **same** id. Its clean form has no spaces at the ends, is all upper case, and has no `-` or spaces inside: `\"MX0042\"`.",
            "question": "**Goal:** a guest-id type that treats every spelling of the same id as equal.\n\n**You have:** `guest_records`, a list of dictionaries, e.g. `{\"id\": \" mx0042\", \"name\": \"dr. anjali rao \", \"mask\": \"fox\"}`. The starter already imports `dataclass` and `FrozenInstanceError` and has the `@dataclass(frozen=True)` line.\n\n**Write** a frozen dataclass `GuestId`:\n- one field, `value: str`\n- a `__post_init__(self)` method that turns `value` into its clean form (see the field notes): `.strip()`, `.upper()`, and remove every `\"-\"` and `\" \"`\n- a frozen object refuses `self.value = ...`, so store the clean value with `object.__setattr__(self, \"value\", clean)`\n- because it is frozen, `some_id.value = \"X\"` afterwards must raise `FrozenInstanceError` (`frozen=True` does this for you)\n- two `GuestId`s with the same clean value must be equal and have the same hash (the dataclass does this for you too)\n\n**Then** store:\n- `unique_ids`: a **set** of `GuestId(r[\"id\"])` for every record `r` in `guest_records`\n- `id_count`: how many items `unique_ids` has (an `int`)\n\n**Example:** `GuestId(\" mx-0042 \").value` is `\"MX0042\"`, and `GuestId(\"MX 0042\") == GuestId(\"mx-0042\")` is `True`. Records with the ids `\"AB-1\"`, `\"ab1\"` and `\"AB-2\"` give `id_count == 2`.",
            "starter": "from dataclasses import dataclass, FrozenInstanceError\n\n\n@dataclass(frozen=True)\nclass GuestId:\n    ...  # your code here\n\n\nunique_ids = set()\nid_count = 0\n\nprint(id_count, sorted(g.value for g in unique_ids))\n",
            "solution": "from dataclasses import dataclass, FrozenInstanceError\n\n\n@dataclass(frozen=True)\nclass GuestId:\n    value: str\n\n    def __post_init__(self):\n        clean = self.value.strip().upper().replace(\"-\", \"\").replace(\" \", \"\")\n        object.__setattr__(self, \"value\", clean)\n\n\nunique_ids = {GuestId(r[\"id\"]) for r in guest_records}\nid_count = len(unique_ids)\n\nprint(id_count, sorted(g.value for g in unique_ids))\n",
            "tests": _MUSEUM_TEST_HELPERS + '''_a = GuestId(" mx-0042 ")
assert _a.value == "MX0042", f"GuestId(' mx-0042 ').value should be 'MX0042', got {_a.value!r}"
assert GuestId("MX 0042") == _a and hash(GuestId("MX 0042")) == hash(_a), "two spellings of the same id should be equal and have the same hash"
try:
    _a.value = "MX9999"
    raise AssertionError("GuestId should be frozen: use @dataclass(frozen=True)")
except FrozenInstanceError:
    pass
_exp = {_cid(_r["id"]) for _r in guest_records}
assert isinstance(unique_ids, set), "unique_ids should be a set"
assert {g.value for g in unique_ids} == _exp, f"unique_ids should hold the ids {sorted(_exp)}"
assert id_count == len(_exp), f"id_count should be {len(_exp)}, got {id_count!r}"''',
            "tips": [
                "Write the field `value: str`, then `def __post_init__(self):` with `clean = self.value.strip().upper().replace(\"-\", \"\").replace(\" \", \"\")`.",
                'Finish `__post_init__` with `object.__setattr__(self, "value", clean)`. Then `unique_ids = {GuestId(r["id"]) for r in guest_records}` and `id_count = len(unique_ids)`.',
            ],
            "reveal": "Fewer ids than records. Some guests were typed in twice, which is harmless. Or is it?",
        },
        {
            "notes": "**The stolen invitation.** Two records are the **same guest** if their clean names and clean ids are equal: the same person typed in twice. The impostor copied someone's invitation, so exactly **one** id is held by **two different** names. That id is the stolen one.\n\nNames are cleaned with `clean_name`: `\" dr. anjali rao \"` becomes `\"Dr. Anjali Rao\"`.",
            "question": "**Goal:** find the invitation id that two different people used.\n\n**You have:** in the starter, `GuestId` (step 1), `clean_name(name)`, and a `Guest` class whose `__init__` already stores `self.name` (a clean name) and `self.guest_id` (a `GuestId`). `defaultdict` is already imported. `guest_records` is as in step 1.\n\n**Write** two methods in `Guest`:\n- `__eq__(self, other)`: `True` when both the `name` and the `guest_id` are equal\n- `__hash__(self)`: a hash of the same two things, e.g. `hash((self.name, self.guest_id))`, so equal guests have the same hash\n\n**Then** store:\n- `guests`: a **set** of `Guest(r[\"name\"], r[\"id\"])` for every record `r`; duplicate records collapse into one\n- `stolen`: the `GuestId` (the object, not a string) that belongs to two different guests in `guests`\n- `claimants`: the two names (strings) holding that id, in a list sorted A to Z\n\n**Example:** `Guest(\" dr. x \", \"mx-1\") == Guest(\"DR. X\", \"MX1\")` is `True`, but `Guest(\"Dr. X\", \"MX1\") == Guest(\"Mr. Y\", \"MX1\")` is `False`. Records `(\"Dr. X\", \"MX1\")`, `(\"dr. x\", \"mx-1\")` and `(\"Mr. Y\", \"MX 1\")` give 2 guests, `stolen` is `GuestId(\"MX1\")` and `claimants` is `[\"Dr. X\", \"Mr. Y\"]`.",
            "starter": _GUEST_ID + "\n\nclass Guest:\n    def __init__(self, name, guest_id):\n        self.name = clean_name(name)\n        self.guest_id = GuestId(guest_id)\n\n    def __repr__(self):\n        return f\"Guest({self.name!r}, {self.guest_id.value!r})\"\n\n    # add __eq__ and __hash__ here\n\n\nfrom collections import defaultdict\n\nguests = set()\nstolen = None\nclaimants = []\n\nprint(len(guests), stolen, claimants)\n",
            "solution": _GUEST_ID + _GUEST + '\n\nfrom collections import defaultdict\n\nguests = {Guest(r["name"], r["id"]) for r in guest_records}\nby_id = defaultdict(list)\nfor g in guests:\n    by_id[g.guest_id].append(g.name)\n\nstolen = None\nclaimants = []\nfor gid, names in by_id.items():\n    if len(names) > 1:\n        stolen = gid\n        claimants = sorted(names)\n\nprint(len(guests), stolen, claimants)\n',
            "tests": _MUSEUM_TEST_HELPERS + '''assert Guest(" dr. x ", "mx-1") == Guest("DR. X", "MX1"), "two records of the same person and id should be equal"
assert hash(Guest(" dr. x ", "mx-1")) == hash(Guest("DR. X", "MX1")), "equal guests must have the same hash"
assert Guest("Dr. X", "MX1") != Guest("Mr. Y", "MX1"), "same id but a different name is a different guest"
_exp = {(_cn(_r["name"]), _cid(_r["id"])) for _r in guest_records}
assert isinstance(guests, set) and len(guests) == len(_exp), f"guests should be a set of {len(_exp)} different guests"
assert stolen is not None and stolen.value == _stolen, f"stolen should be GuestId('{_stolen}'), got {stolen!r}"
assert claimants == _claim, f"claimants should be {_claim}, got {claimants}"''',
            "tips": [
                "`__eq__` compares `self.name == other.name and self.guest_id == other.guest_id`; `__hash__` returns `hash((self.name, self.guest_id))`.",
                "Group with `by_id = defaultdict(list)` and `by_id[g.guest_id].append(g.name)`. The id whose list has 2 names is the stolen one.",
            ],
            "reveal": "One invitation, two faces. One of these two is the real guest. The other walked in wearing a stolen name.",
        },
        {
            "notes": "**What each clue points to.** Every clue in `clues` points to one guest, or to nobody:\n- **fibre**, e.g. `{\"kind\": \"fibre\", \"mask\": \"fox\"}`: a thread from a mask. It points to the name in the **first** record of `guest_records` with that `\"mask\"`, cleaned with `clean_name`. If no record has that mask, it points to nobody (`None`).\n- **ticket**, e.g. `{\"kind\": \"ticket\", \"number\": 9}`: a cloakroom ticket. It points to the name `cloakroom` lists for that number, exactly as written there, or `None` if the number is not in `cloakroom`.\n- **witness**, e.g. `{\"kind\": \"witness\", \"saw\": \" mr. kenji mori\"}`: a sighting. It points to the name the witness gave, cleaned with `clean_name`.\n\nEach kind has a `weight` (used in step 5): fibre 1, ticket 2, witness 3.",
            "question": "**Goal:** give every kind of evidence the same question to answer: who do you point to?\n\n**You have:**\n- in the starter: `clean_name(name)`, the classes `Evidence`, `Fibre` (stores `self.mask`), `Ticket` (stores `self.number`) and `Witness` (stores `self.saw`), and `make_clue(d)`, which turns one clue dictionary into the right object\n- `guest_records` (as in step 1), `clues`, and `cloakroom`, a dictionary from ticket number to name, e.g. `{9: \"Mr. Kenji Mori\"}`\n\n**Write:**\n- in `Evidence`: a method `points_to(self)` marked `@abstractmethod` (its body can be `...`). `Evidence` already inherits from `ABC`, so `Evidence()` then raises `TypeError`.\n- in each of `Fibre`, `Ticket` and `Witness`: its own `points_to(self)`, returning a name (string) or `None` as the field notes say.\n\n**Then** the starter builds `pointed`, the list of what every clue points to, and prints it; leave that.\n\n**Example:** with `guest_records = [{\"id\": \"MX1\", \"name\": \"dr. x\", \"mask\": \"fox\"}]` and `cloakroom = {4: \"Mr. Y\"}`: `Fibre(\"fox\").points_to()` is `\"Dr. X\"`, `Fibre(\"bear\").points_to()` is `None`, `Ticket(4).points_to()` is `\"Mr. Y\"`, `Ticket(5).points_to()` is `None` and `Witness(\" ms. z \").points_to()` is `\"Ms. Z\"`.",
            "starter": "from abc import ABC, abstractmethod\n\n\ndef clean_name(name):\n    return name.strip().title()\n\n\nclass Evidence(ABC):\n    weight = 0\n    # add the abstract method points_to here\n\n\nclass Fibre(Evidence):\n    weight = 1\n\n    def __init__(self, mask):\n        self.mask = mask\n\n\nclass Ticket(Evidence):\n    weight = 2\n\n    def __init__(self, number):\n        self.number = number\n\n\nclass Witness(Evidence):\n    weight = 3\n\n    def __init__(self, saw):\n        self.saw = saw\n" + _MAKE_CLUE + "\n\npointed = [make_clue(c).points_to() for c in clues]\nprint(pointed)\n",
            "solution": _EVIDENCE + _MAKE_CLUE + "\n\npointed = [make_clue(c).points_to() for c in clues]\nprint(pointed)\n",
            "tests": _MUSEUM_TEST_HELPERS + '''assert getattr(Evidence.points_to, "__isabstractmethod__", False), "points_to in Evidence should be marked @abstractmethod"
try:
    Evidence()
    raise AssertionError("Evidence() should be impossible: it is an abstract base class")
except TypeError:
    pass
for _cls in (Fibre, Ticket, Witness):
    assert issubclass(_cls, Evidence), f"{_cls.__name__} should inherit from Evidence"
_exp = [_pt(c) for c in clues]
assert pointed == _exp, f"pointed should be {_exp}, got {pointed}"''',
            "tips": [
                "In `Evidence`: `@abstractmethod` on a line above `def points_to(self): ...`. Each subclass then defines its own `def points_to(self):`.",
                '`Fibre`: loop `for record in guest_records:` and `if record["mask"] == self.mask: return clean_name(record["name"])`, with `return None` after the loop.',
            ],
            "reveal": "Three kinds of evidence, one question for all of them: *who do you point to?* Polymorphism in action.",
        },
        {
            "notes": "A guest is **implicated** if at least one piece of evidence in the locker points to their name (step 3 explains what each clue points to).",
            "question": "**Goal:** make the evidence locker work like a built-in container.\n\n**You have:** in the starter, all the evidence classes and `make_clue` (step 3), and an `EvidenceLocker` class whose `__init__` stores the evidence objects in the list `self.items`. Below it, the starter already builds `locker`, `guest_names` (the clean guest names, sorted) and `implicated`.\n\n**Write** three methods in `EvidenceLocker`:\n- `__len__(self)`: returns how many items the locker holds, so `len(locker)` works\n- `__contains__(self, name)`: returns `True` if any item's `points_to()` equals `name`, otherwise `False`, so `name in locker` works\n- `__getitem__(self, index)`: returns the item at that position in `self.items`, so `locker[0]` and `locker[-1]` work\n\n**Then** the starter's line `implicated = [name for name in guest_names if name in locker]` uses your `__contains__`; leave it and the prints as they are.\n\n**Example:** a locker holding `Witness(\"mr. y\")` and then a `Fibre` that points to nobody has `len(locker) == 2`, `locker[0]` is the witness, `\"Mr. Y\" in locker` is `True` and `\"Nobody At All\" in locker` is `False`.",
            "starter": _EVIDENCE + _MAKE_CLUE + "\n\nclass EvidenceLocker:\n    def __init__(self, items):\n        self.items = list(items)\n\n    # add __len__, __contains__ and __getitem__ here\n\n\nlocker = EvidenceLocker(make_clue(c) for c in clues)\nguest_names = sorted({clean_name(r[\"name\"]) for r in guest_records})\nimplicated = [name for name in guest_names if name in locker]\n\nprint(len(locker), \"items; first:\", type(locker[0]).__name__)\nprint(implicated)\n",
            "solution": _EVIDENCE + _MAKE_CLUE + _LOCKER + "implicated = [name for name in guest_names if name in locker]\n\nprint(len(locker), \"items; first:\", type(locker[0]).__name__)\nprint(implicated)\n",
            "tests": _MUSEUM_TEST_HELPERS + '''assert len(locker) == len(clues), f"len(locker) should be {len(clues)}"
assert locker[0] is locker.items[0] and locker[-1] is locker.items[-1], "locker[i] should return the item at position i"
for _n in _names:
    _e = any(_pt(c) == _n for c in clues)
    assert (_n in locker) == _e, f"{_n!r} in locker should be {_e}"
assert ("Nobody At All" in locker) is False, "a name no clue points to should not be in the locker"
_exp = [n for n in _names if any(_pt(c) == n for c in clues)]
assert implicated == _exp, f"implicated should be {_exp}, got {implicated}"''',
            "tips": [
                "`__len__` returns `len(self.items)` and `__getitem__(self, index)` returns `self.items[index]`.",
                "`__contains__(self, name)`: loop `for item in self.items:` and `return True` if `item.points_to() == name`; after the loop, `return False`.",
            ],
            "reveal": "Now `\"Mr. Kenji Mori\" in locker` just works, like any built-in. Several guests are implicated. Who is the most suspicious?",
        },
        {
            "notes": "**Suspicion score.** A guest's suspicion is the sum of the `weight` of every locker item that points to them: fibre 1, ticket 2, witness 3 (each class already has its `weight`). A guest that no item points to scores `0`.",
            "question": "**Goal:** score how strongly the evidence points to each guest.\n\n**You have:** in the starter, the evidence classes, `make_clue`, `EvidenceLocker`, `locker` and `guest_names` (steps 3 and 4), and a `Suspect` class whose `__init__` stores `self.name` and `self.locker`.\n\n**Write** a **property** `suspicion` in `Suspect`:\n- put `@property` above `def suspicion(self):`, so it is read as `suspect.suspicion`, with no `()`\n- it returns the total weight (an `int`) of the items in `self.locker.items` whose `points_to()` equals `self.name` (see the field notes)\n\n**Then** store:\n- `scores`: a dictionary from **every** name in `guest_names` (including those that score `0`) to `Suspect(name, locker).suspicion`\n- `top`: the name (a string) with the highest score. Use `max(scores, key=...)`; if two names tie, `max` keeps the first one, which is the one that comes first in `guest_names`.\n\n**Example:** if a ticket (2) and a witness (3) point to `\"Mr. Y\"`, a fibre (1) points to `\"Dr. X\"` and nothing points to `\"Ms. Z\"`, then `scores == {\"Dr. X\": 1, \"Mr. Y\": 5, \"Ms. Z\": 0}` and `top == \"Mr. Y\"`.",
            "starter": _EVIDENCE + _MAKE_CLUE + _LOCKER + "\n\nclass Suspect:\n    def __init__(self, name, locker):\n        self.name = name\n        self.locker = locker\n\n    # add the suspicion property here\n\n\nscores = ...\ntop = ...\n\nprint(scores)\nprint(\"Top:\", top)\n",
            "solution": _EVIDENCE + _MAKE_CLUE + _LOCKER + _SUSPECT + "\n\nscores = {name: Suspect(name, locker).suspicion for name in guest_names}\ntop = max(scores, key=lambda name: scores[name])\n\nprint(scores)\nprint(\"Top:\", top)\n",
            "tests": _MUSEUM_TEST_HELPERS + '''assert isinstance(Suspect.__dict__.get("suspicion"), property), "suspicion should be a @property, not a plain method"
assert scores == _scores, f"scores should be {_scores}, got {scores}"
_top = max(_scores, key=lambda n: _scores[n])
assert top == _top, f"top should be {_top!r}, got {top!r}"''',
            "tips": [
                "Put `@property` above `def suspicion(self):`. Inside, start `total = 0`, loop over `self.locker.items`, add `item.weight` when `item.points_to() == self.name`, and `return total`.",
                "`scores = {name: Suspect(name, locker).suspicion for name in guest_names}` and `top = max(scores, key=lambda name: scores[name])`.",
            ],
            "reveal": "The highest score belongs to someone. But wait: the most suspicious guest is not always the impostor. The Chief wants you to combine *everything*.",
        },
        {
            "notes": "**Who is the killer.** The killer is the **impostor**: one of the two people sharing the stolen invitation. Of those two, it is the one with the **higher** suspicion score. The guest with the top score overall may be someone else entirely.",
            "question": "**Goal:** unmask the impostor.\n\n**You have:** in the starter, everything from earlier steps:\n- `find_claimants()` returns the two names sharing the stolen id, sorted A to Z (step 2), e.g. `[\"Dr. X\", \"Mr. Y\"]`\n- `Suspect(name, locker).suspicion` gives a name's score (step 5)\n- `locker`, the evidence locker (step 4)\n\n**Write** a variable `impostor`:\n- a string: the claimant with the higher suspicion (see the field notes)\n- it must be one of the two claimants, even if another guest has a higher score overall\n- if both claimants have the same score, take the first one from `find_claimants()` (that is what `max` does)\n\n**Then** print the accusation: the starter's last line already prints `impostor`, so keep it.\n\n**Example:** if `find_claimants()` gives `[\"Dr. X\", \"Mr. Y\"]` with scores 1 and 4, and `\"Ms. Z\"` scores 6, `impostor` is `\"Mr. Y\"`.",
            "starter": _GUEST_ID + _GUEST + "\nfrom collections import defaultdict\n" + _FIND_CLAIMANTS + "\n\n" + _EVIDENCE + _MAKE_CLUE + _LOCKER + _SUSPECT + "\n\nimpostor = None\n# pick the claimant with the higher suspicion here\n\nprint(\"The impostor is\", impostor)\n",
            "solution": _GUEST_ID + _GUEST + "\nfrom collections import defaultdict\n" + _FIND_CLAIMANTS + "\n\n" + _EVIDENCE + _MAKE_CLUE + _LOCKER + _SUSPECT + "\n\nclaimants = find_claimants()\nimpostor = max(claimants, key=lambda name: Suspect(name, locker).suspicion)\n\nprint(\"The impostor is\", impostor)\n",
            "tests": _MUSEUM_TEST_HELPERS + '''_exp = max(_claim, key=lambda n: _scores[n])
assert impostor is not None, "impostor is still None: look at the claimants of the stolen id"
assert impostor in _claim, "the impostor must be one of the two people claiming the stolen invitation, not just the guest with the top score overall"
assert impostor == _exp, "wrong claimant: of the two people with the stolen id, pick the one with the higher suspicion"
assert str(impostor) in __output__, "print your accusation"''',
            "tips": [
                "`claimants = find_claimants()` gives the two names. `max` can rank them with a `key`.",
                "`impostor = max(claimants, key=lambda name: Suspect(name, locker).suspicion)`.",
            ],
            "reveal": "The mask comes off. The impostor's real invitation never existed: they copied a guest's id to get into the gala, and into the archive. In their glove, rolled tight: a museum catalogue card with a chalk **X**.",
        },
    ],
    "closing": "Case closed, but the Chief isn't smiling. The impostor says they were *hired*: paid in cash, instructions left in a library book, signed only with a chalk **X**. The catalogue card in the glove is for item **MX-0001**, the museum's very first acquisition. Its display case has been empty for years. The label reads *Gift of V.*\n\nThe library, the train, the museum: these weren't three crimes. They were **X's first move**. Day 1 is over, Detective. X is still out there, and the next move is theirs.",
    "fragment": "Museum catalogue no. MX-0001, the very first acquisition: an empty case labelled 'Gift of V.' This was X's first move.",
}

CASES = [GRAND_LIBRARY, MIDNIGHT_EXPRESS, MUSEUM]

"""Beginner layer for Day 1: line-by-line notes, hints, simpler demos and ordering.

`apply(LESSONS, PARTS)` is called at the end of lessons.py. It:
  - inserts the "Start here" part (basics.BASICS) in front,
  - moves the venv lesson into "Start here" and context managers after generators,
  - replaces demos that used syntax before it was taught,
  - adds a "Line by line" walkthrough to every demo and hints to every challenge.
"""
from .basics import BASICS

CODE = {}
IDEA = {}
TITLE = {}

# ---------------------------------------------------------------- demo rewrites
TITLE["python-setup"] = "Projects and virtual environments"
IDEA["python-setup"] = "When you install packages with `pip`, they go into one shared place by default. Two projects that need different versions of the same package would then fight each other.\n\nA **virtual environment** (a `.venv/` folder inside your project) gives each project its own private copy of Python and its own packages. It is like `node_modules/` for JavaScript. Every BookVault milestone in this training lives in its own venv.\n\nThe Python you installed is called **CPython**, the standard implementation: it turns your code into bytecode and runs it. This page runs **Brython**, a Python written in JavaScript, so you could start without installing anything. Run the code to see the difference.\n\nThe card below uses `uv`, a fast tool for creating environments (install it with `pip install uv`). Plain Python works too: `python -m venv .venv`."
CODE["python-setup"] = '''import sys

print("Running on:", sys.implementation.name)   # 'cpython' on your laptop
print("Python version:", sys.version.split()[0])
print(type(42))
'''

CODE["dynamic-typing"] = '''x = 42
print(type(x), x)

x = "hello"
print(type(x), x)

x = [1, 2, 3]
print(type(x), x)

pages = 464
rating = 4.7
available = True
isbn = None
print(type(pages), type(rating), type(available), type(isbn))
'''
IDEA["dynamic-typing"] = "In Python a variable is just a **name**. The **value** it points to carries the type. That is why the same name can hold a number, then some text, then a list: Python checks types while the program runs, not before. This is called **dynamic typing**.\n\nIt makes Python quick to write, but it also means a typo or a wrong type is only discovered when that line runs. Tests (Day 2) and type hints protect you later."

CODE["truthiness"] = '''test_values = [0, 1, -1, "", " ", "False", [], [0], {}, None]
for v in test_values:
    print(repr(v), "->", bool(v))

shelf = []
if shelf:
    print("Shelf has books")
else:
    print("Shelf is empty")

# The same decision in one line (a "conditional expression")
message = "Shelf has books" if shelf else "Shelf is empty"
print(message)
'''

CODE["composition"] = '''class Logger:
    def __init__(self, prefix):
        self.prefix = prefix

    def log(self, msg):
        print(f"[{self.prefix}] {msg}")

class InMemoryCache:
    def __init__(self):
        self._store = {}

    def get(self, key):
        return self._store.get(key)

    def set(self, key, value):
        self._store[key] = value

class Library:
    def __init__(self, logger, cache):
        self.logger = logger          # parts are passed in...
        self.cache = cache            # ...not inherited
        self._items = {}

    def add(self, isbn, title):
        self.logger.log(f"adding {title}")
        self._items[isbn] = title

    def find(self, isbn):
        hit = self.cache.get(isbn)
        if hit is not None:
            self.logger.log(f"cache hit {isbn}")
            return hit
        self.logger.log(f"cache miss {isbn}")
        title = self._items.get(isbn)
        self.cache.set(isbn, title)
        return title

lib = Library(Logger("LIB"), InMemoryCache())
lib.add("978-0132350884", "Clean Code")
lib.find("978-0132350884")
lib.find("978-0132350884")
'''

# ---------------------------------------------------------------- walkthroughs
WALK = {
    "python-setup": [
        ["import sys", "`sys` is a built-in module with information about the running Python."],
        ['print("Running on:", sys.implementation.name)', "Shows which Python is running: `brython` on this page, `cpython` on your computer."],
        ['print("Python version:", sys.version.split()[0])', "`sys.version` is a long text; `.split()` breaks it into words and `[0]` keeps the first one, the version number."],
    ],
    "dynamic-typing": [
        ["x = 42", "`x` points to an `int`."],
        ["print(type(x), x)", "`type(x)` reports the type of the value `x` points to *right now*."],
        ['x = "hello"', "The same name now points to a `str`. Python allows it; the old value is simply forgotten."],
        ["isbn = None", "`None` has its own type, `NoneType`: it means \"no value yet\"."],
    ],
    "is-vs-eq": [
        ["b = [1, 2]", "`a` and `b` are two separate lists that happen to contain the same values."],
        ["c = a", "No copy is made: `c` is a second name for the very same list as `a`."],
        ["print(a == b, a is b)", "`==` compares values (equal → True). `is` asks \"same object?\" (two lists → False)."],
        ["print(id(a) == id(c))", "`id()` is the object's identity number. `a` and `c` share one, which is exactly what `is` checks."],
        ["c.append(3)", "Changing the list through `c` also changes `a`, because they are the same list."],
        ["if isbn is None:", "Checking for `None` is the main everyday use of `is`."],
    ],
    "float-trap": [
        ["print(0.1 + 0.2)", "Computers store decimals in binary, so 0.1 and 0.2 are tiny bit off. The sum prints `0.30000000000000004`."],
        ["from decimal import Decimal", "`Decimal` stores decimal numbers exactly, at the cost of some speed."],
        ['print(Decimal("0.1") + Decimal("0.2"))', "Create Decimals from **strings**: `Decimal(0.1)` would copy the float's error."],
        ["print(math.isclose(0.1 + 0.2, 0.3))", "For measurements, compare with a tolerance instead of `==`."],
    ],
    "truthiness": [
        ["for v in test_values:", "Loop over a list of very different values."],
        ['    print(repr(v), "->", bool(v))', "`bool(v)` converts any value to True or False. `repr(v)` shows the value the way you would type it, so empty text is visible as `''`."],
        ["if shelf:", "An empty list counts as False, so you can test \"has items?\" directly without `len()`."],
        ['message = "Shelf has books" if shelf else "Shelf is empty"', "A **conditional expression**: *value_if_true* `if` *condition* `else` *value_if_false*, all in one line."],
    ],
    "strings": [
        ["print(title[0])", "Strings are sequences of characters, so indexing works just like lists. `[0]` is `T`."],
        ["print(title[4:13])", "A slice: characters 4 up to (not including) 13, which is `Pragmatic`."],
        ["print(title[::-1])", "The third slice number is the **step**. A step of -1 walks backwards, reversing the text."],
        ["print(title.split())", "`split()` breaks text into a list of words at the spaces."],
        ['print("-".join(["a", "b", "c"]))', "`join` is the opposite: it glues a list of strings together, with `-` between them."],
        ['print(title.lower().replace("the ", ""))', "Methods can be chained: lowercase first, then remove `the `."],
    ],
    "f-strings": [
        ['print(f"{name} in {year}")', "The basic f-string you already know: values go inside `{ }`."],
        ['print(f"${price:.2f}")', "After a colon comes a **format spec**. `.2f` means: a number with exactly 2 decimals."],
        ['print(f"{big:,}")', "`,` adds thousands separators."],
        ['print(f"[{price:>10.2f}]")', "`>10` right-aligns in a space 10 characters wide. `<` aligns left, `^` centres."],
        ['print(f"{0.875:.1%}")', "`%` multiplies by 100 and adds a percent sign."],
        ['print(f"{name=}, {year=}, {price=:.2f}")', "Adding `=` prints the expression **and** its value, which is great for quick debugging."],
    ],
    "containers": [
        ['catalog.insert(0, "SICP")', "`insert(position, item)` adds at a specific position; `append` always adds at the end."],
        ['catalog.remove("Refactoring")', "`remove` deletes the first matching item."],
        ["sorted(catalog, key=len)[0]", "`sorted` returns a new sorted list. `key=len` means \"sort by length\", so `[0]` is the shortest title."],
        ["big_set = set(big_list)", "A **set** holds unique items and can answer `in` almost instantly, however large it is."],
        ["t0 = time.perf_counter(); 199_999 in big_list; ...", "Time both lookups. The list checks items one by one; the set jumps straight to the answer."],
        ["shallow = nested.copy()", "`.copy()` copies the outer list only. The inner lists are still shared, so changes leak."],
        ["deep = copy.deepcopy(nested)", "`deepcopy` copies everything inside too, so it is fully independent."],
        ["first, *middle, last = [1, 2, 3, 4, 5]", "Unpacking with `*`: `first` and `last` take one value each and `*middle` collects the rest into a list."],
        ["print(fiction & classics)", "Set maths: `&` is \"in both\", `|` is \"in either\", `-` is \"in the first but not the second\"."],
    ],
    "dicts": [
        ['print(book.get("isbn", "no isbn"))', "Safe lookup with a fallback value, from the Start here lesson."],
        ['print(defaults | {"loans": 3})', "`|` merges two dicts. Values from the right side win."],
        ["c = Counter(words)", "`Counter` counts how many times each item appears."],
        ["groups = defaultdict(list)", "A dict that creates an empty list automatically the first time you use a new key."],
        ["    groups[word[0]].append(word)", "Group words by their first letter, with no \"does the key exist yet?\" check needed."],
        ["recent = deque(maxlen=3)", "A `deque` with `maxlen` keeps only the newest 3 items; older ones fall off automatically."],
        ['Point = namedtuple("Point", ["x", "y"])', "Creates a tuple type whose items also have names, so you can write `p.x` instead of `p[0]`."],
    ],
    "loops": [
        ["for i, row in enumerate(rows, start=1):", "`enumerate` gives a counter **and** the item on each lap. `start=1` counts from 1."],
        ['    if not row["title"]:', "An empty title is falsy, so `not` makes this True for bad rows."],
        ["        continue", "Skip the rest of this lap and go straight to the next row."],
        ["        break", "Leave the loop completely. The row after `STOP` is never reached."],
        ["for title, year in zip([...], [...]):", "`zip` walks two lists side by side, pairing their items."],
    ],
    "control-flow": [
        ["for book in [...]:", "A normal search loop that `break`s when it finds the target."],
        ["else:", "This `else` belongs to the **for**, not the `if`. It runs only if the loop finished without `break`, meaning nothing was found."],
        ["    match item:", "`match` compares one value against several **patterns**, from top to bottom."],
        ['        case {"type": "book", "pages": pages} if pages > 500:', "Matches a dict that has `type` equal to `\"book\"` and some `pages`, which it stores in a variable. `if` adds an extra condition (a *guard*)."],
        ["        case _:", "`_` matches anything: the fallback, like `else`."],
    ],
    "arguments": [
        ["def add_book(title, author, year=2024, *tags, **metadata):", "`*tags` collects any extra positional values into a tuple. `**metadata` collects extra `name=value` arguments into a dict."],
        ['add_book("Clean Code", "Martin", 2008, "programming", "classic", isbn=..., pages=464)', "The first three fill `title`, `author`, `year`; the two loose strings go to `tags`; the named ones go to `metadata`."],
        ["def search(query, /, limit=10, *, exact=False):", "Everything before `/` must be passed by position. Everything after `*` must be passed by name."],
        ['search(query="python")', "Fails: `query` is positional-only."],
        ['search("python", 5, True)', "Fails: `exact` is keyword-only. Writing `exact=True` makes calls readable."],
        ["eval(bad)", "`eval` runs a string as Python code. It is used here only to try the bad calls safely; avoid it in real code."],
    ],
    "mutable-default": [
        ["def add_tag_bad(tag, tags=[]):", "The `[]` is created **once**, when Python reads the `def` line, not on every call."],
        ['print(add_tag_bad("python"))', "The second call reuses the same list, so it still contains `classic` from the first call."],
        ["def add_tag_good(tag, tags=None):", "Use `None` as a placeholder default…"],
        ["    if tags is None:\n        tags = []", "…and create a fresh list inside the function, on every call."],
    ],
    "scope": [
        ["total = 0", "A **global** variable, defined outside any function."],
        ["    total = total + x", "Because the function assigns to `total`, Python treats `total` as a new **local** variable for the whole function, and reading it before it has a value fails."],
        ["def make_counter():", "A function that builds and returns another function."],
        ["        nonlocal count", "Says: `count` belongs to the enclosing function. Without it, `count += 1` would fail the same way."],
        ["counter = make_counter()", "`counter` is the inner function. It remembers `count` between calls; this is called a **closure**."],
    ],
    "first-class": [
        ['styles = {"loud": shout, "quiet": whisper}', "Functions are values: you can store them in a dict (note: no `()`, so they are not called yet)."],
        ['print(styles["loud"]("Hello"))', "Look up the function, then call it with `(\"Hello\")`."],
        ["def make_multiplier(factor):", "A function that **returns a new function**. `double` remembers `factor = 2`."],
        ['for b in sorted(books, key=lambda b: (b["year"], -b["rating"])):', "`lambda b: ...` is a tiny unnamed function in one line. Here it returns `(year, -rating)`, so books sort by year, then by rating from high to low."],
        ['sorted(books, key=itemgetter("rating"), reverse=True)', "`itemgetter(\"rating\")` builds a function equivalent to `lambda b: b[\"rating\"]`. `reverse=True` sorts high to low."],
        ["square = partial(power, exp=2)", "`partial` makes a new function with some arguments already filled in."],
    ],
    "map-filter-reduce": [
        ["with_tax = list(map(lambda p: round(p * 1.18, 2), prices))", "`map` applies the function to every price. `list(...)` collects the results."],
        ["expensive = list(filter(lambda p: p > 20, prices))", "`filter` keeps only the items where the function returns True."],
        ["print([round(p * 1.18, 2) for p in prices])", "The same as `map`, written as a **list comprehension**: `[expression for item in list]`. You will learn these properly in the next lesson."],
        ["total = reduce(lambda acc, p: acc + p, prices, 0)", "`reduce` carries a running value `acc` (starting at 0) through the list, combining it with each item."],
    ],
    "comprehensions": [
        ["squares = [x**2 for x in range(10) if x % 2 == 0]", "Read it as: *x squared, for each x from 0 to 9, if x is even*. It builds the list in one line."],
        ["square_map = {x: x**2 for x in range(5)}", "Curly braces with `key: value` build a dict."],
        ['unique = {w.upper() for w in ["clean", "code", "clean"]}', "Curly braces without a colon build a set, so duplicates disappear."],
        ["gen = (x**2 for x in range(5))", "Round brackets build a **generator**: it produces values only when asked, one at a time."],
        ["print(list(gen))  # second time", "A generator can be used only once. The second `list(gen)` is empty."],
        ["print(sum(x**2 for x in range(1_000)))", "Passing a generator to `sum` avoids building a big list in memory."],
    ],
    "decorators": [
        ["def trace(fn):", "A decorator is a function that takes a function `fn`…"],
        ["    def wrapper(*args, **kwargs):", "…defines a new function that accepts any arguments…"],
        ["        return fn(*args, **kwargs)", "…calls the original with those same arguments and returns its result…"],
        ["    return wrapper", "…and hands back the wrapper to use instead of the original."],
        ["    @wraps(fn)", "Copies the original's name and docstring onto the wrapper, so debugging output stays readable."],
        ["        finally:", "`finally` runs whether the function returned normally or raised an error, so the time is always printed."],
        ["@timed\n@trace\ndef search_books(query):", "`@trace` wraps `search_books`, then `@timed` wraps the result. It is shorthand for `search_books = timed(trace(search_books))`."],
    ],
    "generators": [
        ["catalog_file = io.StringIO(...)", "`StringIO` makes text behave like an open file, so the example works without a real file."],
        ["        yield json.loads(line)", "`yield` hands one value to whoever is looping, then **pauses** the function until the next value is requested."],
        ["pipeline = titles(only_books(read_jsonl(catalog_file)))", "Chain three generators. Nothing has run yet: no `read one line` appears at this point."],
        ["for title in pipeline:", "Only now do values flow, one record at a time, through read → filter → transform."],
    ],
    "context-managers": [
        ["@contextmanager\ndef transaction(db_name):", "`@contextmanager` (a decorator) turns a generator function into something usable with `with`."],
        ['    print(f"BEGIN on {db_name}")', "Code **before** `yield` is the setup, run when the `with` block starts."],
        ["        yield db_name", "The `with` block runs at this point. The yielded value becomes `db` in `as db`."],
        ['        print("COMMIT")', "Runs after the `with` block finishes without errors."],
        ['    except Exception:\n        print("ROLLBACK")\n        raise', "If the block raised an error, roll back, then `raise` passes the error on to the caller."],
    ],
    "classes": [
        ["class Book:", "A **class** is a blueprint for creating objects. Each object made from it is called an **instance**."],
        ['    library_name = "BookVault"', "A **class attribute**: one value shared by all books."],
        ["    def __init__(self, title, author):", "`__init__` runs automatically when you create a book. `self` is the new book being set up."],
        ["        self.title = title", "Store the value on this particular book. Each book gets its own `title`."],
        ["    def borrow(self):", "A **method**: a function that belongs to the class. `self` is the book it is called on."],
        ['b = Book("Clean Code", "Martin")', "Create an instance. Python calls `__init__` with `self` set to the new object."],
        ["b.borrow()", "Call the method. Python passes `b` as `self` automatically."],
        ['    tags = []                           # shared!', "A list as a class attribute is shared by **every** instance, so `b1.tags.append` also changes `b2.tags`."],
    ],
    "properties": [
        ["    @property\n    def pages(self):", "`@property` lets you read `book.pages` like a plain attribute while a method runs behind the scenes."],
        ["    @pages.setter\n    def pages(self, value):", "Runs on every `book.pages = ...`, so the value can be checked before it is stored."],
        ["        self._pages = value", "The real value lives in `_pages`. A leading `_` means \"internal, don't touch from outside\"."],
        ["    @classmethod\n    def from_dict(cls, data):", "A class method receives the **class** (`cls`), not one book. Perfect for alternative ways to create objects."],
        ["    @staticmethod\n    def validate_isbn(isbn):", "A static method receives neither `self` nor `cls`. It is a plain helper that lives in the class for organisation."],
    ],
    "inheritance-abc": [
        ["class LibraryItem(ABC):", "Inheriting from `ABC` makes this an **abstract** class: a template that cannot be created on its own."],
        ["    @abstractmethod\n    def describe(self) -> str: ...", "Every subclass **must** write its own `describe`. `-> str` is a **type hint** (\"returns text\"), and `...` means \"no body here\"."],
        ["class Book(LibraryItem):", "`Book` **inherits** from `LibraryItem`: it gets everything the parent has."],
        ["        super().__init__(title, item_id)", "`super()` calls the parent's `__init__` to set the shared fields, then `Book` adds its own."],
        ['    LibraryItem("X", "Y")', "Creating the abstract class directly raises `TypeError`."],
        ["    print(item.describe())", "Same method call, different behaviour depending on the item type. That is **polymorphism**."],
    ],
    "composition": [
        ["class Library:\n    def __init__(self, logger, cache):", "The library is **given** a logger and a cache when it is created instead of inheriting from them."],
        ['        self.logger.log(f"adding {title}")', "It uses whatever logger it was given. Swap in a different logger and `Library` doesn't change."],
        ["        hit = self.cache.get(isbn)", "Ask the cache first; it returns `None` if it doesn't know the ISBN."],
        ['lib = Library(Logger("LIB"), InMemoryCache())', "Build the parts and pass them in. This is called **dependency injection**."],
    ],
    "dunders": [
        ["    def __repr__(self):", "\"Dunder\" means **d**ouble **under**score. Python calls these special methods for you: `repr(lib)` calls `__repr__`."],
        ["    def __len__(self):", "Makes `len(lib)` work."],
        ["    def __contains__(self, isbn):", "Makes `isbn in lib` work."],
        ["    def __iter__(self):", "Makes `for title in lib:` work. `iter(...)` returns something that hands out items one by one."],
        ["        if isinstance(key, (int, slice)):", "`isinstance(x, T)` checks whether `x` is of type `T`. Numbers and slices index by position; anything else looks up an ISBN."],
        ["    __hash__ = None", "A mutable object that defines `__eq__` should not be hashable (usable in a set)."],
        ["    def __call__(self, query):", "Makes the object callable like a function: `lib(\"clean\")`."],
    ],
    "eq-hash": [
        ["        self.title, self.isbn = title, isbn", "Multiple assignment, from Start here: two attributes set in one line."],
        ["        return f\"Book(title={self.title!r}, isbn={self.isbn!r})\"", "`!r` inside an f-string uses `repr()`, which adds quotes around text. Good for developers."],
        ["        if not isinstance(other, Book):\n            return NotImplemented", "Comparing a Book with something else: let Python handle it (the result is `False`)."],
        ["    def __hash__(self):\n        return hash(self.isbn)", "Equal books must have equal hashes. Hashing the same field used in `__eq__` guarantees it."],
        ['print(len({b, Book("Clean Code (2nd)", "978-0132350884")}))', "Same ISBN, so equal, so the set keeps only one: the length is 1."],
    ],
    "dataclasses": [
        ["@dataclass\nclass Book:", "`@dataclass` writes `__init__`, `__repr__` and `__eq__` for you."],
        ["    title: str", "A **field** with a type hint. Hints document the type; dataclasses do not enforce them."],
        ["    tags: list[str] = field(default_factory=list)", "A mutable default must use `default_factory`, so every book gets its own new list."],
        ["    def __post_init__(self):", "Runs right after the generated `__init__`: the place to clean up and validate."],
        ["print(b1 == b2)", "The generated `__eq__` compares all fields. After cleaning, both books are equal."],
        ["    _reading_time: float = field(init=False, repr=False)", "A field you don't pass in (`init=False`) and that is hidden from the printout (`repr=False`)."],
    ],
    "frozen": [
        ["@dataclass(frozen=True)", "`frozen=True` blocks changes after creation, and makes the object hashable."],
        ["print({ISBN(\"a\"), ISBN(\"a\"), ISBN(\"b\")})", "Equal frozen objects collapse to one in a set."],
        ['    isbn.value = "x"', "Assigning to a frozen object raises `FrozenInstanceError`."],
    ],
}

# ---------------------------------------------------------------- challenge hints
HINTS = {
    "dynamic-typing": ["Use a list comprehension or a loop over `values`.", "For each value `v`, the name is `type(v).__name__`."],
    "is-vs-eq": ["Loop over `values` and count each `v` where `v is None`.", "`sum(1 for v in values if v is None)` does it in one line."],
    "float-trap": ["Convert each string with `Decimal(text)`.", "`sum(Decimal(f) for f in fees)`"],
    "truthiness": ["Use the conditional expression: `a if condition else b`.", "`return items[0] if items else default`"],
    "strings": ["Start with `t = title.strip().lower()`.", "Then `t.startswith(\"the \")` tells you whether to slice off the first 4 characters: `t[4:]`."],
    "f-strings": ["`{title:<14}` pads the title to 14 characters on the left.", "`f\"{title:<14}${price:.2f}\"`"],
    "containers": ["Turn both lists into sets with `set(a)` and `set(b)`.", "`sorted(set(a) & set(b))`"],
    "dicts": ["defaultdict version: `groups = defaultdict(list)`, then `groups[b[\"year\"]].append(b[\"title\"])`, then `return dict(groups)`.", "setdefault version: `groups.setdefault(b[\"year\"], []).append(b[\"title\"])` on a plain `{}`."],
    "loops": ["Use `row.get(\"title\")` so missing keys don't crash; `if not title: continue`.", "After appending, `if len(titles) == limit: break`."],
    "control-flow": ["Patterns can be lists: `case [\"list\"]:` matches exactly one word `list`.", "`case [\"search\", query]:` captures the second word; `case [\"borrow\", *ids] if ids:` captures one or more ids."],
    "arguments": ["Build and return a dict: `{\"title\": title, \"author\": author, \"tags\": list(tags)}`.", "Merge in the extras with `**extra` inside the dict: `{..., **extra}`."],
    "mutable-default": ["Change the default to `basket=None`.", "Inside: `if basket is None: basket = []`."],
    "scope": ["Store `current = start - 1` in the outer function.", "In the inner function: `nonlocal current`, then `current += 1` and `return current`."],
    "context-managers": ["Append `\"open\"` before `yield`.", "Put `yield` inside `try:` and append `\"close\"` in a `finally:` block, so it runs even on errors."],
    "first-class": ["Sort with a tuple key: `key=lambda b: (-b[\"year\"], b[\"title\"])`.", "Then return `[b[\"title\"] for b in ordered]`."],
    "map-filter-reduce": ["`reduce(fn, funcs, value)` starts with `value` and applies each function in turn.", "`return lambda value: reduce(lambda acc, f: f(acc), funcs, value)`"],
    "comprehensions": ["Inside the brackets: `n * 3 for n in nums if n % 2 == 0`.", "Wrap it: `sorted([...], reverse=True)`."],
    "decorators": ["Inside `count_calls`, define `wrapper(*args, **kwargs)` decorated with `@wraps(fn)`.", "Set `wrapper.calls = 0` before returning it, and do `wrapper.calls += 1` inside the wrapper before calling `fn`."],
    "generators": ["Collect items into a `batch` list; when it reaches `size`, `yield batch` and start a new list.", "After the loop, `if batch: yield batch` for the leftovers."],
    "classes": ["In `__init__`: `self.name = name` and `self.loans = []`.", "In `borrow`: `if len(self.loans) >= 3: raise ValueError(...)`, otherwise append."],
    "properties": ["Write a `@property` getter and a `@pages.setter` that stores into `self._pages`.", "Do the same for `rating`. Because `__init__` assigns `self.pages = pages`, the setter runs there too."],
    "inheritance-abc": ["Each class gets its own `def loan_fee(self): return ...`.", "`RareBook` overrides `loan_fee` to return `200 + 500`. `calculate_total` is `sum(item.loan_fee() for item in items)`."],
    "composition": ["`RecordingLogger` needs `__init__` creating `self.messages = []`.", "Its `log(self, msg)` method appends `msg` to `self.messages`."],
    "dunders": ["Store items in `self._items = deque(maxlen=max_size)`.", "Each dunder forwards to the deque: `__len__` returns `len(self._items)`, `__getitem__` returns `self._items[index]`, and so on."],
    "eq-hash": ["Write a helper `_check(self, other)` that raises `ValueError` if currencies differ, and call it in each operator.", "`__hash__` returns `hash((self.amount, self.currency))`, and `__bool__` returns `self.amount > 0`."],
    "dataclasses": ["Declare the fields: `item_id: str`, `member_id: str`, `borrowed_on: date`, `days: int = 14`.", "`due_on` is a `@property` returning `self.borrowed_on + timedelta(days=self.days)`."],
    "frozen": ["Declare `value: str` and add `__post_init__`.", "Check `self.value.startswith(\"M\") and self.value[1:].isdigit()`; raise `ValueError` if not."],
    "a-temperature": ["Convert anything to Celsius first, then from Celsius to the target unit.", "Celsius from F: `(value - 32) * 5 / 9`; to F: `c * 9 / 5 + 32`; K is Celsius + 273.15."],
    "a-word-frequency": ["`text.lower().translate(str.maketrans(\"\", \"\", string.punctuation))` removes punctuation.", "Count with a dict and `counts.get(word, 0) + 1`; for `top_words` use `Counter(...).most_common(n)`."],
    "a-isbn-cleaner": ["Remove `-` and spaces with `.replace()`.", "Return it if `cleaned.isdigit() and len(cleaned) in (10, 13)`, otherwise `raise ValueError`."],
    "a-catalog-loader": ["Split the text into lines and drop empty ones; the first line is the header.", "For each data line: `dict(zip(header, values))`, then convert `year` and `pages` with `int()`."],
    "a-min-max": ["Take the first item as the best so far, then loop over the rest.", "Compare `key(item)` (use `key = key or (lambda x: x)`), and raise `ValueError` if there is no first item."],
    "a-library-v0": ["Keep books in a list `self.books`.", "`remove` can rebuild the list without that ISBN; `find` lowercases both sides before using `in`."],
    "a-reading-time": ["`pages_per_hour = 50 if self.pages < 300 else 40`.", "`is_valid_rating` wraps `0 <= float(rating) <= 5` in `try/except (TypeError, ValueError)`."],
    "a-hierarchy": ["`category()` can live in the base class: `return type(self).__name__`.", "Each subclass calls `super().__init__(title, item_id)` and writes its own `describe()`."],
    "a-native-library": ["`__contains__`: if `item` is a string compare ISBNs, otherwise use `item in self.books`.", "`__getitem__`: ints and slices index the list; a string searches by ISBN and raises `KeyError` if missing."],
    "a-reservations": ["In `borrow`, check in this order: item exists, member exists, item available.", "`overdue_loans` keeps loans where `returned_on is None and due_on < today`."],
    "a-pipeline": ["`pipeline`: loop over `funcs` and reassign `value = f(value)`.", "`pipeline_filter`: for each item, run the stages and `break` when the predicate fails; use the loop's `else` to keep it."],
    "a-mini-orm": ["`__init_subclass__(cls)` should set `cls._registry = []`.", "In `__init__`, compare `set(kwargs)` with `set(self.fields)` to find unknown and missing names."],
    "a-catalog-search": ["Keep items in a dict keyed by `item_id`.", "In `search`, each filter is `(x is None or condition)`, all joined with `and` inside one comprehension."],
}

MISTAKES = {
    "classes": [
        "Forgetting `self` as the first parameter of a method: `def borrow():` fails when called.",
        "Writing `title = title` inside `__init__` instead of `self.title = title`; the value is then lost.",
        "Calling the class without brackets: `b = Book` stores the class itself, not a new book.",
    ],
    "comprehensions": ["Writing the `if` before the `for`: `[x if x > 2 for x in nums]` is a SyntaxError. The filter goes at the end."],
    "decorators": ["Writing `@timed()` with brackets when `timed` takes the function directly."],
}


def apply(LESSONS, PARTS):
    PARTS.insert(0, "Start here")
    PARTS[1] = "Going deeper: language essentials"
    for lesson in LESSONS:
        lesson["part"] += 1

    # Move the venv lesson to the end of "Start here".
    setup = next(l for l in LESSONS if l["id"] == "python-setup")
    LESSONS.remove(setup)
    setup["part"] = 0
    setup.pop("slides", None)

    for b in BASICS:
        b["part"] = 0
    LESSONS[0:0] = BASICS + [setup]

    # Context managers need yield and decorators, so teach them after generators.
    cm = next(l for l in LESSONS if l["id"] == "context-managers")
    LESSONS.remove(cm)
    gi = next(i for i, l in enumerate(LESSONS) if l["id"] == "generators")
    LESSONS.insert(gi + 1, cm)

    for lesson in LESSONS:
        lid = lesson["id"]
        if lid in CODE:
            lesson["code"] = CODE[lid]
        if lid in IDEA:
            lesson["idea"] = IDEA[lid]
        if lid in TITLE:
            lesson["title"] = TITLE[lid]
        if lid in WALK and "walkthrough" not in lesson:
            lesson["walkthrough"] = WALK[lid]
        if lid in MISTAKES and "mistakes" not in lesson:
            lesson["mistakes"] = MISTAKES[lid]
        if lid in HINTS and lesson.get("challenge") and "hints" not in lesson["challenge"]:
            lesson["challenge"]["hints"] = HINTS[lid]

    # Extra practice parts, so every concept a lesson teaches gets practised.
    # practice_a.py / practice_b.py export PRACTICE = {lesson_id: [task, ...]};
    # each task has the same fields as a challenge (task, starter, solution, tests, hints).
    import importlib
    for mod in ("practice_a", "practice_b"):
        full = f"{__package__}.{mod}"
        try:
            extra = importlib.import_module(full).PRACTICE
        except ModuleNotFoundError as e:
            if e.name != full:
                raise
            continue
        for lesson in LESSONS:
            if lesson["id"] in extra:
                lesson.setdefault("practice", []).extend(extra[lesson["id"]])

    # The "Building a real project" part: files/JSON, packages, CLI, custom exceptions, type hints.
    from .project import apply as _apply_project
    _apply_project(LESSONS, PARTS)

"""Extra practice for Day 1, Chapters 2 and 3 (Going deeper ... Dunders & Dataclasses).

Each lesson's existing challenge practises only part of what it teaches. These tasks
cover the rest, so every concept gets practised at least once.
Format: PRACTICE = {lesson_id: [task, ...]}; each task is task/starter/solution/tests/hints.
"""

PRACTICE = {
    # ------------------------------------------------------------ dynamic-typing
    "dynamic-typing": [
        {
            "task": "Use **one** name, `clue`, for three values in turn: the number `221`, the text `\"Baker Street\"`, then the list `[\"pipe\", \"hat\"]`. After each assignment, append `type(clue).__name__` to `history`.",
            "starter": '''history = []

clue = 221
# append the type name, then point clue at the text, then at the list

print(history)
''',
            "solution": '''history = []

clue = 221
history.append(type(clue).__name__)
clue = "Baker Street"
history.append(type(clue).__name__)
clue = ["pipe", "hat"]
history.append(type(clue).__name__)

print(history)
''',
            "tests": '''assert history == ["int", "str", "list"], f"history should be ['int', 'str', 'list'], got {history}"
assert __source__.count("clue =") >= 3, "assign all three values to the same name, clue"
assert clue == ["pipe", "hat"], "at the end, clue should point to the list"''',
            "hints": [
                "After `clue = 221`, write `history.append(type(clue).__name__)`. Repeat that pair for the other two values.",
                "`clue = \"Baker Street\"`, append again, then `clue = [\"pipe\", \"hat\"]` and append once more.",
            ],
        },
        {
            "task": "The page counts arrive from a web form as **text**, so `total_pages` crashes, but only when that line actually runs. Fix it so each value is converted with `int()` before it is added.",
            "starter": '''def total_pages(pages):
    total = 0
    for p in pages:
        total = total + p
    return total

print(total_pages(["464", "448", "352"]))
''',
            "solution": '''def total_pages(pages):
    total = 0
    for p in pages:
        total = total + int(p)
    return total

print(total_pages(["464", "448", "352"]))
''',
            "tests": '''assert total_pages(["464", "448", "352"]) == 1264, "the three books have 1264 pages in total"
assert total_pages([]) == 0, "no books means 0 pages"
assert total_pages(["10", 5]) == 15, "int() also accepts a value that is already a number"''',
            "hints": [
                "Adding a number and a string raises `TypeError`. Turn the string into a number first.",
                "Change the line to `total = total + int(p)`.",
            ],
        },
    ],
    # ------------------------------------------------------------------ is-vs-eq
    "is-vs-eq": [
        {
            "task": "Write `compare(a, b)`: return `\"same object\"` when `a` and `b` are the very same object, `\"equal values\"` when they are different objects with equal values, otherwise `\"different\"`.",
            "starter": '''def compare(a, b):
    ...  # your code here

shelf = ["Dune"]
print(compare(shelf, shelf))
print(compare(["Dune"], ["Dune"]))
print(compare(["Dune"], ["Emma"]))
''',
            "solution": '''def compare(a, b):
    if a is b:
        return "same object"
    if a == b:
        return "equal values"
    return "different"

shelf = ["Dune"]
print(compare(shelf, shelf))
print(compare(["Dune"], ["Dune"]))
print(compare(["Dune"], ["Emma"]))
''',
            "tests": '''_shelf = ["Dune"]
assert compare(_shelf, _shelf) == "same object", "one list compared with itself is the same object (check `is` first)"
assert compare(["Dune"], ["Dune"]) == "equal values", "two separate lists with the same items are equal, but not the same object"
assert compare(["Dune"], ["Emma"]) == "different", "lists with different items are different"''',
            "hints": [
                "Check `is` first: an object is also `==` to itself, so the order of the checks matters.",
                "`if a is b: return \"same object\"`, then `if a == b: return \"equal values\"`, then `return \"different\"`.",
            ],
        },
        {
            "task": "`backup = suspects` copies nothing: both names point to one list, so adding a suspect changes the backup too. Make `backup` a real copy with `list(suspects)`, so `backup is suspects` becomes `False`.",
            "starter": '''suspects = ["Mustard", "Plum"]
backup = suspects
suspects.append("Scarlett")

print("suspects:", suspects)
print("backup:  ", backup)
print("same object?", backup is suspects)
''',
            "solution": '''suspects = ["Mustard", "Plum"]
backup = list(suspects)
suspects.append("Scarlett")

print("suspects:", suspects)
print("backup:  ", backup)
print("same object?", backup is suspects)
''',
            "tests": '''assert suspects == ["Mustard", "Plum", "Scarlett"], "suspects should still get the new name"
assert backup is not suspects, "backup must be a separate list, not a second name for suspects"
assert backup == ["Mustard", "Plum"], f"the backup should keep the two original suspects, got {backup}"''',
            "hints": [
                "`list(something)` builds a brand-new list with the same items.",
                "Change the second line to `backup = list(suspects)`.",
            ],
        },
    ],
    # ---------------------------------------------------------------- float-trap
    "float-trap": [
        {
            "task": "Two scales weighed the same piece of evidence. Write `same_weight(a, b)` that returns `True` when the two floats are equal for practical purposes. Use `math.isclose`, not `==`.",
            "starter": '''import math

def same_weight(a, b):
    return a == b

print(same_weight(0.1 + 0.2, 0.3))
''',
            "solution": '''import math

def same_weight(a, b):
    return math.isclose(a, b)

print(same_weight(0.1 + 0.2, 0.3))
''',
            "tests": '''assert same_weight(0.1 + 0.2, 0.3) is True, "0.1 + 0.2 and 0.3 should count as the same weight"
assert same_weight(1.5, 1.6) is False, "1.5 and 1.6 are clearly different weights"
assert "isclose" in __source__, "use math.isclose"''',
            "hints": [
                "`==` on floats fails because of tiny rounding errors. `math.isclose(a, b)` allows for them.",
                "`return math.isclose(a, b)`",
            ],
        },
        {
            "task": "`Decimal(0.1)` copies the float's tiny error. Fix `fee` so that three fees add up to exactly `Decimal(\"0.3\")`.",
            "starter": '''from decimal import Decimal

fee = Decimal(0.1)
total = fee + fee + fee
print(total)
''',
            "solution": '''from decimal import Decimal

fee = Decimal("0.1")
total = fee + fee + fee
print(total)
''',
            "tests": '''assert fee == Decimal("0.1"), f"fee should be exactly 0.1, got {fee}"
assert total == Decimal("0.3"), f"total should be exactly 0.3, got {total}"''',
            "hints": [
                "Create a Decimal from **text**, not from a float.",
                "`fee = Decimal(\"0.1\")`",
            ],
        },
    ],
    # ---------------------------------------------------------------- truthiness
    "truthiness": [
        {
            "task": "Write `blank_fields(record)` that returns a list of the keys whose value is falsy (empty text, empty list, `0`, `None`...). Use truthiness: no `len()` and no `== \"\"`.",
            "starter": '''def blank_fields(record):
    ...  # your code here

witness = {"name": "Plum", "alibi": "", "items": [], "age": 0, "notes": None, "room": " "}
print(blank_fields(witness))
''',
            "solution": '''def blank_fields(record):
    blanks = []
    for key in record:
        if not record[key]:
            blanks.append(key)
    return blanks

witness = {"name": "Plum", "alibi": "", "items": [], "age": 0, "notes": None, "room": " "}
print(blank_fields(witness))
''',
            "tests": '''_w = {"name": "Plum", "alibi": "", "items": [], "age": 0, "notes": None, "room": " "}
_got = blank_fields(_w)
assert _got == ["alibi", "items", "age", "notes"], f"expected ['alibi', 'items', 'age', 'notes'], got {_got}"
assert "room" not in _got, "a single space ' ' is not empty, so it is truthy"
assert blank_fields({}) == [], "an empty record has no blank fields"
assert "len(" not in __source__ and '== ""' not in __source__, "test the value directly with `if not value:`"''',
            "hints": [
                "Loop over the keys with `for key in record:` and test `if not record[key]:`.",
                "Start with `blanks = []`, append each key whose value is falsy, and return `blanks`.",
            ],
        },
    ],
    # ------------------------------------------------------------------- strings
    "strings": [
        {
            "task": "Write `initials(name)`: `initials(\"agatha mary christie\")` returns `\"A.M.C.\"`. Use `split()` to get the words and `join` to glue the letters together.",
            "starter": '''def initials(name):
    ...  # your code here

print(initials("agatha mary christie"))
''',
            "solution": '''def initials(name):
    letters = []
    for word in name.split():
        letters.append(word[0].upper())
    return ".".join(letters) + "."

print(initials("agatha mary christie"))
''',
            "tests": '''assert initials("agatha mary christie") == "A.M.C.", initials("agatha mary christie")
assert initials("Arthur Conan Doyle") == "A.C.D."
assert initials("Poirot") == "P.", "one word gives one initial"
assert "split(" in __source__ and "join(" in __source__, "use split() and join()"''',
            "hints": [
                "`name.split()` gives a list of words; `word[0]` is a word's first letter.",
                "Collect `word[0].upper()` into a list, then `return \".\".join(letters) + \".\"`.",
            ],
        },
        {
            "task": "A coded message is a *mirror* if it reads the same backwards, ignoring spaces and capitals. Write `is_mirror(code)` using `replace`, `lower` and the reversing slice `[::-1]`.",
            "starter": '''def is_mirror(code):
    ...  # your code here

print(is_mirror("Never odd or even"))
print(is_mirror("Clean Code"))
''',
            "solution": '''def is_mirror(code):
    cleaned = code.replace(" ", "").lower()
    return cleaned == cleaned[::-1]

print(is_mirror("Never odd or even"))
print(is_mirror("Clean Code"))
''',
            "tests": '''assert is_mirror("Never odd or even") is True, "spaces and capitals should be ignored"
assert is_mirror("Clean Code") is False
assert is_mirror("Anna") is True
assert "[::-1]" in __source__, "reverse the text with the slice [::-1]"''',
            "hints": [
                "First clean the text: `cleaned = code.replace(\" \", \"\").lower()`.",
                "Then `return cleaned == cleaned[::-1]`.",
            ],
        },
        {
            "task": "A secret note hides its message in every **second** character and ends with a `#` seal. Write `decode(secret)`: if the last character (`secret[-1]`) is not `#`, return `\"forged\"`; otherwise drop the seal and keep every second character.",
            "starter": '''def decode(secret):
    ...  # your code here

print(decode("BxUxTxLxExRx#"))
print(decode("BxUx?"))
''',
            "solution": '''def decode(secret):
    if secret[-1] != "#":
        return "forged"
    return secret[:-1][::2]

print(decode("BxUxTxLxExRx#"))
print(decode("BxUx?"))
''',
            "tests": '''assert decode("BxUxTxLxExRx#") == "BUTLER", decode("BxUxTxLxExRx#")
assert decode("Hzi#") == "Hi"
assert decode("BxUx?") == "forged", "no # at the end means the note is forged"
assert "[-1]" in __source__, "read the last character with a negative index, [-1]"''',
            "hints": [
                "`secret[-1]` is the last character. `secret[:-1]` is everything except it.",
                "A step of 2 keeps every second character: `return secret[:-1][::2]`.",
            ],
        },
    ],
    # ----------------------------------------------------------------- f-strings
    "f-strings": [
        {
            "task": "Write `fine_total(amount)` that returns `\"Total fines: $1,234.50\"` for `1234.5`: thousands separators **and** exactly 2 decimals, in one format spec.",
            "starter": '''def fine_total(amount):
    return f"Total fines: ${amount}"

print(fine_total(1234.5))
''',
            "solution": '''def fine_total(amount):
    return f"Total fines: ${amount:,.2f}"

print(fine_total(1234.5))
''',
            "tests": '''assert fine_total(1234.5) == "Total fines: $1,234.50", fine_total(1234.5)
assert fine_total(7) == "Total fines: $7.00", fine_total(7)
assert fine_total(1000000) == "Total fines: $1,000,000.00", fine_total(1000000)''',
            "hints": [
                "`,` adds separators and `.2f` gives 2 decimals. They can share one spec, comma first.",
                "`f\"Total fines: ${amount:,.2f}\"`",
            ],
        },
        {
            "task": "Write `progress(solved, total)` that returns `\"37.5% solved\"` for `progress(3, 8)`. Let the `%` format spec do the multiplying: no `* 100`.",
            "starter": '''def progress(solved, total):
    ...  # your code here

print(progress(3, 8))
''',
            "solution": '''def progress(solved, total):
    return f"{solved / total:.1%} solved"

print(progress(3, 8))
''',
            "tests": '''assert progress(3, 8) == "37.5% solved", progress(3, 8)
assert progress(1, 3) == "33.3% solved", progress(1, 3)
assert progress(4, 4) == "100.0% solved", progress(4, 4)
assert "100" not in __source__, "no * 100 needed: the % spec multiplies for you"''',
            "hints": [
                "Divide first, then format the fraction with `.1%` (one decimal, as a percentage).",
                "`return f\"{solved / total:.1%} solved\"`",
            ],
        },
        {
            "task": "Write `table_row(title, copies)` for a catalogue table: the title **centred** in 16 characters and the copies **right-aligned** in 4, between bars: `\"|   Clean Code   |   3|\"`.",
            "starter": '''def table_row(title, copies):
    return f"|{title}|{copies}|"

print(table_row("Clean Code", 3))
print(table_row("Dune", 12))
''',
            "solution": '''def table_row(title, copies):
    return f"|{title:^16}|{copies:>4}|"

print(table_row("Clean Code", 3))
print(table_row("Dune", 12))
''',
            "tests": '''assert table_row("Clean Code", 3) == "|   Clean Code   |   3|", repr(table_row("Clean Code", 3))
assert table_row("Dune", 12) == "|      Dune      |  12|", repr(table_row("Dune", 12))''',
            "hints": [
                "`^16` centres in 16 characters; `>4` right-aligns in 4.",
                "`f\"|{title:^16}|{copies:>4}|\"`",
            ],
        },
        {
            "task": "Print one debug line showing `suspect` and `room` with the `=` form (`suspect='Plum', room='Library'`), then print `locker` in hexadecimal with the `x` spec.",
            "starter": '''suspect = "Plum"
room = "Library"
locker = 3054

print(suspect, room)
print(locker)
''',
            "solution": '''suspect = "Plum"
room = "Library"
locker = 3054

print(f"{suspect=}, {room=}")
print(f"{locker:x}")
''',
            "tests": '''# Real Python prints suspect='Plum'; the in-browser Python prints suspect=Plum. Accept both.
assert "suspect='Plum'" in __output__ or "suspect=Plum" in __output__, "use the debug form {suspect=}"
assert "room='Library'" in __output__ or "room=Library" in __output__, "use the debug form {room=}"
assert "bee" in __output__, "3054 in hexadecimal is bee: use {locker:x}"
assert "=}" in __source__, "write the = inside the braces"''',
            "hints": [
                "`f\"{suspect=}\"` prints the name, `=` and the value with quotes.",
                "`print(f\"{suspect=}, {room=}\")` and `print(f\"{locker:x}\")`.",
            ],
        },
    ],
    # ---------------------------------------------------------------- containers
    "containers": [
        {
            "task": "`snapshot(shelves)` should freeze a record of the shelves, but `.copy()` is shallow, so later changes leak into it. Fix it with `copy.deepcopy`.",
            "starter": '''import copy

def snapshot(shelves):
    return shelves.copy()

shelves = [["Dune", "Emma"], ["Ulysses"]]
saved = snapshot(shelves)
shelves[0].append("Rebecca")
print(saved)
''',
            "solution": '''import copy

def snapshot(shelves):
    return copy.deepcopy(shelves)

shelves = [["Dune", "Emma"], ["Ulysses"]]
saved = snapshot(shelves)
shelves[0].append("Rebecca")
print(saved)
''',
            "tests": '''_s = [["a"], ["b"]]
_snap = snapshot(_s)
_s[0].append("x")
assert _snap == [["a"], ["b"]], f"the snapshot changed when a shelf changed: {_snap}"
assert _snap is not _s, "return a new outer list too"''',
            "hints": [
                "A shallow copy shares the inner lists. `copy.deepcopy` copies them as well.",
                "`return copy.deepcopy(shelves)`",
            ],
        },
        {
            "task": "Unpack `lineup` into `first, *others, last` in **one** line. Then the detective mixed up `prime` and `backup`: swap them in one line, with no temporary variable.",
            "starter": '''lineup = ["Plum", "Peacock", "Green", "Mustard"]
first = others = last = None   # replace with one unpacking line

prime = "Mustard"
backup = "Plum"
# swap prime and backup here

print(first, others, last)
print(prime, backup)
''',
            "solution": '''lineup = ["Plum", "Peacock", "Green", "Mustard"]
first, *others, last = lineup

prime = "Mustard"
backup = "Plum"
prime, backup = backup, prime

print(first, others, last)
print(prime, backup)
''',
            "tests": '''assert first == "Plum" and last == "Mustard", f"first and last should be Plum and Mustard, got {first} and {last}"
assert others == ["Peacock", "Green"], f"*others should collect the middle names into a list, got {others}"
assert "*others" in __source__, "use star unpacking: first, *others, last = lineup"
assert (prime, backup) == ("Plum", "Mustard"), f"prime and backup were not swapped: {prime}, {backup}"
_flat = __source__.replace(" ", "")
assert "prime,backup=backup,prime" in _flat or "backup,prime=prime,backup" in _flat, "swap in one line: prime, backup = backup, prime"''',
            "hints": [
                "`first, *others, last = lineup`: the starred name collects everything in the middle.",
                "Swap with `prime, backup = backup, prime`.",
            ],
        },
        {
            "task": "Write `fix_lineup(names)`: `insert` `\"Inspector\"` at the front, `remove` `\"Butler\"`, then return the names `sorted` by length, shortest first.",
            "starter": '''def fix_lineup(names):
    ...  # your code here

print(fix_lineup(["Plum", "Butler", "Peacock", "Green"]))
''',
            "solution": '''def fix_lineup(names):
    names.insert(0, "Inspector")
    names.remove("Butler")
    return sorted(names, key=len)

print(fix_lineup(["Plum", "Butler", "Peacock", "Green"]))
''',
            "tests": '''_names = ["Plum", "Butler", "Peacock", "Green"]
_got = fix_lineup(_names)
assert _got == ["Plum", "Green", "Peacock", "Inspector"], f"expected shortest to longest without Butler, got {_got}"
assert _names[0] == "Inspector", "use insert(0, ...) to put the Inspector at the front of the list"
assert "remove(" in __source__ and "key=len" in __source__, "use remove() and sorted(..., key=len)"''',
            "hints": [
                "`names.insert(0, \"Inspector\")` and `names.remove(\"Butler\")` change the list in place.",
                "`return sorted(names, key=len)`",
            ],
        },
        {
            "task": "Two branches keep ISBN lists. Write `missing(central, branch)`: a sorted list of ISBNs central has but branch lacks (set `-`). Write `all_isbns(central, branch)`: a sorted list of every ISBN in either (set `|`).",
            "starter": '''def missing(central, branch):
    ...  # your code here

def all_isbns(central, branch):
    ...  # your code here

central = ["111", "222", "333", "222"]
branch = ["333", "444"]
print(missing(central, branch))
print(all_isbns(central, branch))
''',
            "solution": '''def missing(central, branch):
    return sorted(set(central) - set(branch))

def all_isbns(central, branch):
    return sorted(set(central) | set(branch))

central = ["111", "222", "333", "222"]
branch = ["333", "444"]
print(missing(central, branch))
print(all_isbns(central, branch))
''',
            "tests": '''assert missing(["111", "222", "333", "222"], ["333", "444"]) == ["111", "222"], missing(["111", "222", "333", "222"], ["333", "444"])
assert all_isbns(["111", "222", "333", "222"], ["333", "444"]) == ["111", "222", "333", "444"], "every ISBN once, sorted"
assert missing([], ["1"]) == [] and all_isbns([], []) == []''',
            "hints": [
                "Turn both lists into sets. `-` keeps what is only in the left set; `|` keeps everything.",
                "`return sorted(set(central) - set(branch))` and `return sorted(set(central) | set(branch))`.",
            ],
        },
    ],
    # --------------------------------------------------------------------- dicts
    "dicts": [
        {
            "task": "Write `member_settings(overrides)` that returns `DEFAULTS` merged with `overrides` using `|` (overrides win, `DEFAULTS` stays unchanged). Then write `fine_rate(settings)` that returns the `\"fine_rate\"` value, or `0.5` when it is missing, using `.get`.",
            "starter": '''DEFAULTS = {"loan_days": 14, "max_loans": 3}

def member_settings(overrides):
    ...  # your code here

def fine_rate(settings):
    ...  # your code here

print(member_settings({"max_loans": 5}))
print(fine_rate({}))
''',
            "solution": '''DEFAULTS = {"loan_days": 14, "max_loans": 3}

def member_settings(overrides):
    return DEFAULTS | overrides

def fine_rate(settings):
    return settings.get("fine_rate", 0.5)

print(member_settings({"max_loans": 5}))
print(fine_rate({}))
''',
            "tests": '''assert member_settings({"max_loans": 5}) == {"loan_days": 14, "max_loans": 5}, member_settings({"max_loans": 5})
assert member_settings({}) == {"loan_days": 14, "max_loans": 3}
assert DEFAULTS == {"loan_days": 14, "max_loans": 3}, "do not change DEFAULTS itself"
assert fine_rate({}) == 0.5, "use 0.5 when there is no fine_rate"
assert fine_rate({"fine_rate": 1.0}) == 1.0
assert "|" in __source__ and ".get(" in __source__, "use | to merge and .get() with a default"''',
            "hints": [
                "`a | b` builds a new dict; keys from `b` win.",
                "`return DEFAULTS | overrides` and `return settings.get(\"fine_rate\", 0.5)`.",
            ],
        },
        {
            "task": "Witnesses reported which suspect they saw. Using `Counter`, write `most_seen(sightings)` that returns the name seen most often, and `times_seen(sightings, name)` that returns the count (0 for someone never seen).",
            "starter": '''from collections import Counter

def most_seen(sightings):
    ...  # your code here

def times_seen(sightings, name):
    ...  # your code here

seen = ["Plum", "Green", "Plum", "Peacock", "Plum", "Green"]
print(most_seen(seen), times_seen(seen, "Green"), times_seen(seen, "White"))
''',
            "solution": '''from collections import Counter

def most_seen(sightings):
    return Counter(sightings).most_common(1)[0][0]

def times_seen(sightings, name):
    return Counter(sightings)[name]

seen = ["Plum", "Green", "Plum", "Peacock", "Plum", "Green"]
print(most_seen(seen), times_seen(seen, "Green"), times_seen(seen, "White"))
''',
            "tests": '''_seen = ["Plum", "Green", "Plum", "Peacock", "Plum", "Green"]
assert most_seen(_seen) == "Plum", most_seen(_seen)
assert times_seen(_seen, "Green") == 2, times_seen(_seen, "Green")
assert times_seen(_seen, "White") == 0, "someone never seen has a count of 0"
assert "Counter(" in __source__, "use Counter"''',
            "hints": [
                "`Counter(sightings).most_common(1)` gives a list with one `(name, count)` pair.",
                "Take `[0][0]` of that for the name. A Counter returns 0 for missing keys, so `Counter(sightings)[name]` is the count.",
            ],
        },
        {
            "task": "Write `last_visitors(log, n)` that returns a list of the last `n` visitors in the door log, using a `deque` with `maxlen`.",
            "starter": '''from collections import deque

def last_visitors(log, n):
    ...  # your code here

print(last_visitors(["Ada", "Linus", "Grace", "Alan"], 2))
''',
            "solution": '''from collections import deque

def last_visitors(log, n):
    recent = deque(maxlen=n)
    for name in log:
        recent.append(name)
    return list(recent)

print(last_visitors(["Ada", "Linus", "Grace", "Alan"], 2))
''',
            "tests": '''assert last_visitors(["Ada", "Linus", "Grace", "Alan"], 2) == ["Grace", "Alan"], last_visitors(["Ada", "Linus", "Grace", "Alan"], 2)
assert last_visitors(["Ada"], 3) == ["Ada"], "fewer visitors than n: return them all"
assert type(last_visitors([], 2)) is list, "return a plain list"
assert "maxlen" in __source__, "use deque(maxlen=n)"''',
            "hints": [
                "`recent = deque(maxlen=n)` drops the oldest item each time a new one arrives past the limit.",
                "Append every name from the log, then `return list(recent)`.",
            ],
        },
        {
            "task": "Create `Clue = namedtuple(\"Clue\", [\"item\", \"room\"])`. Then write `describe(clue)` that returns `\"candlestick found in the library\"`, reading the fields by name (`.item`, `.room`).",
            "starter": '''from collections import namedtuple

Clue = None  # create the namedtuple type here

def describe(clue):
    ...  # your code here

print(describe(Clue("candlestick", "library")))
''',
            "solution": '''from collections import namedtuple

Clue = namedtuple("Clue", ["item", "room"])

def describe(clue):
    return f"{clue.item} found in the {clue.room}"

print(describe(Clue("candlestick", "library")))
''',
            "tests": '''_c = Clue("rope", "hall")
assert _c.item == "rope" and _c.room == "hall", "Clue needs the fields item and room"
assert _c == ("rope", "hall"), "a namedtuple is still a tuple"
assert describe(Clue("candlestick", "library")) == "candlestick found in the library", describe(Clue("candlestick", "library"))
assert ".room" in __source__, "read the fields by name: clue.item and clue.room"''',
            "hints": [
                "`Clue = namedtuple(\"Clue\", [\"item\", \"room\"])` makes a tuple type with named fields.",
                "`return f\"{clue.item} found in the {clue.room}\"`",
            ],
        },
    ],
    # --------------------------------------------------------------------- loops
    "loops": [
        {
            "task": "Write `numbered(titles)` that returns `[\"1. Dune\", \"2. Emma\"]` for `[\"Dune\", \"Emma\"]`. Use `enumerate` with `start=1`, not a counter variable.",
            "starter": '''def numbered(titles):
    ...  # your code here

print(numbered(["Dune", "Emma", "Ulysses"]))
''',
            "solution": '''def numbered(titles):
    lines = []
    for i, title in enumerate(titles, start=1):
        lines.append(f"{i}. {title}")
    return lines

print(numbered(["Dune", "Emma", "Ulysses"]))
''',
            "tests": '''assert numbered(["Dune", "Emma", "Ulysses"]) == ["1. Dune", "2. Emma", "3. Ulysses"], numbered(["Dune", "Emma", "Ulysses"])
assert numbered([]) == []
assert "enumerate(" in __source__, "use enumerate"''',
            "hints": [
                "`for i, title in enumerate(titles, start=1):` gives 1, 2, 3... alongside each title.",
                "Append `f\"{i}. {title}\"` to a list and return it.",
            ],
        },
        {
            "task": "Write `alibi_report(suspects, alibis)` that walks both lists side by side with `zip` and returns lines like `\"Plum: in the library\"`.",
            "starter": '''def alibi_report(suspects, alibis):
    ...  # your code here

print(alibi_report(["Plum", "Green"], ["in the library", "at the races"]))
''',
            "solution": '''def alibi_report(suspects, alibis):
    lines = []
    for name, alibi in zip(suspects, alibis):
        lines.append(f"{name}: {alibi}")
    return lines

print(alibi_report(["Plum", "Green"], ["in the library", "at the races"]))
''',
            "tests": '''assert alibi_report(["Plum", "Green"], ["in the library", "at the races"]) == ["Plum: in the library", "Green: at the races"], alibi_report(["Plum", "Green"], ["in the library", "at the races"])
assert alibi_report([], []) == []
assert "zip(" in __source__, "use zip"''',
            "hints": [
                "`for name, alibi in zip(suspects, alibis):` gives one pair per lap.",
                "Append `f\"{name}: {alibi}\"` to a list and return it.",
            ],
        },
        {
            "task": "A member pays `weekly` off a `fine` every week. Write `weeks_to_pay(fine, weekly)` with a `while` loop that counts the weeks until nothing is owed.",
            "starter": '''def weeks_to_pay(fine, weekly):
    ...  # your code here

print(weeks_to_pay(100, 30))   # 4
''',
            "solution": '''def weeks_to_pay(fine, weekly):
    weeks = 0
    while fine > 0:
        fine = fine - weekly
        weeks += 1
    return weeks

print(weeks_to_pay(100, 30))
''',
            "tests": '''assert weeks_to_pay(100, 30) == 4, weeks_to_pay(100, 30)
assert weeks_to_pay(60, 30) == 2, "60 paid at 30 a week takes exactly 2 weeks"
assert weeks_to_pay(0, 10) == 0, "nothing owed means 0 weeks"
assert "while" in __source__, "use a while loop"''',
            "hints": [
                "Keep going `while fine > 0:`; each lap subtracts one payment and adds one week.",
                "`weeks = 0`, then inside the loop `fine = fine - weekly` and `weeks += 1`; return `weeks`.",
            ],
        },
    ],
    # -------------------------------------------------------------- control-flow
    "control-flow": [
        {
            "task": "Write `find_overdue(loans)` (a list of day counts). At the first value over 14, set `message = f\"overdue: {days} days\"` and `break`. Use the **loop's** `else` to set `message = \"all on time\"`. Return `message`.",
            "starter": '''def find_overdue(loans):
    for days in loans:
        ...  # your code here
    return message

print(find_overdue([3, 20, 30]))
print(find_overdue([1, 2]))
''',
            "solution": '''def find_overdue(loans):
    for days in loans:
        if days > 14:
            message = f"overdue: {days} days"
            break
    else:
        message = "all on time"
    return message

print(find_overdue([3, 20, 30]))
print(find_overdue([1, 2]))
''',
            "tests": '''assert find_overdue([3, 20, 30]) == "overdue: 20 days", "report the first overdue loan only"
assert find_overdue([1, 2]) == "all on time"
assert find_overdue([]) == "all on time", "an empty list never breaks, so the else runs"
assert "break" in __source__ and "else:" in __source__, "use break and the for loop's else"''',
            "hints": [
                "The `else:` lines up with `for`, not with `if`. It runs only when the loop never hit `break`.",
                "Inside the loop: `if days > 14:` set the message and `break`. After the loop: `else: message = \"all on time\"`.",
            ],
        },
        {
            "task": "Write `classify(evidence)` with `match` and **dict** patterns: a fingerprint with `\"match\"` of 90 or more → `\"strong fingerprint\"`; any other fingerprint → `\"weak fingerprint (<match>%)\"`; a witness → `\"witness: <name>\"`; anything else → `\"unknown\"`.",
            "starter": '''def classify(evidence):
    match evidence:
        case _:
            return "unknown"

print(classify({"kind": "fingerprint", "match": 95}))
print(classify({"kind": "fingerprint", "match": 40}))
print(classify({"kind": "witness", "name": "Mrs White"}))
''',
            "solution": '''def classify(evidence):
    match evidence:
        case {"kind": "fingerprint", "match": score} if score >= 90:
            return "strong fingerprint"
        case {"kind": "fingerprint", "match": score}:
            return f"weak fingerprint ({score}%)"
        case {"kind": "witness", "name": name}:
            return f"witness: {name}"
        case _:
            return "unknown"

print(classify({"kind": "fingerprint", "match": 95}))
print(classify({"kind": "fingerprint", "match": 40}))
print(classify({"kind": "witness", "name": "Mrs White"}))
''',
            "tests": '''assert classify({"kind": "fingerprint", "match": 95}) == "strong fingerprint"
assert classify({"kind": "fingerprint", "match": 90}) == "strong fingerprint", "90 counts as strong"
assert classify({"kind": "fingerprint", "match": 40}) == "weak fingerprint (40%)", classify({"kind": "fingerprint", "match": 40})
assert classify({"kind": "witness", "name": "Mrs White"}) == "witness: Mrs White"
assert classify({"kind": "rumour"}) == "unknown"
assert "case {" in __source__, "use dict patterns such as case {\\"kind\\": ...}"''',
            "hints": [
                "`case {\"kind\": \"fingerprint\", \"match\": score} if score >= 90:` captures the score and checks it with a guard.",
                "Order matters: the guarded fingerprint case first, then the plain fingerprint case, then `{\"kind\": \"witness\", \"name\": name}`, then `case _`.",
            ],
        },
    ],
    # ----------------------------------------------------------------- arguments
    "arguments": [
        {
            "task": "The body of `find_cases` works, but its signature lets callers write unreadable calls. Change **only the signature** so `cases` and `query` are positional-only (`/`), `limit` keeps its default of 2, and `exact` is keyword-only (`*`).",
            "starter": '''def find_cases(cases, query, limit=2, exact=False):
    found = []
    for case in cases:
        if exact:
            hit = case == query
        else:
            hit = query.lower() in case.lower()
        if hit:
            found.append(case)
            if len(found) == limit:
                break
    return found

cases = ["Poison Pen", "The Poisoned Chalice", "Poison Ivy", "Lost Ledger"]
print(find_cases(cases, "poison"))
print(find_cases(cases, "Poison Ivy", exact=True))
''',
            "solution": '''def find_cases(cases, query, /, limit=2, *, exact=False):
    found = []
    for case in cases:
        if exact:
            hit = case == query
        else:
            hit = query.lower() in case.lower()
        if hit:
            found.append(case)
            if len(found) == limit:
                break
    return found

cases = ["Poison Pen", "The Poisoned Chalice", "Poison Ivy", "Lost Ledger"]
print(find_cases(cases, "poison"))
print(find_cases(cases, "Poison Ivy", exact=True))
''',
            "tests": '''_cases = ["Poison Pen", "The Poisoned Chalice", "Poison Ivy", "Lost Ledger"]
assert find_cases(_cases, "poison") == ["Poison Pen", "The Poisoned Chalice"], "limit should default to 2"
assert find_cases(_cases, "poison", limit=3) == ["Poison Pen", "The Poisoned Chalice", "Poison Ivy"]
assert find_cases(_cases, "Poison Ivy", exact=True) == ["Poison Ivy"]
try:
    find_cases(_cases, query="poison")
    raise AssertionError("query should be positional-only: add / after it")
except TypeError:
    pass
try:
    find_cases(_cases, "poison", 2, True)
    raise AssertionError("exact should be keyword-only: add * before it")
except TypeError:
    pass''',
            "hints": [
                "Put `/` right after the last positional-only parameter, and `*` right before the first keyword-only one.",
                "`def find_cases(cases, query, /, limit=2, *, exact=False):`",
            ],
        },
    ],
    # --------------------------------------------------------------------- scope
    "scope": [
        {
            "task": "`fee_for` crashes with `UnboundLocalError`: assigning to `late_fee` inside the function makes it local for the whole function. Fix it by storing the result in a **new** local name, so the global `late_fee` is only read. Don't use `global`.",
            "starter": '''late_fee = 2

def fee_for(days):
    late_fee = late_fee * days
    return late_fee

print(fee_for(3))
''',
            "solution": '''late_fee = 2

def fee_for(days):
    total = late_fee * days
    return total

print(fee_for(3))
''',
            "tests": '''assert fee_for(3) == 6, "3 days at 2 per day is 6"
assert fee_for(10) == 20
assert late_fee == 2, "the global late_fee should not change"
assert "global" not in __source__, "no global needed: just use a different local name"''',
            "hints": [
                "Reading a global inside a function is fine. The problem is *assigning* to the same name.",
                "`total = late_fee * days`, then `return total`.",
            ],
        },
        {
            "task": "Someone named a variable `max`, which hides the built-in `max()` function (the B in LEGB is found last). Rename the variable to `max_loans` so `heaviest(weights)` works again.",
            "starter": '''max = 3   # the most loans a member may have

def heaviest(weights):
    return max(weights)

print("Loan limit:", max)
print(heaviest([2.5, 7.1, 4.0]))
''',
            "solution": '''max_loans = 3   # the most loans a member may have

def heaviest(weights):
    return max(weights)

print("Loan limit:", max_loans)
print(heaviest([2.5, 7.1, 4.0]))
''',
            "tests": '''assert heaviest([2.5, 7.1, 4.0]) == 7.1, "heaviest should use the built-in max()"
assert max_loans == 3, "keep the limit, now called max_loans"''',
            "hints": [
                "Python finds your global `max` before the built-in one, and `3(...)` cannot be called.",
                "Rename both uses: `max_loans = 3` and `print(\"Loan limit:\", max_loans)`.",
            ],
        },
    ],
    # --------------------------------------------------------------- first-class
    "first-class": [
        {
            "task": "Store the three functions in a dict `ACTIONS` (keys `\"arrest\"`, `\"question\"`, `\"release\"`, values the functions themselves, not called). Then write `act(command, name)` that looks up and calls the right one, or returns `\"unknown command\"`.",
            "starter": '''def arrest(name): return f"{name} arrested"
def question(name): return f"{name} questioned"
def release(name): return f"{name} released"

ACTIONS = {}  # your code here

def act(command, name):
    ...  # your code here

print(act("question", "Plum"))
''',
            "solution": '''def arrest(name): return f"{name} arrested"
def question(name): return f"{name} questioned"
def release(name): return f"{name} released"

ACTIONS = {"arrest": arrest, "question": question, "release": release}

def act(command, name):
    action = ACTIONS.get(command)
    if action is None:
        return "unknown command"
    return action(name)

print(act("question", "Plum"))
''',
            "tests": '''assert ACTIONS.get("arrest") is arrest, "store the function itself (no brackets) under the key 'arrest'"
assert ACTIONS.get("release") is release and ACTIONS.get("question") is question
assert act("question", "Plum") == "Plum questioned", act("question", "Plum")
assert act("arrest", "Green") == "Green arrested"
assert act("dance", "Plum") == "unknown command"''',
            "hints": [
                "`ACTIONS = {\"arrest\": arrest, ...}`. No `()`, so nothing is called yet.",
                "In `act`: `action = ACTIONS.get(command)`; if it is `None` return `\"unknown command\"`, else `return action(name)`.",
            ],
        },
        {
            "task": "`late_fee(days, rate)` is given. Make `student_fee` with `partial`, fixing `rate=0.25`. Then write a factory `make_fee(rate)` that **returns a new function** taking only `days`.",
            "starter": '''from functools import partial

def late_fee(days, rate):
    return days * rate

student_fee = None  # use partial

def make_fee(rate):
    ...  # return a function of days

adult_fee = make_fee(1.0)
print(student_fee(8), adult_fee(3))
''',
            "solution": '''from functools import partial

def late_fee(days, rate):
    return days * rate

student_fee = partial(late_fee, rate=0.25)

def make_fee(rate):
    def fee(days):
        return days * rate
    return fee

adult_fee = make_fee(1.0)
print(student_fee(8), adult_fee(3))
''',
            "tests": '''assert student_fee(8) == 2.0, "8 days at 0.25 is 2.0"
assert "partial(" in __source__, "build student_fee with partial"
_f = make_fee(0.5)
assert callable(_f), "make_fee must return a function"
assert _f(4) == 2.0 and make_fee(1.0)(3) == 3.0, "each function should remember its own rate"''',
            "hints": [
                "`partial(late_fee, rate=0.25)` gives a function where only `days` is left to pass.",
                "Inside `make_fee`, define `def fee(days): return days * rate` and `return fee` (no brackets).",
            ],
        },
        {
            "task": "Write `by_motive(suspects)` that returns the names sorted by `\"motive\"`, highest first. Use `itemgetter` as the key with `reverse=True`, no lambda.",
            "starter": '''from operator import itemgetter

suspects = [
    {"name": "Plum", "motive": 6},
    {"name": "Scarlett", "motive": 9},
    {"name": "Green", "motive": 3},
]

def by_motive(suspects):
    ...  # your code here

print(by_motive(suspects))
''',
            "solution": '''from operator import itemgetter

suspects = [
    {"name": "Plum", "motive": 6},
    {"name": "Scarlett", "motive": 9},
    {"name": "Green", "motive": 3},
]

def by_motive(suspects):
    ordered = sorted(suspects, key=itemgetter("motive"), reverse=True)
    names = []
    for s in ordered:
        names.append(s["name"])
    return names

print(by_motive(suspects))
''',
            "tests": '''assert by_motive(suspects) == ["Scarlett", "Plum", "Green"], by_motive(suspects)
assert by_motive([]) == []
assert "itemgetter(" in __source__ and "lambda" not in __source__, "use itemgetter(\\"motive\\") as the key, not a lambda"''',
            "hints": [
                "`sorted(suspects, key=itemgetter(\"motive\"), reverse=True)` sorts the dicts high to low.",
                "Then loop over the sorted dicts and collect each `s[\"name\"]`.",
            ],
        },
    ],
    # --------------------------------------------------------- map-filter-reduce
    "map-filter-reduce": [
        {
            "task": "Write `with_fee(prices)` that adds a 5-rupee handling fee to every price using `map` (and `list(...)` to collect the results).",
            "starter": '''def with_fee(prices):
    ...  # your code here

print(with_fee([100, 250, 40]))
''',
            "solution": '''def with_fee(prices):
    return list(map(lambda p: p + 5, prices))

print(with_fee([100, 250, 40]))
''',
            "tests": '''assert with_fee([100, 250, 40]) == [105, 255, 45], with_fee([100, 250, 40])
assert with_fee([]) == []
assert "map(" in __source__, "use map"''',
            "hints": [
                "`map(fn, items)` applies `fn` to every item; `lambda p: p + 5` is the function.",
                "`return list(map(lambda p: p + 5, prices))`",
            ],
        },
        {
            "task": "Write `long_loans(days)` that keeps only the loans longer than 14 days, using `filter`.",
            "starter": '''def long_loans(days):
    ...  # your code here

print(long_loans([3, 21, 14, 30]))
''',
            "solution": '''def long_loans(days):
    return list(filter(lambda d: d > 14, days))

print(long_loans([3, 21, 14, 30]))
''',
            "tests": '''assert long_loans([3, 21, 14, 30]) == [21, 30], long_loans([3, 21, 14, 30])
assert long_loans([1, 2]) == []
assert "filter(" in __source__, "use filter"''',
            "hints": [
                "`filter(fn, items)` keeps items where `fn` returns True.",
                "`return list(filter(lambda d: d > 14, days))`",
            ],
        },
    ],
    # ------------------------------------------------------------ comprehensions
    "comprehensions": [
        {
            "task": "Write `isbn_index(books)` that returns `{isbn: title}` using a **dict comprehension**.",
            "starter": '''books = [
    {"isbn": "111", "title": "Dune"},
    {"isbn": "222", "title": "Emma"},
]

def isbn_index(books):
    ...  # your code here

print(isbn_index(books))
''',
            "solution": '''books = [
    {"isbn": "111", "title": "Dune"},
    {"isbn": "222", "title": "Emma"},
]

def isbn_index(books):
    return {b["isbn"]: b["title"] for b in books}

print(isbn_index(books))
''',
            "tests": '''import re
assert isbn_index(books) == {"111": "Dune", "222": "Emma"}, isbn_index(books)
assert isbn_index([]) == {}
assert re.search(r"\\{[^}]*:[^}]* for ", __source__), "use a dict comprehension: {key: value for ...}"''',
            "hints": [
                "A dict comprehension looks like `{key: value for item in items}`.",
                "`return {b[\"isbn\"]: b[\"title\"] for b in books}`",
            ],
        },
        {
            "task": "The search log has messy room names. Write `rooms_searched(log)` that returns the **set** of rooms, stripped and lowercased, using a set comprehension.",
            "starter": '''def rooms_searched(log):
    ...  # your code here

print(rooms_searched(["Library", " library", "Hall", "HALL ", "Study"]))
''',
            "solution": '''def rooms_searched(log):
    return {room.strip().lower() for room in log}

print(rooms_searched(["Library", " library", "Hall", "HALL ", "Study"]))
''',
            "tests": '''import re
assert rooms_searched(["Library", " library", "Hall", "HALL ", "Study"]) == {"library", "hall", "study"}, rooms_searched(["Library", " library", "Hall", "HALL ", "Study"])
assert rooms_searched([]) == set()
assert re.search(r"\\{[^:}]* for ", __source__), "use a set comprehension: {expression for ...}"''',
            "hints": [
                "Curly braces without a colon build a set, so duplicates vanish.",
                "`return {room.strip().lower() for room in log}`",
            ],
        },
        {
            "task": "Write `total_pages(books)` that passes a **generator expression** straight to `sum()`, so no list is built.",
            "starter": '''def total_pages(books):
    ...  # your code here

print(total_pages([{"pages": 464}, {"pages": 448}]))
''',
            "solution": '''def total_pages(books):
    return sum(b["pages"] for b in books)

print(total_pages([{"pages": 464}, {"pages": 448}]))
''',
            "tests": '''assert total_pages([{"pages": 464}, {"pages": 448}]) == 912, total_pages([{"pages": 464}, {"pages": 448}])
assert total_pages([]) == 0
_flat = __source__.replace(" ", "")
assert "sum(" in _flat and "sum([" not in _flat, "write sum(x for ...) with no square brackets"''',
            "hints": [
                "`sum(... for b in books)` needs no extra brackets: the generator expression goes right inside.",
                "`return sum(b[\"pages\"] for b in books)`",
            ],
        },
        {
            "task": "Each case has a list of suspects. Write `all_suspects(cases)` that flattens them into one list with a single comprehension that has **two** `for` parts.",
            "starter": '''def all_suspects(cases):
    ...  # your code here

print(all_suspects([["Plum", "Green"], ["Peacock"], []]))
''',
            "solution": '''def all_suspects(cases):
    return [name for case in cases for name in case]

print(all_suspects([["Plum", "Green"], ["Peacock"], []]))
''',
            "tests": '''assert all_suspects([["Plum", "Green"], ["Peacock"], []]) == ["Plum", "Green", "Peacock"], all_suspects([["Plum", "Green"], ["Peacock"], []])
assert all_suspects([]) == []
assert __source__.count(" for ") >= 2 and "append" not in __source__, "one comprehension with two for parts, no append loop"''',
            "hints": [
                "Write the `for` parts in the same order as nested loops: outer list first, then the inner one.",
                "`return [name for case in cases for name in case]`",
            ],
        },
    ],
    # ---------------------------------------------------------------- decorators
    "decorators": [
        {
            "task": "Write an `audited` decorator that appends `\"start <name>\"` to `audit_log` before the call and `\"end <name>\"` **even if the function raises** (use `finally`). Return the original result and keep the name with `@wraps`.",
            "starter": '''from functools import wraps

audit_log = []

def audited(fn):
    ...  # your code here

@audited
def close_case(case_id):
    return f"{case_id} closed"

print(close_case("C7"), audit_log)
''',
            "solution": '''from functools import wraps

audit_log = []

def audited(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        audit_log.append(f"start {fn.__name__}")
        try:
            return fn(*args, **kwargs)
        finally:
            audit_log.append(f"end {fn.__name__}")
    return wrapper

@audited
def close_case(case_id):
    return f"{case_id} closed"

print(close_case("C7"), audit_log)
''',
            "tests": '''audit_log.clear()
@audited
def _ok(x):
    return x * 2
@audited
def _boom():
    raise ValueError("no evidence")
assert _ok(4) == 8, "the wrapper must return the original result"
try:
    _boom()
except ValueError:
    pass
assert audit_log == ["start _ok", "end _ok", "start _boom", "end _boom"], f"the end entry must be written even on errors: {audit_log}"
assert _ok.__name__ == "_ok", "use functools.wraps"''',
            "hints": [
                "Inside `wrapper`: append the start entry, then `try: return fn(*args, **kwargs)`.",
                "Add `finally: audit_log.append(f\"end {fn.__name__}\")` and decorate `wrapper` with `@wraps(fn)`.",
            ],
        },
        {
            "task": "Stacked decorators apply bottom-up. Reorder them so `headline(\"the missing ledger\")` gives `\"case: THE MISSING LEDGER\"`. Then build `manual` from `plain_headline` by calling the decorators yourself (no `@`) so it gives the same result.",
            "starter": '''from functools import wraps

def shout(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        return fn(*args, **kwargs).upper()
    return wrapper

def tag(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        return "case: " + fn(*args, **kwargs)
    return wrapper

@shout
@tag
def headline(title):
    return title

def plain_headline(title):
    return title

manual = plain_headline   # wrap it by hand

print(headline("the missing ledger"))
print(manual("the missing ledger"))
''',
            "solution": '''from functools import wraps

def shout(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        return fn(*args, **kwargs).upper()
    return wrapper

def tag(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        return "case: " + fn(*args, **kwargs)
    return wrapper

@tag
@shout
def headline(title):
    return title

def plain_headline(title):
    return title

manual = tag(shout(plain_headline))

print(headline("the missing ledger"))
print(manual("the missing ledger"))
''',
            "tests": '''assert headline("the missing ledger") == "case: THE MISSING LEDGER", headline("the missing ledger")
assert manual("the missing ledger") == "case: THE MISSING LEDGER", manual("the missing ledger")
assert plain_headline("x") == "x", "leave plain_headline itself unchanged"''',
            "hints": [
                "The decorator nearest the `def` runs on the function first. You want `shout` first, then `tag` on the outside.",
                "Put `@tag` above `@shout`, and write `manual = tag(shout(plain_headline))`.",
            ],
        },
    ],
    # ---------------------------------------------------------------- generators
    "generators": [
        {
            "task": "Build a lazy pipeline. `overdue(loans)` yields only loans with more than 14 `days`; `names(loans)` yields each loan's `member`. Chain them into `report = names(overdue(loans))` (a generator, not a list).",
            "starter": '''loans = [
    {"member": "Ada", "days": 20},
    {"member": "Linus", "days": 3},
    {"member": "Grace", "days": 15},
]

def overdue(loans):
    ...  # your code here

def names(loans):
    ...  # your code here

report = None  # chain the two generators
for name in names(overdue(loans)):
    print(name)
''',
            "solution": '''loans = [
    {"member": "Ada", "days": 20},
    {"member": "Linus", "days": 3},
    {"member": "Grace", "days": 15},
]

def overdue(loans):
    for loan in loans:
        if loan["days"] > 14:
            yield loan

def names(loans):
    for loan in loans:
        yield loan["member"]

report = names(overdue(loans))
for name in names(overdue(loans)):
    print(name)
''',
            "tests": '''import types
assert isinstance(overdue([]), types.GeneratorType), "overdue must use yield"
assert isinstance(names([]), types.GeneratorType), "names must use yield"
assert isinstance(report, types.GeneratorType), "report should be the chained generator, not a list"
assert list(report) == ["Ada", "Grace"], "the pipeline should give Ada and Grace"''',
            "hints": [
                "Each stage loops over its input and `yield`s what it passes on.",
                "`overdue`: `if loan[\"days\"] > 14: yield loan`. `names`: `yield loan[\"member\"]`. Then `report = names(overdue(loans))`.",
            ],
        },
        {
            "task": "Write a generator `case_numbers(start)` that yields `\"CASE-<n>\"` **forever** (`while True`). That is safe, because nothing runs until someone asks. Then fill `first_three` with the first three from `case_numbers(1)` using a `for` loop and `break`.",
            "starter": '''def case_numbers(start):
    ...  # your code here

first_three = []
# loop over case_numbers(1) and stop after three

print(first_three)
''',
            "solution": '''def case_numbers(start):
    n = start
    while True:
        yield f"CASE-{n}"
        n += 1

first_three = []
for case in case_numbers(1):
    first_three.append(case)
    if len(first_three) == 3:
        break

print(first_three)
''',
            "tests": '''import types
assert isinstance(case_numbers(1), types.GeneratorType), "case_numbers must use yield"
assert first_three == ["CASE-1", "CASE-2", "CASE-3"], first_three
_got = []
for _c in case_numbers(7):
    _got.append(_c)
    if len(_got) == 2:
        break
assert _got == ["CASE-7", "CASE-8"], f"start counting at start: {_got}"''',
            "hints": [
                "`n = start`, then `while True: yield f\"CASE-{n}\"` and `n += 1`.",
                "`for case in case_numbers(1):` append each one and `break` once `len(first_three) == 3`.",
            ],
        },
    ],
    # ---------------------------------------------------------- context-managers
    "context-managers": [
        {
            "task": "Write `@contextmanager evidence_bag(label, shelf)`: it yields a new empty list (the bag, used with `as`), and after the block it stores the bag on the shelf: `shelf[label] = bag`.",
            "starter": '''from contextlib import contextmanager

@contextmanager
def evidence_bag(label, shelf):
    ...  # your code here
    yield

shelf = {}
with evidence_bag("Case 7", shelf) as bag:
    bag.append("glove")
    bag.append("key")
print(shelf)
''',
            "solution": '''from contextlib import contextmanager

@contextmanager
def evidence_bag(label, shelf):
    bag = []
    yield bag
    shelf[label] = bag

shelf = {}
with evidence_bag("Case 7", shelf) as bag:
    bag.append("glove")
    bag.append("key")
print(shelf)
''',
            "tests": '''_shelf = {}
with evidence_bag("C1", _shelf) as _bag:
    assert _bag == [], "the bag you yield should start as an empty list"
    _bag.append("hair")
    assert "C1" not in _shelf, "store the bag only after the with block ends"
assert _shelf == {"C1": ["hair"]}, f"after the block the shelf should hold the bag: {_shelf}"''',
            "hints": [
                "Whatever you `yield` becomes the `as` name in the `with` line.",
                "`bag = []`, `yield bag`, then `shelf[label] = bag` after the yield.",
            ],
        },
        {
            "task": "Write `@contextmanager transaction(ledger)`: yield a `pending` list. If the block finishes, **commit**: add the pending entries to `ledger`. If it raises, **roll back**: leave `ledger` unchanged and `raise` the error again.",
            "starter": '''from contextlib import contextmanager

@contextmanager
def transaction(ledger):
    pending = []
    yield pending

ledger = ["opening balance"]
with transaction(ledger) as t:
    t.append("fine paid: 5")
print(ledger)
''',
            "solution": '''from contextlib import contextmanager

@contextmanager
def transaction(ledger):
    pending = []
    try:
        yield pending
    except Exception:
        print("ROLLBACK")
        raise
    for entry in pending:
        ledger.append(entry)
    print("COMMIT")

ledger = ["opening balance"]
with transaction(ledger) as t:
    t.append("fine paid: 5")
print(ledger)
''',
            "tests": '''_ledger = ["start"]
with transaction(_ledger) as _t:
    _t.append("fine 5")
    _t.append("fine 2")
assert _ledger == ["start", "fine 5", "fine 2"], f"a successful block should commit its entries: {_ledger}"
_reached = False
try:
    with transaction(_ledger) as _t:
        _t.append("fine 99")
        raise ValueError("card declined")
except ValueError:
    _reached = True
assert _reached, "re-raise the error so the caller sees it"
assert _ledger == ["start", "fine 5", "fine 2"], f"a failed block must not change the ledger: {_ledger}"''',
            "hints": [
                "Put `yield pending` inside `try:`. In `except Exception:` just `raise` again.",
                "After the try/except, loop over `pending` and append each entry to `ledger`. That line is only reached when no error happened.",
            ],
        },
    ],
    # ------------------------------------------------------------------- classes
    "classes": [
        {
            "task": "Every `CaseFile` shares one `notes` list because it is a class attribute, so notes leak between cases. Fix it so each case file gets its own list.",
            "starter": '''class CaseFile:
    notes = []          # bug: shared by every case file

    def __init__(self, title):
        self.title = title

    def add_note(self, text):
        self.notes.append(text)

a = CaseFile("Missing Ledger")
b = CaseFile("Poison Pen")
a.add_note("ink stain on desk")
print(b.notes)
''',
            "solution": '''class CaseFile:
    def __init__(self, title):
        self.title = title
        self.notes = []

    def add_note(self, text):
        self.notes.append(text)

a = CaseFile("Missing Ledger")
b = CaseFile("Poison Pen")
a.add_note("ink stain on desk")
print(b.notes)
''',
            "tests": '''_a, _b = CaseFile("A"), CaseFile("B")
_a.add_note("clue")
assert _a.notes == ["clue"], _a.notes
assert _b.notes == [], "notes leaked into another case file: create the list in __init__"''',
            "hints": [
                "Anything created in `__init__` with `self.` belongs to one object only.",
                "Delete `notes = []` from the class body and add `self.notes = []` inside `__init__`.",
            ],
        },
        {
            "task": "Give `Detective` a **class attribute** `agency = \"BookVault Investigations\"` shared by every detective, an `__init__` that stores `name`, and a method `badge()` returning `\"<name>, <agency>\"`.",
            "starter": '''class Detective:
    ...  # your code here

holmes = Detective("Holmes")
print(holmes.badge())
''',
            "solution": '''class Detective:
    agency = "BookVault Investigations"

    def __init__(self, name):
        self.name = name

    def badge(self):
        return f"{self.name}, {self.agency}"

holmes = Detective("Holmes")
print(holmes.badge())
''',
            "tests": '''_d = Detective("Holmes")
assert _d.badge() == "Holmes, BookVault Investigations", _d.badge()
Detective.agency = "Baker Street Bureau"
assert _d.badge() == "Holmes, Baker Street Bureau", "agency should live on the class, so changing it there reaches every detective"
Detective.agency = "BookVault Investigations"''',
            "hints": [
                "A class attribute is written directly in the class body, outside any method.",
                "`agency = \"BookVault Investigations\"` in the class, `self.name = name` in `__init__`, and `return f\"{self.name}, {self.agency}\"`.",
            ],
        },
    ],
    # ---------------------------------------------------------------- properties
    "properties": [
        {
            "task": "Add a read-only **computed** property `fine` to `Loan`: 0 for up to 14 days, otherwise 0.5 for each day over 14. It must update when `days_out` changes.",
            "starter": '''class Loan:
    def __init__(self, days_out):
        self.days_out = days_out

    # add the fine property here

loan = Loan(20)
print(loan.fine)
''',
            "solution": '''class Loan:
    def __init__(self, days_out):
        self.days_out = days_out

    @property
    def fine(self):
        if self.days_out <= 14:
            return 0
        return (self.days_out - 14) * 0.5

loan = Loan(20)
print(loan.fine)
''',
            "tests": '''_l = Loan(20)
assert _l.fine == 3.0, f"6 days over at 0.5 is 3.0, got {_l.fine}"
assert Loan(14).fine == 0 and Loan(2).fine == 0, "no fine up to 14 days"
_l.days_out = 24
assert _l.fine == 5.0, "fine should be recalculated when days_out changes"
assert isinstance(Loan.fine, property), "make fine a @property"''',
            "hints": [
                "Put `@property` above `def fine(self):` and compute the value from `self.days_out`.",
                "`if self.days_out <= 14: return 0`, otherwise `return (self.days_out - 14) * 0.5`.",
            ],
        },
        {
            "task": "Add an alternate constructor `@classmethod from_card(cls, card)` to `Member`. A card looks like `\"Ada Lovelace;M042\"`. Use `cls(...)`, so subclasses get their own type back.",
            "starter": '''class Member:
    def __init__(self, name, member_id):
        self.name = name
        self.member_id = member_id

    # add from_card here

m = Member.from_card("Ada Lovelace;M042")
print(m.name, m.member_id)
''',
            "solution": '''class Member:
    def __init__(self, name, member_id):
        self.name = name
        self.member_id = member_id

    @classmethod
    def from_card(cls, card):
        name, member_id = card.split(";")
        return cls(name, member_id)

m = Member.from_card("Ada Lovelace;M042")
print(m.name, m.member_id)
''',
            "tests": '''_m = Member.from_card("Ada Lovelace;M042")
assert (_m.name, _m.member_id) == ("Ada Lovelace", "M042"), (_m.name, _m.member_id)
class _Junior(Member):
    pass
assert type(_Junior.from_card("Tim;M007")) is _Junior, "use cls(...), not Member(...), so subclasses work"''',
            "hints": [
                "`card.split(\";\")` gives the two parts; unpack them into `name, member_id`.",
                "`@classmethod` above `def from_card(cls, card):`, then `return cls(name, member_id)`.",
            ],
        },
        {
            "task": "Add `@staticmethod valid_id(member_id)` to `Member`: `True` when the id is `\"M\"` followed by exactly 3 digits. It needs neither `self` nor `cls`.",
            "starter": '''class Member:
    def __init__(self, name):
        self.name = name

    # add valid_id here

print(Member.valid_id("M042"), Member.valid_id("042"))
''',
            "solution": '''class Member:
    def __init__(self, name):
        self.name = name

    @staticmethod
    def valid_id(member_id):
        return len(member_id) == 4 and member_id[0] == "M" and member_id[1:].isdigit()

print(Member.valid_id("M042"), Member.valid_id("042"))
''',
            "tests": '''assert Member.valid_id("M042") is True, "M042 is valid"
for _bad in ("042", "M42", "M0420", "MABC", "X042"):
    assert Member.valid_id(_bad) is False, f"{_bad!r} should be invalid"
assert Member("Ada").valid_id("M001") is True, "it can also be called on an instance"
assert "@staticmethod" in __source__, "mark it with @staticmethod"''',
            "hints": [
                "Check three things: length 4, first character `\"M\"`, and the rest `.isdigit()`.",
                "`@staticmethod` above `def valid_id(member_id):` (no `self`), returning those checks joined with `and`.",
            ],
        },
    ],
    # ----------------------------------------------------------- inheritance-abc
    "inheritance-abc": [
        {
            "task": "Finish `AudioBook.__init__`: call the parent's `__init__` with `super()` to set `title` and `item_id`, then store `narrator` yourself.",
            "starter": '''class LibraryItem:
    def __init__(self, title, item_id):
        self.title = title
        self.item_id = item_id

class AudioBook(LibraryItem):
    def __init__(self, title, item_id, narrator):
        ...  # your code here

a = AudioBook("Dune", "A001", "Scott Brick")
print(a.title, a.item_id, a.narrator)
''',
            "solution": '''class LibraryItem:
    def __init__(self, title, item_id):
        self.title = title
        self.item_id = item_id

class AudioBook(LibraryItem):
    def __init__(self, title, item_id, narrator):
        super().__init__(title, item_id)
        self.narrator = narrator

a = AudioBook("Dune", "A001", "Scott Brick")
print(a.title, a.item_id, a.narrator)
''',
            "tests": '''_a = AudioBook("Dune", "A001", "Scott Brick")
assert (_a.title, _a.item_id, _a.narrator) == ("Dune", "A001", "Scott Brick"), "set all three attributes"
assert isinstance(_a, LibraryItem)
assert "super().__init__(" in __source__, "let the parent set title and item_id with super().__init__"''',
            "hints": [
                "`super().__init__(...)` runs the parent's `__init__` on this object.",
                "`super().__init__(title, item_id)`, then `self.narrator = narrator`.",
            ],
        },
        {
            "task": "Write an abstract class `Evidence` (inherit from `ABC`) with an abstract method `weight()`. Then `Fingerprint.weight()` returns 3 and `Rumour.weight()` returns 1. Creating `Evidence()` must raise `TypeError`.",
            "starter": '''from abc import ABC, abstractmethod

class Evidence:
    def weight(self):
        return 0

class Fingerprint(Evidence):
    pass

class Rumour(Evidence):
    pass

print(Fingerprint().weight(), Rumour().weight())
''',
            "solution": '''from abc import ABC, abstractmethod

class Evidence(ABC):
    @abstractmethod
    def weight(self): ...

class Fingerprint(Evidence):
    def weight(self):
        return 3

class Rumour(Evidence):
    def weight(self):
        return 1

print(Fingerprint().weight(), Rumour().weight())
''',
            "tests": '''assert Fingerprint().weight() == 3 and Rumour().weight() == 1, "Fingerprint weighs 3, Rumour weighs 1"
assert isinstance(Rumour(), Evidence), "both must inherit from Evidence"
try:
    Evidence()
    raise AssertionError("Evidence() should raise TypeError: make it an ABC with an @abstractmethod")
except TypeError:
    pass
class _Lazy(Evidence):
    pass
try:
    _Lazy()
    raise AssertionError("a subclass without weight() should not be creatable")
except TypeError:
    pass''',
            "hints": [
                "`class Evidence(ABC):` and put `@abstractmethod` above `def weight(self): ...`.",
                "Each subclass writes its own `def weight(self): return 3` (or `1`).",
            ],
        },
    ],
    # --------------------------------------------------------------- composition
    "composition": [
        {
            "task": "Write `CaseRoom`, which is **given** a notifier in `__init__` (do not inherit from one). `open_case(name)` calls the notifier's `send` with `\"case opened: <name>\"`. It must work with either notifier below.",
            "starter": '''class PrintNotifier:
    def send(self, msg):
        print("NOTIFY:", msg)

class ListNotifier:
    def __init__(self):
        self.sent = []
    def send(self, msg):
        self.sent.append(msg)

class CaseRoom:
    ...  # your code here

CaseRoom(PrintNotifier()).open_case("Missing Ledger")
''',
            "solution": '''class PrintNotifier:
    def send(self, msg):
        print("NOTIFY:", msg)

class ListNotifier:
    def __init__(self):
        self.sent = []
    def send(self, msg):
        self.sent.append(msg)

class CaseRoom:
    def __init__(self, notifier):
        self.notifier = notifier

    def open_case(self, name):
        self.notifier.send(f"case opened: {name}")

CaseRoom(PrintNotifier()).open_case("Missing Ledger")
''',
            "tests": '''_ln = ListNotifier()
_room = CaseRoom(_ln)
_room.open_case("Missing Ledger")
_room.open_case("Poison Pen")
assert _ln.sent == ["case opened: Missing Ledger", "case opened: Poison Pen"], _ln.sent
assert "NOTIFY: case opened: Missing Ledger" in __output__, "with a PrintNotifier the message should be printed"
assert not isinstance(_room, (ListNotifier, PrintNotifier)), "CaseRoom should receive a notifier, not inherit from one"''',
            "hints": [
                "`__init__(self, notifier)` stores it: `self.notifier = notifier`.",
                "`open_case` calls `self.notifier.send(f\"case opened: {name}\")`.",
            ],
        },
    ],
    # ------------------------------------------------------------------- dunders
    "dunders": [
        {
            "task": "Give `EvidenceLocker` a `__str__` returning `\"Locker 7 holds 2\"` (number and item count) and a `__bool__` that is `False` while the locker is empty.",
            "starter": '''class EvidenceLocker:
    def __init__(self, number):
        self.number = number
        self.items = []

    def add(self, item):
        self.items.append(item)

    # add __str__ and __bool__ here

locker = EvidenceLocker(7)
print(bool(locker))
locker.add("glove")
print(locker, bool(locker))
''',
            "solution": '''class EvidenceLocker:
    def __init__(self, number):
        self.number = number
        self.items = []

    def add(self, item):
        self.items.append(item)

    def __str__(self):
        return f"Locker {self.number} holds {len(self.items)}"

    def __bool__(self):
        return bool(self.items)

locker = EvidenceLocker(7)
print(bool(locker))
locker.add("glove")
print(locker, bool(locker))
''',
            "tests": '''_l = EvidenceLocker(7)
assert not _l, "an empty locker should be falsy"
assert str(_l) == "Locker 7 holds 0", str(_l)
_l.add("glove"); _l.add("key")
assert _l, "a locker with items should be truthy"
assert str(_l) == "Locker 7 holds 2", str(_l)''',
            "hints": [
                "`print(x)` and `str(x)` call `__str__`; `if x:` and `bool(x)` call `__bool__`.",
                "`__str__` returns `f\"Locker {self.number} holds {len(self.items)}\"`; `__bool__` returns `bool(self.items)`.",
            ],
        },
        {
            "task": "`Alibis` maps suspects to alibis. Add `__getitem__`: an `int` key returns the suspect's **name** at that position, any other key returns that suspect's alibi (use `isinstance`). Add `__call__(word)`: return the names whose alibi contains `word`.",
            "starter": '''class Alibis:
    def __init__(self):
        self._alibis = {}

    def add(self, name, alibi):
        self._alibis[name] = alibi

    # add __getitem__ and __call__ here

book = Alibis()
book.add("Plum", "reading in the library")
book.add("Green", "at the races")
print(book[0], book["Green"], book("library"))
''',
            "solution": '''class Alibis:
    def __init__(self):
        self._alibis = {}

    def add(self, name, alibi):
        self._alibis[name] = alibi

    def __getitem__(self, key):
        if isinstance(key, int):
            return list(self._alibis)[key]
        return self._alibis[key]

    def __call__(self, word):
        found = []
        for name in self._alibis:
            if word in self._alibis[name]:
                found.append(name)
        return found

book = Alibis()
book.add("Plum", "reading in the library")
book.add("Green", "at the races")
print(book[0], book["Green"], book("library"))
''',
            "tests": '''_b = Alibis()
_b.add("Plum", "reading in the library")
_b.add("Green", "at the races")
_b.add("White", "in the library kitchen")
assert _b[0] == "Plum" and _b[2] == "White", "an int key returns the name at that position"
assert _b["Green"] == "at the races", "a name key returns that suspect's alibi"
assert _b("library") == ["Plum", "White"], _b("library")
assert _b("moon") == [], "no matching alibi gives an empty list"''',
            "hints": [
                "In `__getitem__`, `if isinstance(key, int): return list(self._alibis)[key]` (a list of a dict gives its keys).",
                "Otherwise `return self._alibis[key]`. In `__call__`, loop over the names and keep those where `word in self._alibis[name]`.",
            ],
        },
        {
            "task": "Two `Case` objects are equal when their `case_id` matches. Write `__eq__` that returns `NotImplemented` for non-`Case` objects, and set `__hash__ = None`, because a case's suspect list keeps changing.",
            "starter": '''class Case:
    def __init__(self, case_id):
        self.case_id = case_id
        self.suspects = []

    # add __eq__ and __hash__ here

print(Case("C1") == Case("C1"), Case("C1") == "C1")
''',
            "solution": '''class Case:
    def __init__(self, case_id):
        self.case_id = case_id
        self.suspects = []

    def __eq__(self, other):
        if not isinstance(other, Case):
            return NotImplemented
        return self.case_id == other.case_id

    __hash__ = None

print(Case("C1") == Case("C1"), Case("C1") == "C1")
''',
            "tests": '''_a, _b = Case("C1"), Case("C1")
_b.suspects.append("Plum")
assert _a == _b, "cases with the same case_id are equal"
assert Case("C1") != Case("C2")
assert (Case("C1") == "C1") is False, "comparing with a non-Case should simply be False"
assert Case("C1").__eq__("C1") is NotImplemented, "return NotImplemented for non-Case objects"
try:
    {Case("C1")}
    raise AssertionError("Case should be unhashable: set __hash__ = None")
except TypeError:
    pass''',
            "hints": [
                "Start `__eq__` with `if not isinstance(other, Case): return NotImplemented`.",
                "Then `return self.case_id == other.case_id`, and write `__hash__ = None` in the class body.",
            ],
        },
    ],
    # ------------------------------------------------------------------- eq-hash
    "eq-hash": [
        {
            "task": "`Suspect` names are equal ignoring capitals, but the class has no `__hash__`, so suspects can't go in a set. Add a `__hash__` that keeps the contract: equal suspects must have equal hashes.",
            "starter": '''class Suspect:
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return f"Suspect({self.name!r})"

    def __eq__(self, other):
        if not isinstance(other, Suspect):
            return NotImplemented
        return self.name.lower() == other.name.lower()

print({Suspect("Plum"), Suspect("PLUM"), Suspect("Green")})
''',
            "solution": '''class Suspect:
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return f"Suspect({self.name!r})"

    def __eq__(self, other):
        if not isinstance(other, Suspect):
            return NotImplemented
        return self.name.lower() == other.name.lower()

    def __hash__(self):
        return hash(self.name.lower())

print({Suspect("Plum"), Suspect("PLUM"), Suspect("Green")})
''',
            "tests": '''assert hash(Suspect("Plum")) == hash(Suspect("pLUM")), "equal suspects need equal hashes: hash the lowercased name"
assert len({Suspect("Plum"), Suspect("PLUM"), Suspect("Green")}) == 2, "Plum and PLUM should collapse into one"
assert {Suspect("Plum"): "library"}[Suspect("plum")] == "library", "it should work as a dict key too"''',
            "hints": [
                "Hash exactly what `__eq__` compares. `__eq__` compares lowercased names.",
                "`def __hash__(self): return hash(self.name.lower())`",
            ],
        },
    ],
    # --------------------------------------------------------------- dataclasses
    "dataclasses": [
        {
            "task": "Write a `CaseFile` dataclass with `title: str` and `suspects`, a list that is **new for every case** (`field(default_factory=list)`). In `__post_init__`, tidy the title with `.strip().title()`.",
            "starter": '''from dataclasses import dataclass, field

@dataclass
class CaseFile:
    title: str
    # add suspects and __post_init__ here

case = CaseFile("  the missing ledger ")
print(case)
''',
            "solution": '''from dataclasses import dataclass, field

@dataclass
class CaseFile:
    title: str
    suspects: list[str] = field(default_factory=list)

    def __post_init__(self):
        self.title = self.title.strip().title()

case = CaseFile("  the missing ledger ")
print(case)
''',
            "tests": '''_a = CaseFile("  the missing ledger ")
assert _a.title == "The Missing Ledger", repr(_a.title)
_a.suspects.append("Plum")
assert CaseFile("x").suspects == [], "each case file needs its own suspects list"
assert CaseFile("Poison Pen", ["Green"]).suspects == ["Green"], "suspects can be passed in"
assert "default_factory" in __source__, "use field(default_factory=list)"''',
            "hints": [
                "`suspects: list[str] = field(default_factory=list)` creates a fresh list for each object.",
                "`def __post_init__(self): self.title = self.title.strip().title()`",
            ],
        },
        {
            "task": "Write a `Fine` dataclass with `member: str` and `days_late: int`, plus an `amount` field that is **computed**, not passed in (`init=False`) and hidden from the printout (`repr=False`). Set it to `days_late * 0.5` in `__post_init__`.",
            "starter": '''from dataclasses import dataclass, field

@dataclass
class Fine:
    ...  # your code here

f = Fine("Ada", 4)
print(f, f.amount)
''',
            "solution": '''from dataclasses import dataclass, field

@dataclass
class Fine:
    member: str
    days_late: int
    amount: float = field(init=False, repr=False)

    def __post_init__(self):
        self.amount = self.days_late * 0.5

f = Fine("Ada", 4)
print(f, f.amount)
''',
            "tests": '''_f = Fine("Ada", 4)
assert _f.amount == 2.0, _f.amount
assert "amount" not in repr(_f), f"amount should be hidden from the repr: {_f!r}"
assert "Ada" in repr(_f), "member should still show in the repr"
try:
    Fine("Ada", 4, 9.0)
    raise AssertionError("amount must not be an __init__ argument: use init=False")
except TypeError:
    pass''',
            "hints": [
                "`amount: float = field(init=False, repr=False)` declares it without making it an argument.",
                "Fill it in `def __post_init__(self): self.amount = self.days_late * 0.5`.",
            ],
        },
    ],
    # -------------------------------------------------------------------- frozen
    "frozen": [
        {
            "task": "Make `Spot` a **frozen** dataclass so it can be a dict key. Then write `count_sightings(pairs)` that turns each `(x, y)` pair into a `Spot` and returns `{Spot: number of sightings}`.",
            "starter": '''from dataclasses import dataclass, FrozenInstanceError

@dataclass
class Spot:
    x: int
    y: int

def count_sightings(pairs):
    ...  # your code here

print(count_sightings([(1, 2), (3, 4), (1, 2)]))
''',
            "solution": '''from dataclasses import dataclass, FrozenInstanceError

@dataclass(frozen=True)
class Spot:
    x: int
    y: int

def count_sightings(pairs):
    counts = {}
    for x, y in pairs:
        spot = Spot(x, y)
        counts[spot] = counts.get(spot, 0) + 1
    return counts

print(count_sightings([(1, 2), (3, 4), (1, 2)]))
''',
            "tests": '''_c = count_sightings([(1, 2), (3, 4), (1, 2)])
assert _c == {Spot(1, 2): 2, Spot(3, 4): 1}, _c
assert count_sightings([]) == {}
try:
    Spot(1, 2).x = 9
    raise AssertionError("Spot must be frozen")
except FrozenInstanceError:
    pass''',
            "hints": [
                "`@dataclass(frozen=True)` makes `Spot` hashable, so it can be a dict key.",
                "Loop `for x, y in pairs:`, make `spot = Spot(x, y)`, then `counts[spot] = counts.get(spot, 0) + 1`.",
            ],
        },
    ],
}

"""Detective X: cases for the "Project craft" skill (files/JSON, custom exceptions, type hints, CLI).

Same format as game.py. Tests compute the expected answer from the evidence itself.
Evidence JSON is written as Python text so it reads like a real file.
"""

_PARSE_LINE = '''import json

class LogError(Exception):
    pass

class CorruptLineError(LogError):
    pass

class MissingFieldError(LogError):
    pass

def parse_line(line):
    try:
        record = json.loads(line)
    except json.JSONDecodeError:
        raise CorruptLineError(f"not JSON: {line!r}") from None
    for field in ("agent", "file", "hour"):
        if field not in record:
            raise MissingFieldError(f"missing {field}: {line!r}")
    return record
'''

_REF = '''import json as _json
def _ref_records(text):
    _good, _errs = [], {}
    for _line in text.splitlines():
        if not _line.strip():
            continue
        try:
            _r = _json.loads(_line)
        except Exception:
            _errs["CorruptLineError"] = _errs.get("CorruptLineError", 0) + 1
            continue
        if not all(_f in _r for _f in ("agent", "file", "hour")):
            _errs["MissingFieldError"] = _errs.get("MissingFieldError", 0) + 1
            continue
        _good.append(_r)
    return _good, _errs
'''

CASES = [
    # ------------------------------------------------------------------ small
    {
        "id": "dead-drop",
        "tier": "small",
        "title": "The Dead Drop",
        "teaser": "An intercepted file, written in JSON. Who is it for?",
        "skills": ["project"],
        "story": "Surveillance photographed a courier leaving a USB stick in a hollow brick. The file on it, `dead_drop`, is JSON: the courier's code name and a list of messages, each with a recipient (`to`) and some `text`.\n\nOne of the recipients signs with a single chalk letter. Find out what they were told.",
        "suspects": [{"name": "the courier", "note": "Never seen without a newspaper."}],
        "variants": [
            '''dead_drop = """{"courier": "Kestrel", "messages": [
  {"to": "Falcon", "text": "Payment received"},
  {"to": "X", "text": "Meet at Pier 9, 02:00"},
  {"to": "Heron", "text": "Burn the ledger"},
  {"to": "X", "text": "Bring the folio"}
]}"""
''',
            '''dead_drop = """{"courier": "Magpie", "messages": [
  {"to": "X", "text": "The museum guard is ours"},
  {"to": "Wren", "text": "Lie low until Friday"}
]}"""
''',
            '''dead_drop = """{"courier": "Osprey", "messages": [
  {"to": "Rook", "text": "New phone number soon"},
  {"to": "Rook", "text": "Ignore the old one"},
  {"to": "Swift", "text": "Car is ready"},
  {"to": "X", "text": "Library vault, Sunday night"}
]}"""
''',
        ],
        "steps": [
            {
                "notes": "**JSON** is a text format for data. In JSON, `{...}` is an *object* (it becomes a Python dict when loaded), `[...]` is an *array* (it becomes a list), and text is always in double quotes.\n\nThe file `dead_drop` holds one object with two keys:\n- `\"courier\"`: the courier's code name (text)\n- `\"messages\"`: an array of messages; each message is an object with the keys `\"to\"` (the recipient) and `\"text\"` (the message)\n\nFor example: `{\"courier\": \"Lark\", \"messages\": [{\"to\": \"Wren\", \"text\": \"Stay put\"}]}`",
                "question": "**Goal:** find out who the courier is and who the messages are for.\n\n**You have:** `dead_drop`, a **string** of JSON text (its layout is in the field notes).\n\n**Write** three variables:\n- `drop`: the dict you get from `json.loads(dead_drop)`\n- `courier`: the courier's code name, the value under the key `\"courier\"`\n- `recipients`: a **list** of the `\"to\"` names from all the messages, each name only **once**, sorted A to Z\n\n**Then** print `courier` and `recipients`. The starter already does this.\n\n**Example:** if the messages go to `\"Wren\"`, `\"Crow\"` and `\"Wren\"`, then `recipients` is `[\"Crow\", \"Wren\"]`.",
                "starter": "import json\n\ndrop = ...\ncourier = ...\nrecipients = ...\nprint(courier, recipients)\n",
                "solution": 'import json\n\ndrop = json.loads(dead_drop)\ncourier = drop["courier"]\nrecipients = sorted({m["to"] for m in drop["messages"]})\nprint(courier, recipients)\n',
                "tests": '''import json as _j
_d = _j.loads(dead_drop)
assert courier == _d["courier"], f"courier should be {_d['courier']!r}, got {courier!r}"
_r = sorted({m["to"] for m in _d["messages"]})
assert recipients == _r, f"recipients should be {_r}, got {recipients!r}"''',
                "tips": [
                    "`json.loads(dead_drop)` gives a dict. `drop[\"messages\"]` is a list of dicts.",
                    "A set comprehension removes duplicates: `sorted({m[\"to\"] for m in drop[\"messages\"]})`.",
                ],
                "reveal": "One recipient isn't a bird's name at all. Just a letter: X.",
            },
            {
                "question": "**Goal:** read every message meant for X.\n\n**You have:** `drop = json.loads(dead_drop)`, already in the starter. `drop[\"messages\"]` is a list of dicts like `{\"to\": \"X\", \"text\": \"Bring the folio\"}`.\n\n**Write** a list `for_x`:\n- the `\"text\"` of every message whose `\"to\"` is exactly `\"X\"`\n- in the same order as in the file\n- only the texts (strings), not the whole message dicts\n\n**Then** print each text in `for_x`, one per line.\n\n**Example:** three messages, to `\"X\"` (`\"Go north\"`), to `\"Wren\"` (`\"Stay\"`) and to `\"X\"` (`\"Wait\"`), give `for_x = [\"Go north\", \"Wait\"]`, and the program prints `Go north` and then `Wait`.",
                "starter": "import json\n\ndrop = json.loads(dead_drop)\nfor_x = []\n# your loop here\n",
                "solution": 'import json\n\ndrop = json.loads(dead_drop)\nfor_x = [m["text"] for m in drop["messages"] if m["to"] == "X"]\nfor text in for_x:\n    print(text)\n',
                "tests": '''import json as _j
_e = [m["text"] for m in _j.loads(dead_drop)["messages"] if m["to"] == "X"]
assert for_x == _e, f"for_x should be {_e}, got {for_x!r}"
assert all(t in __output__ for t in _e), "print each message for X"''',
                "tips": [
                    "Loop over `drop[\"messages\"]` and keep the `text` when `m[\"to\"] == \"X\"`.",
                    "`for_x = [m[\"text\"] for m in drop[\"messages\"] if m[\"to\"] == \"X\"]`, then a `for` loop to print.",
                ],
                "reveal": "X is planning something, and now the Bureau knows where.",
            },
        ],
        "closing": "Case closed. The courier was picked up at the next drop. X's message is pinned to the board: another piece of the puzzle.",
    },
    # ------------------------------------------------------------------ medium
    {
        "id": "leaked-dossier",
        "tier": "medium",
        "title": "The Leaked Dossier",
        "teaser": "Someone opened DOSSIER-X after hours. The access log is half destroyed.",
        "skills": ["project", "dataclasses"],
        "story": "The Bureau's most secret file, **DOSSIER-X**, turned up in a newspaper. The records room logs every access as one JSON object per line: `agent`, `file` and `hour` (0–23). The log is in `access_log`.\n\nThe night before the leak, someone attacked the server, so some lines are **corrupt** (not JSON at all) and some are **missing fields**. The Chief wants every damaged line accounted for, using the Bureau's own error classes, before anyone is accused.\n\nOffice hours are **09:00 to 17:59**. Opening DOSSIER-X outside them is a firing offence.",
        "suspects": [
            {"name": "the archivist", "note": "Has keys to everything."},
            {"name": "the analyst", "note": "Works late, says it's dedication."},
            {"name": "the deputy", "note": "Wants the Chief's job."},
        ],
        "variants": [
            '''access_log = """{"agent": "Analyst Rao", "file": "DOSSIER-X", "hour": 22}
{"agent": "Archivist Iyer", "file": "DOSSIER-X", "hour": 10}
{"agent": "Deputy Novak", "file": "BUDGET", "hour": 23}
{agent: Deputy Novak, file: DOSSIER-X}
{"agent": "Analyst Rao", "file": "DOSSIER-X", "hour": 2}
{"file": "DOSSIER-X", "hour": 3}
{"agent": "Archivist Iyer", "file": "DOSSIER-X", "hour": 19}
{"agent": "Deputy Novak", "file": "DOSSIER-X", "hour": 11}
"""
''',
            '''access_log = """{"agent": "Deputy Novak", "file": "DOSSIER-X", "hour": 6}
{"agent": "Analyst Rao", "file": "DOSSIER-X", "hour": 21}
######## CORRUPTED ########
{"agent": "Deputy Novak", "file": "DOSSIER-X", "hour": 23}
{"agent": "Archivist Iyer", "file": "PAYROLL"}
{"agent": "Deputy Novak", "file": "DOSSIER-X", "hour": 1}
{"agent": "Archivist Iyer", "file": "DOSSIER-X", "hour": 9}
"""
''',
            '''access_log = """{"agent": "Archivist Iyer", "file": "DOSSIER-X", "hour": 20}
{"agent": "Analyst Rao", "file": "DOSSIER-X", "hour": 14}
{"agent": "Archivist Iyer", "file": "DOSSIER-X", "hour": 4}
{"agent": "Analyst Rao", "file": "DOSSIER-X", "hour": 23}
not even close to json
{"agent": "Deputy Novak", "hour": 2}
{agent: "x"}
{"agent": "Archivist Iyer", "file": "DOSSIER-X", "hour": 0}
"""
''',
        ],
        "steps": [
            {
                "notes": "Each line of the access log should be one **JSON object** with three fields: `agent` (text), `file` (text) and `hour` (a whole number from 0 to 23). For example: `{\"agent\": \"Clerk Bose\", \"file\": \"MAPS\", \"hour\": 14}`\n\nA damaged line is one of two kinds:\n- **corrupt**: the text is not valid JSON at all, e.g. `{oops` or `{agent: Bose}` (JSON needs double quotes around every key and text value)\n- **missing a field**: valid JSON, but `agent`, `file` or `hour` is not there, e.g. `{\"agent\": \"Clerk Bose\", \"hour\": 3}`",
                "question": "**Goal:** give the Bureau its own error types for damaged log lines, and a function that reads one line.\n\n**You have:** `access_log`, the whole log as one string, one JSON object per line (see the field notes).\n\n**Write** three exception classes:\n- `LogError`, based on `Exception`\n- `CorruptLineError` and `MissingFieldError`, both based on `LogError`\n\n**Write** a function `parse_line(line)`:\n- `line` is one line of the log, as a string\n- if `line` is not valid JSON, raise `CorruptLineError`. (`json.loads` raises `json.JSONDecodeError` on bad JSON: catch that and raise yours instead.)\n- if the JSON loads but any of the keys `\"agent\"`, `\"file\"` or `\"hour\"` is missing, raise `MissingFieldError`\n- otherwise return the loaded dict, unchanged\n\n**Then** print `parse_line` of the first log line. The starter already does this.\n\n**Example:** `parse_line('{\"agent\": \"A\", \"file\": \"F\", \"hour\": 1}')` returns `{\"agent\": \"A\", \"file\": \"F\", \"hour\": 1}`. `parse_line('{oops')` raises `CorruptLineError`. `parse_line('{\"agent\": \"A\", \"file\": \"F\"}')` raises `MissingFieldError`.",
                "starter": "import json\n\n# define the three error classes here\n\ndef parse_line(line):\n    ...\n\nprint(parse_line(access_log.splitlines()[0]))\n",
                "solution": _PARSE_LINE + "\nprint(parse_line(access_log.splitlines()[0]))\n",
                "tests": '''assert issubclass(LogError, Exception), "LogError should inherit from Exception"
assert issubclass(CorruptLineError, LogError) and issubclass(MissingFieldError, LogError), "both errors should inherit from LogError"
assert parse_line('{"agent": "A", "file": "F", "hour": 1}') == {"agent": "A", "file": "F", "hour": 1}, "a good line should come back as a dict"
for _line, _err in (("{oops", CorruptLineError), ('{"agent": "A", "hour": 1}', MissingFieldError), ('{"file": "F", "hour": 1}', MissingFieldError), ('{"agent": "A", "file": "F"}', MissingFieldError)):
    try:
        parse_line(_line)
        raise AssertionError(f"parse_line({_line!r}) should raise {_err.__name__}")
    except _err:
        pass''',
                "tips": [
                    "Turn the JSON error into yours: `try: record = json.loads(line)` and `except json.JSONDecodeError: raise CorruptLineError(...)`.",
                    "Then loop over `(\"agent\", \"file\", \"hour\")` and `raise MissingFieldError(...)` if one is not `in record`.",
                ],
                "reveal": "The Bureau now has words for exactly what is wrong with each line.",
            },
            {
                "question": "**Goal:** sort the whole log into good records and counted damage.\n\n**You have:** `access_log`, plus a finished `parse_line` and the three error classes (already in the starter).\n\n**Write** a loop over `access_log.splitlines()` that fills two variables:\n- skip lines that are empty or only spaces\n- call `parse_line(line)` inside `try`; if it works, append the returned dict to the list `records`, in log order\n- catch errors with `except LogError as e:` (the base class, written exactly like that, so one `except` catches both kinds)\n- `errors` is a dict from the error's class name (a string, from `type(e).__name__`) to how many lines had that error. Only error kinds that actually happened appear: no `0` entries.\n\n**Then** print `len(records)` and `errors`. The starter already does this.\n\n**Example:** a log with 3 good lines, 1 corrupt line and 2 lines missing a field gives 3 dicts in `records` and `errors == {\"CorruptLineError\": 1, \"MissingFieldError\": 2}`.",
                "starter": _PARSE_LINE + "\nrecords = []\nerrors = {}\n# your loop here\n\nprint(len(records), errors)\n",
                "solution": _PARSE_LINE + '''
records = []
errors = {}
for line in access_log.splitlines():
    if not line.strip():
        continue
    try:
        records.append(parse_line(line))
    except LogError as e:
        name = type(e).__name__
        errors[name] = errors.get(name, 0) + 1

print(len(records), errors)
''',
                "tests": _REF + '''_good, _errs = _ref_records(access_log)
assert records == _good, f"records should hold the {len(_good)} good lines, in order; you have {len(records)}"
assert errors == _errs, f"errors should be {_errs}, got {errors!r}"
assert "except LogError" in __source__, "catch the base class: except LogError"''',
                "tips": [
                    "Skip blank lines with `if not line.strip(): continue`, then `try: records.append(parse_line(line))`.",
                    "In `except LogError as e:`, use `type(e).__name__` as the key and `errors.get(name, 0) + 1` to count.",
                ],
                "reveal": "Every damaged line is on the record. The defence can't claim the evidence was cherry-picked.",
            },
            {
                "notes": "Bureau office hours are **09:00 to 17:59**. The log stores only the hour (0 to 23), so:\n- **inside** office hours: `hour` is 9 up to and including 17\n- **outside** office hours: `hour` is 0 to 8, or 18 to 23\n\nThe leaker is the agent who opened `DOSSIER-X` outside office hours the **most** times.",
                "question": "**Goal:** name the leaker.\n\n**You have:** `records`, the list of good records from the last step (the starter builds it again). Each record is a dict like `{\"agent\": \"Clerk Bose\", \"file\": \"DOSSIER-X\", \"hour\": 22}`.\n\n**Write** code that:\n- counts, for each agent, the records where `file` is exactly `\"DOSSIER-X\"` **and** the hour is outside office hours (see the field notes). A dict from agent name to count works well.\n- ignores every other file, and every visit inside office hours\n- stores in `leaker` the name (a string) of the agent with the highest count. If two agents tie, either one is accepted.\n\n**Then** print the accusation with the leaker's name in it. The starter's last line already does this.\n\n**Example:** Bose opens DOSSIER-X at hours 22, 3 and 11, and Pal opens it at 20 and opens `\"BUDGET\"` at 23. Bose has 2 (11 is office hours), Pal has 1, so `leaker` is `\"Clerk Bose\"`.",
                "starter": _PARSE_LINE + '''
records = []
for line in access_log.splitlines():
    if line.strip():
        try:
            records.append(parse_line(line))
        except LogError:
            pass

leaker = None
print("The leaker is", leaker)
''',
                "solution": _PARSE_LINE + '''
records = []
for line in access_log.splitlines():
    if line.strip():
        try:
            records.append(parse_line(line))
        except LogError:
            pass

after_hours = {}
for r in records:
    if r["file"] == "DOSSIER-X" and (r["hour"] < 9 or r["hour"] >= 18):
        after_hours[r["agent"]] = after_hours.get(r["agent"], 0) + 1

leaker = max(after_hours, key=after_hours.get)
print("The leaker is", leaker)
''',
                "tests": _REF + '''_good, _ = _ref_records(access_log)
_c = {}
for _r in _good:
    if _r["file"] == "DOSSIER-X" and (_r["hour"] < 9 or _r["hour"] >= 18):
        _c[_r["agent"]] = _c.get(_r["agent"], 0) + 1
_top = max(_c.values())
assert leaker is not None, "leaker is still None"
assert _c.get(leaker) == _top, "wrong agent: count only DOSSIER-X opened before 9 or from 18 onwards, and take the most"
assert str(leaker) in __output__, "print your accusation"''',
                "tips": [
                    "Count in a dict: for each record where `r[\"file\"] == \"DOSSIER-X\"` and `r[\"hour\"] < 9 or r[\"hour\"] >= 18`, add 1 for `r[\"agent\"]`.",
                    "`max(after_hours, key=after_hours.get)` gives the agent with the highest count.",
                ],
                "reveal": "The pattern of late-night visits leaves no doubt. On the leaker's desk: a sheet of paper with a chalk **X** pressed into it.",
            },
        ],
        "closing": "Case closed. The leaker confessed: they had been paid to copy DOSSIER-X, page by page, at night. They never met their buyer. All they had was a phone number, and a single letter: X.",
    },
]

"""Detective X — small cases for the skills after the vertical slice.

Same format as game.py. Tier "small": 1-2 steps, one main skill each.
Several are the official Day 1 assignments (Q1, Q2, Q3, Q4, Q5, Q7, Q8, Q10, Q16) with a crime story.
"""

CASES = [
    # ------------------------------------------------------------ records
    {
        "id": "phone-records",
        "tier": "small",
        "title": "Phone Records",
        "teaser": "A burner phone, a list of calls, and one number it kept dialling.",
        "skills": ["records"],
        "story": "A burner phone was found in the getaway car. The carrier sent the list of every number it `called`, in order. A number that shows up again and again is the gang's contact.\n\nCount the calls per number with a dictionary.",
        "suspects": [{"name": "the getaway driver", "note": "Says the phone isn't theirs."}],
        "variants": [
            'calls = ["98201", "77450", "98201", "11223", "98201", "77450"]\n',
            'calls = ["55102", "55102", "40011", "40011", "40011", "99870", "55102", "40011"]\n',
            'calls = ["31337", "20480", "20480", "31337", "88001", "20480"]\n',
        ],
        "steps": [
            {
                "question": "**Goal:** find the number the burner phone called most often.\n\n**You have:** `calls`, a list of phone numbers as strings, in the order they were dialled (for example `[\"98201\", \"77450\", \"98201\"]`).\n\n**Write** a dictionary `counts`:\n- each key is a phone number (a string, exactly as in `calls`)\n- each value is how many times that number appears in `calls` (an int)\n\n**Then** store the most-called number (a string) in `contact`. If two numbers tie for the most calls, either one is accepted.\n\n**Example:** for `[\"111\", \"222\", \"111\"]`, `counts` is `{\"111\": 2, \"222\": 1}` and `contact` is `\"111\"`.",
                "starter": "counts = {}\n# count the calls here\n\ncontact = ...\nprint(counts)\nprint(contact)\n",
                "solution": "counts = {}\nfor number in calls:\n    counts[number] = counts.get(number, 0) + 1\n\ncontact = calls[0]\nfor number in counts:\n    if counts[number] > counts[contact]:\n        contact = number\nprint(counts)\nprint(contact)\n",
                "tests": '''_exp = {}
for _n in calls:
    _exp[_n] = _exp.get(_n, 0) + 1
assert counts == _exp, f"counts should be {_exp}, got {counts}"
_best = max(_exp.values())
assert _exp.get(contact) == _best, f"contact should be the number called {_best} times, got {contact!r}"''',
                "tips": [
                    "`counts.get(number, 0)` gives the count so far, or 0 for a new number. Add 1 and store it back.",
                    "For the most-called number, start with `contact = calls[0]`, then loop over `counts` and switch whenever a number has a bigger count.",
                ],
                "reveal": "One number dominates the log. The carrier traces it to a flat above a pawn shop.",
            },
        ],
        "closing": "Case closed. The flat above the pawn shop was the gang's planning room. One dictionary did what a week of stakeouts couldn't.",
    },
    # ------------------------------------------------------------ functions (Q1)
    {
        "id": "frozen-body",
        "tier": "small",
        "title": "The Frozen Body",
        "teaser": "A body in a cold store. When did the victim die?",
        "skills": ["functions", "errors"],
        "story": "A body was found in a restaurant's cold store at **7 am**. The pathologist's thermometer reads in Fahrenheit, but the Bureau's formula needs Celsius.\n\nThe rule of thumb: a body cools about **1.5 °C per hour** from 37 °C. The reading is in `body_temp_f`.\n\n*(This is the official assignment Q1: a temperature converter.)*",
        "suspects": [{"name": "the head chef", "note": "Says they locked up at 11 pm."}, {"name": "the delivery driver", "note": "Had a key to the back door."}],
        "variants": ["body_temp_f = 75.2\n", "body_temp_f = 73.4\n", "body_temp_f = 71.6\n"],
        "steps": [
            {
                "notes": "Temperature scales: **C** = Celsius, **F** = Fahrenheit, **K** = Kelvin.\n- Fahrenheit to Celsius: `C = (F - 32) * 5 / 9`\n- Celsius to Fahrenheit: `F = C * 9 / 5 + 32`\n- Kelvin to Celsius: `C = K - 273.15`\n- Celsius to Kelvin: `K = C + 273.15`\n\nAn easy way to handle every pair: first turn any value into Celsius, then turn the Celsius into the unit you want.",
                "question": "**Goal:** a converter that works for any pair of units, so the lab can read the thermometer in Celsius.\n\n**You have:** `body_temp_f`, the body temperature in Fahrenheit (for example `80.6`).\n\n**Write** a function `convert(value, from_unit, to_unit)`:\n- `from_unit` and `to_unit` are each `\"C\"`, `\"F\"` or `\"K\"`.\n- It returns `value` converted from the first unit to the second (use the field notes).\n- If both units are the same, it returns `value` unchanged.\n- If either unit is anything else (like `\"X\"`), it raises `ValueError`.\n\n**Then** print the body temperature in Celsius: `print(convert(body_temp_f, \"F\", \"C\"))`.\n\n**Example:** `convert(0, \"C\", \"F\")` gives `32.0`, and `convert(100, \"C\", \"K\")` gives `373.15`.",
                "starter": "def convert(value, from_unit, to_unit):\n    ...\n\nprint(convert(body_temp_f, \"F\", \"C\"))\n",
                "solution": 'def convert(value, from_unit, to_unit):\n    units = ["C", "F", "K"]\n    if from_unit not in units or to_unit not in units:\n        raise ValueError("unknown unit")\n    if from_unit == to_unit:\n        return value\n    if from_unit == "C":\n        celsius = value\n    elif from_unit == "F":\n        celsius = (value - 32) * 5 / 9\n    else:\n        celsius = value - 273.15\n    if to_unit == "C":\n        return celsius\n    if to_unit == "F":\n        return celsius * 9 / 5 + 32\n    return celsius + 273.15\n\nprint(convert(body_temp_f, "F", "C"))\n',
                "tests": '''assert convert(0, "C", "F") == 32.0, "convert(0, 'C', 'F') should be 32.0"
assert convert(100, "C", "K") == 373.15, "convert(100, 'C', 'K') should be 373.15"
assert round(convert(32, "F", "C"), 2) == 0.0, "convert(32, 'F', 'C') should be 0.0"
assert convert(21.5, "C", "C") == 21.5, "the same unit should return the value unchanged"
assert round(convert(373.15, "K", "C"), 2) == 100.0, "convert(373.15, 'K', 'C') should be 100.0"
assert round(convert(32, "F", "K"), 2) == 273.15, "convert(32, 'F', 'K') should be 273.15: turn F into C first, then C into K"
try:
    convert(1, "X", "C")
    raise AssertionError("an unknown from_unit like 'X' should raise ValueError")
except ValueError:
    pass
assert round(convert(body_temp_f, "F", "C"), 2) == round((body_temp_f - 32) * 5 / 9, 2), "the body temperature in Celsius is wrong"
try:
    convert(10, "C", "X")
    raise AssertionError("an unknown unit like 'X' should raise ValueError")
except ValueError:
    pass''',
                "tips": [
                    "Check the units first: `if from_unit not in [\"C\", \"F\", \"K\"] or to_unit not in [\"C\", \"F\", \"K\"]: raise ValueError(\"unknown unit\")`. Then `if from_unit == to_unit: return value`.",
                    "Use two `if` / `elif` blocks: the first sets `celsius` from `value` depending on `from_unit`; the second returns `celsius` turned into `to_unit`.",
                ],
                "reveal": "Now the pathologist's reading makes sense in Celsius.",
            },
            {
                "notes": "A living body is at **37 °C**. After death it cools by about **1.5 °C every hour**.\n\nSo: hours since death = (37 - body temperature in °C) / 1.5",
                "question": "**Goal:** estimate how many hours ago the victim died.\n\n**You have:** `body_temp_f` and a simple `convert` function (already in the editor).\n\n**Write** a function `hours_since_death(temp_c)`:\n- `temp_c` is the body temperature in Celsius.\n- It returns the hours since death from the field notes, rounded to 1 decimal place with `round(..., 1)`.\n\n**Then** store the answer for this body in a variable `hours`: convert `body_temp_f` to Celsius first, then pass it to your function.\n\n**Example:** `hours_since_death(37)` gives `0.0`, and `hours_since_death(34)` gives `2.0`.",
                "starter": "def convert(value, from_unit, to_unit):\n    if from_unit == \"F\" and to_unit == \"C\":\n        return (value - 32) * 5 / 9\n    return value\n\ndef hours_since_death(temp_c):\n    ...\n\nhours = ...\nprint(hours, \"hours\")\n",
                "solution": "def convert(value, from_unit, to_unit):\n    if from_unit == \"F\" and to_unit == \"C\":\n        return (value - 32) * 5 / 9\n    return value\n\ndef hours_since_death(temp_c):\n    return round((37 - temp_c) / 1.5, 1)\n\nhours = hours_since_death(convert(body_temp_f, \"F\", \"C\"))\nprint(hours, \"hours\")\n",
                "tests": '''_c = (body_temp_f - 32) * 5 / 9
assert hours_since_death(37) == 0, "at 37 °C no time has passed"
assert hours == round((37 - _c) / 1.5, 1), f"hours should be {round((37 - _c) / 1.5, 1)}, got {hours!r}"''',
                "tips": [
                    "Turn the field-notes formula into one line of Python inside the function, wrapped in `round(..., 1)`: `return round((37 - temp_c) / 1.5, 1)`.",
                    'Call one function inside the other: `hours = hours_since_death(convert(body_temp_f, "F", "C"))`.',
                ],
                "reveal": "Count back that many hours from 7 am: the victim died before 11 pm, when the chef, by their own account, was still in the building.",
            },
        ],
        "closing": "Case closed. Two small functions, called together, broke the chef's alibi.",
    },
    # ------------------------------------------------------------ errors
    {
        "id": "corrupted-ledger",
        "tier": "small",
        "title": "The Corrupted Ledger",
        "teaser": "A smuggler's ledger, half of it smudged. Add up what you can.",
        "skills": ["errors"],
        "story": "Customs seized a smuggler's ledger. The clerk typed each amount into `ledger`, but water damage turned some entries into nonsense like `\"12OO\"` (letter O instead of zero) or `\"??\"`.\n\nThe court will accept the total of the **readable** amounts, plus a count of the damaged ones.",
        "suspects": [{"name": "the smuggler", "note": "Claims the ledger is a shopping list."}],
        "variants": [
            'ledger = ["1200", "350", "12OO", "800", "??", "45"]\n',
            'ledger = ["99", "abc", "1000", "1000", "7 00", "250", "x1"]\n',
            'ledger = ["5000", "2500", "5OOO", "125"]\n',
        ],
        "steps": [
            {
                "question": "**Goal:** add up the readable amounts in the ledger and count the damaged ones.\n\n**You have:** `ledger`, a list of strings typed from the ledger (for example `[\"1200\", \"12OO\", \"45\"]`).\n\n**Write** a loop over `ledger` that uses `try` / `except ValueError`:\n- an entry is **readable** if `int(entry)` works; add that whole number to `total`\n- an entry is **damaged** if `int(entry)` raises `ValueError`; add 1 to `damaged`\n- the program must not crash on a damaged entry\n\n**Then** leave the results in the two variables from the starter: `total` (an int, starting at 0) and `damaged` (an int, starting at 0).\n\n**Example:** for `[\"10\", \"x\", \"5\"]`, `total` is `15` and `damaged` is `1`.",
                "starter": "total = 0\ndamaged = 0\n# loop with try / except here\n\nprint(\"Total:\", total, \"Damaged:\", damaged)\n",
                "solution": "total = 0\ndamaged = 0\nfor entry in ledger:\n    try:\n        total += int(entry)\n    except ValueError:\n        damaged += 1\n\nprint(\"Total:\", total, \"Damaged:\", damaged)\n",
                "tests": '''_t, _d = 0, 0
for _e in ledger:
    try:
        _t += int(_e)
    except ValueError:
        _d += 1
assert total == _t, f"total should be {_t}, got {total!r}"
assert damaged == _d, f"damaged should be {_d}, got {damaged!r}"''',
                "tips": [
                    "Put `total += int(entry)` inside `try:`. If `int()` fails, Python jumps to `except ValueError:`.",
                    "In the `except ValueError:` block write `damaged += 1`.",
                ],
                "reveal": "The readable amounts alone exceed the import limit by a long way.",
            },
        ],
        "closing": "Case closed. Bad data didn't crash the investigation; it became evidence too.",
    },
    # ------------------------------------------------------------ toolkit
    {
        "id": "overdue-witness",
        "tier": "small",
        "title": "The Overdue Witness",
        "teaser": "A key witness stopped checking in. How long ago?",
        "skills": ["toolkit"],
        "story": "A protected witness must check in at least every **7 days**. Their `last_check_in` and `today` are dates. If the gap is longer than 7 days, the case is escalated.\n\nTip: subtracting two dates gives a `timedelta`; its `.days` is the number of days.",
        "suspects": [{"name": "the witness's handler", "note": "Was on holiday last week."}],
        "variants": [
            "from datetime import date\nlast_check_in = date(2026, 3, 1)\ntoday = date(2026, 3, 12)\n",
            "from datetime import date\nlast_check_in = date(2026, 6, 20)\ntoday = date(2026, 6, 25)\n",
            "from datetime import date\nlast_check_in = date(2026, 12, 28)\ntoday = date(2027, 1, 9)\n",
        ],
        "steps": [
            {
                "notes": "The check-in rule: a protected witness must check in at least every **7 days**.\n- A gap of 7 days or less is fine.\n- A gap of **more than 7 days** (8 or more) means the case is escalated.",
                "question": "**Goal:** find how long the witness has been missing and whether to escalate.\n\n**You have:** two `date` objects (from `datetime`), already loaded:\n- `last_check_in`, for example `date(2026, 3, 1)`\n- `today`, for example `date(2026, 3, 12)`\n\n**Write** two variables:\n- `days_missing`: the number of days from `last_check_in` to `today`, as a whole number (an int, not a timedelta)\n- `escalate`: the boolean `True` if `days_missing` is more than 7, otherwise `False` (a real `True`/`False`, not the text `\"True\"`)\n\n**Then** print both (the starter already does).\n\n**Example:** from `date(2026, 5, 1)` to `date(2026, 5, 9)`, `days_missing` is `8` and `escalate` is `True`. From `date(2026, 5, 1)` to `date(2026, 5, 8)` it is `7` and `False`.",
                "starter": "days_missing = ...\nescalate = ...\nprint(days_missing, escalate)\n",
                "solution": "days_missing = (today - last_check_in).days\nescalate = days_missing > 7\nprint(days_missing, escalate)\n",
                "tests": '''_d = (today - last_check_in).days
assert days_missing == _d, f"days_missing should be {_d}, got {days_missing!r}"
assert escalate is (_d > 7), f"escalate should be {_d > 7} when {_d} days have passed"''',
                "tips": [
                    "`today - last_check_in` gives a timedelta. Add `.days` to get a whole number.",
                    "`escalate = days_missing > 7` stores True or False.",
                ],
                "reveal": "The gap is on the record. The handler has some explaining to do.",
            },
        ],
        "closing": "Case closed. The witness was safe, but the handler had stopped visiting. Dates don't forget.",
    },
    # ------------------------------------------------------------ identity
    {
        "id": "rounding-fraud",
        "tier": "small",
        "title": "The Rounding Fraud",
        "teaser": "A bank teller skims fractions of a rupee. Floats can't see it.",
        "skills": ["identity"],
        "story": "A teller is suspected of skimming. Each transaction in `amounts` is stored as text, exactly as on the receipts. The teller reported `reported_total`.\n\nFloats are slightly wrong with decimals, so the Bureau insists on `Decimal` for money.",
        "suspects": [{"name": "the teller", "note": "\"It's just rounding.\""}],
        "variants": [
            'amounts = ["10.10", "20.20", "0.35", "99.99"]\nreported_total = "130.40"\n',
            'amounts = ["0.10", "0.20", "0.30", "1500.05"]\nreported_total = "1500.50"\n',
            'amounts = ["45.55", "45.55", "45.55"]\nreported_total = "136.60"\n',
        ],
        "steps": [
            {
                "notes": "How skimming shows up: the **skimmed** amount is the true total of the receipts minus the total the teller reported.\n- 0 means the books balance (honest).\n- Anything else means money is missing (or was invented).",
                "question": "**Goal:** add the receipts exactly and see how much the teller skimmed.\n\n**You have:**\n- `amounts`, a list of money amounts as strings, e.g. `[\"10.10\", \"20.20\"]`\n- `reported_total`, the teller's total as a string, e.g. `\"30.00\"`\n- `Decimal` is already imported in the starter\n\n**Write** three variables:\n- `exact_total`: the sum of all `amounts`, as a `Decimal` (not a float). Make each Decimal from the **string**, e.g. `Decimal(\"10.10\")`.\n- `skimmed`: `exact_total` minus `reported_total` (turned into a `Decimal`). It is a Decimal and may be 0.\n- `honest`: the boolean `True` if `skimmed` is 0, otherwise `False`\n\n**Then** print all three (the starter already does).\n\n**Example:** for `[\"10.10\", \"20.20\"]` and `\"30.00\"`, `exact_total` is `Decimal(\"30.30\")`, `skimmed` is `Decimal(\"0.30\")` and `honest` is `False`.",
                "starter": "from decimal import Decimal\n\nexact_total = ...\nskimmed = ...\nhonest = ...\nprint(exact_total, skimmed, honest)\n",
                "solution": "from decimal import Decimal\n\nexact_total = Decimal(\"0\")\nfor a in amounts:\n    exact_total += Decimal(a)\nskimmed = exact_total - Decimal(reported_total)\nhonest = skimmed == 0\nprint(exact_total, skimmed, honest)\n",
                "tests": '''from decimal import Decimal as _D
_t = sum((_D(a) for a in amounts), _D("0"))
assert exact_total == _t, f"exact_total should be {_t}, got {exact_total!r}"
assert isinstance(exact_total, _D), "exact_total must be a Decimal, not a float"
assert skimmed == _t - _D(reported_total), f"skimmed should be {_t - _D(reported_total)}, got {skimmed!r}"
assert honest is (_t == _D(reported_total)), "honest should be True only when skimmed is 0"''',
                "tips": [
                    "Start with `exact_total = Decimal(\"0\")` and add `Decimal(a)` for each amount. Create Decimals from the **strings**.",
                    "`skimmed = exact_total - Decimal(reported_total)` and `honest = skimmed == 0`.",
                ],
                "reveal": "Exact arithmetic shows exactly how much is missing, to the paisa.",
            },
        ],
        "closing": "Case closed. Tiny amounts, thousands of times a year: the float trap would have hidden it.",
    },
    # ------------------------------------------------------------ forensic text (Q2)
    {
        "id": "anonymous-letters",
        "tier": "small",
        "title": "The Anonymous Letters",
        "teaser": "Threatening letters. Every writer has a favourite word.",
        "skills": ["records", "forensic-text"],
        "story": "Someone is sending threatening letters to the mayor. Linguists say every writer overuses one word. The newest letter is in `letter`, and `favourite_words` maps each suspect to the word they use most in their known emails.\n\n*(This is the official assignment Q2: word frequency.)*",
        "suspects": [{"name": "Kapoor", "note": "The rival candidate. Gains the most if the mayor resigns."}, {"name": "Iyer", "note": "The former aide. Left the mayor's office on bad terms."}, {"name": "Mendes", "note": "The journalist. Has written about the mayor for years."}],
        "variants": [
            'letter = "Resign now. Resign before the vote! Everyone knows. Resign."\nfavourite_words = {"Kapoor": "everyone", "Iyer": "resign", "Mendes": "vote"}\n',
            'letter = "The truth will come out. The truth is near. Truth, always truth."\nfavourite_words = {"Kapoor": "truth", "Iyer": "near", "Mendes": "always"}\n',
            'letter = "Money talks. Your silence, my silence. Silence costs money? Silence."\nfavourite_words = {"Kapoor": "money", "Iyer": "costs", "Mendes": "silence"}\n',
        ],
        "steps": [
            {
                "question": "**Goal:** count how often each word appears in the letter.\n\n**You have:** `letter`, the newest letter as one string, e.g. `\"Resign now. Resign!\"`.\n\n**Write** a function `word_frequency(text)`:\n- `text` is any string\n- first turn the whole text into lower case\n- then remove these four marks: `.` `,` `!` `?` (nothing else needs removing)\n- then split it into words on spaces\n- return a dict mapping each word (a lower-case string) to how many times it appears (an int)\n- an empty text `\"\"` returns an empty dict `{}`\n\n**Then** print `word_frequency(letter)` (the starter already does).\n\n**Example:** `word_frequency(\"Run, Forest! Run.\")` gives `{\"run\": 2, \"forest\": 1}`.",
                "starter": "def word_frequency(text):\n    ...\n\nprint(word_frequency(letter))\n",
                "solution": 'def word_frequency(text):\n    cleaned = text.lower()\n    for mark in [".", ",", "!", "?"]:\n        cleaned = cleaned.replace(mark, "")\n    counts = {}\n    for word in cleaned.split():\n        counts[word] = counts.get(word, 0) + 1\n    return counts\n\nprint(word_frequency(letter))\n',
                "tests": '''assert word_frequency("The fox. The quick fox. The fox jumps.") == {"the": 3, "fox": 3, "quick": 1, "jumps": 1}, "on 'The fox. The quick fox. The fox jumps.' the counts are wrong"
assert word_frequency("") == {}, "an empty text should give an empty dict"
_c = letter.lower()
for _m in ".,!?":
    _c = _c.replace(_m, "")
_e = {}
for _w in _c.split():
    _e[_w] = _e.get(_w, 0) + 1
assert word_frequency(letter) == _e, "the counts for the letter are wrong"''',
                "tips": [
                    "Lower-case first, then remove each mark with `.replace(mark, \"\")`, then `.split()` into words.",
                    "Count with a dict: `counts[word] = counts.get(word, 0) + 1`.",
                ],
                "reveal": "The letter's vocabulary is on the table.",
            },
            {
                "notes": "The linguists' rule: the writer of the letter is the suspect whose **favourite word** (the word they use most in their emails) is the **most frequent word in the letter**.",
                "question": "**Goal:** name the suspect who wrote the letter.\n\n**You have:**\n- `letter`, the letter as a string\n- `favourite_words`, a dict mapping each suspect's name to their favourite word (lower case), e.g. `{\"Kapoor\": \"everyone\", \"Iyer\": \"resign\"}`\n- a working `word_frequency(text)` from step 1 (already in the editor)\n\n**Write** code that:\n- gets the word counts with `word_frequency(letter)`\n- finds the word with the highest count. If two words tie, keep the one that comes **first** in the counts dict (the one that appeared first in the letter): only switch to a new word when its count is strictly bigger.\n- finds the suspect in `favourite_words` whose word equals that top word\n\n**Then** store that suspect's name (a string, a key of `favourite_words`) in `writer`.\n\n**Example:** if the counts are `{\"cash\": 3, \"now\": 1}` and `favourite_words` is `{\"Ali\": \"now\", \"Bea\": \"cash\"}`, then `writer` is `\"Bea\"`.",
                "starter": 'def word_frequency(text):\n    cleaned = text.lower()\n    for mark in [".", ",", "!", "?"]:\n        cleaned = cleaned.replace(mark, "")\n    counts = {}\n    for word in cleaned.split():\n        counts[word] = counts.get(word, 0) + 1\n    return counts\n\nwriter = ...\nprint("Written by", writer)\n',
                "solution": 'def word_frequency(text):\n    cleaned = text.lower()\n    for mark in [".", ",", "!", "?"]:\n        cleaned = cleaned.replace(mark, "")\n    counts = {}\n    for word in cleaned.split():\n        counts[word] = counts.get(word, 0) + 1\n    return counts\n\ncounts = word_frequency(letter)\ntop = None\nfor word in counts:\n    if top is None or counts[word] > counts[top]:\n        top = word\n\nwriter = None\nfor suspect, word in favourite_words.items():\n    if word == top:\n        writer = suspect\nprint("Written by", writer)\n',
                "tests": '''_c = word_frequency(letter)
_top = None
for _w in _c:
    if _top is None or _c[_w] > _c[_top]:
        _top = _w
_exp = [s for s, w in favourite_words.items() if w == _top][0]
assert writer == _exp, f"the writer should be {_exp!r}, got {writer!r}"''',
                "tips": [
                    "Find the top word like the phone-records case: loop over the counts and keep the word with the biggest count.",
                    "Then loop over `favourite_words.items()` and pick the suspect whose word equals the top word.",
                ],
                "reveal": "The favourite word gives the writer away.",
            },
        ],
        "closing": "Case closed. People can disguise their handwriting, but not their habits.",
    },
    # ------------------------------------------------------------ forensic text + errors (Q4)
    {
        "id": "smudged-serials",
        "tier": "small",
        "title": "Smudged Serial Numbers",
        "teaser": "Stolen laptops, scratched serial numbers. Which ones are real?",
        "skills": ["errors", "forensic-text"],
        "story": "A warehouse of stolen laptops. Each has a serial number, but thieves scratched them and added fake ones. A real serial has **exactly 10 or 13 digits** once spaces and hyphens are removed.\n\n*(This is the official assignment Q4: the ISBN cleaner.)*",
        "suspects": [{"name": "the warehouse manager", "note": "Signed for every delivery."}],
        "variants": [
            'serials = ["978-0-13-235088-4", "  0132350882  ", "abc", "12345", "555-555-5555"]\n',
            'serials = ["0201485677", "0-201-48567-X", "1234567890123", "98-76", "  4 4 4 4 4 4 4 4 4 4 "]\n',
            'serials = ["X", "1111111111", "2222-2222-22", "9780132350884", "97801323508841"]\n',
        ],
        "steps": [
            {
                "notes": "What makes a serial number real (the same rule as an ISBN book number, without the check digit):\n- Ignore every space and every hyphen `-` in it.\n- What is left must be **only digits** 0-9 (a letter such as `X` makes it fake).\n- It must be **exactly 10 or exactly 13** digits long. Any other length is fake, including an empty one.",
                "question": "**Goal:** a function that cleans one serial number and rejects the fakes.\n\n**You have:** `serials`, a list of raw serial numbers as strings, e.g. `[\"978-0-13-235088-4\", \"abc\"]`.\n\n**Write** a function `clean_serial(raw)`:\n- `raw` is one serial number as a string\n- remove all spaces and hyphens from it\n- if the result is real (see the field notes), return the cleaned string, e.g. `\"9780132350884\"` (a string, not an int)\n- otherwise `raise ValueError(...)` (any message)\n\n**Then** try it: the starter prints `clean_serial(\"978-0-13-235088-4\")`.\n\n**Example:** `clean_serial(\" 12-345 67890 \")` returns `\"1234567890\"`. `clean_serial(\"12345\")`, `clean_serial(\"\")` and `clean_serial(\"123456789X\")` each raise `ValueError`.",
                "starter": "def clean_serial(raw):\n    ...\n\nprint(clean_serial(\"978-0-13-235088-4\"))\n",
                "solution": 'def clean_serial(raw):\n    cleaned = raw.replace("-", "").replace(" ", "")\n    if cleaned.isdigit() and (len(cleaned) == 10 or len(cleaned) == 13):\n        return cleaned\n    raise ValueError("invalid serial: " + raw)\n\nfor s in serials:\n    try:\n        print(clean_serial(s))\n    except ValueError as e:\n        print(e)\n',
                "tests": '''assert clean_serial("978-0-13-235088-4") == "9780132350884", "clean_serial('978-0-13-235088-4') should give '9780132350884'"
assert clean_serial("  0132350882  ") == "0132350882", "spaces around the number must be removed"
for _bad in ("abc", "12345", "", "978-0-13-23508X-4", "97801323508841"):
    try:
        clean_serial(_bad)
        raise AssertionError(f"clean_serial({_bad!r}) should raise ValueError")
    except ValueError:
        pass''',
                "tips": [
                    "`raw.replace(\"-\", \"\").replace(\" \", \"\")` removes hyphens and spaces. `.isdigit()` is True only if every character is a digit.",
                    "Return it if `cleaned.isdigit()` and its length is 10 or 13; otherwise `raise ValueError(...)`.",
                ],
                "reveal": "The rule is written down. Now apply it to the warehouse.",
            },
            {
                "question": "**Goal:** sort the whole warehouse into genuine and fake serials.\n\n**You have:**\n- `serials`, the list of raw serial numbers (strings)\n- a working `clean_serial(raw)` from step 1 (already in the editor): it returns the cleaned string or raises `ValueError`\n\n**Write** a loop over `serials` that calls `clean_serial` inside `try` / `except ValueError`:\n- `genuine`: a list of the **cleaned** strings for the real serials, in the same order as in `serials`\n- `fakes`: an int, how many serials raised `ValueError`\n\n**Then** leave the results in `genuine` and `fakes` (both start empty / 0 in the starter).\n\n**Example:** for `[\"12-345-67890\", \"abc\"]`, `genuine` is `[\"1234567890\"]` and `fakes` is `1`.",
                "starter": 'def clean_serial(raw):\n    cleaned = raw.replace("-", "").replace(" ", "")\n    if cleaned.isdigit() and (len(cleaned) == 10 or len(cleaned) == 13):\n        return cleaned\n    raise ValueError("invalid serial: " + raw)\n\ngenuine = []\nfakes = 0\n# loop here\n\nprint(genuine, fakes)\n',
                "solution": 'def clean_serial(raw):\n    cleaned = raw.replace("-", "").replace(" ", "")\n    if cleaned.isdigit() and (len(cleaned) == 10 or len(cleaned) == 13):\n        return cleaned\n    raise ValueError("invalid serial: " + raw)\n\ngenuine = []\nfakes = 0\nfor s in serials:\n    try:\n        genuine.append(clean_serial(s))\n    except ValueError:\n        fakes += 1\n\nprint(genuine, fakes)\n',
                "tests": '''_g, _f = [], 0
for _s in serials:
    _c = _s.replace("-", "").replace(" ", "")
    if _c.isdigit() and len(_c) in (10, 13):
        _g.append(_c)
    else:
        _f += 1
assert genuine == _g, f"genuine should be {_g}, got {genuine}"
assert fakes == _f, f"fakes should be {_f}, got {fakes!r}"''',
                "tips": [
                    "Loop over `serials`; inside `try:` append `clean_serial(s)` to `genuine`.",
                    "In `except ValueError:` add 1 to `fakes`.",
                ],
                "reveal": "The genuine serials match a shipment reported stolen from the docks.",
            },
        ],
        "closing": "Case closed. A clear rule, written once as a function, sorted real from fake in seconds.",
    },
    # ------------------------------------------------------------ collections (Q8)
    {
        "id": "cold-case-archive",
        "tier": "small",
        "title": "The Cold Case Archive",
        "teaser": "Decades of unsolved cases in one messy box.",
        "skills": ["collections"],
        "story": "The archive's unsolved cases arrived in one unsorted list, `cases`. The Chief wants them grouped **by year** so patterns jump out.\n\n*(This is the official assignment Q8: group by year, once with `defaultdict` and once with `setdefault`.)*",
        "suspects": [{"name": "unknown", "note": "That's the point of a cold case."}],
        "variants": [
            'cases = [{"code": "CC-11", "year": 1998}, {"code": "CC-12", "year": 2003}, {"code": "CC-13", "year": 1998}, {"code": "CC-14", "year": 2011}]\n',
            'cases = [{"code": "K-1", "year": 2015}, {"code": "K-2", "year": 2015}, {"code": "K-3", "year": 2015}, {"code": "K-4", "year": 1987}]\n',
            'cases = [{"code": "Z-9", "year": 2001}, {"code": "Z-8", "year": 2002}, {"code": "Z-7", "year": 2001}, {"code": "Z-6", "year": 2002}, {"code": "Z-5", "year": 2002}]\n',
        ],
        "steps": [
            {
                "question": "**Goal:** group the cold cases by year (two ways) and find the year with the most.\n\n**You have:** `cases`, a list of dicts, each with a `\"code\"` (string) and a `\"year\"` (int), e.g. `[{\"code\": \"CC-11\", \"year\": 1998}, {\"code\": \"CC-12\", \"year\": 2003}]`.\n\n**Write** two functions that give the same answer:\n- `by_year(cases)`: use `defaultdict(list)`, then return it as a **plain dict** with `dict(...)`\n- `by_year_setdefault(cases)`: use a plain `{}` and `.setdefault(...)`\n- both return a dict mapping each year (int) to a list of that year's case codes, in the same order as in `cases`\n- both return `{}` for an empty list\n\n**Then** store the year (an int) that has the most cases in `worst_year`. If two years tie, either is accepted.\n\n**Example:** for `[{\"code\": \"A\", \"year\": 2000}, {\"code\": \"B\", \"year\": 2001}, {\"code\": \"C\", \"year\": 2000}]`, both functions return `{2000: [\"A\", \"C\"], 2001: [\"B\"]}` and `worst_year` is `2000`.",
                "starter": "from collections import defaultdict\n\ndef by_year(cases):\n    ...\n\ndef by_year_setdefault(cases):\n    ...\n\nworst_year = ...\nprint(by_year(cases), worst_year)\n",
                "solution": "from collections import defaultdict\n\ndef by_year(cases):\n    groups = defaultdict(list)\n    for c in cases:\n        groups[c[\"year\"]].append(c[\"code\"])\n    return dict(groups)\n\ndef by_year_setdefault(cases):\n    groups = {}\n    for c in cases:\n        groups.setdefault(c[\"year\"], []).append(c[\"code\"])\n    return groups\n\ngroups = by_year(cases)\nworst_year = None\nfor year in groups:\n    if worst_year is None or len(groups[year]) > len(groups[worst_year]):\n        worst_year = year\nprint(by_year(cases), worst_year)\n",
                "tests": '''_e = {}
for _c in cases:
    _e.setdefault(_c["year"], []).append(_c["code"])
_r = by_year(cases)
assert type(_r) is dict, "by_year should return a plain dict (wrap it with dict(...))"
assert _r == _e, f"by_year gave {_r}, expected {_e}"
assert by_year_setdefault(cases) == _e, "by_year_setdefault gives a different result"
assert by_year([]) == {} and by_year_setdefault([]) == {}, "no cases should give an empty dict"
_most = max(len(v) for v in _e.values())
assert len(_e.get(worst_year, [])) == _most, f"worst_year should be a year with {_most} cases"''',
                "tips": [
                    "`groups = defaultdict(list)` then `groups[c[\"year\"]].append(c[\"code\"])`, and `return dict(groups)`.",
                    "The setdefault version: `groups.setdefault(c[\"year\"], []).append(c[\"code\"])` on a plain `{}`.",
                ],
                "reveal": "One year stands out with far more unsolved cases than any other.",
            },
        ],
        "closing": "Case closed, or rather, reopened: the busiest year leads to a forgotten serial burglar.",
    },
    {
        "id": "double-agent",
        "tier": "small",
        "title": "The Double Agent",
        "teaser": "Two rival gangs. Someone is on both payrolls.",
        "skills": ["collections"],
        "story": "Undercover officers copied the member lists of two rival gangs, `red_dragons` and `blue_vipers`. Anyone on **both** lists is a double agent. Names may repeat within a list.\n\nSets make this fast.",
        "suspects": [{"name": "the double agent", "note": "Selling secrets both ways."}],
        "variants": [
            'red_dragons = ["Arjun", "Leela", "Omar", "Leela", "Sam"]\nblue_vipers = ["Priya", "Omar", "Kiran", "Omar"]\n',
            'red_dragons = ["Neel", "Tara", "Yusuf", "Rhea"]\nblue_vipers = ["Rhea", "Farhan", "Neel", "Maya"]\n',
            'red_dragons = ["Zoya", "Dev", "Ira"]\nblue_vipers = ["Ira", "Ira", "Kabir"]\n',
        ],
        "steps": [
            {
                "notes": "A **double agent** is a person whose name is on **both** gang lists. A name written twice in the same list is still one person.",
                "question": "**Goal:** find the double agents and count everyone involved.\n\n**You have:** two lists of names (strings), and a name can repeat inside one list:\n- `red_dragons`, e.g. `[\"Arjun\", \"Leela\", \"Leela\"]`\n- `blue_vipers`, e.g. `[\"Leela\", \"Kiran\"]`\n\n**Write** two variables:\n- `double_agents`: a **list** of the names that are in both lists, each name once, sorted A to Z\n- `total_members`: an int, the number of **different** people in either gang (count each name once)\n\n**Then** print both (the starter already does).\n\n**Example:** for `[\"Bo\", \"Al\", \"Al\"]` and `[\"Al\", \"Cy\", \"Bo\"]`, `double_agents` is `[\"Al\", \"Bo\"]` and `total_members` is `3`.",
                "starter": "double_agents = ...\ntotal_members = ...\nprint(double_agents, total_members)\n",
                "solution": "double_agents = sorted(set(red_dragons) & set(blue_vipers))\ntotal_members = len(set(red_dragons) | set(blue_vipers))\nprint(double_agents, total_members)\n",
                "tests": '''_d = sorted(set(red_dragons) & set(blue_vipers))
assert double_agents == _d, f"double_agents should be {_d}, got {double_agents!r}"
_t = len(set(red_dragons) | set(blue_vipers))
assert total_members == _t, f"total_members should be {_t}, got {total_members!r}"''',
                "tips": [
                    "`set(a) & set(b)` keeps names in both; `set(a) | set(b)` keeps names in either.",
                    "Wrap the intersection in `sorted(...)` to get a list; use `len(...)` on the union.",
                ],
                "reveal": "The double agent's name is on both payrolls in plain sight.",
            },
        ],
        "closing": "Case closed. Two lists, one `&`, and the leak was plugged.",
    },
    # ------------------------------------------------------------ function craft (Q5, Q7)
    {
        "id": "shared-notebook",
        "tier": "small",
        "title": "The Shared Notebook",
        "teaser": "One detective's notes keep appearing in everyone else's case.",
        "skills": ["function-craft"],
        "story": "The Bureau's note-taking helper has a bug: notes from one case show up in every other case's notebook. Here is the helper:\n\n`def add_note(note, notebook=[]): notebook.append(note); return notebook`\n\nThe raw notes are in `case_notes`, a list of `(case, note)` pairs.\n\n*(This is the official assignment Q5: the mutable default trap.)*",
        "suspects": [{"name": "the helper function", "note": "The culprit is a default argument."}],
        "variants": [
            'case_notes = [("C1", "glove"), ("C2", "receipt"), ("C1", "footprint")]\n',
            'case_notes = [("A", "ticket"), ("B", "lighter"), ("C", "map"), ("A", "coin")]\n',
            'case_notes = [("X9", "key"), ("X9", "badge"), ("Y1", "phone")]\n',
        ],
        "steps": [
            {
                "notes": "**How a default value works:** Python builds a default value like `notebook=[]` **once**, when the `def` line runs, not each time the function is called. Every call that leaves `notebook` out gets that **same** list, so it keeps everything earlier calls appended. A call that passes its own list, like `add_note(\"x\", [])`, uses that list instead and doesn't touch the shared one.",
                "question": "**Goal:** predict what the buggy helper does before you run it.\n\n**You have:** `case_notes` (see the evidence) and, in the starter, the buggy `add_note(note, notebook=[])`, plus `n1`, `n2` and `n3`: the notes of the first three entries in `case_notes`.\n\nThe starter will make these four calls, in this order, and print what each one returns:\n1. `add_note(n1)`\n2. `add_note(n2)`\n3. `add_note(n3, [])`\n4. `add_note(n1)`\n\n**Write** a variable `predicted`: a list of **four** lists, what you expect each call to print. Work it out from the field notes **before** you run the code, and type the lists in by hand (with the note words, or with `n1`, `n2` and `n3`).\n\n**Then** run it: the starter prints the real results under your prediction so you can compare.\n\n**Example:** if the notes were `\"x\"`, `\"y\"` and `\"z\"`, the four calls print `['x']`, `['x', 'y']`, `['z']` and `['x', 'y', 'x']`, so `predicted` is `[[\"x\"], [\"x\", \"y\"], [\"z\"], [\"x\", \"y\", \"x\"]]`.",
                "starter": "def add_note(note, notebook=[]):\n    notebook.append(note)\n    return notebook\n\nn1, n2, n3 = case_notes[0][1], case_notes[1][1], case_notes[2][1]\nprint(\"The notes:\", n1, n2, n3)\n\npredicted = []    # your four lists here\n\nprint(\"Predicted:\", predicted)\nprint(\"Really:\")\nprint(add_note(n1))\nprint(add_note(n2))\nprint(add_note(n3, []))\nprint(add_note(n1))\n",
                "solution": "def add_note(note, notebook=[]):\n    notebook.append(note)\n    return notebook\n\nn1, n2, n3 = case_notes[0][1], case_notes[1][1], case_notes[2][1]\nprint(\"The notes:\", n1, n2, n3)\n\npredicted = [[n1], [n1, n2], [n3], [n1, n2, n1]]\n\nprint(\"Predicted:\", predicted)\nprint(\"Really:\")\nprint(add_note(n1))\nprint(add_note(n2))\nprint(add_note(n3, []))\nprint(add_note(n1))\n",
                "tests": '''def _buggy(_note, _book=[]):
    _book.append(_note)
    return _book
_n1, _n2, _n3 = case_notes[0][1], case_notes[1][1], case_notes[2][1]
_real = [list(_buggy(_n1)), list(_buggy(_n2)), list(_buggy(_n3, [])), list(_buggy(_n1))]
assert isinstance(predicted, list) and len(predicted) == 4, f"predicted should be a list of 4 lists, one per call; got {predicted!r}"
for _i in range(4):
    assert predicted[_i] == _real[_i], f"call {_i + 1} really prints {_real[_i]}, but you predicted {predicted[_i]!r}. Remember: the default list is shared by every call that leaves notebook out."''',
                "tips": [
                    "Calls 1, 2 and 4 leave `notebook` out, so they all add to the **same** list: it grows with each of those calls. Call 3 passes a brand-new list, so it only holds its own note.",
                    "Call 4 adds `n1` again to the shared list, which already holds `n1` and `n2` from calls 1 and 2. You may write the lists with the variables, e.g. `[n1, n2]`, or with the words themselves.",
                ],
                "reveal": "The fourth call prints notes from the first two. The helper has been remembering every note it was ever given.",
            },
            {
                "question": "**Goal:** fix the helper so notes stop leaking between cases.\n\n**You have:**\n- `case_notes`, a list of `(case, note)` pairs (both strings), e.g. `[(\"C1\", \"glove\"), (\"C2\", \"receipt\")]`\n- the buggy `add_note` in the editor: its default `notebook=[]` is one list shared by every call\n- a loop that builds `notebooks` with `add_note` (already written; it works once `add_note` is fixed)\n\n**Write** a fixed `add_note(note, notebook=None)`:\n- if no notebook is passed (`notebook` is `None`), start a **new empty list** inside the function\n- append `note` to the notebook and return that same list\n- if a notebook **is** passed, add to that exact list (do not copy it) and return it\n\n**Then** run the loop as given: `notebooks` must be a dict mapping each case to a list of its own notes, in order.\n\n**Example:** `add_note(\"a\")` returns `[\"a\"]`, and a second call `add_note(\"b\")` returns `[\"b\"]` (not `[\"a\", \"b\"]`). For `[(\"C1\", \"glove\"), (\"C2\", \"map\"), (\"C1\", \"hair\")]`, `notebooks` is `{\"C1\": [\"glove\", \"hair\"], \"C2\": [\"map\"]}`.",
                "starter": "def add_note(note, notebook=[]):\n    notebook.append(note)\n    return notebook\n\nnotebooks = {}\nfor case, note in case_notes:\n    if case in notebooks:\n        add_note(note, notebooks[case])\n    else:\n        notebooks[case] = add_note(note)\n\nprint(notebooks)\n",
                "solution": "def add_note(note, notebook=None):\n    if notebook is None:\n        notebook = []\n    notebook.append(note)\n    return notebook\n\nnotebooks = {}\nfor case, note in case_notes:\n    if case in notebooks:\n        add_note(note, notebooks[case])\n    else:\n        notebooks[case] = add_note(note)\n\nprint(notebooks)\n",
                "tests": '''assert add_note("a") == ["a"], "a call without a notebook should return a new list"
assert add_note("b") == ["b"], "the default list is still shared between calls"
_mine = ["x"]
assert add_note("y", _mine) is _mine and _mine == ["x", "y"], "passing a notebook should add to that notebook"
_e = {}
for _c, _n in case_notes:
    _e.setdefault(_c, []).append(_n)
assert notebooks == _e, f"notebooks should be {_e}, got {notebooks}"''',
                "tips": [
                    "Change the default to `notebook=None`.",
                    "Inside: `if notebook is None: notebook = []`, then append and return.",
                ],
                "reveal": "Each case now has its own notebook. The cross-contamination was the code, not a mole.",
            },
        ],
        "closing": "Case closed. The \"mole\" leaking notes between cases was one default argument.",
    },
    {
        "id": "shortest-alibi",
        "tier": "medium",         # re-tiered: ~27 lines to write
        "title": "The Shortest Alibi",
        "teaser": "Whose alibi leaves the biggest hole? No min() allowed.",
        "skills": ["function-craft"],
        "story": "Each suspect's alibi covers some minutes of the evening, in `alibis` (a list of dicts with `name` and `minutes`). The shortest alibi leaves the most time unaccounted for.\n\nThe Bureau's computers are ancient: no `min`, `max` or `sorted` here.\n\n*(This is the official assignment Q7: min/max without built-ins.)*",
        "suspects": [{"name": "everyone with a short alibi", "note": ""}],
        "variants": [
            'alibis = [{"name": "Asha", "minutes": 120}, {"name": "Ravi", "minutes": 45}, {"name": "Zoya", "minutes": 200}]\n',
            'alibis = [{"name": "Omar", "minutes": 15}, {"name": "Leela", "minutes": 90}, {"name": "Sam", "minutes": 300}, {"name": "Nisha", "minutes": 15}]\n',
            'alibis = [{"name": "Kabir", "minutes": 75}, {"name": "Meera", "minutes": 80}, {"name": "Dev", "minutes": 60}]\n',
        ],
        "steps": [
            {
                "question": "**Goal:** rebuild `min` and `max` yourself, then find the shortest alibi.\n\n**You have:** `alibis`, a list of dicts, each with a `\"name\"` (string) and `\"minutes\"` (int), e.g. `[{\"name\": \"Asha\", \"minutes\": 120}, {\"name\": \"Ravi\", \"minutes\": 45}]`.\n\n**Write** two functions, **without** using `min`, `max` or `sorted`:\n- `my_min(items, key=None)` returns the smallest item in the list `items`; `my_max(items, key=None)` returns the largest\n- `key` is an optional function: compare `key(item)` instead of the item itself. If `key` is `None`, compare the items themselves.\n- return the **item** itself (not `key(item)`)\n- ties keep the **first** such item: only replace your best item when the new one is strictly smaller (for `my_min`) or strictly larger (for `my_max`)\n- an empty list raises `ValueError`\n\n**Then** store the **name** (a string) of the suspect with the fewest minutes in `prime_suspect`, using `my_min` with a key. If two alibis tie, the one listed first.\n\n**Example:** `my_min([3, 1, 2])` is `1`, `my_max([3, 1, 2])` is `3`, `my_max([\"aa\", \"b\", \"cc\"], key=len)` is `\"aa\"`, and `my_min([])` raises `ValueError`.",
                "starter": "def my_min(items, key=None):\n    ...\n\ndef my_max(items, key=None):\n    ...\n\nprime_suspect = ...\nprint(prime_suspect)\n",
                "solution": '''def same(x):
    return x

def my_min(items, key=None):
    if key is None:
        key = same
    best = None
    found = False
    for item in items:
        if not found or key(item) < key(best):
            best = item
            found = True
    if not found:
        raise ValueError(\"empty sequence\")
    return best

def my_max(items, key=None):
    if key is None:
        key = same
    best = None
    found = False
    for item in items:
        if not found or key(item) > key(best):
            best = item
            found = True
    if not found:
        raise ValueError(\"empty sequence\")
    return best

def minutes(alibi):
    return alibi[\"minutes\"]

prime_suspect = my_min(alibis, key=minutes)[\"name\"]
print(prime_suspect)
''',
                "tests": '''assert my_min([3, 1, 2]) == 1 and my_max([3, 1, 2]) == 3, "my_min/my_max are wrong on [3, 1, 2]"
assert my_max(["aa", "b", "cc"], key=len) == "aa", "ties should keep the first item"
for _fn in (my_min, my_max):
    try:
        _fn([])
        raise AssertionError(f"{_fn.__name__}([]) should raise ValueError")
    except ValueError:
        pass
_low = alibis[0]
for _a in alibis:
    if _a["minutes"] < _low["minutes"]:
        _low = _a
assert prime_suspect == _low["name"], f"prime_suspect should be {_low['name']!r}, got {prime_suspect!r}"
assert my_min(alibis, key=lambda _a: _a["minutes"]) is _low, "my_min(alibis, key=...) should compare key(item) and return the whole alibi dict with the fewest minutes"
assert my_min(["bb", "a", "c"], key=len) == "a", "my_min with key=len: \\"a\\" and \\"c\\" tie, so the first one, \\"a\\", should win"
assert my_min([5, 2, 9], key=lambda _x: -_x) == 9, "my_min should compare key(item), not the item itself"''',
                "tips": [
                    "Keep the best item so far; replace it only when `key(item)` is strictly smaller (min) or larger (max), so ties keep the first.",
                    "`key` is a function: when it is None, use one that returns the item itself. Use a `found` flag; if nothing was found, `raise ValueError(...)`. For the alibis, write `def minutes(alibi): return alibi[\"minutes\"]` and call `my_min(alibis, key=minutes)`.",
                ],
                "reveal": "One alibi is so short it barely covers a cup of tea.",
            },
        ],
        "closing": "Case closed. You rebuilt `min` from scratch and found the hole in the story.",
    },
    # ------------------------------------------------------------ functional (Q3)
    {
        "id": "badge-code",
        "tier": "small",
        "title": "The Badge Code",
        "teaser": "The evidence safe opens with a code hidden in badge numbers.",
        "skills": ["functional"],
        "story": "The evidence safe's code is derived from the on-duty officers' `badges`: take only the **even** badge numbers, **multiply each by 3**, and sort them **from largest to smallest**.\n\n*(This is the official assignment Q3: a one-line list comprehension.)*",
        "suspects": [{"name": "nobody", "note": "Just open the safe."}],
        "variants": [
            "badges = [5, 8, 3, 12, 7, 4, 9, 2]\n",
            "badges = [10, 21, 14, 3, 6]\n",
            "badges = [1, 22, 40, 13, 8, 8]\n",
        ],
        "steps": [
            {
                "notes": "How the safe code is made from the badge numbers:\n1. Keep only the **even** badge numbers (even = divides by 2 with no remainder, like 2, 4, 8).\n2. Multiply each one by **3**.\n3. Put them in order from **largest to smallest**. Repeated numbers stay repeated.",
                "question": "**Goal:** work out the safe code in a single line of Python.\n\n**You have:** `badges`, a list of badge numbers (ints), e.g. `[5, 8, 3, 12]`.\n\n**Write** a variable `code` in **one** line:\n- use a list comprehension that keeps the even badges (`b % 2 == 0`) and multiplies each by 3\n- wrap it in `sorted(..., reverse=True)` so the biggest number comes first\n- `code` is a list of ints; keep duplicates\n\n**Then** print `code` (the starter already does).\n\n**Example:** for `[1, 4, 6, 4, 7]`, `code` is `[18, 12, 12]`.",
                "starter": "code = ...\nprint(code)\n",
                "solution": "code = sorted([b * 3 for b in badges if b % 2 == 0], reverse=True)\nprint(code)\n",
                "tests": '''_e = sorted([b * 3 for b in badges if b % 2 == 0], reverse=True)
assert code == _e, f"code should be {_e}, got {code!r}"''',
                "tips": [
                    "Inside the brackets: `b * 3 for b in badges if b % 2 == 0`.",
                    "Wrap it: `sorted([...], reverse=True)`.",
                ],
                "reveal": "The code is on the screen. Before the Chief types it in, the old safe manual wants it worked out the long way too.",
            },
            {
                "notes": "Same rule as before: keep the **even** badges, multiply each by **3**, order from **largest to smallest**, duplicates stay.",
                "question": "**Goal:** work out the same code without a list comprehension, then compare the two versions.\n\n**You have:** `badges`, and `code` from step 1 (the one-line version, already in the editor).\n\n**Write** a variable `code_loop`, built step by step:\n- start with an empty list `code_loop = []`\n- loop with `for b in badges:`; inside, `if b % 2 == 0:` append `b * 3` with `code_loop.append(...)`\n- after the loop, sort it largest first with `code_loop.sort(reverse=True)`\n- don't use a list comprehension (no `[... for ...]`) for this version\n\n**Then** store `same = code_loop == code` (it should be `True`) and print both lists. Look at them side by side: the comprehension is one line, the loop is five, and both say the same thing.\n\n**Example:** for `[1, 4, 6, 4, 7]`, `code_loop` is `[18, 12, 12]`, the same as `code`.",
                "starter": "code = sorted([b * 3 for b in badges if b % 2 == 0], reverse=True)\n\ncode_loop = []\n# your loop here\n\nsame = ...\nprint(code)\nprint(code_loop)\nprint(\"Same code:\", same)\n",
                "solution": "code = sorted([b * 3 for b in badges if b % 2 == 0], reverse=True)\n\ncode_loop = []\nfor b in badges:\n    if b % 2 == 0:\n        code_loop.append(b * 3)\ncode_loop.sort(reverse=True)\n\nsame = code_loop == code\nprint(code)\nprint(code_loop)\nprint(\"Same code:\", same)\n",
                "tests": '''_e = sorted([b * 3 for b in badges if b % 2 == 0], reverse=True)
assert code_loop == _e, f"code_loop should be {_e}, got {code_loop!r}"
assert ".append(" in __source__, "build code_loop with a for loop and code_loop.append(...), not a comprehension"
assert same is True, "same should be the result of code_loop == code, which is True"''',
                "tips": [
                    "Three lines make the list: `for b in badges:`, then (indented) `if b % 2 == 0:`, then (indented again) `code_loop.append(b * 3)`.",
                    "After the loop (not indented), `code_loop.sort(reverse=True)` sorts the list in place. Then `same = code_loop == code`.",
                ],
                "reveal": "Both versions give the same code. Click. The safe swings open.",
            },
        ],
        "closing": "Case closed. One readable line of Python opened the safe, and the long way proved it.",
    },
    {
        "id": "lineup",
        "tier": "small",
        "title": "The Line-up",
        "teaser": "Order the suspects: weakest alibi first.",
        "skills": ["functional"],
        "story": "Detectives rate each alibi's strength from 1 to 10. For the line-up, the Chief wants suspects ordered by **alibi strength (weakest first)**, then **alphabetically** when strengths tie. The ratings are in `suspects` (a list of dicts).",
        "suspects": [{"name": "the whole line-up", "note": ""}],
        "variants": [
            'suspects = [{"name": "Vikram", "alibi": 7}, {"name": "Asha", "alibi": 3}, {"name": "Dev", "alibi": 3}, {"name": "Meera", "alibi": 9}]\n',
            'suspects = [{"name": "Zara", "alibi": 1}, {"name": "Omar", "alibi": 5}, {"name": "Ana", "alibi": 5}]\n',
            'suspects = [{"name": "Kiran", "alibi": 4}, {"name": "Bilal", "alibi": 8}, {"name": "Chen", "alibi": 2}, {"name": "Ada", "alibi": 2}]\n',
        ],
        "steps": [
            {
                "notes": "The Chief's line-up rule:\n- Alibi strength runs from 1 (weakest) to 10 (strongest). The **weakest** alibi stands first.\n- If two suspects have the same strength, they stand in **alphabetical** order of name (A before Z).",
                "question": "**Goal:** put the suspects in line-up order.\n\n**You have:** `suspects`, a list of dicts, each with a `\"name\"` (string) and an `\"alibi\"` strength (int), e.g. `[{\"name\": \"Vikram\", \"alibi\": 7}, {\"name\": \"Asha\", \"alibi\": 3}]`.\n\n**Write** three variables:\n- `ordered`: `suspects` sorted with `sorted(...)` and `key=lambda s: ...` returning a **tuple**: alibi strength first (low to high), then name (A to Z)\n- `order`: a list of just the **names** from `ordered`, in that order\n- `prime_suspect`: the first name in `order` (a string)\n\n**Then** print `order` and `prime_suspect` (the starter already does).\n\n**Example:** for `[{\"name\": \"Mo\", \"alibi\": 5}, {\"name\": \"Al\", \"alibi\": 5}, {\"name\": \"Zed\", \"alibi\": 2}]`, `order` is `[\"Zed\", \"Al\", \"Mo\"]` and `prime_suspect` is `\"Zed\"`.",
                "starter": "ordered = ...\norder = ...\nprime_suspect = ...\nprint(order, prime_suspect)\n",
                "solution": "ordered = sorted(suspects, key=lambda s: (s[\"alibi\"], s[\"name\"]))\norder = [s[\"name\"] for s in ordered]\nprime_suspect = order[0]\nprint(order, prime_suspect)\n",
                "tests": '''_e = [s["name"] for s in sorted(suspects, key=lambda s: (s["alibi"], s["name"]))]
assert order == _e, f"order should be {_e}, got {order!r}"
assert prime_suspect == _e[0], f"prime_suspect should be {_e[0]!r}"''',
                "tips": [
                    "A tuple key sorts by the first item, then the second: `key=lambda s: (s[\"alibi\"], s[\"name\"])`.",
                    "Then `order = [s[\"name\"] for s in ordered]` and `prime_suspect = order[0]`.",
                ],
                "reveal": "The weakest alibi stands at the front of the line.",
            },
        ],
        "closing": "Case closed. `sorted` with a good key turned opinions into an order everyone accepted.",
    },
    # ------------------------------------------------------------ decorators
    {
        "id": "wiretap",
        "tier": "small",
        "title": "The Wiretap",
        "teaser": "Record every call a suspect's phone makes, without changing the phone.",
        "skills": ["decorators"],
        "story": "Internal Affairs suspects an officer is tipping off a gang. You may not change the officer's `send` function, but you may **wrap** it. Every message they will send is in `outgoing` (a list of `(to, text)` pairs).\n\nA decorator can record each call and still let it through.",
        "suspects": [{"name": "the officer", "note": "Very popular on the phone."}],
        "variants": [
            'outgoing = [("Mum", "home late"), ("Viper", "raid at 6"), ("Pizza", "one large")]\n',
            'outgoing = [("Viper", "move the van"), ("Viper", "now"), ("Gym", "cancel")]\n',
            'outgoing = [("Bank", "balance?"), ("Dragon", "cops at pier 9")]\n',
        ],
        "steps": [
            {
                "notes": "Internal Affairs' rule: a message is a **tip-off** if its text contains any of the words `raid`, `cops` or `move` (lower case, anywhere in the text). The person it was sent to has been **tipped off**.",
                "question": "**Goal:** record every message the officer sends, without changing `send`, and find who was tipped off.\n\n**You have:**\n- `outgoing`, a list of `(to, text)` pairs (both strings), e.g. `[(\"Mum\", \"home late\"), (\"Viper\", \"raid at 6\")]`\n- in the starter: an empty list `wiretap_log`, the function `send(to, text)` already decorated with `@tap`, and a loop that sends every message in `outgoing`\n\n**Write** the decorator `tap(fn)`:\n- inside it, define a wrapper `(*args, **kwargs)` and put `@wraps(fn)` on it, so `send.__name__` stays `\"send\"`\n- on every call, append the tuple `(fn.__name__, args)` to `wiretap_log` (`args` is the tuple of positional arguments, e.g. `(\"Viper\", \"raid at 6\")`)\n- then call the original function and **return its result**\n- `tap` returns the wrapper\n\n**Then** store in `tipped_off` a list of the contacts (`to` names) who got a tip-off message: in the order they first got one, each name only once.\n\n**Example:** after `send(\"Ann\", \"hi\")`, the last log entry is `(\"send\", (\"Ann\", \"hi\"))` and the call still returns `\"sent to Ann\"`. For messages `[(\"Bo\", \"move it\"), (\"Cy\", \"hi\"), (\"Bo\", \"cops!\")]`, `tipped_off` is `[\"Bo\"]`.",
                "starter": "from functools import wraps\n\nwiretap_log = []\n\ndef tap(fn):\n    ...\n\n@tap\ndef send(to, text):\n    return f\"sent to {to}\"\n\nfor to, text in outgoing:\n    send(to, text)\n\ntipped_off = ...\nprint(wiretap_log)\nprint(tipped_off)\n",
                "solution": "from functools import wraps\n\nwiretap_log = []\n\ndef tap(fn):\n    @wraps(fn)\n    def wrapper(*args, **kwargs):\n        wiretap_log.append((fn.__name__, args))\n        return fn(*args, **kwargs)\n    return wrapper\n\n@tap\ndef send(to, text):\n    return f\"sent to {to}\"\n\nfor to, text in outgoing:\n    send(to, text)\n\ntipped_off = []\nfor name, args in wiretap_log:\n    to, text = args\n    if (\"raid\" in text or \"cops\" in text or \"move\" in text) and to not in tipped_off:\n        tipped_off.append(to)\nprint(wiretap_log)\nprint(tipped_off)\n",
                "tests": '''assert send.__name__ == "send", "use @wraps(fn) so send keeps its name"
assert send("X", "y") == "sent to X", "the wrapper must return the original result"
assert wiretap_log[-1] == ("send", ("X", "y")), "each call should log (fn.__name__, args)"
assert wiretap_log[:len(outgoing)] == [("send", m) for m in outgoing], "the log should hold every message from outgoing, in order"
_e = []
for _to, _t in outgoing:
    if ("raid" in _t or "cops" in _t or "move" in _t) and _to not in _e:
        _e.append(_to)
assert tipped_off == _e, f"tipped_off should be {_e}, got {tipped_off!r}"''',
                "tips": [
                    "Inside `tap`, define `wrapper(*args, **kwargs)` decorated with `@wraps(fn)`: append to the log, then `return fn(*args, **kwargs)`.",
                    "Afterwards loop over `wiretap_log`; each entry is `(name, args)` and `args` is `(to, text)`.",
                ],
                "reveal": "The log shows exactly who got the warnings, and when.",
            },
        ],
        "closing": "Case closed. You recorded every call without touching the original function: that's what decorators are for.",
    },
    # ------------------------------------------------------------ streams
    {
        "id": "endless-log",
        "tier": "small",
        "title": "The Endless Log",
        "teaser": "A door log too long to read. Find the first forced entry.",
        "skills": ["streams"],
        "story": "The bank's door sensors write thousands of lines a night into `log`. Somewhere, one line contains `FORCED`. Reading everything into new lists wastes memory, so use a **generator** that hands lines over one at a time.",
        "suspects": [{"name": "the night crew", "note": ""}],
        "variants": [
            'log = [f"{i:04d} side door ok" for i in range(800)]\nlog[317] = "0317 vault door FORCED"\nlog[540] = "0540 roof hatch FORCED"\n',
            'log = [f"{i:04d} lobby ok" for i in range(500)]\nlog[42] = "0042 server room FORCED"\n',
            'log = [f"{i:04d} garage ok" for i in range(1200)]\nlog[999] = "0999 cash room FORCED"\nlog[1001] = "1001 vault FORCED"\n',
        ],
        "steps": [
            {
                "question": "**Goal:** find the first forced entry in a huge door log, and how many there were.\n\n**You have:** `log`, a long list of strings, one per sensor line, e.g. `\"0317 vault door FORCED\"`. At least one line contains `FORCED`.\n\n**Write** a generator function `forced_entries(lines)`:\n- `lines` is a list of strings\n- it uses `yield` (not `return` of a list) to hand back, one at a time, only the lines that contain `\"FORCED\"` (capital letters, as written), in order\n\n**Then** store, using `forced_entries(log)`:\n- `first_breach`: the first forced line (a string)\n- `breaches`: how many forced lines there are (an int)\n- a generator can only be run through once, so call `forced_entries(log)` again for the count\n\n**Example:** for `[\"a ok\", \"b FORCED\", \"c FORCED\"]`, `first_breach` is `\"b FORCED\"` and `breaches` is `2`.",
                "starter": "def forced_entries(lines):\n    ...\n\nfirst_breach = ...\nbreaches = ...\nprint(first_breach, breaches)\n",
                "solution": "def forced_entries(lines):\n    for line in lines:\n        if \"FORCED\" in line:\n            yield line\n\nfirst_breach = next(forced_entries(log))\nbreaches = sum(1 for _ in forced_entries(log))\nprint(first_breach, breaches)\n",
                "tests": '''import types as _types
assert isinstance(forced_entries([]), _types.GeneratorType), "forced_entries must be a generator: use yield"
_f = [l for l in log if "FORCED" in l]
assert first_breach == _f[0], f"first_breach should be {_f[0]!r}, got {first_breach!r}"
assert breaches == len(_f), f"breaches should be {len(_f)}, got {breaches!r}"''',
                "tips": [
                    "Inside the generator: `for line in lines:` then `if \"FORCED\" in line: yield line`.",
                    "`next(forced_entries(log))` gets the first one. `sum(1 for _ in forced_entries(log))` counts them.",
                ],
                "reveal": "The first breach happened long before anyone noticed.",
            },
        ],
        "closing": "Case closed. You streamed the log instead of loading it all, the way real log processors work.",
    },
    # ------------------------------------------------------------ classes (Q10)
    {
        "id": "suspect-file",
        "tier": "small",
        "title": "The Suspect File",
        "teaser": "Witness descriptions full of impossible numbers.",
        "skills": ["classes"],
        "story": "Witnesses gave descriptions of the burglar, but some are impossible (a 300 cm tall suspect, an age of -4). The Bureau's `Suspect` record must reject impossible values.\n\nRaw descriptions are in `descriptions`: a list of `(name, age, height_cm)` tuples.\n\n*(This is the official assignment Q10: properties and validation.)*",
        "suspects": [{"name": "the burglar", "note": "Described many different ways."}],
        "variants": [
            'descriptions = [("Witness A", 34, 178), ("Witness B", -4, 170), ("Witness C", 36, 300), ("Witness D", 35, 181)]\n',
            'descriptions = [("Guard", 0, 160), ("Cabbie", 52, 165), ("Kid", 51, 49)]\n',
            'descriptions = [("Neighbour", 29, 175), ("Postman", 30, 176), ("Barber", 28, 174), ("Dog walker", 130, 175)]\n',
        ],
        "steps": [
            {
                "notes": "The Bureau's limits for a possible person (both ends included):\n- age: from **1** to **120** years\n- height: from **50** to **250** cm\n\nAnything outside these is an impossible description.",
                "question": "**Goal:** a `Suspect` record that refuses impossible values, then keep only the credible witnesses.\n\n**You have:** `descriptions`, a list of `(name, age, height_cm)` tuples, e.g. `[(\"Witness A\", 34, 178), (\"Witness B\", -4, 170)]`.\n\n**Write** a class `Suspect(name, age, height_cm)`:\n- `__init__` stores `name`, `age` and `height_cm` (the starter already does this with `self.age = age` etc.)\n- make `age` a `@property` with an `@age.setter`: if the value is outside 1 to 120, `raise ValueError`; otherwise store it (e.g. in `self._age`)\n- do the same for `height_cm`: outside 50 to 250 raises `ValueError`\n- the checks must also run when the object is created, so `Suspect(\"Bad\", -1, 170)` raises `ValueError` (this happens by itself because `__init__` uses the setters)\n- changing a value later, e.g. `s.age = 121`, must raise `ValueError` too\n\n**Then** build `credible`: a list of the **names** whose description makes a valid `Suspect`, in the same order as `descriptions`. Use `try` / `except ValueError` around `Suspect(...)`.\n\n**Example:** `Suspect(\"T\", 30, 170)` works and `.age` gives `30`; `Suspect(\"T\", 0, 170)` and `Suspect(\"T\", 30, 251)` raise `ValueError`. For `[(\"Al\", 40, 180), (\"Bo\", 200, 180)]`, `credible` is `[\"Al\"]`.",
                "starter": "class Suspect:\n    def __init__(self, name, age, height_cm):\n        self.name = name\n        self.age = age\n        self.height_cm = height_cm\n\n    # add the properties here\n\ncredible = []\n# try each description here\n\nprint(credible)\n",
                "solution": "class Suspect:\n    def __init__(self, name, age, height_cm):\n        self.name = name\n        self.age = age\n        self.height_cm = height_cm\n\n    @property\n    def age(self):\n        return self._age\n\n    @age.setter\n    def age(self, value):\n        if not 1 <= value <= 120:\n            raise ValueError(f\"impossible age: {value}\")\n        self._age = value\n\n    @property\n    def height_cm(self):\n        return self._height_cm\n\n    @height_cm.setter\n    def height_cm(self, value):\n        if not 50 <= value <= 250:\n            raise ValueError(f\"impossible height: {value}\")\n        self._height_cm = value\n\ncredible = []\nfor name, age, height in descriptions:\n    try:\n        Suspect(name, age, height)\n        credible.append(name)\n    except ValueError:\n        pass\n\nprint(credible)\n",
                "tests": '''_s = Suspect("T", 30, 170)
_s.age = 31
assert _s.age == 31, "setting a valid age should work"
for _attr, _bad in (("age", 0), ("age", 121), ("height_cm", 49), ("height_cm", 251)):
    try:
        setattr(_s, _attr, _bad)
        raise AssertionError(f"setting {_attr} = {_bad} should raise ValueError")
    except ValueError:
        pass
try:
    Suspect("Bad", -1, 170)
    raise AssertionError("__init__ must validate too: Suspect('Bad', -1, 170) should raise")
except ValueError:
    pass
try:
    Suspect("Edge", 1, 50)
    Suspect("Edge", 120, 250)
except ValueError:
    raise AssertionError("both ends are allowed: ages 1 and 120, heights 50 and 250 must not raise (use <= and >=)")
_e = [n for n, a, h in descriptions if 1 <= a <= 120 and 50 <= h <= 250]
assert credible == _e, f"credible should be {_e}, got {credible!r}"''',
                "tips": [
                    "Write a `@property def age(self)` returning `self._age`, and `@age.setter` that checks the range before storing `self._age`. Same for height.",
                    "Because `__init__` does `self.age = age`, the setter runs there too. Build `credible` with try/except around `Suspect(...)`.",
                ],
                "reveal": "With the impossible descriptions thrown out, the rest agree with each other.",
            },
        ],
        "closing": "Case closed. Validation in one place kept bad data out of the whole investigation.",
    },
    # ------------------------------------------------------------ dunders (Q16)
    {
        "id": "last-known-locations",
        "tier": "small",
        "title": "Last Known Locations",
        "teaser": "Track only the most recent sightings of a fugitive.",
        "skills": ["dunders"],
        "story": "A fugitive is on the move. Every sighting is radioed in, in order, in `sightings`. Old sightings are useless: the team only wants the **3 most recent**.\n\n*(This is the official assignment Q16: RecentBooks, as a sightings tracker.)*",
        "suspects": [{"name": "the fugitive", "note": "Never in one place for long."}],
        "variants": [
            'sightings = ["Pier 9", "Old Mill", "Station", "Market", "Bridge"]\n',
            'sightings = ["Airport", "Hotel"]\n',
            'sightings = ["Fort", "Museum", "Harbour", "Temple", "Beach", "Club", "Docks"]\n',
        ],
        "steps": [
            {
                "question": "**Goal:** a tracker that keeps only the most recent sightings.\n\n**You have:** `sightings`, a list of places (strings), oldest first, e.g. `[\"Pier 9\", \"Old Mill\", \"Station\", \"Market\"]`. It may have fewer than 3 places.\n\n**Write** a class `Tracker(max_size)`:\n- it keeps at most `max_size` places; when a new one is added and it is full, the **oldest** is dropped (a `deque(maxlen=max_size)` does this for you)\n- `add(place)`: adds a place as the newest\n- `oldest()` returns the oldest place kept; `newest()` returns the newest\n- `len(tracker)` gives how many places are kept (`__len__`)\n- `for place in tracker` and `list(tracker)` go from oldest to newest (`__iter__`)\n- `tracker[0]` is the oldest and `tracker[-1]` the newest (`__getitem__`, negative indexes work)\n- `\"Market\" in tracker` is `True` only for a place still kept (`__contains__`)\n- `repr(tracker)` returns text that contains the word `Tracker`, e.g. `Tracker(['Station', 'Market'])` (`__repr__`)\n\n**Then** the starter fills `tracker = Tracker(max_size=3)` with `sightings` and stores `recent = list(tracker)`.\n\n**Example:** after adding `\"A\"`, `\"B\"`, `\"C\"`, `\"D\"` to `Tracker(3)`: `list(tracker)` is `[\"B\", \"C\", \"D\"]`, `tracker.oldest()` is `\"B\"`, `len(tracker)` is `3` and `\"A\" in tracker` is `False`.",
                "starter": "from collections import deque\n\nclass Tracker:\n    ...\n\ntracker = Tracker(max_size=3)\nfor place in sightings:\n    tracker.add(place)\n\nrecent = list(tracker)\nprint(recent, tracker.newest())\n",
                "solution": "from collections import deque\n\nclass Tracker:\n    def __init__(self, max_size):\n        self._items = deque(maxlen=max_size)\n    def add(self, place):\n        self._items.append(place)\n    def oldest(self):\n        return self._items[0]\n    def newest(self):\n        return self._items[-1]\n    def __len__(self):\n        return len(self._items)\n    def __iter__(self):\n        return iter(self._items)\n    def __getitem__(self, i):\n        return self._items[i]\n    def __contains__(self, place):\n        return place in self._items\n    def __repr__(self):\n        return f\"Tracker({list(self._items)})\"\n\ntracker = Tracker(max_size=3)\nfor place in sightings:\n    tracker.add(place)\n\nrecent = list(tracker)\nprint(recent, tracker.newest())\n",
                "tests": '''_e = sightings[max(0, len(sightings) - 3):]   # (avoids a Brython bug with short negative slices)
assert recent == _e, f"recent should be {_e}, got {recent!r}"
assert len(tracker) == len(_e) and tracker[0] == _e[0] and tracker[-1] == _e[-1], "len and [] should work"
assert tracker.oldest() == _e[0] and tracker.newest() == _e[-1], "oldest/newest are wrong"
assert _e[-1] in tracker, "in should work"
if len(sightings) > 3:
    assert sightings[0] not in tracker, "the oldest sightings should be dropped"
assert "Tracker" in repr(tracker), "write a __repr__ that mentions Tracker"''',
                "tips": [
                    "Store the places in `deque(maxlen=max_size)`: it drops the oldest automatically.",
                    "Each dunder forwards to the deque, e.g. `def __len__(self): return len(self._items)`; `oldest` is `self._items[0]`.",
                ],
                "reveal": "The most recent sightings all point the same way. The team knows where to wait.",
            },
        ],
        "closing": "Case closed. The team was waiting at the last sighting.",
    },
    # ------------------------------------------------------------ dataclasses
    {
        "id": "case-numbers",
        "tier": "small",
        "title": "Case Numbers",
        "teaser": "Duplicate case numbers are wrecking the filing system.",
        "skills": ["dataclasses"],
        "story": "Every case number looks like `PIB-` + a 4-digit year + `-` + a 3-digit number, e.g. `PIB-2026-041`. The intake desk typed the raw numbers into `intake`, with duplicates and typos.\n\nA **frozen** dataclass makes case numbers safe to put in a set.",
        "suspects": [{"name": "the intake desk", "note": "Overworked."}],
        "variants": [
            'intake = ["PIB-2026-041", "PIB-2026-041", "PIB-2025-007", "PIB-26-1", "PIB-2026-099"]\n',
            'intake = ["PIB-2024-001", "PIB-2024-001", "PIB-2024-001", "pib-2024-002"]\n',
            'intake = ["PIB-2023-123", "PIB-2023-124", "XYZ", "PIB-2023-123", "PIB-2023-12A"]\n',
        ],
        "steps": [
            {
                "notes": "The Bureau's case number format, e.g. `PIB-2026-041`. It has three parts joined by hyphens `-`:\n- `PIB` in capital letters\n- a year of exactly **4 digits**\n- a number of exactly **3 digits** (with leading zeros, like `041`)\n\nNothing else is allowed: no lower case `pib`, no 2-digit year, no letters in the number parts.",
                "question": "**Goal:** a case-number type that rejects typos, so the duplicates can be removed with a set.\n\n**You have:** `intake`, a list of raw case numbers (strings), with duplicates and typos, e.g. `[\"PIB-2026-041\", \"PIB-2026-041\", \"PIB-26-1\"]`.\n\n**Write** a dataclass `CaseNumber` with `@dataclass(frozen=True)`:\n- one field: `value: str`\n- a `__post_init__(self)` method that raises `ValueError` if `self.value` does not follow the format in the field notes exactly\n- because it is frozen, `c.value = \"x\"` raises an error, and two `CaseNumber`s with the same value are equal and count once in a set (the dataclass does both for you)\n\n**Then**, for each entry in `intake`:\n- if `CaseNumber(raw)` works, add the `CaseNumber` object (not the string) to the set `unique_cases`\n- if it raises `ValueError`, add 1 to `rejected` (an int). Every bad entry counts, even a repeated one.\n\n**Example:** `CaseNumber(\"PIB-2020-007\")` works. `CaseNumber(\"pib-2020-007\")`, `CaseNumber(\"PIB-20-7\")` and `CaseNumber(\"PIB-2020-07A\")` raise `ValueError`. For `[\"PIB-2020-007\", \"PIB-2020-007\", \"bad\"]`, `unique_cases` holds 1 case number and `rejected` is `1`.",
                "starter": "from dataclasses import dataclass\n\n@dataclass(frozen=True)\nclass CaseNumber:\n    ...\n\nunique_cases = set()\nrejected = 0\n# process intake here\n\nprint(len(unique_cases), rejected)\n",
                "solution": "from dataclasses import dataclass\n\n@dataclass(frozen=True)\nclass CaseNumber:\n    value: str\n\n    def __post_init__(self):\n        parts = self.value.split(\"-\")\n        ok = (len(parts) == 3 and parts[0] == \"PIB\" and len(parts[1]) == 4 and parts[1].isdigit()\n              and len(parts[2]) == 3 and parts[2].isdigit())\n        if not ok:\n            raise ValueError(f\"bad case number: {self.value!r}\")\n\nunique_cases = set()\nrejected = 0\nfor raw in intake:\n    try:\n        unique_cases.add(CaseNumber(raw))\n    except ValueError:\n        rejected += 1\n\nprint(len(unique_cases), rejected)\n",
                "tests": '''from dataclasses import FrozenInstanceError as _FIE
_c = CaseNumber("PIB-2026-041")
try:
    _c.value = "x"
    raise AssertionError("CaseNumber must be frozen")
except _FIE:
    pass
assert CaseNumber("PIB-2026-041") == _c and len({_c, CaseNumber("PIB-2026-041")}) == 1, "equal case numbers should collapse in a set"
def _ok(v):
    p = v.split("-")
    return len(p) == 3 and p[0] == "PIB" and len(p[1]) == 4 and p[1].isdigit() and len(p[2]) == 3 and p[2].isdigit()
for _bad in ("PIB-26-1", "pib-2024-002", "XYZ", "PIB-2023-12A"):
    try:
        CaseNumber(_bad)
        raise AssertionError(f"CaseNumber({_bad!r}) should raise ValueError")
    except ValueError:
        pass
_valid = {v for v in intake if _ok(v)}
assert {c.value for c in unique_cases} == _valid, f"unique_cases should hold {sorted(_valid)}"
assert rejected == sum(1 for v in intake if not _ok(v)), "rejected count is wrong"''',
                "tips": [
                    "`self.value.split(\"-\")` should give 3 parts: `\"PIB\"`, 4 digits, 3 digits. Use `len(...)` and `.isdigit()`.",
                    "Loop over `intake`: inside `try`, `unique_cases.add(CaseNumber(raw))`; in `except ValueError`, add 1 to `rejected`.",
                ],
                "reveal": "The duplicates collapse, and the typos are caught at the door.",
            },
        ],
        "closing": "Case closed. Immutable, validated, hashable: the filing system is clean again.",
    },
]

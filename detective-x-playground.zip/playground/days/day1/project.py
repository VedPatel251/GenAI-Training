"""Part · Building a real project: the skills the BookVault deliverable (Q21) needs.

Added because the Day 1 deliverable asks trainees to load books.json, build a package that runs with
`python -m bookvault.cli`, write a command-line interface and define their own exception classes,
and no lesson taught those yet. Type hints are used throughout the course (and Pydantic on Day 4).

`apply(LESSONS, PARTS)` inserts these lessons as a new part before "Assignments".
Every task follows the usual format; `practice` holds extra parts (see beginner.py).
"""

PART_TITLE = "Building a real project"

_ANN = '''def _n(t):
    return t.__name__ if t in (int, float, str, bool) else str(t)
'''

LESSONS = [
    # ------------------------------------------------------------------ type hints
    {
        "id": "type-hints",
        "title": "Type hints",
        "idea": "A **type hint** labels what a value should be: `pages: int`, `def late_fee(days: int) -> float:`. The part after `->` is what the function returns.\n\nPython does **not** check hints when the program runs. Your editor (VS Code), checking tools and libraries such as Pydantic (Day 4) read them to catch mistakes before you run anything.\n\nThe hints you will write most:\n- `int`, `float`, `str`, `bool`\n- `list[str]`, `dict[str, int]`, `tuple[str, int]`\n- `str | None`: a string, or nothing\n- your own classes, such as `Book`",
        "code": '''def late_fee(days_late: int, per_day: float = 2.5) -> float:
    return days_late * per_day

def find_title(isbn: str, catalog: dict[str, str]) -> str | None:
    return catalog.get(isbn)

titles: list[str] = ["Clean Code", "Refactoring"]

print(late_fee(4))
print(find_title("111", {"111": "Clean Code"}))
print(find_title("999", {}))
print(late_fee.__annotations__)

print(late_fee("4", 2))   # hints are not enforced: Python still runs this
''',
        "walkthrough": [
            ["def late_fee(days_late: int, per_day: float = 2.5) -> float:", "Each parameter gets `: type`, and `-> float` says what the function returns. A default still goes after the hint: `per_day: float = 2.5`."],
            ["def find_title(isbn: str, catalog: dict[str, str]) -> str | None:", "`dict[str, str]` is a dictionary from text to text. `str | None` means it returns a title, or `None` when the ISBN is missing."],
            ['titles: list[str] = ["Clean Code", "Refactoring"]', "Variables can have hints too, though it's most common on function parameters."],
            ["print(late_fee.__annotations__)", "Python stores the hints in `__annotations__`. Tools read them from there."],
            ['print(late_fee("4", 2))', "The hint says `int`, but Python runs it anyway: `\"4\" * 2` is `\"44\"`. Hints help tools catch this; they don't stop it at runtime."],
        ],
        "mistakes": [
            "Expecting Python to reject wrong types. Hints are labels, not checks (Pydantic, on Day 4, adds real checking).",
            "Writing `list(str)` instead of `list[str]`: hints use square brackets.",
            "Forgetting `| None` when a function can return `None`.",
        ],
        "challenge": {
            "task": "Add type hints to `average_rating`: `ratings` is a list of floats, `digits` is an int, and it returns a float.",
            "hints": [
                "Hints go after each parameter name: `ratings: list[float]`. The return type goes after the brackets: `) -> float:`.",
                "`def average_rating(ratings: list[float], digits: int = 1) -> float:`",
            ],
            "starter": '''def average_rating(ratings, digits=1):
    return round(sum(ratings) / len(ratings), digits)

print(average_rating([4.5, 3.0, 5.0]))
''',
            "solution": '''def average_rating(ratings: list[float], digits: int = 1) -> float:
    return round(sum(ratings) / len(ratings), digits)

print(average_rating([4.5, 3.0, 5.0]))
''',
            "tests": _ANN + '''_a = average_rating.__annotations__
assert "ratings" in _a, "add a hint to ratings"
assert _n(_a["ratings"]) == "list[float]", f"ratings should be list[float], got {_n(_a['ratings'])}"
assert _n(_a.get("digits")) == "int", "digits should be int"
assert _n(_a.get("return")) == "float", "add -> float for the return value"
assert average_rating([4.0, 5.0]) == 4.5, "the function should still work"''',
        },
        "practice": [
            {
                "task": "Write `loans_for(history: dict[str, list[str]], member: str) -> int` that returns how many loans `member` has, or `0` if the member isn't in `history`. Include all the hints.",
                "hints": [
                    "`history.get(member, [])` gives the member's list, or an empty list.",
                    "`return len(history.get(member, []))`, with the hints from the task on the `def` line.",
                ],
                "starter": '''# write loans_for here

history = {"M1": ["Clean Code", "Refactoring"], "M2": ["Dune"]}
print(loans_for(history, "M1"), loans_for(history, "M9"))
''',
                "solution": '''def loans_for(history: dict[str, list[str]], member: str) -> int:
    return len(history.get(member, []))

history = {"M1": ["Clean Code", "Refactoring"], "M2": ["Dune"]}
print(loans_for(history, "M1"), loans_for(history, "M9"))
''',
                "tests": _ANN + '''assert loans_for({"A": ["x", "y"]}, "A") == 2 and loans_for({}, "B") == 0, "loans_for gives the wrong count"
_a = loans_for.__annotations__
assert _n(_a.get("history")) == "dict[str, list[str]]", f"history should be dict[str, list[str]], got {_n(_a.get('history'))}"
assert _n(_a.get("member")) == "str", "member should be str"
assert _n(_a.get("return")) == "int", "add -> int"''',
            },
            {
                "task": "Write `find_member(members: dict[str, str], member_id: str) -> str | None` that returns the member's name, or `None` if the id is unknown. Then store `missing = find_member(members, \"M9\")`.",
                "hints": [
                    "`members.get(member_id)` already returns `None` for a missing key.",
                    "Hint the return as `str | None`: `def find_member(members: dict[str, str], member_id: str) -> str | None:`",
                ],
                "starter": '''members = {"M1": "Asha", "M2": "Ravi"}

# write find_member here

missing = ...
print(find_member(members, "M1"), missing)
''',
                "solution": '''members = {"M1": "Asha", "M2": "Ravi"}

def find_member(members: dict[str, str], member_id: str) -> str | None:
    return members.get(member_id)

missing = find_member(members, "M9")
print(find_member(members, "M1"), missing)
''',
                "tests": _ANN + '''assert find_member({"A": "Ann"}, "A") == "Ann", "find_member should return the name"
assert missing is None, "missing should be None for an unknown id"
assert _n(find_member.__annotations__.get("return")).replace(" ", "") in ("str|None", "Optional[str]", "typing.Optional[str]"), "the return hint should be str | None"''',
            },
        ],
    },
    # ------------------------------------------------------------------ custom exceptions
    {
        "id": "custom-exceptions",
        "title": "Your own exception classes",
        "idea": "Built-in errors like `ValueError` are generic. A real project defines **its own family** of errors, so code can say exactly what went wrong.\n\nMake a base class that inherits from `Exception`, then subclasses for each problem:\n- `class BookVaultError(Exception): pass`\n- `class ItemNotFoundError(BookVaultError): pass`\n\n`except ItemNotFoundError:` catches only that problem, and `except BookVaultError:` catches **every** BookVault error at once while letting unrelated bugs through. Always raise with a helpful message: `raise ItemNotFoundError(f\"No item {item_id}\")`.",
        "code": '''class BookVaultError(Exception):
    """Base class for every BookVault problem."""

class ItemNotFoundError(BookVaultError):
    pass

class ItemUnavailableError(BookVaultError):
    pass

available = {"B001": True, "B002": False}

def borrow(item_id):
    if item_id not in available:
        raise ItemNotFoundError(f"No item with id {item_id}")
    if not available[item_id]:
        raise ItemUnavailableError(f"{item_id} is already on loan")
    available[item_id] = False
    return f"Borrowed {item_id}"

for item in ["B001", "B002", "B999"]:
    try:
        print(borrow(item))
    except ItemNotFoundError as e:
        print("Not found:", e)
    except BookVaultError as e:
        print("Can't borrow:", e)

print(issubclass(ItemNotFoundError, BookVaultError))
''',
        "walkthrough": [
            ["class BookVaultError(Exception):", "The project's base error. Inheriting from `Exception` is what makes it something you can `raise` and catch."],
            ['    """Base class for every BookVault problem."""', "A docstring is enough for a body; nothing else is needed."],
            ["class ItemNotFoundError(BookVaultError):", "A specific error that **is a** `BookVaultError`, so catching the base also catches it."],
            ['        raise ItemNotFoundError(f"No item with id {item_id}")', "Raise with a message that tells the reader exactly what went wrong."],
            ["    except ItemNotFoundError as e:", "The first matching `except` wins: missing items land here."],
            ["    except BookVaultError as e:", "Any other BookVault error lands here, such as `ItemUnavailableError`."],
        ],
        "mistakes": [
            "Inheriting from `BaseException` instead of `Exception`. Ordinary code should never catch `BaseException`.",
            "Putting `except BookVaultError` **before** a more specific `except`: the general one would catch everything first.",
            "Raising without a message: `raise ItemNotFoundError()` tells the reader nothing.",
        ],
        "challenge": {
            "task": "Create `BookVaultError` (based on `Exception`) and two subclasses, `UnknownMemberError` and `LoanLimitError`. Then finish `check_borrow(member_id, members, loans)`: raise `UnknownMemberError` if the member isn't in `members`, `LoanLimitError` if they already have 3 or more loans, otherwise return `True`.",
            "hints": [
                "Each class is two lines: `class UnknownMemberError(BookVaultError):` and `pass`.",
                "In `check_borrow`: `if member_id not in members: raise UnknownMemberError(...)`, then `if loans.get(member_id, 0) >= 3: raise LoanLimitError(...)`, then `return True`.",
            ],
            "starter": '''# define the three exception classes here

def check_borrow(member_id, members, loans):
    ...

members = {"M1": "Asha", "M2": "Ravi"}
loans = {"M1": 1, "M2": 3}
print(check_borrow("M1", members, loans))
''',
            "solution": '''class BookVaultError(Exception):
    pass

class UnknownMemberError(BookVaultError):
    pass

class LoanLimitError(BookVaultError):
    pass

def check_borrow(member_id, members, loans):
    if member_id not in members:
        raise UnknownMemberError(f"Unknown member {member_id}")
    if loans.get(member_id, 0) >= 3:
        raise LoanLimitError(f"{member_id} already has 3 loans")
    return True

members = {"M1": "Asha", "M2": "Ravi"}
loans = {"M1": 1, "M2": 3}
print(check_borrow("M1", members, loans))
''',
            "tests": '''assert issubclass(BookVaultError, Exception), "BookVaultError should inherit from Exception"
assert issubclass(UnknownMemberError, BookVaultError) and issubclass(LoanLimitError, BookVaultError), "both errors should inherit from BookVaultError"
_m = {"A": "Ann"}
assert check_borrow("A", _m, {"A": 2}) is True, "a member with 2 loans may borrow"
for _args, _err in ((("Z", _m, {}), UnknownMemberError), (("A", _m, {"A": 3}), LoanLimitError)):
    try:
        check_borrow(*_args)
        raise AssertionError(f"check_borrow{_args[:1]} should raise {_err.__name__}")
    except _err as _e:
        assert str(_e), f"give {_err.__name__} a helpful message"''',
        },
        "practice": [
            {
                "task": "Using the classes below, write `try_borrow(item_id)`: call `borrow(item_id)` and return its result, but if **any** BookVault error happens, return `\"Sorry: \"` followed by the error's message. Catch the base class only.",
                "hints": [
                    "Wrap the call: `try: return borrow(item_id)`.",
                    "`except BookVaultError as e: return \"Sorry: \" + str(e)`",
                ],
                "starter": '''class BookVaultError(Exception):
    pass

class ItemNotFoundError(BookVaultError):
    pass

class ItemUnavailableError(BookVaultError):
    pass

available = {"B1": True, "B2": False}

def borrow(item_id):
    if item_id not in available:
        raise ItemNotFoundError(f"no item {item_id}")
    if not available[item_id]:
        raise ItemUnavailableError(f"{item_id} is on loan")
    return f"borrowed {item_id}"

def try_borrow(item_id):
    ...

print(try_borrow("B1"), "|", try_borrow("B2"), "|", try_borrow("B9"))
''',
                "solution": '''class BookVaultError(Exception):
    pass

class ItemNotFoundError(BookVaultError):
    pass

class ItemUnavailableError(BookVaultError):
    pass

available = {"B1": True, "B2": False}

def borrow(item_id):
    if item_id not in available:
        raise ItemNotFoundError(f"no item {item_id}")
    if not available[item_id]:
        raise ItemUnavailableError(f"{item_id} is on loan")
    return f"borrowed {item_id}"

def try_borrow(item_id):
    try:
        return borrow(item_id)
    except BookVaultError as e:
        return "Sorry: " + str(e)

print(try_borrow("B1"), "|", try_borrow("B2"), "|", try_borrow("B9"))
''',
                "tests": '''assert try_borrow("B9") == "Sorry: no item B9", f"got {try_borrow('B9')!r}"
assert try_borrow("B2") == "Sorry: B2 is on loan", f"got {try_borrow('B2')!r}"
assert "except BookVaultError" in __source__, "catch the base class: except BookVaultError"''',
            },
        ],
    },
    # ------------------------------------------------------------------ files and json
    {
        "id": "files-json",
        "title": "Files and JSON",
        "idea": "Programs keep data in files so it survives after they stop. **JSON** is the most common text format for that, and it maps straight onto Python:\n- a JSON object `{...}` becomes a dict, an array `[...]` becomes a list\n- `true`, `false`, `null` become `True`, `False`, `None`\n\n`json.loads(text)` turns JSON text into Python values; `json.dumps(value, indent=2)` turns them back into text. Bad JSON raises `json.JSONDecodeError`.\n\nWith real files you use `with open(...)`, which closes the file for you: `json.load(f)` reads a whole file and `json.dump(value, f)` writes one. **JSON Lines** files hold one JSON object per line, so you can read them line by line.\n\nThis page can't touch your computer's files, so the examples use text and `io.StringIO`, a pretend file. The card at the bottom shows the same thing with real files.",
        "code": '''import io
import json

text = '[{"title": "Clean Code", "pages": 464, "available": true}, {"title": "Refactoring", "pages": 448, "available": false}]'
books = json.loads(text)
print(type(books), books[0]["title"], books[1]["available"])

books.append({"title": "Fluent Python", "pages": 1014, "available": True})
print(json.dumps(books[2], indent=2))

log = io.StringIO('{"id": "B1", "action": "out"}\\n{"id": "B2", "action": "in"}\\nnot json\\n')
for number, line in enumerate(log, start=1):
    try:
        record = json.loads(line)
        print(number, record["id"], record["action"])
    except json.JSONDecodeError:
        print(number, "skipped a bad line")
''',
        "walkthrough": [
            ["books = json.loads(text)", "`loads` = *load from string*. The JSON array becomes a Python list of dicts."],
            ['print(type(books), books[0]["title"], books[1]["available"])', "JSON's `false` arrived as Python's `False`."],
            ["print(json.dumps(books[2], indent=2))", "`dumps` = *dump to string*. `indent=2` makes it readable, and `True` becomes `true` again."],
            ["log = io.StringIO(...)", "A pretend file holding three lines, the way a JSON Lines file would."],
            ["for number, line in enumerate(log, start=1):", "Looping over a file gives one line at a time, so a huge file never has to fit in memory."],
            ["    except json.JSONDecodeError:", "One bad line shouldn't stop the whole import: catch it, report it, move on."],
        ],
        "mistakes": [
            "Mixing up `load`/`loads` and `dump`/`dumps`: the **s** versions work with strings, the others with files.",
            "Writing JSON by hand with single quotes. JSON needs double quotes: `{\"title\": \"Dune\"}`.",
            "Forgetting `encoding=\"utf-8\"` when opening files with names like *Café* or *São Paulo*.",
        ],
        "local": [{
            "title": "The same with real files",
            "note": "Save as `files_demo.py` and run it. It creates `books.json` next to the script.",
            "code": '''import json

books = [{"title": "Clean Code", "pages": 464}, {"title": "Refactoring", "pages": 448}]

with open("books.json", "w", encoding="utf-8") as f:
    json.dump(books, f, indent=2)

with open("books.json", encoding="utf-8") as f:
    loaded = json.load(f)

print(len(loaded), "books loaded:", [b["title"] for b in loaded])''',
            "output": "2 books loaded: ['Clean Code', 'Refactoring']",
        }],
        "challenge": {
            "task": "`catalog_json` is the text of a `books.json` file. Load it with `json.loads`, then store the total pages of the books that are **available** in `available_pages`.",
            "hints": [
                "`books = json.loads(catalog_json)` gives a list of dicts.",
                "Loop over `books`, and when `book[\"available\"]` is True add `book[\"pages\"]` to `available_pages`.",
            ],
            "starter": '''import json

catalog_json = """[
  {"title": "Clean Code", "pages": 464, "available": true},
  {"title": "Refactoring", "pages": 448, "available": false},
  {"title": "Fluent Python", "pages": 1014, "available": true}
]"""

available_pages = ...
print(available_pages)
''',
            "solution": '''import json

catalog_json = """[
  {"title": "Clean Code", "pages": 464, "available": true},
  {"title": "Refactoring", "pages": 448, "available": false},
  {"title": "Fluent Python", "pages": 1014, "available": true}
]"""

books = json.loads(catalog_json)
available_pages = 0
for book in books:
    if book["available"]:
        available_pages += book["pages"]
print(available_pages)
''',
            "tests": '''import io, contextlib, json as _j
assert available_pages == 1478, f"available_pages should be 1478, got {available_pages!r}"
_other = __source__.replace('"available": false', '"available": true')
_t = {}
with contextlib.redirect_stdout(io.StringIO()):
    exec(_other, _t)
assert _t.get("available_pages") == 1926, "calculate the total from the JSON, don't type it in"''',
        },
        "practice": [
            {
                "task": "`log_text` is a JSON Lines file (one record per line), but some lines are damaged. Count the good lines in `good` and the damaged ones in `bad`, using `json.JSONDecodeError`. Skip empty lines.",
                "hints": [
                    "Loop over `log_text.splitlines()`; `continue` when `line.strip()` is empty.",
                    "Inside `try:` call `json.loads(line)` and add 1 to `good`; in `except json.JSONDecodeError:` add 1 to `bad`.",
                ],
                "starter": '''import json

log_text = """{"id": "B1", "action": "out"}
{"id": "B2", "action": "in"}
{id: B3}

{"id": "B4", "action": "out"}
this is not json"""

good = 0
bad = 0
# your loop here

print(good, bad)
''',
                "solution": '''import json

log_text = """{"id": "B1", "action": "out"}
{"id": "B2", "action": "in"}
{id: B3}

{"id": "B4", "action": "out"}
this is not json"""

good = 0
bad = 0
for line in log_text.splitlines():
    if not line.strip():
        continue
    try:
        json.loads(line)
        good += 1
    except json.JSONDecodeError:
        bad += 1

print(good, bad)
''',
                "tests": '''assert (good, bad) == (3, 2), f"expected 3 good and 2 bad lines, got {good} and {bad}"
assert "JSONDecodeError" in __source__, "catch json.JSONDecodeError"''',
            },
            {
                "task": "Turn the `member` dict into JSON text with `json.dumps`, using `indent=2` and `sort_keys=True` so the keys come out in alphabetical order. Store it in `text` and print it.",
                "hints": [
                    "`json.dumps(member, ...)` takes options after the value, separated by commas.",
                    "`text = json.dumps(member, indent=2, sort_keys=True)`",
                ],
                "starter": '''import json

member = {"name": "Asha", "member_id": "M001", "active": True, "loans": ["B1", "B2"]}

text = ...
print(text)
''',
                "solution": '''import json

member = {"name": "Asha", "member_id": "M001", "active": True, "loans": ["B1", "B2"]}

text = json.dumps(member, indent=2, sort_keys=True)
print(text)
''',
                "tests": '''import json as _j
assert isinstance(text, str), "text should be the JSON string from json.dumps"
assert text == _j.dumps(member, indent=2, sort_keys=True), "use indent=2 and sort_keys=True"
assert _j.loads(text) == member, "the JSON should load back into the same dict"''',
            },
        ],
    },
    # ------------------------------------------------------------------ modules and packages
    {
        "id": "modules-packages",
        "title": "Modules, packages and __main__",
        "idea": "Bigger programs are split across files. Every `.py` file is a **module**: if `library.py` defines `Library`, another file can use `from library import Library`.\n\nA folder of modules with an `__init__.py` file inside is a **package**: `from bookvault.items import Book` imports from `bookvault/items.py`. `python -m bookvault.cli` runs the `cli` module inside the package.\n\nEvery module has a name in `__name__`. It is `\"__main__\"` when you run the file directly, and the module's own name when another file imports it. So the line `if __name__ == \"__main__\": main()` runs `main()` only when the file is run, never when it's imported by your tests or other modules.",
        "code": '''CATALOG = ["Clean Code", "Refactoring", "Fluent Python"]

def main():
    print("BookVault is starting")
    print("Books in the catalog:", len(CATALOG))
    print("This code is running as:", __name__)

if __name__ == "__main__":
    main()
else:
    print("Imported: main() did not run")
''',
        "walkthrough": [
            ["def main():", "Put the start-up steps in a function called `main`. Defining it doesn't run it."],
            ['    print("This code is running as:", __name__)', "Here the page runs your code directly, so `__name__` is `\"__main__\"`."],
            ['if __name__ == "__main__":', "True only when this file is the program being run."],
            ["    main()", "So `main()` runs when you run the file, and stays quiet when another module imports it."],
        ],
        "mistakes": [
            "Putting start-up code (prints, loading files) at the top level of a module. It then runs every time anything imports the module, including your tests.",
            "Naming your own file like a standard module (`json.py`, `random.py`): Python imports yours instead of the real one.",
            "Running `python bookvault/cli.py` instead of `python -m bookvault.cli`. Imports between package modules only work reliably with `-m`.",
        ],
        "local": [
            {
                "title": "A package on your computer",
                "note": "Create these folders and files. The `src/` folder and `pyproject.toml` are optional for a first try; this is the minimum.",
                "code": '''bookvault/
├── __init__.py        (can be empty)
├── items.py
└── cli.py''',
            },
            {
                "title": "items.py and cli.py",
                "code": '''# bookvault/items.py
class Book:
    def __init__(self, title):
        self.title = title

# bookvault/cli.py
from bookvault.items import Book

def main():
    books = [Book("Clean Code"), Book("Refactoring")]
    for book in books:
        print(book.title)

if __name__ == "__main__":
    main()''',
            },
            {
                "title": "Run it",
                "note": "Run from the folder that **contains** `bookvault/`.",
                "code": "python -m bookvault.cli",
                "output": "Clean Code\nRefactoring",
            },
        ],
        "challenge": {
            "task": "Write `main()` that prints `Catalog loaded: ` followed by the number of books in `CATALOG`. Then add the `if __name__ == \"__main__\":` line so `main()` runs only when the file is run directly.",
            "hints": [
                'Inside `main`: `print("Catalog loaded:", len(CATALOG))`.',
                'Below the function, at the left margin: `if __name__ == "__main__":` and, indented under it, `main()`.',
            ],
            "starter": '''CATALOG = ["Clean Code", "Refactoring", "Fluent Python", "Dune"]

# write main() and the __name__ check here
''',
            "solution": '''CATALOG = ["Clean Code", "Refactoring", "Fluent Python", "Dune"]

def main():
    print("Catalog loaded:", len(CATALOG))

if __name__ == "__main__":
    main()
''',
            "tests": '''import io, contextlib
assert __output__.strip() == "Catalog loaded: 4", f"when run, it should print 'Catalog loaded: 4', got {__output__.strip()!r}"
_buf = io.StringIO()
with contextlib.redirect_stdout(_buf):
    exec(__source__, {"__name__": "catalog"})
assert _buf.getvalue() == "", "when imported, nothing should print: call main() only under if __name__ == '__main__':"''',
        },
        "practice": [
            {
                "task": "This module prints a greeting as soon as anything imports it. Move the print into a `main()` function and only call it under `if __name__ == \"__main__\":`, so importing is silent.",
                "hints": [
                    "Indent the `print` line under a new `def main():`.",
                    "Then add `if __name__ == \"__main__\":` with `main()` indented under it.",
                ],
                "starter": '''OPENING_HOURS = "09:00-18:00"

print("Welcome to BookVault, open", OPENING_HOURS)
''',
                "solution": '''OPENING_HOURS = "09:00-18:00"

def main():
    print("Welcome to BookVault, open", OPENING_HOURS)

if __name__ == "__main__":
    main()
''',
                "tests": '''import io, contextlib
assert "Welcome to BookVault, open 09:00-18:00" in __output__, "running the file should still print the welcome line"
_buf = io.StringIO()
_ns = {"__name__": "bookvault_hours"}
with contextlib.redirect_stdout(_buf):
    exec(__source__, _ns)
assert _buf.getvalue() == "", "importing should print nothing"
assert _ns.get("OPENING_HOURS") == "09:00-18:00", "keep OPENING_HOURS at the top level so other modules can import it"''',
            },
        ],
    },
    # ------------------------------------------------------------------ command-line programs
    {
        "id": "cli-programs",
        "title": "Command-line programs",
        "idea": "A command-line program reads the words typed after it: in `python -m bookvault.cli search clean`, the words are `search` and `clean`. Python gives them to you in `sys.argv`, a list whose first item is the program's name.\n\nTwo ways to handle them:\n- `match` on the list of words: simple and readable for a few commands.\n- `argparse`: builds `--help` for you, checks types, and handles options like `--today 2026-05-18`.\n\nWrite `main(argv=None)` so it takes the list of words. Real runs use `sys.argv[1:]`; tests, and this page, call it with a list like `main([\"search\", \"clean\"])`.",
        "code": '''import argparse

def build_parser():
    parser = argparse.ArgumentParser(prog="bookvault")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("list")
    search = commands.add_parser("search")
    search.add_argument("query")
    overdue = commands.add_parser("overdue")
    overdue.add_argument("--today", default="2026-01-01")
    return parser

def main(argv=None):
    args = build_parser().parse_args(argv)
    match args.command:
        case "list":
            return "listing every item"
        case "search":
            return f"searching for {args.query!r}"
        case "overdue":
            return f"overdue loans as of {args.today}"

print(main(["list"]))
print(main(["search", "clean"]))
print(main(["overdue", "--today", "2026-05-18"]))
''',
        "walkthrough": [
            ['    parser = argparse.ArgumentParser(prog="bookvault")', "The parser knows the program's name and builds `--help` text for you."],
            ['    commands = parser.add_subparsers(dest="command", required=True)', "Sub-commands like `list` and `search`. The chosen one is stored in `args.command`."],
            ['    search.add_argument("query")', "A **positional** argument: the word after `search`."],
            ['    overdue.add_argument("--today", default="2026-01-01")', "An **option**, written `--today VALUE`. It's optional because it has a default."],
            ["    args = build_parser().parse_args(argv)", "Turns the list of words into `args`, with attributes like `args.query`. With `argv=None` it reads the real command line."],
            ["    match args.command:", "Pick what to do for each command, using `match` from the control-flow lesson."],
        ],
        "mistakes": [
            "Reading `sys.argv` directly inside `main` instead of taking a list: then tests can't call it.",
            "Forgetting that everything from the command line is **text**: use `type=int` in `add_argument` to get a number.",
            "Using `sys.argv[0]` as the first word: that's the program's name. The words start at `sys.argv[1]`.",
        ],
        "local": [{
            "title": "Run it from a terminal",
            "note": "Add `import sys` and `if __name__ == \"__main__\": print(main(sys.argv[1:]))` to the example, save it as `bookvault_cli.py` and try these.",
            "code": '''python bookvault_cli.py search clean
python bookvault_cli.py overdue --today 2026-05-18
python bookvault_cli.py --help''',
            "output": '''searching for 'clean'
overdue loans as of 2026-05-18
usage: bookvault [-h] {list,search,overdue} ...''',
        }],
        "challenge": {
            "task": "Write `main(argv)` with `match argv:` that returns `\"listing\"` for `[\"list\"]`, `\"searching <query>\"` for `[\"search\", query]`, `\"borrowing <n> items\"` for `[\"borrow\", ...]` with at least one id, and `\"usage: list | search <q> | borrow <ids...>\"` for anything else.",
            "hints": [
                'List patterns: `case ["list"]:`, `case ["search", query]:` and `case ["borrow", *ids] if ids:`.',
                'Use f-strings for the answers, e.g. `return f"searching {query}"` and `return f"borrowing {len(ids)} items"`, and `case _:` for usage.',
            ],
            "starter": '''def main(argv):
    match argv:
        case _:
            return "usage: list | search <q> | borrow <ids...>"

print(main(["search", "clean"]))
''',
            "solution": '''def main(argv):
    match argv:
        case ["list"]:
            return "listing"
        case ["search", query]:
            return f"searching {query}"
        case ["borrow", *ids] if ids:
            return f"borrowing {len(ids)} items"
        case _:
            return "usage: list | search <q> | borrow <ids...>"

print(main(["search", "clean"]))
''',
            "tests": '''assert main(["list"]) == "listing", f"main(['list']) gave {main(['list'])!r}"
assert main(["search", "dune"]) == "searching dune"
assert main(["borrow", "B1", "B2", "B3"]) == "borrowing 3 items"
for _bad in ([], ["borrow"], ["dance"], ["search"]):
    assert main(_bad).startswith("usage"), f"main({_bad}) should return the usage line"''',
        },
        "practice": [
            {
                "task": "Build a parser with `argparse` for `borrow`: one or more item ids (`nargs=\"+\"`) and an option `--days` that is an **int** with default `14`. Write `parse_borrow(argv)` that returns `(item_ids, days)`.",
                "hints": [
                    'Inside the function: `parser = argparse.ArgumentParser(prog="borrow")`, then `parser.add_argument("item_ids", nargs="+")`.',
                    'Add `parser.add_argument("--days", type=int, default=14)`, then `args = parser.parse_args(argv)` and `return args.item_ids, args.days`.',
                ],
                "starter": '''import argparse

def parse_borrow(argv):
    ...

print(parse_borrow(["B001", "M001", "--days", "7"]))
''',
                "solution": '''import argparse

def parse_borrow(argv):
    parser = argparse.ArgumentParser(prog="borrow")
    parser.add_argument("item_ids", nargs="+")
    parser.add_argument("--days", type=int, default=14)
    args = parser.parse_args(argv)
    return args.item_ids, args.days

print(parse_borrow(["B001", "M001", "--days", "7"]))
''',
                "tests": '''_ids, _days = parse_borrow(["B1"])
assert _ids == ["B1"] and _days == 14, f"without --days, days should be 14, got {_days!r}"
_ids, _days = parse_borrow(["B1", "B2", "--days", "7"])
assert _ids == ["B1", "B2"], f"item_ids should be ['B1', 'B2'], got {_ids!r}"
assert _days == 7, "--days should be converted to the int 7 (use type=int)"''',
            },
        ],
    },
]


def apply(LESSONS_LIST, PARTS):
    """Insert the project lessons as their own part, just before "Assignments"."""
    at = PARTS.index("Assignments")
    PARTS.insert(at, PART_TITLE)
    for lesson in LESSONS_LIST:
        if lesson["part"] >= at:
            lesson["part"] += 1
    first_assignment = next(i for i, l in enumerate(LESSONS_LIST) if l["part"] == at + 1)
    for offset, lesson in enumerate(LESSONS):
        lesson["part"] = at
        LESSONS_LIST.insert(first_assignment + offset, lesson)

"""Extra practice tasks for Chapter 1 ("Start here").

Each lesson's existing challenge only covers part of what it teaches. These tasks make
sure every concept is practised at least once. Each task only uses syntax taught in that
lesson or an earlier one. Check with:
    python engine/build.py day1 --check-practice practice_a
"""

PRACTICE = {
    # ------------------------------------------------------------------
    "welcome": [
        {
            "task": "Python runs lines from top to bottom. Print exactly two lines, in this order:\n`Day 1 of my Python journey`\n`BookVault is open`",
            "starter": '''print("BookVault is open")
''',
            "solution": '''print("Day 1 of my Python journey")
print("BookVault is open")
''',
            "tests": '''_lines = __output__.strip().split("\\n")
assert len(_lines) == 2, f"expected 2 lines of output, got {len(_lines)}"
assert _lines[0] == "Day 1 of my Python journey", f"line 1 should be 'Day 1 of my Python journey', you printed {_lines[0]!r}"
assert _lines[1] == "BookVault is open", f"line 2 should be 'BookVault is open', you printed {_lines[1]!r}"''',
            "hints": [
                "You need two `print(...)` lines. The one that should appear first must be written first.",
                'Add `print("Day 1 of my Python journey")` above the line that is already there.',
            ],
        },
    ],
    # ------------------------------------------------------------------
    "print-comments": [
        {
            "task": "Print `Copies: 3` by giving `print` **two things separated by a comma**: the text `\"Copies:\"` and the number `3` (no quotes around the number).",
            "starter": '''print("Copies:")
''',
            "solution": '''print("Copies:", 3)
''',
            "tests": '''assert __output__.strip() == "Copies: 3", f"you printed {__output__.strip()!r}, expected 'Copies: 3'"
assert "Copies: 3" not in __source__, "do not type 'Copies: 3' as one piece of text: put a comma between the text and the number"
assert '"3"' not in __source__ and "'3'" not in __source__, "numbers do not need quotes: write 3, not \\"3\\""''',
            "hints": [
                "A comma between the things inside `print( )` prints them with one space between.",
                'Write `print("Copies:", 3)`.',
            ],
        },
        {
            "task": "Print `Clean Code`, then an **empty line**, then `Due back in 14 days`. Use `print()` for the empty line, and add a **comment** (a line starting with `#`) that says what the code does.",
            "starter": '''print("Clean Code")
print("Due back in 14 days")
''',
            "solution": '''# print a loan slip with a gap in the middle
print("Clean Code")
print()
print("Due back in 14 days")
''',
            "tests": '''assert __output__ == "Clean Code\\n\\nDue back in 14 days\\n", f"you printed {__output__!r}; expected the title, an empty line, then the due line"
assert "print()" in __source__, "use print() with nothing inside to print the empty line"
assert "#" in __source__, "add a comment: a line starting with #"''',
            "hints": [
                "`print()` with nothing inside the brackets prints an empty line. Put it between the other two.",
                'Add a first line like `# print a loan slip`, then `print("Clean Code")`, `print()`, `print("Due back in 14 days")`.',
            ],
        },
    ],
    # ------------------------------------------------------------------
    "variables": [
        {
            "task": "A book has `pages = 448` and the reader has done `pages_read = 120`. Create `pages_left` by subtracting, **using the two variables** (not the numbers), then print `Pages left: 328`.",
            "starter": '''pages = 448
pages_read = 120

pages_left = ...
print("Pages left:", pages_left)
''',
            "solution": '''pages = 448
pages_read = 120

pages_left = pages - pages_read
print("Pages left:", pages_left)
''',
            "tests": '''import io, contextlib
assert pages_left == 328, f"pages_left is {pages_left!r}, expected 328"
assert __output__.strip() == "Pages left: 328", f"you printed {__output__.strip()!r}"
_trial = {}
with contextlib.redirect_stdout(io.StringIO()):
    exec(__source__.replace("pages = 448", "pages = 300", 1).replace("pages_read = 120", "pages_read = 50", 1), _trial)
assert _trial.get("pages_left") == 250, "with pages = 300 and pages_read = 50, pages_left should be 250: use the variable names, not the numbers"''',
            "hints": [
                "The right side of `=` is worked out first, and you can use variable names there.",
                "`pages_left = pages - pages_read`",
            ],
        },
        {
            "task": "The shelf starts with `copies = 5`. Someone borrows one. On a new line, **store a new value** in `copies` that is one less than the old value (use `copies` on the right side), then print it.",
            "starter": '''copies = 5

# a copy is borrowed: update copies here

print(copies)
''',
            "solution": '''copies = 5

# a copy is borrowed: update copies here
copies = copies - 1

print(copies)
''',
            "tests": '''import io, contextlib
assert copies == 4, f"copies is {copies!r}, expected 4"
_trial = {}
with contextlib.redirect_stdout(io.StringIO()):
    exec(__source__.replace("copies = 5", "copies = 9", 1), _trial)
assert _trial.get("copies") == 8, "if copies started at 9 your code should give 8: use copies - 1, not the number 4"''',
            "hints": [
                "Assigning to a name again replaces its old value. The right side can use the old value.",
                "`copies = copies - 1`",
            ],
        },
    ],
    # ------------------------------------------------------------------
    "numbers": [
        {
            "task": "A reader reads `per_day = 30` pages a day of a `pages = 464` book. Use `//` to store the number of **full days** in `full_days`, and `%` to store the **pages left over** in `left_over`.",
            "starter": '''pages = 464
per_day = 30

full_days = ...
left_over = ...
print(full_days, left_over)
''',
            "solution": '''pages = 464
per_day = 30

full_days = pages // per_day
left_over = pages % per_day
print(full_days, left_over)
''',
            "tests": '''import io, contextlib
assert full_days == 15, f"full_days is {full_days!r}, expected 15"
assert left_over == 14, f"left_over is {left_over!r}, expected 14"
_trial = {}
with contextlib.redirect_stdout(io.StringIO()):
    exec(__source__.replace("pages = 464", "pages = 100", 1), _trial)
assert _trial.get("full_days") == 3 and _trial.get("left_over") == 10, "with pages = 100 you should get 3 full days and 10 left over: use the variables, not fixed numbers"''',
            "hints": [
                "`//` divides and drops the remainder; `%` gives only the remainder.",
                "`full_days = pages // per_day` and `left_over = pages % per_day`.",
            ],
        },
        {
            "task": "A book got ratings adding up to `total = 31` from `reviews = 7` readers. Store `average` (use `/`), then `rounded` as the average rounded to **2 decimal places**, and `kind` as the `type` of `average`.",
            "starter": '''total = 31
reviews = 7

average = ...
rounded = ...
kind = ...
print(average, rounded, kind)
''',
            "solution": '''total = 31
reviews = 7

average = total / reviews
rounded = round(average, 2)
kind = type(average)
print(average, rounded, kind)
''',
            "tests": '''assert abs(average - 31 / 7) < 0.000001, f"average is {average!r}; divide total by reviews"
assert rounded == 4.43, f"rounded is {rounded!r}, expected 4.43"
assert kind is float, f"kind is {kind!r}; use type(average), which should be float"''',
            "hints": [
                "`round(x, 2)` rounds to 2 decimal places, and `type(x)` tells you what kind of value `x` is.",
                "`average = total / reviews`, `rounded = round(average, 2)`, `kind = type(average)`.",
            ],
        },
        {
            "task": "A locker code has 4 digits, so there are `10` to the power `4` possible codes: store it in `codes` using `**`. The library has 12 shelves upstairs and 8 downstairs, each holding 30 books: store the total in `total_books` using **brackets** so the adding happens first.",
            "starter": '''codes = ...
total_books = 12 + 8 * 30
print(codes, total_books)
''',
            "solution": '''codes = 10 ** 4
total_books = (12 + 8) * 30
print(codes, total_books)
''',
            "tests": '''assert codes == 10000, f"codes is {codes!r}, expected 10000"
assert "**" in __source__, "use ** for the power"
assert total_books == 600, f"total_books is {total_books!r}, expected 600: without brackets 8 * 30 happens first"
assert "(" in __source__.replace("print(", ""), "use brackets ( ) so 12 + 8 is added before multiplying"''',
            "hints": [
                "`2 ** 3` is 8. Multiplication happens before addition unless you use brackets.",
                "`codes = 10 ** 4` and `total_books = (12 + 8) * 30`.",
            ],
        },
    ],
    # ------------------------------------------------------------------
    "strings-basics": [
        {
            "task": "Using `+` (not an f-string), build `label` as `Deep Work (296 pages)` from `title` and `pages`. You will need `str()` for the number. Also store the number of characters in `title` in `length`.",
            "starter": '''title = "Deep Work"
pages = 296

label = ...
length = ...
print(label, length)
''',
            "solution": '''title = "Deep Work"
pages = 296

label = title + " (" + str(pages) + " pages)"
length = len(title)
print(label, length)
''',
            "tests": '''assert label == "Deep Work (296 pages)", f"label is {label!r}"
assert "str(pages)" in __source__, "turn the number into text with str(pages) before joining with +"
assert length == 9, f"length is {length!r}; use len(title)"
assert "len(" in __source__, "use len() to count the characters"''',
            "hints": [
                "`+` glues text together but does not add spaces; `str(296)` turns a number into text.",
                '`label = title + " (" + str(pages) + " pages)"` and `length = len(title)`.',
            ],
        },
        {
            "task": "The catalogue stores numbers as text: `pages_text = \"464\"` and `rating_text = \"4.5\"`. Convert them to real numbers: `pages` with `int()` and `rating` with `float()`. Then store `next_page` as `pages + 1`.",
            "starter": '''pages_text = "464"
rating_text = "4.5"

pages = pages_text
rating = rating_text
next_page = ...
print(next_page, rating)
''',
            "solution": '''pages_text = "464"
rating_text = "4.5"

pages = int(pages_text)
rating = float(rating_text)
next_page = pages + 1
print(next_page, rating)
''',
            "tests": '''assert pages == 464 and type(pages) is int, f"pages is {pages!r}; convert with int(pages_text)"
assert rating == 4.5 and type(rating) is float, f"rating is {rating!r}; convert with float(rating_text)"
assert next_page == 465, f"next_page is {next_page!r}, expected 465"''',
            "hints": [
                "`int(\"5\")` turns text into a whole number, and `float(\"4.5\")` into a decimal number.",
                "`pages = int(pages_text)`, `rating = float(rating_text)`, `next_page = pages + 1`.",
            ],
        },
        {
            "task": "Shelf tags must be lower case with `_` instead of `-`. Turn `code = \"CLEAN-CODE\"` into `shelf_tag` = `clean_code` using the `.lower()` and `.replace()` methods.",
            "starter": '''code = "CLEAN-CODE"

shelf_tag = ...
print(shelf_tag)
''',
            "solution": '''code = "CLEAN-CODE"

shelf_tag = code.lower().replace("-", "_")
print(shelf_tag)
''',
            "tests": '''assert shelf_tag == "clean_code", f"shelf_tag is {shelf_tag!r}, expected 'clean_code'"
assert ".lower()" in __source__, "use the .lower() method"
assert ".replace(" in __source__, "use the .replace() method"''',
            "hints": [
                "You can chain methods: the result of the first one is used by the second.",
                '`shelf_tag = code.lower().replace("-", "_")`',
            ],
        },
    ],
    # ------------------------------------------------------------------
    "booleans": [
        {
            "task": "A book is a **staff pick** if its `rating` is 4.5 or more, **or** its `author` is `\"Robert Martin\"`. Create `staff_pick` with one expression using `>=`, `==` and `or`.",
            "starter": '''rating = 4.2
author = "Robert Martin"

staff_pick = ...
print(staff_pick)
''',
            "solution": '''rating = 4.2
author = "Robert Martin"

staff_pick = rating >= 4.5 or author == "Robert Martin"
print(staff_pick)
''',
            "tests": '''import io, contextlib
assert staff_pick is True, f"with rating 4.2 and author Robert Martin, staff_pick should be True, got {staff_pick!r}"
for _r, _a, _expected in ((4.5, "Cal Newport", True), (4.4, "Cal Newport", False), (3.0, "Robert Martin", True), (4.9, "Robert Martin", True)):
    _code = __source__.replace("rating = 4.2", f"rating = {_r}", 1).replace('author = "Robert Martin"', f'author = "{_a}"', 1)
    _trial = {}
    with contextlib.redirect_stdout(io.StringIO()):
        exec(_code, _trial)
    assert _trial.get("staff_pick") is _expected, f"with rating {_r} and author {_a}, staff_pick should be {_expected}, got {_trial.get('staff_pick')!r}"''',
            "hints": [
                "4.5 or more is `rating >= 4.5`. Comparing text uses two equals signs: `==`.",
                '`staff_pick = rating >= 4.5 or author == "Robert Martin"`',
            ],
        },
        {
            "task": "Create `on_loan`, which is the **opposite** of `available` (use `not`), and `misplaced`, which is `True` when `shelf` is **not equal** to `\"A3\"` (use `!=`).",
            "starter": '''available = False
shelf = "B2"

on_loan = ...
misplaced = ...
print(on_loan, misplaced)
''',
            "solution": '''available = False
shelf = "B2"

on_loan = not available
misplaced = shelf != "A3"
print(on_loan, misplaced)
''',
            "tests": '''import io, contextlib
assert on_loan is True, f"available is False, so on_loan should be True, got {on_loan!r}"
assert misplaced is True, f"shelf is B2, so misplaced should be True, got {misplaced!r}"
_code = __source__.replace("available = False", "available = True", 1).replace('shelf = "B2"', 'shelf = "A3"', 1)
_trial = {}
with contextlib.redirect_stdout(io.StringIO()):
    exec(_code, _trial)
assert _trial.get("on_loan") is False, "with available = True, on_loan should be False: use not available"
assert _trial.get("misplaced") is False, "with shelf = 'A3', misplaced should be False: use shelf != \\"A3\\""''',
            "hints": [
                "`not` flips True and False. `!=` means \"not equal\".",
                '`on_loan = not available` and `misplaced = shelf != "A3"`.',
            ],
        },
    ],
    # ------------------------------------------------------------------
    "if-else": [
        {
            "task": "Use `if available:` (the boolean on its own, no `== True`) and `else:` to set `message` to `\"You can borrow it now.\"` when the book is available, otherwise to `\"Join the waiting list.\"`.",
            "starter": '''available = False

message = ...
print(message)
''',
            "solution": '''available = False

if available:
    message = "You can borrow it now."
else:
    message = "Join the waiting list."
print(message)
''',
            "tests": '''import io, contextlib
assert message == "Join the waiting list.", f"with available = False, message should be 'Join the waiting list.', got {message!r}"
_trial = {}
with contextlib.redirect_stdout(io.StringIO()):
    exec(__source__.replace("available = False", "available = True", 1), _trial)
assert _trial.get("message") == "You can borrow it now.", f"with available = True, message should be 'You can borrow it now.', got {_trial.get('message')!r}"
assert "== True" not in __source__, "a boolean can be the condition by itself: write if available:"''',
            "hints": [
                "A boolean variable can be the condition directly. Remember the colon and the 4-space indent.",
                '`if available:` → indented `message = "You can borrow it now."`, then `else:` → indented `message = "Join the waiting list."`.',
            ],
        },
        {
            "task": "If `fines` is more than 0, print `Please pay your fines first.` Then, **outside** the `if` (not indented), always print `Goodbye!`. No `else` is needed.",
            "starter": '''fines = 20

# your if here

''',
            "solution": '''fines = 20

if fines > 0:
    print("Please pay your fines first.")
print("Goodbye!")
''',
            "tests": '''import io, contextlib
assert __output__ == "Please pay your fines first.\\nGoodbye!\\n", f"with fines = 20 you printed {__output__!r}"
_buf = io.StringIO()
with contextlib.redirect_stdout(_buf):
    exec(__source__.replace("fines = 20", "fines = 0", 1), {})
assert _buf.getvalue() == "Goodbye!\\n", f"with fines = 0 only 'Goodbye!' should print, but got {_buf.getvalue()!r}: is Goodbye! outside the if?"''',
            "hints": [
                "Only indented lines belong to the `if`. A line back at the left edge always runs.",
                '`if fines > 0:` → indented `print("Please pay your fines first.")`, then `print("Goodbye!")` with no indent.',
            ],
        },
    ],
    # ------------------------------------------------------------------
    "lists-basics": [
        {
            "task": "Store the **last** book in `last_book` using a negative index, and store whether `\"Dune\"` is in the list in `has_dune` using `in`.",
            "starter": '''books = ["Clean Code", "Refactoring", "Fluent Python"]

last_book = ...
has_dune = ...
print(last_book, has_dune)
''',
            "solution": '''books = ["Clean Code", "Refactoring", "Fluent Python"]

last_book = books[-1]
has_dune = "Dune" in books
print(last_book, has_dune)
''',
            "tests": '''assert last_book == "Fluent Python", f"last_book is {last_book!r}"
assert "[-1]" in __source__, "use the negative index books[-1] for the last item"
assert has_dune is False, f"has_dune is {has_dune!r}; Dune is not in the list"
assert " in books" in __source__, "use the in keyword to check: Dune in books"''',
            "hints": [
                "`-1` counts from the end. `x in books` gives True or False.",
                '`last_book = books[-1]` and `has_dune = "Dune" in books`.',
            ],
        },
        {
            "task": "Replace the second book (index 1) with `\"Refactoring (2nd edition)\"`. Then store the **first two** books in `first_two` using a slice.",
            "starter": '''books = ["Clean Code", "Refactoring", "Fluent Python"]

# replace the second book here

first_two = ...
print(first_two)
''',
            "solution": '''books = ["Clean Code", "Refactoring", "Fluent Python"]

books[1] = "Refactoring (2nd edition)"

first_two = books[0:2]
print(first_two)
''',
            "tests": '''assert books == ["Clean Code", "Refactoring (2nd edition)", "Fluent Python"], f"books is {books}"
assert first_two == ["Clean Code", "Refactoring (2nd edition)"], f"first_two is {first_two}"
assert ":" in __source__.split("first_two")[1], "use a slice like books[0:2]"''',
            "hints": [
                "`books[1] = ...` replaces the item at index 1. A slice `[start:stop]` stops *before* `stop`.",
                '`books[1] = "Refactoring (2nd edition)"` and `first_two = books[0:2]`.',
            ],
        },
        {
            "task": "For the list `pages`, store the total in `total` with `sum()`, the biggest in `longest` with `max()` and the smallest in `shortest` with `min()`.",
            "starter": '''pages = [464, 448, 1014, 180]

total = ...
longest = ...
shortest = ...
print(total, longest, shortest)
''',
            "solution": '''pages = [464, 448, 1014, 180]

total = sum(pages)
longest = max(pages)
shortest = min(pages)
print(total, longest, shortest)
''',
            "tests": '''import io, contextlib
assert total == 2106, f"total is {total!r}, expected 2106"
assert longest == 1014, f"longest is {longest!r}, expected 1014"
assert shortest == 180, f"shortest is {shortest!r}, expected 180"
_trial = {}
with contextlib.redirect_stdout(io.StringIO()):
    exec(__source__.replace("pages = [464, 448, 1014, 180]", "pages = [10, 20, 30]", 1), _trial)
assert (_trial.get("total"), _trial.get("longest"), _trial.get("shortest")) == (60, 30, 10), "use sum(pages), max(pages) and min(pages) instead of typing the answers"''',
            "hints": [
                "Each helper takes the list inside its brackets.",
                "`total = sum(pages)`, `longest = max(pages)`, `shortest = min(pages)`.",
            ],
        },
    ],
    # ------------------------------------------------------------------
    "for-loops": [
        {
            "task": "Use a `for` loop to print `Reading: ` followed by each book, one per line.",
            "starter": '''books = ["Clean Code", "Refactoring", "Fluent Python"]

# your loop here
''',
            "solution": '''books = ["Clean Code", "Refactoring", "Fluent Python"]

for book in books:
    print("Reading:", book)
''',
            "tests": '''_lines = __output__.strip().split("\\n")
assert _lines == ["Reading: Clean Code", "Reading: Refactoring", "Reading: Fluent Python"], f"you printed {_lines}"
assert "for " in __source__, "use a for loop"''',
            "hints": [
                "`for book in books:` and an indented `print` line inside it.",
                '`for book in books:` → indented `print("Reading:", book)`.',
            ],
        },
        {
            "task": "Use `range(1, 6)` in a `for` loop to print `Shelf 1`, `Shelf 2`, … up to `Shelf 5`, one per line.",
            "starter": '''# your loop here
''',
            "solution": '''for number in range(1, 6):
    print("Shelf", number)
''',
            "tests": '''_lines = __output__.strip().split("\\n")
assert _lines == ["Shelf 1", "Shelf 2", "Shelf 3", "Shelf 4", "Shelf 5"], f"you printed {_lines}"
assert "range(" in __source__, "use range(1, 6) to get the numbers 1 to 5"''',
            "hints": [
                "`range(1, 6)` gives 1, 2, 3, 4, 5: it stops just before 6.",
                '`for number in range(1, 6):` → indented `print("Shelf", number)`.',
            ],
        },
        {
            "task": "Add up all the pages with a `for` loop and an **accumulator**: start `total` at 0 before the loop and add each number to it. Don't use `sum()`.",
            "starter": '''pages = [464, 448, 1014, 180]

total = 0
# your loop here

print(total)
''',
            "solution": '''pages = [464, 448, 1014, 180]

total = 0
for p in pages:
    total = total + p

print(total)
''',
            "tests": '''import io, contextlib
assert total == 2106, f"total is {total!r}, expected 2106"
assert "sum(" not in __source__, "practise the loop: don't use sum()"
_trial = {}
with contextlib.redirect_stdout(io.StringIO()):
    exec(__source__.replace("pages = [464, 448, 1014, 180]", "pages = [5, 7]", 1), _trial)
assert _trial.get("total") == 12, "with pages = [5, 7] total should be 12: add each p inside the loop"''',
            "hints": [
                "Inside `for p in pages:`, make `total` bigger by `p` each lap.",
                "`for p in pages:` → indented `total = total + p`.",
            ],
        },
    ],
    # ------------------------------------------------------------------
    "while-loops": [
        {
            "task": "There are `copies = 3` copies. Use a `while` loop that runs while `copies > 0`; each lap, take one copy away with `-=` and add 1 to `lent` with `+=`.",
            "starter": '''copies = 3
lent = 0

# your while loop here

print(copies, lent)
''',
            "solution": '''copies = 3
lent = 0

while copies > 0:
    copies -= 1
    lent += 1

print(copies, lent)
''',
            "tests": '''import io, contextlib
assert copies == 0, f"copies is {copies!r}, expected 0"
assert lent == 3, f"lent is {lent!r}, expected 3"
assert "while" in __source__, "use a while loop"
assert "-=" in __source__, "use -= to take a copy away"
_trial = {}
with contextlib.redirect_stdout(io.StringIO()):
    exec(__source__.replace("copies = 3", "copies = 5", 1), _trial)
assert _trial.get("lent") == 5, "with copies = 5, lent should end at 5"''',
            "hints": [
                "`copies -= 1` means `copies = copies - 1`. Without it the loop never ends.",
                "`while copies > 0:` → indented `copies -= 1` and `lent += 1`.",
            ],
        },
        {
            "task": "A reader reads 35 pages a day. Use `while True:` and `break` to find the first `day` on which `pages_read` reaches **200 or more**. Each lap: add 1 to `day`, add 35 to `pages_read`, and `break` if the goal is reached.",
            "starter": '''day = 0
pages_read = 0

# your while True loop here

print(day, pages_read)
''',
            "solution": '''day = 0
pages_read = 0

while True:
    day += 1
    pages_read += 35
    if pages_read >= 200:
        break

print(day, pages_read)
''',
            "tests": '''assert day == 6, f"day is {day!r}, expected 6"
assert pages_read == 210, f"pages_read is {pages_read!r}, expected 210"
assert "while True" in __source__, "use while True:"
assert "break" in __source__, "use break to stop the loop"''',
            "hints": [
                "`while True:` repeats forever until `break` runs. Put the `if ...: break` inside the loop.",
                "Inside: `day += 1`, `pages_read += 35`, then `if pages_read >= 200:` → indented `break`.",
            ],
        },
    ],
    # ------------------------------------------------------------------
    "dicts-basics": [
        {
            "task": "The book has no ISBN or year yet. Use `.get()` with a default to store `isbn` as `\"unknown\"`, use `.get()` without a default to store `year` (it should be `None`), and store the number of keys in `fields` with `len()`.",
            "starter": '''book = {"title": "Clean Code", "author": "Robert Martin", "pages": 464}

isbn = ...
year = ...
fields = ...
print(isbn, year, fields)
''',
            "solution": '''book = {"title": "Clean Code", "author": "Robert Martin", "pages": 464}

isbn = book.get("isbn", "unknown")
year = book.get("year")
fields = len(book)
print(isbn, year, fields)
''',
            "tests": '''assert isbn == "unknown", f"isbn is {isbn!r}; use book.get(\\"isbn\\", \\"unknown\\")"
assert year is None, f"year is {year!r}; book.get(\\"year\\") gives None for a missing key"
assert fields == 3, f"fields is {fields!r}; use len(book)"
assert ".get(" in __source__, "use the .get() method"''',
            "hints": [
                "`.get(key)` gives `None` for a missing key; `.get(key, default)` gives the default instead.",
                '`isbn = book.get("isbn", "unknown")`, `year = book.get("year")`, `fields = len(book)`.',
            ],
        },
        {
            "task": "Loop over `book.items()` and print each pair as `key: value`, for example `title: Clean Code`.",
            "starter": '''book = {"title": "Clean Code", "author": "Robert Martin", "pages": 464}

# your loop here
''',
            "solution": '''book = {"title": "Clean Code", "author": "Robert Martin", "pages": 464}

for key, value in book.items():
    print(f"{key}: {value}")
''',
            "tests": '''_lines = __output__.strip().split("\\n")
assert _lines == ["title: Clean Code", "author: Robert Martin", "pages: 464"], f"you printed {_lines}"
assert ".items()" in __source__, "loop over book.items()"''',
            "hints": [
                "`for key, value in book.items():` gives you each pair.",
                'Inside the loop: `print(f"{key}: {value}")`.',
            ],
        },
        {
            "task": "`catalog` is a list of dictionaries. Loop over it, print each book's `title`, and add up the `pages` of all books in `total_pages`.",
            "starter": '''catalog = [
    {"title": "Clean Code", "pages": 464},
    {"title": "Refactoring", "pages": 448},
    {"title": "Deep Work", "pages": 296},
]

total_pages = 0
# your loop here

print(total_pages)
''',
            "solution": '''catalog = [
    {"title": "Clean Code", "pages": 464},
    {"title": "Refactoring", "pages": 448},
    {"title": "Deep Work", "pages": 296},
]

total_pages = 0
for b in catalog:
    print(b["title"])
    total_pages = total_pages + b["pages"]

print(total_pages)
''',
            "tests": '''_lines = __output__.strip().split("\\n")
assert _lines[:3] == ["Clean Code", "Refactoring", "Deep Work"], f"print each title first; you printed {_lines}"
assert total_pages == 1208, f"total_pages is {total_pages!r}, expected 1208"
assert "for " in __source__, "use a for loop over catalog"''',
            "hints": [
                'Each item in the loop is a dictionary, so `b["title"]` and `b["pages"]` work.',
                '`for b in catalog:` → indented `print(b["title"])` and `total_pages = total_pages + b["pages"]`.',
            ],
        },
    ],
    # ------------------------------------------------------------------
    "functions-basics": [
        {
            "task": "Write `fine(days_late, per_day=2)` that **returns** `days_late * per_day`. Because of the default, `fine(5)` is 10, but `fine(5, 3)` is 15.",
            "starter": '''def fine(days_late, per_day):
    return days_late * per_day

print(fine(5, 3))
''',
            "solution": '''def fine(days_late, per_day=2):
    return days_late * per_day

print(fine(5))
print(fine(5, 3))
''',
            "tests": '''assert fine(5) == 10, f"fine(5) should be 10 (per_day defaults to 2), got {fine(5)!r}"
assert fine(5, 3) == 15, f"fine(5, 3) should be 15, got {fine(5, 3)!r}"
assert fine(0) == 0, "fine(0) should be 0"''',
            "hints": [
                "Give a parameter a default by writing `=value` after its name in the `def` line.",
                "`def fine(days_late, per_day=2):`",
            ],
        },
        {
            "task": "Write `print_label(title)` that **prints** `Shelf label: ` followed by the title (it does not need `return`). Then call it twice: with `\"Clean Code\"` and with `\"Refactoring\"`.",
            "starter": '''def print_label(title):
    ...

# call it twice here
''',
            "solution": '''def print_label(title):
    print("Shelf label:", title)

print_label("Clean Code")
print_label("Refactoring")
''',
            "tests": '''_lines = __output__.strip().split("\\n")
assert _lines == ["Shelf label: Clean Code", "Shelf label: Refactoring"], f"you printed {_lines}"
assert "def print_label" in __source__, "define the function with def print_label(title):"''',
            "hints": [
                "Defining a function does not run it. Call it with `print_label(...)` after the `def` block.",
                'Body: `print("Shelf label:", title)`. Then `print_label("Clean Code")` and `print_label("Refactoring")`.',
            ],
        },
        {
            "task": "Write `is_overdue(days_out)` that **returns** `True` when `days_out` is more than 14, otherwise `False`. Then use it in an `if` to print `Overdue!` for `days_out = 20`.",
            "starter": '''def is_overdue(days_out):
    ...

days_out = 20
# your if here
''',
            "solution": '''def is_overdue(days_out):
    return days_out > 14

days_out = 20
if is_overdue(days_out):
    print("Overdue!")
''',
            "tests": '''assert is_overdue(20) is True, f"is_overdue(20) should be True, got {is_overdue(20)!r}"
assert is_overdue(14) is False, f"is_overdue(14) should be False, got {is_overdue(14)!r}"
assert is_overdue(0) is False, "is_overdue(0) should be False"
assert __output__.strip() == "Overdue!", f"you printed {__output__.strip()!r}"''',
            "hints": [
                "A comparison already gives True or False, so you can return it directly.",
                '`return days_out > 14`, then `if is_overdue(days_out):` → indented `print("Overdue!")`.',
            ],
        },
    ],
    # ------------------------------------------------------------------
    "errors-basics": [
        {
            "task": "This code crashes. Run it and read the **last line** of the error: it is a `TypeError`. Fix the print line so it prints `Pages: 464` (keep `pages` a number).",
            "starter": '''pages = 464
print("Pages: " + pages)
''',
            "solution": '''pages = 464
print("Pages: " + str(pages))
''',
            "tests": '''assert __output__.strip() == "Pages: 464", f"you printed {__output__.strip()!r}"
assert pages == 464, "keep pages = 464 as a number; change the print line instead"''',
            "hints": [
                "The error says you cannot `+` text and a number.",
                'Turn the number into text: `print("Pages: " + str(pages))`.',
            ],
        },
        {
            "task": "Write `set_rating(stars)` that **raises** `ValueError(\"rating must be 1 to 5\")` when `stars` is below 1 or above 5, and otherwise returns `stars`.",
            "starter": '''def set_rating(stars):
    return stars

print(set_rating(4))
''',
            "solution": '''def set_rating(stars):
    if stars < 1 or stars > 5:
        raise ValueError("rating must be 1 to 5")
    return stars

print(set_rating(4))
''',
            "tests": '''assert set_rating(4) == 4, "set_rating(4) should return 4"
assert set_rating(1) == 1 and set_rating(5) == 5, "1 and 5 are allowed ratings"
for _bad in (0, 6, -3):
    _raised = False
    try:
        set_rating(_bad)
    except ValueError:
        _raised = True
    assert _raised, f"set_rating({_bad}) should raise ValueError"''',
            "hints": [
                "Check the bad case with `if stars < 1 or stars > 5:` before returning.",
                'Inside that `if`: `raise ValueError("rating must be 1 to 5")`.',
            ],
        },
        {
            "task": "Looking up a missing key crashes with `KeyError`. Wrap `print(book[\"isbn\"])` in `try`, and under `except KeyError as error:` print `Missing key:` followed by the error.",
            "starter": '''book = {"title": "Clean Code"}

print(book["isbn"])
print("Still running")
''',
            "solution": '''book = {"title": "Clean Code"}

try:
    print(book["isbn"])
except KeyError as error:
    print("Missing key:", error)
print("Still running")
''',
            "tests": '''_lines = __output__.strip().split("\\n")
assert len(_lines) == 2, f"expected 2 lines of output, got {_lines}"
assert _lines[0].startswith("Missing key:") and "isbn" in _lines[0], f"line 1 should be 'Missing key:' followed by the error, got {_lines[0]!r}"
assert _lines[1] == "Still running", "the program should keep running after the error is handled"
assert "as error" in __source__, "use except KeyError as error: so you can print the error"''',
            "hints": [
                "Put the risky line indented under `try:`, then the `except` block below it.",
                '`except KeyError as error:` → indented `print("Missing key:", error)`.',
            ],
        },
    ],
    # ------------------------------------------------------------------
    "modules-basics": [
        {
            "task": "Import the `math` module. Store `days` as `464 / 40` rounded **up** with `math.ceil`, and `side` as the square root of 144 (the side of a square reading room) with `math.sqrt`.",
            "starter": '''days = ...
side = ...
print(days, side)
''',
            "solution": '''import math

days = math.ceil(464 / 40)
side = math.sqrt(144)
print(days, side)
''',
            "tests": '''assert "import math" in __source__, "start with import math"
assert days == 12, f"days is {days!r}, expected 12 (11.6 rounded up)"
assert "math.ceil(" in __source__, "use math.ceil()"
assert side == 12, f"side is {side!r}, expected 12.0"
assert "math.sqrt(" in __source__, "use math.sqrt()"''',
            "hints": [
                "After `import math`, write the module name, a dot and the function: `math.ceil(...)`.",
                "`import math`, then `days = math.ceil(464 / 40)` and `side = math.sqrt(144)`.",
            ],
        },
        {
            "task": "Import `random` and store one randomly chosen book from `books` in `pick` using `random.choice`.",
            "starter": '''books = ["Clean Code", "Refactoring", "Fluent Python"]

pick = books[0]
print("Tonight's read:", pick)
''',
            "solution": '''import random

books = ["Clean Code", "Refactoring", "Fluent Python"]

pick = random.choice(books)
print("Tonight's read:", pick)
''',
            "tests": '''assert "import random" in __source__, "start with import random"
assert "random.choice(" in __source__, "use random.choice(books)"
assert pick in books, f"pick is {pick!r}, which is not in books"''',
            "hints": [
                "Add `import random` at the top.",
                "`pick = random.choice(books)`",
            ],
        },
    ],
    # ------------------------------------------------------------------
    "tuples-none": [
        {
            "task": "Create a **tuple** `book` holding `\"Fluent Python\"` and `1014`. Then **unpack** it in one line into `title` and `pages`.",
            "starter": '''book = ...

# unpack here

print(title, pages)
''',
            "solution": '''book = ("Fluent Python", 1014)

title, pages = book

print(title, pages)
''',
            "tests": '''assert type(book) is tuple, "book should be a tuple: use round brackets ( )"
assert book == ("Fluent Python", 1014), f"book is {book!r}"
assert title == "Fluent Python" and pages == 1014, f"title={title!r}, pages={pages!r}"
assert "title, pages = book" in __source__.replace("title,pages", "title, pages"), "unpack in one line: title, pages = book"''',
            "hints": [
                "Round brackets make a tuple. Unpacking puts the values into names in order.",
                '`book = ("Fluent Python", 1014)` then `title, pages = book`.',
            ],
        },
        {
            "task": "`find_shelf` returns a shelf only for `\"Clean Code\"`; otherwise it has no `return`, so it gives `None`. Store `find_shelf(\"Dune\")` in `shelf`, then use `is None` to print `Not on any shelf` when there is no shelf.",
            "starter": '''def find_shelf(title):
    if title == "Clean Code":
        return "Shelf A3"

shelf = ...
# check for None here
''',
            "solution": '''def find_shelf(title):
    if title == "Clean Code":
        return "Shelf A3"

shelf = find_shelf("Dune")
if shelf is None:
    print("Not on any shelf")
''',
            "tests": '''assert shelf is None, f"shelf is {shelf!r}; find_shelf(\\"Dune\\") should give None"
assert __output__.strip() == "Not on any shelf", f"you printed {__output__.strip()!r}"
assert "is None" in __source__, "check with: if shelf is None:"''',
            "hints": [
                "A function that ends without `return` gives back `None`.",
                '`shelf = find_shelf("Dune")`, then `if shelf is None:` → indented `print("Not on any shelf")`.',
            ],
        },
    ],
    # ------------------------------------------------------------------
    "python-setup": [
        {
            "task": "Using the `sys` module, store the version number (just the first word of `sys.version`) in `version`, and the name of the Python that is running in `running_on`. On this page it will say `brython`.",
            "starter": '''import sys

version = sys.version
running_on = ...
print(running_on, version)
''',
            "solution": '''import sys

version = sys.version.split()[0]
running_on = sys.implementation.name
print(running_on, version)
''',
            "tests": '''import sys as _sys
assert version == _sys.version.split()[0], f"version is {version!r}; use sys.version.split()[0] to keep only the first word"
assert running_on == _sys.implementation.name, f"running_on is {running_on!r}; use sys.implementation.name"''',
            "hints": [
                "`.split()` breaks text into a list of words, and `[0]` keeps the first one.",
                "`version = sys.version.split()[0]` and `running_on = sys.implementation.name`.",
            ],
        },
    ],
}

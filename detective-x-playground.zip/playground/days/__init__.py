"""Course content, one package per training day (day1, day2, ...)."""

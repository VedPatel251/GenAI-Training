"""Detective X: the Day 2 division (Forensics Lab).

SKILLS reuse lessons from lessons.py (this package) by id. Course-wide settings (ranks, XP per
tier, X fragments) live in days/day1/game.py; this file only adds the division's own content.
Check with:  python engine/build_game.py --day day2 --no-write
"""

DIVISION = "Day 2 · Forensics Lab"

# Skills in teaching order. A case may only use syntax from the skills it lists and earlier ones
# (Day 1 skills are always known).
SKILLS = [
    {"id": "lab-bench", "title": "Lab bench", "badge": "Lab coat",
     "tagline": "Set up the lab: what Day 2 adds, VS Code and the right Python interpreter.",
     "lessons": ["lab-briefing", "vscode-setup"]},
    {"id": "microscope", "title": "Microscope", "badge": "Microscope",
     "tagline": "The debugger: pause code, inspect variables, step through, conditional breakpoints.",
     "lessons": ["debugger-basics", "conditional-breakpoints"]},
    {"id": "logbook", "title": "Lab logbook", "badge": "Ledger",
     "tagline": "Logging: levels, handlers, structured JSON logs and keeping secrets out.",
     "lessons": ["logging-levels", "structured-logging"]},
    {"id": "test-bench", "title": "Test bench", "badge": "Test tubes",
     "tagline": "Tests that convict: asserts, raises, fixtures and parametrized tables.",
     "lessons": ["first-tests", "fixtures", "parametrize"]},
    {"id": "decoy-kit", "title": "Decoy kit", "badge": "Mannequin",
     "tagline": "Fakes and mocks, coverage, and imports that survive bad records.",
     "lessons": ["test-doubles", "coverage", "import-report", "validate-and-stream"]},
    {"id": "task-force", "title": "Task force", "badge": "Walkie-talkie",
     "tagline": "Concurrency: I/O-bound vs CPU-bound, threads and locks, executors.",
     "lessons": ["concurrency-concepts", "threads-locks", "executors"]},
    {"id": "switchboard", "title": "Switchboard", "badge": "Telephone exchange",
     "tagline": "Async: the event loop, gather, concurrency caps, timeouts and partial failures.",
     "lessons": ["event-loop", "async-patterns"]},
    {"id": "field-resilience", "title": "Field resilience", "badge": "Grappling hook",
     "tagline": "Retries with backoff, and swappable LLM providers you can test.",
     "lessons": ["retry-backoff", "provider-injection"]},
]

# Chapters continue the course numbering: Day 2 starts at chapter 4.
CHAPTERS = [
    # "finale" is set to the chapter's big case once it is written (phantom-fines, rigged-verdict, midnight-ledger).
    {"id": "lab-tech", "title": "Lab Technician", "number": 4,
     "tagline": "Debugging and logging: see what the code really does.",
     "skills": ["lab-bench", "microscope", "logbook"], "finale": "phantom-fines"},
    {"id": "examiner", "title": "Forensic Examiner", "number": 5,
     "tagline": "Testing: fixtures, parametrize, fakes, coverage and safe imports.",
     "skills": ["test-bench", "decoy-kit"], "finale": "rigged-verdict"},
    {"id": "task-force-ch", "title": "Task Force", "number": 6,
     "tagline": "Concurrency and resilience: threads, processes, async, retries and providers.",
     "skills": ["task-force", "switchboard", "field-resilience"], "finale": "midnight-ledger"},
]

CASES = []

import importlib as _importlib

for _mod in ("cases_small", "cases_medium", "cases_taskforce", "cases_big", "cases_final"):
    _full = f"{__package__}.{_mod}"
    try:
        CASES.extend(_importlib.import_module(_full).CASES)
    except ModuleNotFoundError as _e:
        if _e.name != _full:
            raise

# Extra locks on top of skills: "cases" that must be closed first, and how many "mediums"
# (that only use this case's skills) must be closed. Use it for the big cases and the exam.
UNLOCKS = {
    # Day 2 opens after the Day 1 exam. Each finale needs the one before it and some of its own
    # chapter's medium cases ("among" lists which mediums count).
    "phantom-fines": {"cases": ["detective-exam"], "mediums": 1, "among": ["overdue-mixup", "json-trail"]},
    "rigged-verdict": {"cases": ["phantom-fines"], "mediums": 3,
                       "among": ["book-inquest", "fresh-evidence", "loan-limit", "smuggled-records", "fake-clock", "paper-trail"]},
    "midnight-ledger": {"cases": ["rigged-verdict"], "mediums": 3,
                        "among": ["cover-raid", "merged-manifests", "switchboard-jam", "retry-storm", "false-informant"]},
    "forensics-exam": {"cases": ["midnight-ledger"], "mediums": 0},
}
for _c in CASES:
    if _c["id"] in UNLOCKS:
        _c["requires"] = UNLOCKS[_c["id"]]

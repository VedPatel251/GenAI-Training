"""Day 2 lesson content for the Detective X Academy (Forensics Lab).

Format of one lesson (every field except `practice`, `mistakes`, `local` and `predict` is required):
  id          url-safe slug, unique across ALL days (prefix it if it could clash, e.g. "d2-...")
  part        index into PARTS
  title       short name
  slides      slide numbers in the Day 2 deck it maps to (text, e.g. "8-9")
  idea        1-3 short paragraphs of markdown; **bold** key terms, `code` inline, "- " bullet lists
  code        runnable demo, Python 3.11+, runs in the browser (Brython): no files, network or async
  walkthrough [[code line, plain-English explanation], ...] for every line that teaches something
  mistakes    common beginner mistakes, one sentence each
  local       optional "Run this on your machine" cards: [{title, note, code, output}]
              for real libraries the browser can't run (pytest, asyncio, LangChain, FastAPI ...)
  predict     optional "guess first" quiz: {q, options, answer (index), why}
  challenge   {task, starter, solution, tests, hints: [2 hints], needs_demo?: True}
  practice    more tasks in the same format, so the practice covers EVERYTHING the lesson teaches

Tests are assert statements run after the trainee's code. They can read `__output__` (printed text)
and `__source__` (the trainee's code). The failure message is shown to the trainee as-is.
Check with:  python engine/build.py day2
"""

DAY = {
    "number": 2,
    "title": "Forensics Lab",
    "tagline": "Debugging, logging, testing and concurrency: proving what really happened.",
}

PARTS = [
    "Lab Technician",       # chapter 4: VS Code, debugger, logging
    "Forensic Examiner",    # chapter 5: testing, fakes, coverage, imports
    "Task Force",           # chapter 6: concurrency, async, retries, providers
]

# Each part lives in its own module so the parts can be written and checked separately.
from .part_lab import LESSONS as _LAB
from .part_examiner import LESSONS as _EXAMINER
from .part_taskforce import LESSONS as _TASKFORCE

LESSONS = []
for _part, _lessons in enumerate((_LAB, _EXAMINER, _TASKFORCE)):
    for _l in _lessons:
        _l["part"] = _part
        LESSONS.append(_l)

"""Day 2 - Forensics Lab: Academy lessons and the Detective X division."""

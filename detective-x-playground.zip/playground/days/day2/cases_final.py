"""Detective X Day 2: the Forensics Lab exam and the BookVault production upgrade (Q20, with Q9 and Q17).

These cases have no code steps:
  - tier "exam": a `quiz` (multiple choice) with a `pass_mark`.
  - tier "capstone": `local` cards (run on your own machine) and a `checklist` the trainee ticks off.
Check with:  python engine/build_game.py --check cases_final --day day2
"""

_ALL_SKILLS = [
    "lab-bench", "microscope", "logbook", "test-bench",
    "decoy-kit", "task-force", "switchboard", "field-resilience",
]

_QUIZ = [
    {
        "q": "The debugger is paused on `fee = late_fee(loan)`. You want to go **inside** `late_fee`, and once there, see which function called it. Which key, then which panel?",
        "options": [
            "F10, then the Variables panel",
            "F11, then the Call Stack panel",
            "Shift+F11, then the Watch panel",
            "F5, then the Debug Console",
        ],
        "answer": 1,
        "why": "F11 (step into) goes inside the function the line calls; F10 would run the whole call without stopping. The Call Stack lists how you got here, newest call on top.",
    },
    {
        "q": "You want the Debug Console to show `Checking B042` for every loan in a loop, without the program ever pausing and without editing the code. What do you add?",
        "options": [
            "A `print()` call inside the loop",
            "A conditional breakpoint with the condition `loan.item_id == \"B042\"`",
            "A plain breakpoint, pressing F5 at every pause",
            "A logpoint with the message `Checking {loan.item_id}`",
        ],
        "answer": 3,
        "why": "A logpoint prints a message with `{values}` filled in and never pauses. A conditional breakpoint does pause (when its condition is true), and a `print()` changes the code.",
    },
    {
        "q": "The `bookvault` logger's level is INFO. It has a FileHandler with level DEBUG and a StreamHandler with level WARNING. Where does `logger.debug(\"cache_miss\")` end up?",
        "options": [
            "Nowhere: the logger's own INFO level drops it before any handler sees it",
            "Only in the file, because the FileHandler accepts DEBUG",
            "Only on the screen",
            "In both the file and on the screen",
        ],
        "answer": 0,
        "why": "A message must pass the logger's level first, then each handler's level. DEBUG (10) is below the logger's INFO (20), so no handler ever receives it.",
    },
    {
        "q": "Which log call follows the structured-logging checklist?",
        "options": [
            "`logger.info(f\"Borrowed {title} for {member_id}!\")`",
            "`logger.info(\"book_borrowed\", extra={\"isbn\": isbn, \"api_key\": api_key})`",
            "`logger.info(\"book_borrowed\", extra={\"isbn\": isbn, \"member_id\": member_id, \"request_id\": rid})`",
            "`print(json.dumps({\"event\": \"book_borrowed\", \"isbn\": isbn}))`",
        ],
        "answer": 2,
        "why": "A stable event name plus consistent fields (`isbn`, `member_id`, `request_id`) can be searched. A worded message can't, secrets such as API keys never go in a log, and `print` has no level or handler.",
    },
    {
        "q": "`tests/conftest.py` defines a `stocked_library` fixture with the default scope. `test_borrow(stocked_library, item_id)` in `tests/test_library.py` is parametrized with 3 item ids and has no imports from conftest. How many times does the fixture run?",
        "options": [
            "Once, shared by the three test cases",
            "Three times: each parametrized case is its own test and gets a fresh library",
            "Never: the test file must import the fixture from conftest first",
            "Six times: once per case and once more per test",
        ],
        "answer": 1,
        "why": "pytest loads `conftest.py` by itself, and parametrize turns one function into 3 tests. With the default `function` scope every test gets a fresh fixture, so one case's borrowing can't leak into the next.",
    },
    {
        "q": "`bookvault/covers.py` starts with `from requests import get` and calls `get(url)`. Which replacement stops the real network call in a test?",
        "options": [
            "`patch(\"requests.get\")`",
            "Either one: both names point to the same function",
            "Neither: only `MagicMock` can replace a network call",
            "`patch(\"bookvault.covers.get\")`",
        ],
        "answer": 3,
        "why": "`from requests import get` copies the name into `bookvault.covers`, so patch the name where it is used. pytest's `monkeypatch.setattr(covers, \"get\", fake)` does the same by name and is undone after the test.",
    },
    {
        "q": "The coverage report says 100% for `fees.py`. What does that prove?",
        "options": [
            "`fees.py` has no bugs",
            "Every test of `fees.py` contains an `assert`",
            "Every line of `fees.py` ran at least once while the tests ran, nothing more",
            "Every possible input to `fees.py` was tested",
        ],
        "answer": 2,
        "why": "Coverage counts which lines ran, not whether their results were checked: a test with no assert can reach 100%. That's why the Missing column is useful and 100% is vanity.",
    },
    {
        "q": "Two threads each run `counter += 1` a thousand times on a shared counter, and the total sometimes ends below 2,000. What fixes it?",
        "options": [
            "One shared `threading.Lock`, with every `counter += 1` inside `with lock:`",
            "Start more threads so the work finishes before they can clash",
            "Give each thread its own `threading.Lock()`",
            "Write `counter = counter + 1` instead",
        ],
        "answer": 0,
        "why": "`counter += 1` is read, add, write: two threads can read the same old value and one update is lost. A lock only helps if both threads use the same one, so only one is inside the read-add-write at a time.",
    },
    {
        "q": "Job A downloads 15 cover images with a library that isn't async. Job B computes a difficulty score for 100 books (pure maths, no waiting). Which tools fit?",
        "options": [
            "A: processes, B: threads",
            "A: asyncio, B: threads",
            "Threads for both: the GIL lets them all compute in parallel",
            "A: ThreadPoolExecutor, B: ProcessPoolExecutor",
        ],
        "answer": 3,
        "why": "A is I/O-bound with few calls and a sync library, so threads overlap the waiting. B is CPU-bound, and with the GIL only one thread computes at a time, so it needs processes.",
    },
    {
        "q": "With a `ThreadPoolExecutor`, you want to handle each cover result the moment it's ready, fastest first. Which pattern?",
        "options": [
            "`for result in pool.map(fetch_cover, isbns):`",
            "`submit` every job into a dict `{future: isbn}`, then `for future in as_completed(futures):`",
            "`pool.map`, then sort the results by ISBN",
            "Loop over the futures in input order, calling `future.result(timeout=5)` on each",
        ],
        "answer": 1,
        "why": "`as_completed` hands back futures in finishing order; `pool.map` always keeps input order. The dict tells you which ISBN each finished future belongs to.",
    },
    {
        "q": "Which `ProcessPoolExecutor` script works on Windows, macOS and Linux with Python 3.14?",
        "options": [
            "`score` defined at the top of the file, and the pool used only under `if __name__ == \"__main__\":`",
            "`pool.map(lambda b: b[\"pages\"] * 100, books)` under `if __name__ == \"__main__\":`",
            "`score` defined at the top of the file, and the pool at the top level with no guard (the guard is only for Windows)",
            "`score` defined inside `main()`, and `main()` called under `if __name__ == \"__main__\":`",
        ],
        "answer": 0,
        "why": "Jobs are sent to workers by pickling, which needs top-level functions (no lambdas or nested functions). Each worker re-imports the file, so without the guard Windows, macOS and Linux from Python 3.14 stop with a `RuntimeError`.",
    },
    {
        "q": "20 cover calls each take 2 seconds. Each one runs inside `async with sem:`, where `sem = asyncio.Semaphore(5)`, and all 20 are started with `asyncio.gather`. About how long does the batch take?",
        "options": [
            "About 40 seconds: `gather` runs them one after another",
            "About 2 seconds: `gather` starts all 20 and the semaphore only counts them",
            "About 4 seconds: the semaphore lets 5 requests start per second",
            "About 8 seconds: at most 5 calls are in progress at once, so they run in 4 waves of 2 seconds",
        ],
        "answer": 3,
        "why": "`gather` runs the calls concurrently (awaiting them one by one would take 40 s), and `Semaphore(5)` caps how many are in progress at the same moment. It limits concurrency, not requests per second.",
    },
    {
        "q": "A cover fetch retries transient errors with backoff 0.1 s doubling, capped at 2 s, up to 4 attempts. Attempt 1 passes its `asyncio.timeout(2)` deadline, attempt 2 gets HTTP 503, attempt 3 gets HTTP 404. What happens?",
        "options": [
            "It stops at once: a timeout is a permanent error",
            "It waits 0.1 s, then 0.2 s, then raises the 404 without retrying: 404 is permanent",
            "It retries all three, waiting 0.1, 0.2 and 0.4 s, then returns the last answer",
            "It waits 0.1 s twice, because the delay only doubles after a 503",
        ],
        "answer": 1,
        "why": "Timeouts and 429/500/502/503/504 are transient, so they are retried with delays 0.1, 0.2, 0.4 (never above the cap). 400/401/403/404 won't change on a retry, so they are raised at once.",
    },
    {
        "q": "`BookClassifier.classify` asks an LLM for a category. How should its tests avoid slow, paid model calls?",
        "options": [
            "Add `if testing: return {...}` inside `classify`",
            "Call the real model once and keep its reply in a global variable",
            "Pass a `FakeLLMProvider` into `BookClassifier(provider)`: the class only relies on the `LLMProvider` interface",
            "Turn off the network while the tests run",
        ],
        "answer": 2,
        "why": "With dependency injection the classifier receives its provider instead of creating one, so tests hand it a fake with known replies, including malformed ones. The real code stays free of test-only branches.",
    },
]

CASES = [
    {
        "id": "forensics-exam",
        "tier": "exam",
        "title": "The Forensics Lab Exam",
        "teaser": "Fourteen questions stand between you and your Forensics Lab clearance.",
        "skills": _ALL_SKILLS,
        "story": "The Lab Director sets one last test before you get your clearance: **fourteen questions** across the whole Forensics Lab. They cover the debugger and logs from the Lab Technician chapter, tests, fakes and coverage from the Forensic Examiner chapter, and threads, processes, async and retries from the Task Force.\n\nNo code this time: pick one answer per question. You need **11 right** to pass. Every answer comes with a short explanation, so a miss still teaches you something. You can take the exam again.",
        "suspects": [{"name": "you", "note": "Ready for your Lab clearance?"}],
        "quiz": _QUIZ,
        "pass_mark": 11,
        "closing": "Exam passed. The Lab Director clips the clearance badge to your coat: *\"Debugger, logs, tests, task force. You can prove what happened now, not just guess. One job left: BookVault.\"*",
    },
    {
        "id": "forensics-upgrade",
        "tier": "capstone",
        "title": "The BookVault Upgrade",
        "teaser": "Go back undercover at BookVault and make its system production-proof. X is watching the logs.",
        "skills": _ALL_SKILLS,
        "story": "Your cover at BookVault still holds, and the borrower ID **X** keeps turning up in its logs. The Chief wants the system hardened before X tries anything: every function tested, every failure logged, every slow import running concurrently, so that whatever X touches leaves a trace you can prove.\n\nThis is a field operation on your own computer: you upgrade the Day 1 BookVault package into production-ready code using every Forensics Lab skill. It is the official **assignment Q20**, and it also covers **Q9** (CLI tests with `capsys` and `tmp_path`) and **Q17** (async tests with `httpx.MockTransport`), which only run on your machine.\n\n**What to build** (details in the cards and the checklist below)\n- Project setup: VS Code settings and launch configs, `pyproject.toml` with pytest and coverage settings, `python -m pytest` working from the project folder.\n- Stable domain: the Day 1 models and exceptions, the max-active-loans rule, plus **renew** and **member history**, two new features you design yourself.\n- 50+ tests: fixtures in `conftest.py`, parametrized tables, fakes for environment, time and network, coverage of at least 85%.\n- Debuggability: useful `__repr__`s, helpful exception messages, JSON logs written to a file, and `DEBUG_NOTES.md` about the overdue bug.\n- Import pipeline, concurrency and GenAI readiness: the JSONL loader (strict and non-strict), a ThreadPool import, the async `CoverFetcher` with retry, and `FakeLLMProvider`.\n\nThe cards use the **flat layout** from the lessons (a `bookvault/` package folder next to `tests/`, with `pythonpath = [\".\"]`); the assignment sheet draws a `src/` layout, and either is fine. The cards assume the names from the lessons (`Library(name, max_active_loans=3)`, `add_item`, `add_member`, `borrow(item_id, member_id, today=None)`, `overdue_loans(today=...)`, the `import_catalog` loader). If yours differ, change the names, not the idea. Tick each item below only when it really works, then file your report.",
        "suspects": [{"name": "X", "note": "Somewhere in BookVault's logs."}],
        "local": [
            {
                "title": "Project layout",
                "note": "The Day 1 package, grown for Day 2. `.vscode/` is committed so every developer gets the same interpreter and debug configs. `logs/` is created when the app runs (add it to `.gitignore`). The two `python -c` lines check that VS Code's terminal uses the project's interpreter and finds the package (your paths will differ; on macOS/Linux the interpreter is `.venv/bin/python`).",
                "code": r'''bookvault-project/
├── pyproject.toml
├── README.md
├── OUTPUT.md
├── DEBUG_NOTES.md
├── COVERAGE_AFTER.md
├── .vscode/
│   ├── settings.json
│   └── launch.json
├── bookvault/
│   ├── __init__.py
│   ├── cli.py
│   ├── covers.py          # async CoverFetcher (Q16-Q18)
│   ├── exceptions.py
│   ├── items.py
│   ├── library.py         # borrow, return, renew, overdue, history
│   ├── loader.py          # JSONL import, strict and non-strict
│   ├── logging_setup.py   # JSON logs to a file
│   ├── members.py
│   ├── providers.py       # LLMProvider, FakeLLMProvider, BookClassifier
│   ├── retry.py
│   └── services.py        # load_library, ThreadPool multi-file import
├── data/
│   ├── books.jsonl
│   └── bad_books.jsonl
└── tests/
    ├── conftest.py
    ├── test_borrowing.py
    ├── test_cli.py
    ├── test_covers.py
    ├── test_items.py
    ├── test_library.py
    ├── test_loader.py
    └── test_providers.py

$ python -c "import sys; print(sys.executable)"
$ python -c "import bookvault; print(bookvault.__file__)"''',
                "output": r'''C:\Users\you\bookvault-project\.venv\Scripts\python.exe
C:\Users\you\bookvault-project\bookvault\__init__.py''',
            },
            {
                "title": "pyproject.toml: pytest and coverage settings",
                "note": "Install the tools once in the venv: `pip install -e \".[dev]\"` (or `uv pip install -e \".[dev]\"`). With these settings a plain `python -m pytest` finds the tests, imports `bookvault` from the project folder (`pythonpath`), measures coverage every time and **fails the run** when the total is below 85% (`fail_under`). `branch = true` also checks both sides of every `if`. The output is from `--collect-only -q`, which lists the tests without running them (end of the list shown).",
                "code": r'''[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "bookvault"
version = "0.2.0"
requires-python = ">=3.11"
dependencies = ["httpx>=0.27"]

[project.optional-dependencies]
dev = ["pytest>=8", "pytest-cov>=5", "pytest-asyncio>=0.24"]

[tool.setuptools]
packages = ["bookvault"]

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["."]
addopts = "--cov=bookvault --cov-report=term-missing"

[tool.coverage.run]
source = ["bookvault"]
branch = true

[tool.coverage.report]
fail_under = 85
show_missing = true
exclude_also = [
    "if __name__ == .__main__.:",
    "raise NotImplementedError",
]

# check it:  python -m pytest --collect-only -q''',
                "output": r'''...
tests/test_providers.py::test_classify_uses_fake_provider
tests/test_providers.py::test_malformed_reply_raises_provider_error
tests/test_providers.py::test_slow_provider_times_out

63 tests collected in 0.24s''',
            },
            {
                "title": "bookvault/logging_setup.py: JSON logs to a file",
                "note": "Called once at startup (in `cli.py`'s `__main__` block, never in tests). The logger lets everything through; the `FileHandler` keeps every line as JSON, the screen shows only warnings and errors. Every `extra=` field becomes a JSON key, and `logger.exception` adds the traceback. Modules just do `logger = logging.getLogger(__name__)`: names like `bookvault.library` pass their records up to the `bookvault` logger. Output from a real run (traceback path shortened).",
                "code": r'''# bookvault/logging_setup.py
import json
import logging
from pathlib import Path

# attributes every LogRecord has; anything else came from extra=
_STANDARD = set(vars(logging.LogRecord("x", 0, "", 0, "", None, None))) | {"message", "asctime"}


class JsonFormatter(logging.Formatter):
    def format(self, record):
        entry = {
            "time": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "level": record.levelname,
            "logger": record.name,
            "event": record.getMessage(),
        }
        for key, value in vars(record).items():
            if key not in _STANDARD:
                entry[key] = value              # the extra= fields
        if record.exc_info:
            entry["traceback"] = self.formatException(record.exc_info)
        return json.dumps(entry)


def setup_logging(log_file="logs/bookvault.log", console_level=logging.WARNING):
    Path(log_file).parent.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("bookvault")
    logger.handlers.clear()                     # calling it twice never doubles lines
    logger.setLevel(logging.DEBUG)

    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setFormatter(JsonFormatter())  # the file keeps everything, as JSON

    console = logging.StreamHandler()
    console.setLevel(console_level)             # the screen shows warnings and up
    console.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))

    logger.addHandler(file_handler)
    logger.addHandler(console)
    return logger


# try_logging.py (in the project folder)
import logging
from bookvault.logging_setup import setup_logging

setup_logging()
log = logging.getLogger("bookvault.library")
log.debug("cache_miss", extra={"item_id": "B001"})
log.info("book_borrowed", extra={"item_id": "B001", "member_id": "M001", "request_id": "r-17"})
log.warning("import_line_rejected", extra={"line_no": 2})
try:
    {}["url"]
except KeyError:
    log.exception("cover_fetch_failed", extra={"isbn": "9780132350884"})''',
                "output": r'''# in the terminal (warnings and up only)
WARNING: import_line_rejected
ERROR: cover_fetch_failed
Traceback (most recent call last):
  File "try_logging.py", line 11, in <module>
    {}["url"]
    ~~^^^^^^^
KeyError: 'url'

# in logs/bookvault.log (every level, one JSON object per line)
{"time": "2026-11-27T10:23:42", "level": "DEBUG", "logger": "bookvault.library", "event": "cache_miss", "item_id": "B001"}
{"time": "2026-11-27T10:23:42", "level": "INFO", "logger": "bookvault.library", "event": "book_borrowed", "item_id": "B001", "member_id": "M001", "request_id": "r-17"}
{"time": "2026-11-27T10:23:42", "level": "WARNING", "logger": "bookvault.library", "event": "import_line_rejected", "line_no": 2}
{"time": "2026-11-27T10:23:42", "level": "ERROR", "logger": "bookvault.library", "event": "cover_fetch_failed", "isbn": "9780132350884", "traceback": "Traceback (most recent call last):\n  File \"try_logging.py\", line 11, in <module>\n    {}[\"url\"]\n    ~~^^^^^^^\nKeyError: 'url'"}''',
            },
            {
                "title": "tests/conftest.py: shared fixtures",
                "note": "Every test file in `tests/` can use these fixtures by naming them, with no import. `no_network` has `autouse=True`, so it runs for **every** test without being named: it makes httpx's real transports refuse to connect, which proves no test reaches the network (`MockTransport` is a different class, so mocked tests still work). Fixed dates and fake sleeps keep tests fast and repeatable. `tests/test_borrowing.py` shows the library fixtures at work.",
                "code": r'''# tests/conftest.py
import json
from datetime import date

import httpx
import pytest

from bookvault.items import Book
from bookvault.library import Library
from bookvault.members import Member
from bookvault.providers import FakeLLMProvider

CLEAN_CODE = {"type": "book", "title": "Clean Code", "item_id": "B001",
              "author": "Robert Martin", "pages": 464}
DUNE = {"type": "book", "title": "Dune", "item_id": "B002",
        "author": "Frank Herbert", "pages": 412}


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def refuse(*args, **kwargs):
        raise RuntimeError("a test tried to use the real network")
    monkeypatch.setattr(httpx.HTTPTransport, "handle_request", refuse)
    monkeypatch.setattr(httpx.AsyncHTTPTransport, "handle_async_request", refuse)


@pytest.fixture
def empty_library():
    return Library("Test Vault", max_active_loans=3)


@pytest.fixture
def clean_code():
    return Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)


@pytest.fixture
def member():
    return Member(member_id="M001", name="Asha", email="asha@example.com")


@pytest.fixture
def stocked_library(empty_library, clean_code, member):
    empty_library.add_item(clean_code)
    empty_library.add_member(member)
    return empty_library


@pytest.fixture
def today():
    return date(2026, 5, 18)          # tests never read the real clock


@pytest.fixture
def books_file(tmp_path):
    path = tmp_path / "books.jsonl"
    path.write_text(json.dumps(CLEAN_CODE) + "\n" + json.dumps(DUNE) + "\n", encoding="utf-8")
    return path


@pytest.fixture
def messy_file(tmp_path):
    path = tmp_path / "bad_books.jsonl"
    path.write_text(json.dumps(CLEAN_CODE) + "\nBAD JSON HERE\n", encoding="utf-8")
    return path


@pytest.fixture
def fake_llm():
    return FakeLLMProvider()


class FakeSleep:
    """Awaited like asyncio.sleep, but only records the delay."""
    def __init__(self):
        self.calls = []

    async def __call__(self, seconds):
        self.calls.append(seconds)


@pytest.fixture
def fake_sleep():
    return FakeSleep()


# tests/test_borrowing.py
import pytest

from bookvault.exceptions import ItemUnavailableError, LoanLimitExceededError, UnknownMemberError
from bookvault.items import Book


def test_new_library_is_empty(empty_library):
    assert len(empty_library) == 0


def test_borrow_marks_item_out(stocked_library, today):
    stocked_library.borrow("B001", "M001", today=today)
    assert stocked_library.items["B001"].available is False


def test_each_test_gets_a_fresh_library(stocked_library):
    assert stocked_library.items["B001"].available is True


def test_cannot_borrow_twice(stocked_library, today):
    stocked_library.borrow("B001", "M001", today=today)
    with pytest.raises(ItemUnavailableError, match="B001"):
        stocked_library.borrow("B001", "M001", today=today)


def test_loan_limit(stocked_library, today):
    for n in range(2, 5):
        stocked_library.add_item(Book(title=f"Book {n}", item_id=f"B00{n}", author="A", pages=100))
    for item_id in ["B001", "B002", "B003"]:
        stocked_library.borrow(item_id, "M001", today=today)
    with pytest.raises(LoanLimitExceededError):
        stocked_library.borrow("B004", "M001", today=today)


@pytest.mark.parametrize("member_id", ["M999", "", "m001"])
def test_unknown_member(stocked_library, today, member_id):
    with pytest.raises(UnknownMemberError):
        stocked_library.borrow("B001", member_id, today=today)''',
                "output": r'''$ python -m pytest -v tests/test_borrowing.py --no-cov
collected 8 items

tests/test_borrowing.py::test_new_library_is_empty PASSED                [ 12%]
tests/test_borrowing.py::test_borrow_marks_item_out PASSED               [ 25%]
tests/test_borrowing.py::test_each_test_gets_a_fresh_library PASSED      [ 37%]
tests/test_borrowing.py::test_cannot_borrow_twice PASSED                 [ 50%]
tests/test_borrowing.py::test_loan_limit PASSED                          [ 62%]
tests/test_borrowing.py::test_unknown_member[M999] PASSED                [ 75%]
tests/test_borrowing.py::test_unknown_member[] PASSED                    [ 87%]
tests/test_borrowing.py::test_unknown_member[m001] PASSED                [100%]

============================== 8 passed in 0.04s ===============================''',
            },
            {
                "title": "CLI tests with capsys and tmp_path (Q9)",
                "note": "`main(argv=None)` takes the argument list, so tests call it directly instead of starting a shell: `main([\"--data\", path, \"list\"])`. It **returns** 0 or 1 instead of exiting, so a test can check the code; only `argparse` itself exits (code 2) on a bad command line. `load_library(path)` in `services.py` runs your loader and returns `(library, report)`, with the demo member M001 registered. The fixtures `books_file` and `messy_file` come from `conftest.py` and write into `tmp_path`. `--no-cov` skips the coverage table for a single file.",
                "code": r'''# bookvault/cli.py
import argparse
import logging
import sys
from datetime import date

from bookvault.exceptions import BookVaultError
from bookvault.logging_setup import setup_logging
from bookvault.services import load_library

logger = logging.getLogger(__name__)


def build_parser():
    parser = argparse.ArgumentParser(prog="bookvault")
    parser.add_argument("--data", default="data/books.jsonl")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("list")
    commands.add_parser("search").add_argument("text")
    borrow = commands.add_parser("borrow")
    borrow.add_argument("item_id")
    borrow.add_argument("member_id")
    commands.add_parser("overdue").add_argument("--today", type=date.fromisoformat)
    commands.add_parser("import-report")
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)     # argv=None reads the real command line
    library, report = load_library(args.data)
    try:
        match args.command:
            case "list":
                for item in library:
                    print(item)
            case "search":
                for item in library.search(args.text):
                    print(item)
            case "borrow":
                loan = library.borrow(args.item_id, args.member_id)
                print(f"Borrowed {loan.item_id} for {loan.member_id}, due {loan.due_date}")
            case "overdue":
                today = args.today or date.today()
                late = library.overdue_loans(today=today)
                for loan in late:
                    print(f"{loan.item_id}  {loan.member_id}  due {loan.due_date}")
                if not late:
                    print(f"No overdue loans on {today}")
            case "import-report":
                print(f"loaded {report.loaded_count}, errors {report.error_count}")
                for error in report.errors:
                    print(f"  line {error['line']}: {error['error']}")
    except BookVaultError as e:
        logger.warning("cli_error", extra={"command": args.command})
        print(f"error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    setup_logging()
    sys.exit(main())


# tests/test_cli.py
import pytest

from bookvault.cli import main


def run(capsys, *args):
    code = main(list(args))
    captured = capsys.readouterr()
    return code, captured.out, captured.err


def test_list_prints_every_title(books_file, capsys):
    code, out, _ = run(capsys, "--data", str(books_file), "list")
    assert code == 0
    assert "Clean Code" in out and "Dune" in out


@pytest.mark.parametrize("text", ["clean", "CLEAN", "Clean"])
def test_search_ignores_case(books_file, capsys, text):
    code, out, _ = run(capsys, "--data", str(books_file), "search", text)
    assert "Clean Code" in out
    assert "Dune" not in out


def test_borrow_prints_confirmation(books_file, capsys):
    code, out, _ = run(capsys, "--data", str(books_file), "borrow", "B001", "M001")
    assert code == 0
    assert "Borrowed B001 for M001" in out


def test_unknown_item_is_a_clear_error(books_file, capsys):
    code, out, err = run(capsys, "--data", str(books_file), "borrow", "B999", "M001")
    assert code == 1
    assert "B999" in err
    assert "Traceback" not in err


def test_overdue_uses_the_given_day(books_file, capsys):
    code, out, _ = run(capsys, "--data", str(books_file), "overdue", "--today", "2026-05-18")
    assert out.strip() == "No overdue loans on 2026-05-18"


def test_import_report_names_bad_lines(messy_file, capsys):
    code, out, _ = run(capsys, "--data", str(messy_file), "import-report")
    assert "loaded 1, errors 1" in out
    assert "line 2:" in out


def test_missing_command_shows_usage(books_file, capsys):
    with pytest.raises(SystemExit) as info:
        main(["--data", str(books_file)])
    assert info.value.code == 2
    assert "usage:" in capsys.readouterr().err''',
                "output": r'''$ python -m pytest -v tests/test_cli.py --no-cov
collected 9 items

tests/test_cli.py::test_list_prints_every_title PASSED                   [ 11%]
tests/test_cli.py::test_search_ignores_case[clean] PASSED                [ 22%]
tests/test_cli.py::test_search_ignores_case[CLEAN] PASSED                [ 33%]
tests/test_cli.py::test_search_ignores_case[Clean] PASSED                [ 44%]
tests/test_cli.py::test_borrow_prints_confirmation PASSED                [ 55%]
tests/test_cli.py::test_unknown_item_is_a_clear_error PASSED             [ 66%]
tests/test_cli.py::test_overdue_uses_the_given_day PASSED                [ 77%]
tests/test_cli.py::test_import_report_names_bad_lines PASSED             [ 88%]
tests/test_cli.py::test_missing_command_shows_usage PASSED               [100%]

============================== 9 passed in 0.06s ===============================''',
            },
            {
                "title": "Async CoverFetcher with retry, tested with MockTransport (Q16-Q18)",
                "note": "`retry.py` is the one from the retry lesson's card (Q18): it retries timeouts and HTTP 429/500/502/503/504 with backoff 0.1, 0.2, 0.4 s (capped at 2 s) and raises anything else at once. The fetcher gets its transport and its `sleep` injected, so tests answer every request in memory and never really wait. Each test builds a fresh fake server, which records every ISBN it was asked for, so the tests can count retries. All seven Q17 cases are here: success, 404, 503, missing `url`, invalid JSON, a slow server, and a mixed batch, plus proof that the real network is blocked.",
                "code": r'''# bookvault/covers.py
import asyncio
import logging
from dataclasses import dataclass

import httpx

from bookvault.retry import retry

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class CoverResult:
    isbn: str
    url: str | None
    error: str | None = None


class CoverFetcher:
    def __init__(self, *, base_url: str, concurrency: int = 5, timeout: float = 2.0,
                 attempts: int = 3, transport=None, sleep=asyncio.sleep):
        self.base_url = base_url
        self._sem = asyncio.Semaphore(concurrency)   # at most 5 requests in progress
        self._timeout = timeout
        self._attempts = attempts
        self._transport = transport                  # tests pass an httpx.MockTransport
        self._sleep = sleep                          # tests pass a fake that doesn't wait

    async def _get_url(self, client: httpx.AsyncClient, isbn: str) -> str:
        async with asyncio.timeout(self._timeout):
            response = await client.get(f"/covers/{isbn}")
        response.raise_for_status()
        return response.json()["url"]

    async def fetch_one(self, client: httpx.AsyncClient, isbn: str) -> CoverResult:
        async with self._sem:
            try:
                url = await retry(lambda: self._get_url(client, isbn),
                                  attempts=self._attempts, sleep=self._sleep)
                return CoverResult(isbn, url)
            except (httpx.HTTPError, TimeoutError, KeyError, ValueError) as e:
                logger.warning("cover_fetch_failed", extra={"isbn": isbn, "error_type": type(e).__name__})
                return CoverResult(isbn, None, type(e).__name__)

    async def fetch_all(self, isbns: list[str]) -> dict[str, CoverResult]:
        async with httpx.AsyncClient(base_url=self.base_url, timeout=self._timeout,
                                     transport=self._transport) as client:
            results = await asyncio.gather(*(self.fetch_one(client, i) for i in isbns))
        return {r.isbn: r for r in results}


# tests/test_covers.py
import asyncio

import httpx
import pytest

from bookvault.covers import CoverFetcher


def make_server():
    """A fake cover API. Returns the transport and the list of ISBNs it was asked for."""
    seen = []

    def handler(request):
        isbn = request.url.path.rsplit("/", 1)[-1]
        seen.append(isbn)
        if isbn == "B404":
            return httpx.Response(404)
        if isbn == "B503":
            return httpx.Response(503)
        if isbn == "FLAKY" and seen.count("FLAKY") < 3:
            return httpx.Response(503)               # fails twice, then works
        if isbn == "NOURL":
            return httpx.Response(200, json={"size": 3})
        if isbn == "BADJSON":
            return httpx.Response(200, text="not json")
        return httpx.Response(200, json={"url": f"https://img.example/{isbn}.jpg"})

    return httpx.MockTransport(handler), seen


def fetcher(transport, sleep, **options):
    return CoverFetcher(base_url="https://api.test", transport=transport, sleep=sleep, **options)


@pytest.mark.asyncio
async def test_success(fake_sleep):
    transport, _ = make_server()
    results = await fetcher(transport, fake_sleep).fetch_all(["B001"])
    assert results["B001"].url == "https://img.example/B001.jpg"
    assert results["B001"].error is None


@pytest.mark.asyncio
async def test_404_is_not_retried(fake_sleep):
    transport, seen = make_server()
    results = await fetcher(transport, fake_sleep).fetch_all(["B404"])
    assert results["B404"].error == "HTTPStatusError"
    assert seen == ["B404"]
    assert fake_sleep.calls == []


@pytest.mark.asyncio
async def test_503_is_retried_with_backoff_then_gives_up(fake_sleep):
    transport, seen = make_server()
    results = await fetcher(transport, fake_sleep, attempts=3).fetch_all(["B503"])
    assert results["B503"].error == "HTTPStatusError"
    assert seen == ["B503"] * 3
    assert fake_sleep.calls == [0.1, 0.2]


@pytest.mark.asyncio
async def test_recovers_after_two_transient_failures(fake_sleep):
    transport, seen = make_server()
    results = await fetcher(transport, fake_sleep, attempts=3).fetch_all(["FLAKY"])
    assert results["FLAKY"].url == "https://img.example/FLAKY.jpg"
    assert len(seen) == 3


@pytest.mark.asyncio
@pytest.mark.parametrize("isbn, error", [("NOURL", "KeyError"), ("BADJSON", "JSONDecodeError")])
async def test_bad_body_is_a_named_failure(fake_sleep, isbn, error):
    transport, seen = make_server()
    results = await fetcher(transport, fake_sleep).fetch_all([isbn])
    assert results[isbn].url is None
    assert results[isbn].error == error
    assert len(seen) == 1                            # a bad body is permanent: no retry


@pytest.mark.asyncio
async def test_slow_server_times_out(fake_sleep):
    async def slow(request):
        await asyncio.sleep(1)
        return httpx.Response(200, json={"url": "late"})
    results = await fetcher(httpx.MockTransport(slow), fake_sleep, timeout=0.05).fetch_all(["B001"])
    assert results["B001"].error == "TimeoutError"
    assert fake_sleep.calls == [0.1, 0.2]            # a timeout is transient: retried


@pytest.mark.asyncio
async def test_mixed_batch_gives_every_isbn_a_result(fake_sleep):
    transport, _ = make_server()
    isbns = ["B001", "B002", "B404", "B503", "NOURL", "BADJSON"]
    results = await fetcher(transport, fake_sleep).fetch_all(isbns)
    assert set(results) == set(isbns)
    assert sorted(i for i, r in results.items() if r.error is None) == ["B001", "B002"]


@pytest.mark.asyncio
async def test_real_network_is_blocked():
    async with httpx.AsyncClient() as client:
        with pytest.raises(RuntimeError, match="real network"):
            await client.get("https://example.com")''',
                "output": r'''$ python -m pytest -v tests/test_covers.py --no-cov
collected 9 items

tests/test_covers.py::test_success PASSED                                [ 11%]
tests/test_covers.py::test_404_is_not_retried PASSED                     [ 22%]
tests/test_covers.py::test_503_is_retried_with_backoff_then_gives_up PASSED [ 33%]
tests/test_covers.py::test_recovers_after_two_transient_failures PASSED  [ 44%]
tests/test_covers.py::test_bad_body_is_a_named_failure[NOURL-KeyError] PASSED [ 55%]
tests/test_covers.py::test_bad_body_is_a_named_failure[BADJSON-JSONDecodeError] PASSED [ 66%]
tests/test_covers.py::test_slow_server_times_out PASSED                  [ 77%]
tests/test_covers.py::test_mixed_batch_gives_every_isbn_a_result PASSED  [ 88%]
tests/test_covers.py::test_real_network_is_blocked PASSED                [100%]

============================== 9 passed in 0.21s ===============================''',
            },
            {
                "title": "Run everything",
                "note": "From the project folder with the venv active. The whole suite runs with coverage in one command and passes only if every test passes **and** the total is at least 85%. Copy the final table into `COVERAGE_AFTER.md` and the CLI output into `OUTPUT.md`. The Missing column is your to-do list (here `logging_setup.py`, whose setup only runs from the command line). Your file names, counts and item text (from your own `__str__`) will differ. On macOS/Linux use `cat` instead of `type`.",
                "code": r'''python -m pytest
python -m bookvault.cli --data data/books.jsonl list
python -m bookvault.cli --data data/books.jsonl search clean
python -m bookvault.cli --data data/bad_books.jsonl import-report
python -m bookvault.cli --data data/books.jsonl borrow B999 M001
type logs\bookvault.log''',
                "output": r'''$ python -m pytest
collected 63 items

tests/test_borrowing.py ........                                         [ 12%]
tests/test_cli.py .........                                              [ 26%]
tests/test_covers.py .........                                           [ 41%]
tests/test_items.py ..........                                           [ 57%]
tests/test_library.py .........                                          [ 71%]
tests/test_loader.py ...........                                         [ 88%]
tests/test_providers.py .......                                          [100%]

================================ tests coverage ================================
_______________ coverage: platform win32, python 3.12.4-final-0 ________________

Name                         Stmts   Miss Branch BrPart  Cover   Missing
------------------------------------------------------------------------
bookvault/__init__.py            1      0      0      0   100%
bookvault/cli.py                46      2     12      1    95%   48->51, 62-63
bookvault/covers.py             32      0      4      0   100%
bookvault/exceptions.py         18      0      0      0   100%
bookvault/items.py              52      3      8      1    93%   41, 77-78
bookvault/library.py            96      6     30      3    93%   88->92, 131-134, 160-161
bookvault/loader.py             47      2     16      2    94%   58->61, 73-74
bookvault/logging_setup.py      23     11      4      0    59%   28-41
bookvault/members.py            21      0      2      0   100%
bookvault/providers.py          34      2      8      1    93%   47->50, 66-67
bookvault/retry.py              14      0      6      0   100%
bookvault/services.py           22      1      6      1    93%   35
------------------------------------------------------------------------
TOTAL                          406     27     96      9    93%
Required test coverage of 85% reached. Total coverage: 92.83%
============================== 63 passed in 0.92s ==============================

$ python -m bookvault.cli --data data/books.jsonl list
B001  Clean Code by Robert Martin (464 pages)
B002  Dune by Frank Herbert (412 pages)
A001  Atomic Habits, read by James Clear (320 min)
MG001  National Geographic, issue 247

$ python -m bookvault.cli --data data/books.jsonl search clean
B001  Clean Code by Robert Martin (464 pages)

$ python -m bookvault.cli --data data/bad_books.jsonl import-report
WARNING: import_line_rejected
WARNING: import_line_rejected
loaded 2, errors 2
  line 2: Expecting value: line 1 column 1 (char 0)
  line 4: unknown type 'dvd'

$ python -m bookvault.cli --data data/books.jsonl borrow B999 M001
WARNING: cli_error
error: no item with id 'B999'

$ type logs\bookvault.log
{"time": "2026-11-27T11:02:15", "level": "INFO", "logger": "bookvault.loader", "event": "import_finished", "loaded": 4, "errors": 0}
{"time": "2026-11-27T11:02:19", "level": "INFO", "logger": "bookvault.loader", "event": "import_finished", "loaded": 4, "errors": 0}
{"time": "2026-11-27T11:02:24", "level": "WARNING", "logger": "bookvault.loader", "event": "import_line_rejected", "line_no": 2}
{"time": "2026-11-27T11:02:24", "level": "WARNING", "logger": "bookvault.loader", "event": "import_line_rejected", "line_no": 4}
{"time": "2026-11-27T11:02:24", "level": "INFO", "logger": "bookvault.loader", "event": "import_finished", "loaded": 2, "errors": 2}
{"time": "2026-11-27T11:02:30", "level": "INFO", "logger": "bookvault.loader", "event": "import_finished", "loaded": 4, "errors": 0}
{"time": "2026-11-27T11:02:30", "level": "WARNING", "logger": "bookvault.cli", "event": "cli_error", "command": "borrow"}''',
            },
        ],
        "checklist": [
            "The layout from the first card exists, `.vscode/settings.json` and `launch.json` are committed, and `python -m pytest` runs from the project folder with no extra flags",
            "`pyproject.toml` holds the pytest and coverage settings, with `pythonpath = [\".\"]` and `fail_under = 85`",
            "Day 1 still works: Book, AudioBook, Magazine, Member and Loan, a useful `__repr__` on each core object, and domain exceptions with helpful messages",
            "Borrow, return, overdue and the maximum-active-loans rule work and are tested",
            "**renew** and **member history** work and are tested. These are new features no lesson covers: you design them yourself (for example, decide whether an overdue loan may be renewed, and what history returns)",
            "At least 50 tests pass, with shared fixtures in `tests/conftest.py` and parametrized tests for ISBN cleaning, search and the loader",
            "Mocked or faked tests for the environment, the clock and external calls; no test makes a real network or model call (the `no_network` fixture proves it)",
            "Coverage of the business logic is at least 85%, and `COVERAGE_AFTER.md` holds the final table",
            "`DEBUG_NOTES.md` describes the overdue-loan bug and how the debugger (a conditional breakpoint) found it",
            "Structured JSON logging with stable event names, written to `logs/bookvault.log` by a `FileHandler`, with no secrets in it",
            "The JSONL streaming loader reports bad lines with their line numbers, keeps going in non-strict mode, and raises in strict mode",
            "A ThreadPoolExecutor multi-file import (or sync cover fetching)",
            "The async `CoverFetcher` uses a Semaphore, a timeout, partial failures and retry with backoff, tested with `httpx.MockTransport` and a fake sleep (CLI `fetch-covers --limit 5`)",
            "An `LLMProvider` ABC, a `FakeLLMProvider`, and a `BookClassifier` that receives its provider by dependency injection",
            "The CLI's list, search, borrow, overdue and import-report commands work, tested by calling `main([...])` with `capsys` and `tmp_path`",
            "`README.md` and `OUTPUT.md` explain how to run it and show real output, and no `# TODO` is left anywhere",
        ],
        "closing": "Report filed. BookVault now proves every claim it makes: 50-plus tests, a log line for every event, imports that keep going. And in the very first JSON log line after deployment you find it: a `book_borrowed` event with `member_id: \"X\"` and a `request_id` that leads somewhere new. X has moved on from the library. Day 3 picks up the trail.",
    },
]

"""Detective X Day 2: small cases (one skill each, 1-2 steps).

Case format (see .claude/skills/write-cases/SKILL.md for the full rules):
  id, tier ("small" | "medium" | "big"), title, teaser, skills, story, suspects,
  variants  2-3 evidence scripts; the trainee's code runs on each, answers must differ
  steps     [{question, starter, solution, tests, tips: [2 tips], reveal}]
  closing   text shown when the case is closed; optional "fragment" (an X clue, big cases)
Check with:  python engine/build_game.py --check cases_small --day day2

Code strings (variants, starters, solutions, tests) are raw (r'''...''') so backslashes and "\\n"
inside them reach Python exactly as typed.
"""

CASES = [
    # ------------------------------------------------------------ lab-bench (Q1)
    {
        "id": "wrong-interpreter",
        "tier": "small",
        "title": "The Wrong Interpreter",
        "teaser": "Two lab machines, two different answers. One of them isn't running the lab's Python.",
        "skills": ["lab-bench"],
        "story": """The Bureau's new **Forensics Lab** has barely opened and the results already disagree: the same test passes on one technician's machine and fails on another's. Somebody's VS Code is not running the project's own Python, and the chalk X on the bench says it isn't an accident.

Forensics collected two things from every workstation:
- `reports`: what `sys.executable` printed on each technician's machine (the path of the Python that really runs)
- `settings_files`: the text of each technician's `.vscode/settings.json`

*(This is the official assignment Q1: the VS Code project health check.)*""",
        "suspects": [
            {"name": "the technician on the global Python", "note": "Says \"Python is Python, what does it matter?\""},
            {"name": "the technician with the odd settings", "note": "Likes to customise everything."},
        ],
        "variants": [
            r'''reports = {
    "Asha": r"C:\lab\forensics\.venv\Scripts\python.exe",
    "Bruno": r"C:\Users\bruno\AppData\Local\Programs\Python\Python312\python.exe",
    "Chen": "/home/chen/forensics/.venv/bin/python",
    "Dana": "/home/dana/forensics/.venv-old/bin/python",
}
settings_files = {
    "Asha": '{"python.defaultInterpreterPath": ".venv\\\\Scripts\\\\python.exe", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": true, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}',
    "Bruno": '{"python.defaultInterpreterPath": ".venv\\\\Scripts\\\\python.exe", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": true, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}',
    "Chen": '{"python.defaultInterpreterPath": ".venv/bin/python", "python.analysis.typeCheckingMode": "strict", "editor.formatOnSave": true, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}',
    "Dana": '{"python.defaultInterpreterPath": "/usr/bin/python3", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": true, "python.testing.pytestEnabled": false, "python.testing.pytestArgs": ["tests"]}',
}
''',
            r'''reports = {
    "Eli": "/Users/eli/forensics/.venv/bin/python",
    "Farah": r"C:\Python311\python.exe",
    "Gus": r"D:\cases\forensics\.venv\Scripts\python.exe",
    "Hana": "/opt/homebrew/bin/python3",
}
settings_files = {
    "Eli": '{"python.defaultInterpreterPath": ".venv/bin/python", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": false, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}',
    "Farah": '{"python.defaultInterpreterPath": "C:/Python311/python.exe", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": true, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["."]}',
    "Gus": '{"python.defaultInterpreterPath": ".venv\\\\Scripts\\\\python.exe", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": true, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}',
    "Hana": '{"python.defaultInterpreterPath": ".venv/bin/python", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": true, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}',
}
''',
            r'''reports = {
    "Ivo": "/home/ivo/lab/.venv/bin/python",
    "Jun": "/home/jun/lab/venv/bin/python",
    "Kemi": r"C:\lab\.venv\Scripts\python.exe",
    "Lars": "/usr/local/bin/python3.12",
    "Mira": "/home/mira/.venv.bak/bin/python",
}
settings_files = {
    "Ivo": '{"python.defaultInterpreterPath": ".venv/bin/python", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": true, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}',
    "Jun": '{"python.defaultInterpreterPath": ".venv/bin/python", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": true, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}',
    "Kemi": '{"python.defaultInterpreterPath": ".venv\\\\Scripts\\\\python.exe", "editor.formatOnSave": true, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}',
    "Lars": '{"python.defaultInterpreterPath": ".venv/bin/python", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": true, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}',
    "Mira": '{"python.defaultInterpreterPath": "/home/mira/.venv.bak/bin/python", "python.analysis.typeCheckingMode": "off", "editor.formatOnSave": false, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}',
}
''',
        ],
        "steps": [
            {
                "notes": """The **interpreter** is the `python` program that runs your code. Each one has its own installed packages.

- A project's own interpreter lives in its `.venv` folder: `.venv\\Scripts\\python.exe` on Windows, `.venv/bin/python` on macOS and Linux.
- A path is **inside the venv** when one of its folder names is exactly `.venv`. A folder called `.venv-old`, `.venv.bak` or `venv` is a different folder.
- Windows paths use backslashes `\\`, macOS and Linux paths use forward slashes `/`.

Why a wrong interpreter causes confusing bugs: packages you `pip install` into `.venv` are invisible to another Python, so code fails with `ModuleNotFoundError`, or tests pass in the terminal and fail in the editor, and the code itself looks fine.""",
                "question": """**Goal:** find the technicians whose machines run a Python outside the project's `.venv`.

**You have:** `reports`, a dict from technician name to the path `sys.executable` printed on their machine, e.g. `{"Asha": r"C:\\lab\\.venv\\Scripts\\python.exe", "Dev": "/usr/bin/python3"}`.

**Write** two functions:
- `in_venv(path)`: returns `True` if one of the folder names in `path` is exactly `.venv`, otherwise `False`. The path may use `\\` or `/`.
- `find_wrong(reports)`: returns a **sorted** list of the names whose path is **not** inside a `.venv` folder.

**Then** store `wrong = find_wrong(reports)` and print it.

**Example:** `in_venv("/home/x/app/.venv/bin/python")` is `True`, `in_venv(r"C:\\app\\.venv\\Scripts\\python.exe")` is `True`, and `in_venv("/home/x/.venv-old/bin/python")` is `False`. `find_wrong({"Zed": "/usr/bin/python3", "Al": "/a/.venv/bin/python"})` is `["Zed"]`.""",
                "starter": r'''def in_venv(path):
    return ".venv" in path

def find_wrong(reports):
    return []

wrong = find_wrong(reports)
print(wrong)
''',
                "solution": r'''def in_venv(path):
    folders = path.replace("\\", "/").split("/")
    return ".venv" in folders

def find_wrong(reports):
    return sorted(name for name, path in reports.items() if not in_venv(path))

wrong = find_wrong(reports)
print(wrong)
''',
                "tests": r'''def _inv(p):
    return ".venv" in p.replace("\\", "/").split("/")
assert in_venv("/home/x/app/.venv/bin/python") is True, "a macOS/Linux path inside .venv should give True"
assert in_venv("C:\\app\\.venv\\Scripts\\python.exe") is True, "a Windows path inside .venv should give True"
assert in_venv("/home/x/.venv-old/bin/python") is False, "'.venv-old' is a different folder: in_venv should give False"
assert in_venv("C:\\Tools\\venv\\python.exe") is False, "'venv' without the dot is not the project's .venv"
assert in_venv("/usr/bin/python3") is False, "a global Python is not inside .venv"
assert find_wrong({"Zed": "/usr/bin/python3", "Al": "/a/.venv/bin/python", "Bo": "C:\\Python311\\python.exe"}) == ["Bo", "Zed"], "find_wrong should return the names outside .venv, sorted"
_exp = sorted(n for n, p in reports.items() if not _inv(p))
assert wrong == _exp, f"on this evidence wrong should be {_exp}, got {wrong!r}"''',
                "tips": [
                    "Turn every backslash into a slash first: `path.replace(\"\\\\\", \"/\")`, then `.split(\"/\")` gives a list of folder names. Check `\".venv\" in folders`.",
                    "`return sorted(name for name, path in reports.items() if not in_venv(path))`",
                ],
                "reveal": "Some machines run the computer's global Python, or an old copy of the venv. Their test results can't be trusted. But a wrong interpreter can be an honest slip; next, the settings files.",
            },
            {
                "notes": """The lab's required `.vscode/settings.json` (assignment Q1). A workstation's settings are correct only when all of these hold:
1. `"python.defaultInterpreterPath"` is a path inside a `.venv` folder (the rule from step 1)
2. `"python.analysis.typeCheckingMode"` is `"basic"`
3. `"editor.formatOnSave"` is `true`
4. `"python.testing.pytestEnabled"` is `true`
5. `"python.testing.pytestArgs"` is `["tests"]`

A missing key counts as wrong. JSON writes `true` / `false`; after `json.loads` they are Python's `True` / `False`.

The saboteur both runs the wrong Python **and** has tampered settings. Someone with only one of the two made an honest mistake.""",
                "question": """**Goal:** find the workstations with tampered settings, and the technician who is guilty on both counts.

**You have:**
- `reports` and `settings_files`, two dicts keyed by technician name. Each value in `settings_files` is the JSON **text** of that technician's settings.json, e.g. `'{"editor.formatOnSave": true}'`.
- In the editor: `in_venv`, `find_wrong` and the dict `REQUIRED` (rules 2 to 5 from the field notes).

**Write** a function `check_settings(text)`:
- read `text` with `json.loads`
- a missing key must not crash: read every key with `settings.get(key)`, and the interpreter path with `settings.get("python.defaultInterpreterPath", "")` (so `in_venv` always gets a string)
- return a list of the keys that break a rule, in this order: first `"python.defaultInterpreterPath"` (if rule 1 fails), then each key of `REQUIRED` whose value is missing or different, in `REQUIRED`'s order
- return `[]` when everything is right

**Then** store:
- `tampered`: a **sorted** list of the technicians whose `check_settings` result is not empty
- `culprit`: the one technician (a string) who is in both `wrong` and `tampered`

**Example:** for `'{"python.defaultInterpreterPath": "/usr/bin/python3", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": false, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}'` the result is `["python.defaultInterpreterPath", "editor.formatOnSave"]`.""",
                "starter": r'''import json

def in_venv(path):
    folders = path.replace("\\", "/").split("/")
    return ".venv" in folders

def find_wrong(reports):
    return sorted(name for name, path in reports.items() if not in_venv(path))

REQUIRED = {
    "python.analysis.typeCheckingMode": "basic",
    "editor.formatOnSave": True,
    "python.testing.pytestEnabled": True,
    "python.testing.pytestArgs": ["tests"],
}

def check_settings(text):
    return []

wrong = find_wrong(reports)
tampered = ...
culprit = ...
print(wrong, tampered, culprit)
''',
                "solution": r'''import json

def in_venv(path):
    folders = path.replace("\\", "/").split("/")
    return ".venv" in folders

def find_wrong(reports):
    return sorted(name for name, path in reports.items() if not in_venv(path))

REQUIRED = {
    "python.analysis.typeCheckingMode": "basic",
    "editor.formatOnSave": True,
    "python.testing.pytestEnabled": True,
    "python.testing.pytestArgs": ["tests"],
}

def check_settings(text):
    settings = json.loads(text)
    bad = []
    if not in_venv(settings.get("python.defaultInterpreterPath", "")):
        bad.append("python.defaultInterpreterPath")
    for key, value in REQUIRED.items():
        if settings.get(key) != value:
            bad.append(key)
    return bad

wrong = find_wrong(reports)
tampered = sorted(name for name, text in settings_files.items() if check_settings(text))
culprit = [name for name in wrong if name in tampered][0]
print(wrong, tampered, culprit)
''',
                "tests": r'''import json as _json
def _inv(p):
    return ".venv" in p.replace("\\", "/").split("/")
_REQ = {"python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": True, "python.testing.pytestEnabled": True, "python.testing.pytestArgs": ["tests"]}
def _bad(text):
    s = _json.loads(text)
    out = []
    if not _inv(s.get("python.defaultInterpreterPath", "")):
        out.append("python.defaultInterpreterPath")
    for k, v in _REQ.items():
        if s.get(k) != v:
            out.append(k)
    return out
_good = '{"python.defaultInterpreterPath": ".venv/bin/python", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": true, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}'
assert check_settings(_good) == [], f"correct settings should give [], got {check_settings(_good)!r}"
_t = '{"python.defaultInterpreterPath": "/usr/bin/python3", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": false, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["tests"]}'
assert check_settings(_t) == ["python.defaultInterpreterPath", "editor.formatOnSave"], f"the example should give ['python.defaultInterpreterPath', 'editor.formatOnSave'], got {check_settings(_t)!r}"
assert check_settings("{}") == ["python.defaultInterpreterPath"] + list(_REQ), "empty settings break every rule: list all five keys in order"
assert check_settings('{"python.defaultInterpreterPath": ".venv/bin/python", "python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": true, "python.testing.pytestEnabled": true, "python.testing.pytestArgs": ["."]}') == ["python.testing.pytestArgs"], "pytestArgs must be exactly [\"tests\"]"
for _n, _text in settings_files.items():
    assert check_settings(_text) == _bad(_text), f"for {_n}'s settings check_settings should give {_bad(_text)}, got {check_settings(_text)!r}"
_tam = sorted(n for n, t in settings_files.items() if _bad(t))
assert tampered == _tam, f"on this evidence tampered should be {_tam}, got {tampered!r}"
_wr = sorted(n for n, p in reports.items() if not _inv(p))
_cul = [n for n in _wr if n in _tam][0]
assert culprit == _cul, f"the technician in both lists is {_cul}, got {culprit!r}"''',
                "tips": [
                    "Start with `bad = []`. First `if not in_venv(settings.get(\"python.defaultInterpreterPath\", \"\")):` append that key; then `for key, value in REQUIRED.items():` append `key` when `settings.get(key) != value` (a missing key gives `None`, which never matches).",
                    "`tampered = sorted(name for name, text in settings_files.items() if check_settings(text))` (an empty list counts as false). Then `culprit = [name for name in wrong if name in tampered][0]`.",
                ],
                "reveal": "Only one technician runs the wrong Python *and* rewrote the lab's settings to hide it: switching off the test runner, loosening the type checks.",
            },
        ],
        "closing": "Case closed. The others had honest slips: one forgot to pick the interpreter, one liked a stricter type check. The saboteur did both on purpose, so their machine \"passed\" tests that fail everywhere else. Next to their keyboard: a chalk X.",
    },
    # ------------------------------------------------------------ microscope
    {
        "id": "breakpoint-hunt",
        "tier": "small",
        "title": "The Breakpoint Hunt",
        "teaser": "Thousands of fines, a handful of them fake. Pause only on the ones that matter.",
        "skills": ["microscope"],
        "story": """Patrons are complaining: they returned their books on time and were fined anyway. The fine run went through every loan in the archive; stepping through all of them by hand would take days.

A detective's answer: a **conditional breakpoint** that pauses only on the loans that should never have been fined. The fine run's records are in `loans`, a list of `Loan` objects (forensics recorded which clerk processed each one).""",
        "suspects": [
            {"name": "the clerks at the returns desk", "note": "Each one processed part of the fine run."},
        ],
        "variants": [
            r'''from dataclasses import dataclass
from datetime import date

@dataclass
class Loan:
    item_id: str
    clerk: str
    due_on: date
    returned_on: date | None
    fine: float

loans = [
    Loan("B101", "Ines", date(2026, 3, 1), date(2026, 2, 27), 4.5),
    Loan("B102", "Omar", date(2026, 3, 1), date(2026, 3, 9), 4.0),
    Loan("B103", "Ines", date(2026, 3, 5), None, 6.0),
    Loan("B104", "Omar", date(2026, 3, 8), date(2026, 3, 8), 0.0),
    Loan("B105", "Ines", date(2026, 3, 10), date(2026, 3, 10), 2.5),
    Loan("B106", "Pia", date(2026, 3, 12), date(2026, 3, 2), 3.0),
    Loan("B107", "Ines", date(2026, 3, 15), date(2026, 3, 14), 5.0),
    Loan("B108", "Pia", date(2026, 3, 20), None, 0.0),
]
''',
            r'''from dataclasses import dataclass
from datetime import date

@dataclass
class Loan:
    item_id: str
    clerk: str
    due_on: date
    returned_on: date | None
    fine: float

loans = [
    Loan("C201", "Tomas", date(2026, 6, 1), date(2026, 5, 30), 1.5),
    Loan("C202", "Ruth", date(2026, 6, 2), None, 8.0),
    Loan("C203", "Tomas", date(2026, 6, 4), date(2026, 6, 4), 3.5),
    Loan("C204", "Ruth", date(2026, 6, 5), date(2026, 6, 12), 3.5),
    Loan("C205", "Sven", date(2026, 6, 7), date(2026, 6, 1), 0.0),
    Loan("C206", "Ruth", date(2026, 6, 9), date(2026, 6, 20), 5.5),
]
''',
            r'''from dataclasses import dataclass
from datetime import date

@dataclass
class Loan:
    item_id: str
    clerk: str
    due_on: date
    returned_on: date | None
    fine: float

loans = [
    Loan("D301", "Priya", date(2026, 9, 1), date(2026, 9, 3), 1.0),
    Loan("D302", "Quinn", date(2026, 9, 2), date(2026, 9, 1), 0.0),
    Loan("D303", "Priya", date(2026, 9, 4), date(2026, 8, 30), 6.0),
    Loan("D304", "Quinn", date(2026, 9, 6), None, 2.0),
    Loan("D305", "Priya", date(2026, 9, 8), date(2026, 9, 8), 2.0),
    Loan("D306", "Quinn", date(2026, 9, 9), date(2026, 9, 9), 1.5),
    Loan("D307", "Priya", date(2026, 9, 11), date(2026, 9, 2), 3.0),
]
''',
        ],
        "steps": [
            {
                "notes": """The fine rule at the Bureau's library:
- A loan returned **on or before** its due date (`returned_on <= due_on`) must have a fine of `0`.
- A loan returned late, or still out (`returned_on` is `None`) after its due date, may have a fine.

So a **fake fine** is a loan that was returned (`returned_on is not None`), on time (`returned_on <= due_on`), with `fine > 0`.

A conditional breakpoint pauses only when its condition is true. Here a plain `if` around the "pause" plays that part.""",
                "question": """**Goal:** pause only on the loans with a fake fine, and find the clerk who charged them.

**You have:** `loans`, a list of `Loan` objects. Each has `item_id` (str), `clerk` (str), `due_on` (a `date`), `returned_on` (a `date`, or `None` if still out) and `fine` (a float). For example `Loan("B101", "Ines", date(2026, 3, 1), date(2026, 2, 27), 4.5)`.

**Write** a function `run_with_breakpoint(loans, condition)`:
- `condition` is a function that takes one loan and returns `True` or `False`
- loop over `loans`; when `condition(loan)` is `True`, print `PAUSED on <item_id>` (e.g. `PAUSED on B101`) and remember the `item_id`
- return the list of item ids it paused on, in the order of `loans`

**Then** store:
- `hits = run_with_breakpoint(loans, ...)`, passing a `lambda` that is true only for a fake fine (field notes)
- `refund`: the total of the fines of those loans, rounded to 2 decimals with `round(..., 2)`
- `culprit`: the clerk who processed the most of those loans (a string; there is exactly one, count with a dict)

**Example:** with `run_with_breakpoint(loans, lambda loan: loan.fine > 5)` it would print one `PAUSED on ...` line per loan with a fine above 5 and return their ids.""",
                "starter": r'''def run_with_breakpoint(loans, condition):
    paused = []
    return paused

hits = run_with_breakpoint(loans, lambda loan: False)
refund = ...
culprit = ...
print(hits, refund, culprit)
''',
                "solution": r'''def run_with_breakpoint(loans, condition):
    paused = []
    for loan in loans:
        if condition(loan):
            print(f"PAUSED on {loan.item_id}")
            paused.append(loan.item_id)
    return paused

hits = run_with_breakpoint(
    loans,
    lambda loan: loan.returned_on is not None and loan.returned_on <= loan.due_on and loan.fine > 0,
)
refund = round(sum(loan.fine for loan in loans if loan.item_id in hits), 2)
counts = {}
for loan in loans:
    if loan.item_id in hits:
        counts[loan.clerk] = counts.get(loan.clerk, 0) + 1
culprit = max(counts, key=counts.get)
print(hits, refund, culprit)
''',
                "tests": r'''import contextlib as _cl, io as _io
_buf = _io.StringIO()
with _cl.redirect_stdout(_buf):
    _r = run_with_breakpoint(loans, lambda loan: loan.fine > 3)
_ids = [l.item_id for l in loans if l.fine > 3]
assert _r == _ids, f"with the condition 'fine > 3' run_with_breakpoint should return {_ids}, got {_r!r}"
assert _buf.getvalue() == "".join(f"PAUSED on {i}\n" for i in _ids), f"it should print one 'PAUSED on <item_id>' line per pause, got {_buf.getvalue()!r}"
_buf = _io.StringIO()
with _cl.redirect_stdout(_buf):
    assert run_with_breakpoint(loans, lambda loan: False) == [], "a condition that is never true should pause nowhere"
_fake = [l for l in loans if l.returned_on is not None and l.returned_on <= l.due_on and l.fine > 0]
assert hits == [l.item_id for l in _fake], f"on this evidence the fake fines are {[l.item_id for l in _fake]}, got {hits!r}"
assert refund == round(sum(l.fine for l in _fake), 2), f"refund should be {round(sum(l.fine for l in _fake), 2)}, got {refund!r}"
_c = {}
for _l in _fake:
    _c[_l.clerk] = _c.get(_l.clerk, 0) + 1
_who = max(_c, key=_c.get)
assert culprit == _who, f"the clerk behind most fake fines is {_who}, got {culprit!r}"''',
                "tips": [
                    "Inside the loop: `if condition(loan):` then `print(f\"PAUSED on {loan.item_id}\")` and `paused.append(loan.item_id)`. The condition is a `lambda loan: ...` joining three checks with `and`.",
                    "For the clerk, count with a dict (`counts[loan.clerk] = counts.get(loan.clerk, 0) + 1`) over the loans whose id is in `hits`, then `max(counts, key=counts.get)`.",
                ],
                "reveal": "The breakpoint stops only on the fake fines, and nearly all of them went through the same clerk's hands.",
            },
        ],
        "closing": "Case closed. A conditional breakpoint turned days of stepping into a few pauses. The clerk had \"adjusted\" the fine run so on-time returns paid up, pocketing the difference. Every fake fine is refunded.",
    },
    # ------------------------------------------------------------ logbook
    {
        "id": "silent-alarm",
        "tier": "small",
        "title": "The Silent Alarm",
        "teaser": "The vault door opened at 3 am. The log saw it. The guard's pager never buzzed.",
        "skills": ["logbook"],
        "story": """Overnight, someone opened a door in the evidence vault. The alarm system logged it, yet the night guard's pager stayed silent. The logging configuration was changed the evening before.

Forensics recovered the night's configuration and events:
- `logger_level`: the level set on the alarm logger
- `pager_level`: the level set on the handler that feeds the guard's pager
- `events`: every message the sensors logged, as `(level, message, badge)` tuples; `badge` is whose card triggered it (or `"system"`)""",
        "suspects": [
            {"name": "the evening technician", "note": "Changed the logging configuration \"to reduce noise\"."},
            {"name": "the badge holders", "note": "Each badge in the events belongs to a lab worker."},
        ],
        "variants": [
            r'''import logging
logger_level = logging.INFO
pager_level = logging.ERROR
events = [
    (logging.INFO, "night shift started", "guard Ola"),
    (logging.DEBUG, "sensor 4 heartbeat", "system"),
    (logging.WARNING, "vault door 3 opened", "badge K-17"),
    (logging.ERROR, "freezer B temperature high", "system"),
    (logging.WARNING, "evidence locker 9 opened", "badge K-17"),
    (logging.CRITICAL, "power cut in lab 2", "system"),
    (logging.INFO, "night shift ended", "guard Ola"),
]
''',
            r'''import logging
logger_level = logging.ERROR
pager_level = logging.DEBUG
events = [
    (logging.INFO, "night shift started", "guard Ben"),
    (logging.WARNING, "side gate opened", "badge R-02"),
    (logging.WARNING, "camera 2 lost signal", "system"),
    (logging.ERROR, "lab 4 fire door forced", "badge M-11"),
    (logging.WARNING, "vault door 1 opened", "badge R-02"),
    (logging.DEBUG, "sensor sweep done", "system"),
]
''',
            r'''import logging
logger_level = logging.WARNING
pager_level = logging.CRITICAL
events = [
    (logging.INFO, "night shift started", "guard Ola"),
    (logging.WARNING, "archive window opened", "badge T-40"),
    (logging.CRITICAL, "fire alarm drill", "guard Ola"),
    (logging.ERROR, "cold store door left open", "system"),
    (logging.ERROR, "vault door 2 forced", "badge T-40"),
    (logging.INFO, "night shift ended", "guard Ola"),
]
''',
        ],
        "steps": [
            {
                "notes": """Log levels are numbers: `logging.DEBUG` = 10, `INFO` = 20, `WARNING` = 30, `ERROR` = 40, `CRITICAL` = 50.

A record goes through **two** gates:
1. the **logger's** level: a record below it is dropped before any handler sees it
2. each **handler's** own level: a record below it is not written by that handler

So a record reaches the pager only if its level is **at least** `logger_level` **and at least** `pager_level`.

`logger.log(level, message)` logs at any level number: `logger.log(logging.WARNING, "x")` is the same as `logger.warning("x")`.""",
                "question": """**Goal:** rebuild the night's alarm logger and see which lines reached the pager.

**You have:** `logger_level` and `pager_level` (level numbers such as `logging.INFO`), and `events`, a list of `(level, message, badge)` tuples, e.g. `(logging.WARNING, "vault door 3 opened", "badge K-17")`.

**Write** a function `setup(logger_level, pager_level, stream)` that returns the logger called `"lab.alarm"`, set up like this:
- remove any old handlers, set the logger's level to `logger_level`, set `propagate` to `False`
- add one `StreamHandler(stream)` whose **own** level is `pager_level` and whose format is `"%(levelname)s %(message)s"`

**Then:**
- make `pager = io.StringIO()` and `alarm = setup(logger_level, pager_level, pager)`
- log every event with `alarm.log(level, message)` (`log` takes the level number first)
- store `paged = pager.getvalue().splitlines()`: the list of lines the pager received

**Example:** with `setup(logging.INFO, logging.WARNING, stream)`, logging `(logging.INFO, "hi")` and `(logging.ERROR, "fire")` writes only `"ERROR fire"` to `stream`.""",
                "starter": r'''import io
import logging

def setup(logger_level, pager_level, stream):
    logger = logging.getLogger("lab.alarm")
    return logger

pager = io.StringIO()
alarm = setup(logger_level, pager_level, pager)
# log every event here

paged = pager.getvalue().splitlines()
print(paged)
''',
                "solution": r'''import io
import logging

def setup(logger_level, pager_level, stream):
    logger = logging.getLogger("lab.alarm")
    logger.handlers.clear()
    logger.setLevel(logger_level)
    logger.propagate = False
    handler = logging.StreamHandler(stream)
    handler.setLevel(pager_level)
    handler.setFormatter(logging.Formatter("%(levelname)s %(message)s"))
    logger.addHandler(handler)
    return logger

pager = io.StringIO()
alarm = setup(logger_level, pager_level, pager)
for level, message, badge in events:
    alarm.log(level, message)

paged = pager.getvalue().splitlines()
print(paged)
''',
                "tests": r'''import io as _io, logging as _lg
_NAMES = {10: "DEBUG", 20: "INFO", 30: "WARNING", 40: "ERROR", 50: "CRITICAL"}
_s = _io.StringIO()
_lgr = setup(_lg.INFO, _lg.WARNING, _s)
_lgr.log(_lg.INFO, "hi")
_lgr.log(_lg.ERROR, "fire")
assert _s.getvalue() == "ERROR fire\n", f"with logger INFO and pager WARNING only 'ERROR fire' should be written, got {_s.getvalue()!r}"
_s = _io.StringIO()
_lgr = setup(_lg.ERROR, _lg.DEBUG, _s)
_lgr.log(_lg.WARNING, "door")
_lgr.log(_lg.CRITICAL, "flood")
assert _s.getvalue() == "CRITICAL flood\n", f"the logger's own level (ERROR) must drop the WARNING, got {_s.getvalue()!r}"
assert len(_lgr.handlers) == 1, "setup should leave exactly one handler (remove old ones first)"
assert _lgr.propagate is False, "set propagate to False"
_exp = [f"{_NAMES[l]} {m}" for l, m, b in events if l >= logger_level and l >= pager_level]
assert paged == _exp, f"on this evidence the pager should have received {_exp}, got {paged!r}"''',
                "tips": [
                    "Like the lesson: `logger.handlers.clear()`, `logger.setLevel(logger_level)`, `logger.propagate = False`. The handler gets its own level: `handler = logging.StreamHandler(stream)` then `handler.setLevel(pager_level)` and `handler.setFormatter(logging.Formatter(\"%(levelname)s %(message)s\"))`.",
                    "`for level, message, badge in events: alarm.log(level, message)`. Don't forget `logger.addHandler(handler)` and `return logger`.",
                ],
                "reveal": "The pager got a few lines, but not the ones that mattered. Some serious events never made it through the two gates.",
            },
            {
                "notes": """An event is **serious** when its level is `WARNING` (30) or higher.

A serious event is **silenced** when it did not reach the pager: its level is below `logger_level` **or** below `pager_level`.""",
                "question": """**Goal:** list the serious events the pager never got, and whose badge they belong to.

**You have:** `logger_level`, `pager_level` and `events` (same as step 1); `logging` is imported in the starter.

**Write** two variables:
- `silenced`: a list of `(badge, message)` tuples for every **silenced** serious event (field notes), in the order of `events`
- `culprit`: the badge that appears most often in `silenced` (a string)

**Then** print both (the starter already does).

**Example:** with `logger_level = logging.INFO`, `pager_level = logging.ERROR` and the events `(logging.WARNING, "door opened", "badge A")`, `(logging.ERROR, "fire", "system")`, `silenced` is `[("badge A", "door opened")]`; the ERROR reached the pager.""",
                "starter": r'''import logging

silenced = []
culprit = ...
print(silenced)
print(culprit)
''',
                "solution": r'''import logging

silenced = []
for level, message, badge in events:
    if level >= logging.WARNING and (level < logger_level or level < pager_level):
        silenced.append((badge, message))

counts = {}
for badge, message in silenced:
    counts[badge] = counts.get(badge, 0) + 1
culprit = max(counts, key=counts.get)
print(silenced)
print(culprit)
''',
                "tests": r'''_exp = [(b, m) for l, m, b in events if l >= 30 and (l < logger_level or l < pager_level)]
assert silenced == _exp, f"on this evidence silenced should be {_exp}, got {silenced!r}"
_c = {}
for _b, _m in _exp:
    _c[_b] = _c.get(_b, 0) + 1
_who = max(_c, key=_c.get)
assert culprit == _who, f"the badge silenced most often is {_who!r}, got {culprit!r}"''',
                "tips": [
                    "Loop with `for level, message, badge in events:` and keep an event when `level >= logging.WARNING and (level < logger_level or level < pager_level)`.",
                    "Count the badges in `silenced` with a dict, then `culprit = max(counts, key=counts.get)`.",
                ],
                "reveal": "Every silenced alarm points at the same badge. The configuration change wasn't about noise: it was set up so that one person's night-time visits would never reach the pager.",
            },
        ],
        "closing": "Case closed. Two gates, the logger's level and the handler's level, and one of them was quietly raised just high enough. The badge holder and the evening technician turn out to be the same person. The pager now gets every WARNING.",
    },
    # ------------------------------------------------------------ test-bench (Q4)
    {
        "id": "forged-isbns",
        "tier": "small",
        "title": "The Forged ISBNs",
        "teaser": "Three technicians each sent in a clean_isbn. Write the tables that expose the forgery.",
        "skills": ["test-bench"],
        "story": """Fake books are slipping into the Bureau's catalogue with made-up ISBNs. Every import runs through `clean_isbn`, and the lab keeps one copy per technician. At least one of those copies has been rewritten to wave the forgeries through.

Forensics loaded:
- `clean_isbn`: the lab's genuine version, which your tests must pass
- `SUSPECTS`: a dict from technician name to that technician's copy of `clean_isbn`

Don't read their code line by line: write the tables once and let the tests convict.

*(This is the official assignment Q4: parametrized `clean_isbn` tests.)*""",
        "suspects": [
            {"name": "the technicians who sent in a copy", "note": "Each swears their copy is identical to the lab's."},
        ],
        "variants": [
            r'''def clean_isbn(raw):
    if not isinstance(raw, str):
        raise ValueError("ISBN must be text")
    cleaned = ""
    for ch in raw:
        if ch not in " -\t\n":
            cleaned += ch
    cleaned = cleaned.upper()
    if len(cleaned) == 13 and cleaned.isdigit():
        return cleaned
    if len(cleaned) == 10 and cleaned[:9].isdigit() and cleaned[9] in "0123456789X":
        return cleaned
    raise ValueError(f"not a valid ISBN: {raw!r}")

def isbn_by_ama(raw):
    if not isinstance(raw, str):
        raise ValueError("not text")
    s = raw.replace(" ", "").replace("-", "").replace("\t", "").replace("\n", "").upper()
    if len(s) == 13 and s.isdigit():
        return s
    if len(s) == 10 and s[:9].isdigit() and (s[9].isdigit() or s[9] == "X"):
        return s
    raise ValueError("bad ISBN")

def isbn_by_bo(raw):
    if not isinstance(raw, str):
        raise ValueError("not text")
    digits = "".join(ch for ch in raw if ch.isdigit())
    if len(digits) in (10, 13):
        return digits
    raise ValueError("bad ISBN")

SUSPECTS = {"Ama": isbn_by_ama, "Bo": isbn_by_bo, "Cleo": clean_isbn}
''',
            r'''def clean_isbn(raw):
    if not isinstance(raw, str):
        raise ValueError("ISBN must be text")
    cleaned = ""
    for ch in raw:
        if ch not in " -\t\n":
            cleaned += ch
    cleaned = cleaned.upper()
    if len(cleaned) == 13 and cleaned.isdigit():
        return cleaned
    if len(cleaned) == 10 and cleaned[:9].isdigit() and cleaned[9] in "0123456789X":
        return cleaned
    raise ValueError(f"not a valid ISBN: {raw!r}")

def isbn_by_dee(raw):
    if not isinstance(raw, str):
        raise ValueError("not text")
    s = raw.strip().replace(" ", "").replace("-", "").upper()
    if len(s) == 13 and s.isdigit():
        return s
    if len(s) == 10 and s[:9].isdigit() and s[9] in "0123456789X":
        return s
    raise ValueError("bad ISBN")

def isbn_by_eve(raw):
    if type(raw) is not str:
        raise ValueError("not text")
    kept = [ch for ch in raw.upper() if ch not in " -\t\n"]
    s = "".join(kept)
    if (len(s) == 13 and s.isdigit()) or (len(s) == 10 and s[:9].isdigit() and s[9] in "0123456789X"):
        return s
    raise ValueError("bad ISBN")

SUSPECTS = {"Dee": isbn_by_dee, "Eve": isbn_by_eve, "Fynn": clean_isbn}
''',
            r'''def clean_isbn(raw):
    if not isinstance(raw, str):
        raise ValueError("ISBN must be text")
    cleaned = ""
    for ch in raw:
        if ch not in " -\t\n":
            cleaned += ch
    cleaned = cleaned.upper()
    if len(cleaned) == 13 and cleaned.isdigit():
        return cleaned
    if len(cleaned) == 10 and cleaned[:9].isdigit() and cleaned[9] in "0123456789X":
        return cleaned
    raise ValueError(f"not a valid ISBN: {raw!r}")

def isbn_by_gil(raw):
    s = raw.replace(" ", "").replace("-", "").replace("\t", "").replace("\n", "").upper()
    if len(s) == 13 and s.isdigit():
        return s
    if len(s) == 10 and s[:9].isdigit() and s[9] in "0123456789X":
        return s
    raise ValueError("bad ISBN")

def isbn_by_hal(raw):
    if not isinstance(raw, str):
        raise ValueError("not text")
    s = raw.replace(" ", "").replace("-", "").replace("\t", "").replace("\n", "")
    if s.isdigit():
        return s
    raise ValueError("bad ISBN")

def isbn_by_ivy(raw):
    if not isinstance(raw, str):
        raise ValueError("not text")
    s = ""
    for ch in raw.upper():
        if ch in "0123456789X":
            s += ch
        elif ch not in " -\t\n":
            raise ValueError(f"unexpected {ch!r}")
    if len(s) == 13 and s.isdigit():
        return s
    if len(s) == 10 and s[:9].isdigit():
        return s
    raise ValueError("bad ISBN")

SUSPECTS = {"Gil": isbn_by_gil, "Hal": isbn_by_hal, "Ivy": isbn_by_ivy}
''',
        ],
        "steps": [
            {
                "notes": """The table rows come from assignment Q4. `clean_isbn(raw)` must:

**Clean these into the right ISBN:**
- `"978-0-13-235088-4"` gives `"9780132350884"`
- `"0132350882"` gives `"0132350882"`
- `"  978 0132350884  "` gives `"9780132350884"`
- `"978\\t0132350884"` (with a tab) gives `"9780132350884"`

**Raise `ValueError` for each of these:** `"abc"`, `"12345"`, `""`, `None`, `"978abc0132350884"`

**And** a newline is cleaned too: `"978\\n0132350884"` gives `"9780132350884"`.

A forged copy is one that fails at least one of these checks (a wrong answer, a missing `ValueError`, or a different error such as `AttributeError`).""",
                "question": """**Goal:** write the Q4 test tables once, then run them against every technician's copy to find the forgers.

**You have:**
- `clean_isbn` (the genuine version) and `SUSPECTS`, a dict from name to a copy of `clean_isbn`, e.g. `{"Ama": <function>, ...}`
- in the editor: the mini pytest pieces `raises`, `parametrize`, `run_rows(namespace)` (runs every `test_` function and every table row, returns how many failed) and `run_lineup(namespace, suspects)` (runs all your tests once per suspect, with that suspect's copy as `clean_isbn`, and returns a dict from name to failed rows)

**Write** three tests (field notes for the data):
- `test_clean_isbn_valid(raw, expected)` with `@parametrize("raw, expected", [...])` holding the **4** valid rows; body: `assert clean_isbn(raw) == expected`
- `test_clean_isbn_invalid(bad)` with `@parametrize("bad", [...])` holding the **5** bad inputs; body: `with raises(ValueError):` around `clean_isbn(bad)`
- `test_newline_is_cleaned()`, which asserts that `clean_isbn("978\\n0132350884")` is `"9780132350884"`

**Then** store:
- `results = run_lineup(globals(), SUSPECTS)`
- `forgers`: a **sorted** list of the names whose number of failed rows is more than 0

Every test must pass on the genuine `clean_isbn` (the starter prints that count).

**Example:** if `results` were `{"Kai": 0, "Lu": 2}`, `forgers` would be `["Lu"]`.""",
                "starter": r'''# ---- mini pytest (a stand-in; real pytest does this for you) ----
from contextlib import contextmanager

@contextmanager
def raises(error, match=""):
    try:
        yield
    except error as e:
        assert match in str(e), f"{match!r} is not in the message {str(e)!r}"
        return
    raise AssertionError(f"DID NOT RAISE {error.__name__}")

def parametrize(argnames, rows):
    def mark(fn):
        if "," in argnames:
            fn.rows = list(rows)
        else:
            fn.rows = [(row,) for row in rows]
        return fn
    return mark

def run_rows(namespace):
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            for row in getattr(fn, "rows", [()]):
                try:
                    fn(*row)
                except Exception:
                    failed += 1
    return failed

def run_lineup(namespace, suspects):
    genuine = namespace["clean_isbn"]
    results = {}
    for name, impl in suspects.items():
        namespace["clean_isbn"] = impl
        results[name] = run_rows(namespace)
    namespace["clean_isbn"] = genuine
    return results

# ---- the tests start here ----

def test_clean_isbn_valid(raw, expected):
    assert clean_isbn(raw) == expected

# write the tables and the newline test here


print("genuine clean_isbn:", run_rows(globals()), "failed")
results = run_lineup(globals(), SUSPECTS)
forgers = ...
print(results)
print(forgers)
''',
                "solution": r'''# ---- mini pytest (a stand-in; real pytest does this for you) ----
from contextlib import contextmanager

@contextmanager
def raises(error, match=""):
    try:
        yield
    except error as e:
        assert match in str(e), f"{match!r} is not in the message {str(e)!r}"
        return
    raise AssertionError(f"DID NOT RAISE {error.__name__}")

def parametrize(argnames, rows):
    def mark(fn):
        if "," in argnames:
            fn.rows = list(rows)
        else:
            fn.rows = [(row,) for row in rows]
        return fn
    return mark

def run_rows(namespace):
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            for row in getattr(fn, "rows", [()]):
                try:
                    fn(*row)
                except Exception:
                    failed += 1
    return failed

def run_lineup(namespace, suspects):
    genuine = namespace["clean_isbn"]
    results = {}
    for name, impl in suspects.items():
        namespace["clean_isbn"] = impl
        results[name] = run_rows(namespace)
    namespace["clean_isbn"] = genuine
    return results

# ---- the tests start here ----

@parametrize("raw, expected", [
    ("978-0-13-235088-4", "9780132350884"),
    ("0132350882", "0132350882"),
    ("  978 0132350884  ", "9780132350884"),
    ("978\t0132350884", "9780132350884"),
])
def test_clean_isbn_valid(raw, expected):
    assert clean_isbn(raw) == expected

@parametrize("bad", ["abc", "12345", "", None, "978abc0132350884"])
def test_clean_isbn_invalid(bad):
    with raises(ValueError):
        clean_isbn(bad)

def test_newline_is_cleaned():
    assert clean_isbn("978\n0132350884") == "9780132350884"


print("genuine clean_isbn:", run_rows(globals()), "failed")
results = run_lineup(globals(), SUSPECTS)
forgers = sorted(name for name, failed in results.items() if failed > 0)
print(results)
print(forgers)
''',
                "tests": r'''_VALID = [("978-0-13-235088-4", "9780132350884"), ("0132350882", "0132350882"), ("  978 0132350884  ", "9780132350884"), ("978\t0132350884", "9780132350884")]
_BAD = ["abc", "12345", "", None, "978abc0132350884"]
for _name in ("test_clean_isbn_valid", "test_clean_isbn_invalid", "test_newline_is_cleaned"):
    assert callable(globals().get(_name)), f"write a test function called {_name}"
_vr = getattr(test_clean_isbn_valid, "rows", None)
assert _vr, 'put @parametrize("raw, expected", [...]) on the line above test_clean_isbn_valid'
assert sorted(tuple(_r) for _r in _vr) == sorted(_VALID), f"the valid table should hold exactly the 4 rows from the field notes, got {_vr!r}"
_ir = getattr(test_clean_isbn_invalid, "rows", None)
assert _ir, 'put @parametrize("bad", [...]) on the line above test_clean_isbn_invalid'
assert len(_ir) == 5 and all(_r[0] in _BAD for _r in _ir) and all(any(_r[0] == _b for _r in _ir) for _b in _BAD), f"the invalid table should hold the 5 bad inputs from the field notes, got {_ir!r}"
def _count_fail():
    _n = 0
    for _k, _f in list(globals().items()):
        if _k.startswith("test_") and callable(_f):
            for _row in getattr(_f, "rows", [()]):
                try:
                    _f(*_row)
                except Exception:
                    _n += 1
    return _n
def _with(_impl):
    _real = globals()["clean_isbn"]
    globals()["clean_isbn"] = _impl
    try:
        return _count_fail()
    finally:
        globals()["clean_isbn"] = _real
assert _count_fail() == 0, "every test must pass on the genuine clean_isbn: check your expected values"
_genuine = clean_isbn
def _m_digits(raw):
    if not isinstance(raw, str):
        raise ValueError("x")
    d = "".join(c for c in raw if c.isdigit())
    if len(d) in (10, 13):
        return d
    raise ValueError("x")
def _m_notab(raw):
    if isinstance(raw, str) and "\t" in raw:
        return raw.replace("-", "").replace(" ", "")
    return _genuine(raw)
def _m_nonl(raw):
    if isinstance(raw, str) and "\n" in raw:
        return raw.replace("-", "").replace(" ", "")
    return _genuine(raw)
def _m_none(raw):
    if raw is None:
        raise TypeError("NoneType has no replace")
    return _genuine(raw)
def _m_short(raw):
    if raw == "12345":
        return raw
    return _genuine(raw)
def _m_empty(raw):
    if raw == "":
        return ""
    return _genuine(raw)
def _m_hyphen(raw):
    if isinstance(raw, str) and "-" in raw:
        return raw.strip()
    return _genuine(raw)
for _m, _why in [(_m_digits, "accepts '978abc0132350884' by dropping the letters"), (_m_notab, "forgets to remove tabs"), (_m_nonl, "forgets to remove newlines"), (_m_none, "crashes with TypeError on None instead of ValueError"), (_m_short, "accepts '12345'"), (_m_empty, "accepts ''"), (_m_hyphen, "keeps the hyphens")]:
    assert _with(_m) > 0, f"your tests should catch a clean_isbn that {_why}"
def _forged(_impl):
    for _raw, _exp in _VALID + [("978\n0132350884", "9780132350884")]:
        try:
            if _impl(_raw) != _exp:
                return True
        except Exception:
            return True
    for _b in _BAD:
        try:
            _impl(_b)
            return True
        except ValueError:
            pass
        except Exception:
            return True
    return False
_exp = sorted(_n for _n, _f in SUSPECTS.items() if _forged(_f))
assert forgers == _exp, f"on this evidence the forgers are {_exp}, got {forgers!r}"''',
                "tips": [
                    "A table is a list of tuples inside `@parametrize(\"raw, expected\", [ (...), (...) ])`, one row per line. Write the tab row as `(\"978\\t0132350884\", \"9780132350884\")`; with one name, the rows are plain values: `@parametrize(\"bad\", [\"abc\", \"12345\", \"\", None, \"978abc0132350884\"])`.",
                    "The invalid test body is `with raises(ValueError):` followed by an indented `clean_isbn(bad)`. At the end: `forgers = sorted(name for name, failed in results.items() if failed > 0)`.",
                ],
                "reveal": "The genuine `clean_isbn` passes every row. Against the line-up, the honest copies pass too, whatever their style; the forgeries fail rows they were rewritten to dodge.",
            },
        ],
        "closing": "Case closed. Ten rows of tests did what reading three versions of the code could not: they turned \"looks the same to me\" into a verdict. The forged copy is pulled from the import pipeline, and the parametrized tables now run on every change.",
    },
    # ------------------------------------------------------------ test-bench (Q6)
    {
        "id": "exception-lineup",
        "tier": "small",
        "title": "The Exception Line-up",
        "teaser": "Every failure in the locker log just says ValueError. Give each crime its own name.",
        "skills": ["test-bench"],
        "story": """Someone is probing the evidence locker system with bad requests: asking for items that don't exist, using member cards that were never issued, trying to add items twice. The trouble is that the locker code raises plain `ValueError` and `KeyError` for everything, so the log can't tell a typo from a break-in attempt.

Forensics recovered `requests`, the locker's request log, as tuples:
- `(clerk, "add", item_id)`: add a new item
- `(clerk, "join", member_id)`: register a member
- `(clerk, "borrow", item_id, member_id)`: lend an item to a member

*(This is the official assignment Q6: domain exceptions instead of generic errors.)*""",
        "suspects": [
            {"name": "the clerks at the locker", "note": "Every request in the log was typed by one of them."},
        ],
        "variants": [
            r'''requests = [
    ("Rosa", "add", "B001"),
    ("Rosa", "add", "B002"),
    ("Rosa", "join", "M001"),
    ("Sami", "borrow", "B001", "M001"),
    ("Theo", "borrow", "B001", "M002"),
    ("Theo", "borrow", "B009", "M001"),
    ("Sami", "join", "M002"),
    ("Sami", "borrow", "B002", "M002"),
    ("Theo", "add", "B001"),
    ("Rosa", "borrow", "B001", "M002"),
    ("Sami", "add", "B003"),
]
''',
            r'''requests = [
    ("Uma", "add", "C100"),
    ("Uma", "add", "C200"),
    ("Vik", "join", "M010"),
    ("Vik", "join", "M020"),
    ("Wen", "add", "C100"),
    ("Vik", "borrow", "C100", "M010"),
    ("Uma", "borrow", "C100", "M020"),
    ("Wen", "borrow", "C300", "M010"),
    ("Uma", "borrow", "C200", "M030"),
    ("Wen", "borrow", "C200", "M099"),
    ("Vik", "borrow", "C200", "M020"),
]
''',
            r'''requests = [
    ("Yusuf", "add", "D1"),
    ("Yusuf", "add", "D2"),
    ("Yusuf", "join", "M7"),
    ("Xia", "borrow", "D9", "M7"),
    ("Zoe", "borrow", "D1", "M8"),
    ("Xia", "add", "D2"),
    ("Yusuf", "borrow", "D1", "M7"),
    ("Xia", "borrow", "D1", "M7"),
    ("Zoe", "add", "D1"),
    ("Xia", "borrow", "D3", "M1"),
]
''',
        ],
        "steps": [
            {
                "notes": """The BookVault domain errors (assignment Q6). All of them are children of one base class, so a caller can catch every locker problem with `except BookVaultError`:

| Error | When |
|---|---|
| `ItemNotFoundError` | borrowing an item id the locker doesn't have |
| `UnknownMemberError` | borrowing for a member id that was never registered |
| `ItemUnavailableError` | borrowing an item that is already lent out |
| `DuplicateItemError` | adding an item whose id is already in the locker |

`ItemUnavailableError` is also a kind of `ValueError` (older code catches `ValueError` for it), so it has **two** parents: `BookVaultError` and `ValueError`.

`borrow` checks in this order: the item exists, then the member exists, then the item is available.""",
                "question": """**Goal:** give every locker failure its own exception class, so the log shows what really happened.

**You have:** `requests` (see the story). In the editor: a `Book` dataclass (`item_id`, `available`), the base class `BookVaultError`, a `Library` that still raises generic errors, and `replay(requests)`, which runs every request and records `(clerk, error class name)` for each request that raises a `BookVaultError`.

**Write:**
- four classes, each a child of `BookVaultError`: `ItemNotFoundError`, `UnknownMemberError`, `DuplicateItemError` and `ItemUnavailableError(BookVaultError, ValueError)` (field notes)
- change `Library` so `add_item` raises `DuplicateItemError` and `borrow` raises `ItemNotFoundError`, `UnknownMemberError` or `ItemUnavailableError`, in the order from the field notes, instead of `ValueError` / `KeyError`

**Then** keep the starter's last lines: `failures = replay(requests)` and the print.

**Example:** after adding `Book("B1")` and registering `"M1"`, `lib.borrow("B9", "M1")` raises `ItemNotFoundError`, and borrowing `"B1"` twice raises `ItemUnavailableError` the second time (which `except ValueError` also catches).""",
                "starter": r'''from dataclasses import dataclass

@dataclass
class Book:
    item_id: str
    available: bool = True

class BookVaultError(Exception):
    """Base class for BookVault domain errors."""

# write the four domain errors here


class Library:
    def __init__(self, name):
        self.name = name
        self.items = {}
        self.members = set()

    def add_item(self, item):
        if item.item_id in self.items:
            raise ValueError(f"{item.item_id} already exists")
        self.items[item.item_id] = item

    def add_member(self, member_id):
        self.members.add(member_id)

    def borrow(self, item_id, member_id):
        item = self.items[item_id]
        if member_id not in self.members:
            raise KeyError(member_id)
        if not item.available:
            raise ValueError(f"{item_id} is unavailable")
        item.available = False

def replay(requests):
    lib = Library("Evidence Locker")
    failures = []
    for request in requests:
        clerk, action = request[0], request[1]
        try:
            if action == "add":
                lib.add_item(Book(request[2]))
            elif action == "join":
                lib.add_member(request[2])
            else:
                lib.borrow(request[2], request[3])
        except BookVaultError as e:
            failures.append((clerk, type(e).__name__))
    return failures

failures = replay(requests)
print(failures)
''',
                "solution": r'''from dataclasses import dataclass

@dataclass
class Book:
    item_id: str
    available: bool = True

class BookVaultError(Exception):
    """Base class for BookVault domain errors."""

class ItemNotFoundError(BookVaultError):
    pass

class ItemUnavailableError(BookVaultError, ValueError):
    pass

class UnknownMemberError(BookVaultError):
    pass

class DuplicateItemError(BookVaultError):
    pass

class Library:
    def __init__(self, name):
        self.name = name
        self.items = {}
        self.members = set()

    def add_item(self, item):
        if item.item_id in self.items:
            raise DuplicateItemError(f"{item.item_id} already exists")
        self.items[item.item_id] = item

    def add_member(self, member_id):
        self.members.add(member_id)

    def borrow(self, item_id, member_id):
        if item_id not in self.items:
            raise ItemNotFoundError(item_id)
        if member_id not in self.members:
            raise UnknownMemberError(member_id)
        item = self.items[item_id]
        if not item.available:
            raise ItemUnavailableError(f"{item_id} is unavailable")
        item.available = False

def replay(requests):
    lib = Library("Evidence Locker")
    failures = []
    for request in requests:
        clerk, action = request[0], request[1]
        try:
            if action == "add":
                lib.add_item(Book(request[2]))
            elif action == "join":
                lib.add_member(request[2])
            else:
                lib.borrow(request[2], request[3])
        except BookVaultError as e:
            failures.append((clerk, type(e).__name__))
    return failures

failures = replay(requests)
print(failures)
''',
                "tests": r'''for _n in ("ItemNotFoundError", "ItemUnavailableError", "UnknownMemberError", "DuplicateItemError"):
    _cls = globals().get(_n)
    assert isinstance(_cls, type), f"define a class called {_n}"
    assert issubclass(_cls, BookVaultError), f"{_n} should be a child of BookVaultError"
assert issubclass(ItemUnavailableError, ValueError), "ItemUnavailableError should also be a ValueError: class ItemUnavailableError(BookVaultError, ValueError)"
assert not issubclass(ItemNotFoundError, ValueError), "only ItemUnavailableError also inherits ValueError"
def _what(_fn, *_args):
    try:
        _fn(*_args)
    except Exception as _e:
        return type(_e).__name__
    return "no error"
_lib = Library("t")
_lib.add_item(Book("B1"))
_lib.add_member("M1")
_w = _what(_lib.borrow, "B9", "M1")
assert _w == "ItemNotFoundError", f"borrowing an unknown item should raise ItemNotFoundError, got {_w}"
_w = _what(_lib.borrow, "B9", "M9")
assert _w == "ItemNotFoundError", f"an unknown item AND an unknown member: the item is checked first, so ItemNotFoundError; got {_w}"
_w = _what(_lib.borrow, "B1", "M9")
assert _w == "UnknownMemberError", f"borrowing for an unknown member should raise UnknownMemberError, got {_w}"
_w = _what(_lib.add_item, Book("B1"))
assert _w == "DuplicateItemError", f"adding an id that exists should raise DuplicateItemError, got {_w}"
_lib.borrow("B1", "M1")
_w = _what(_lib.borrow, "B1", "M1")
assert _w == "ItemUnavailableError", f"borrowing a lent-out item should raise ItemUnavailableError, got {_w}"
_items, _members, _exp = {}, set(), []
for _r in requests:
    if _r[1] == "add":
        if _r[2] in _items:
            _exp.append((_r[0], "DuplicateItemError"))
        else:
            _items[_r[2]] = True
    elif _r[1] == "join":
        _members.add(_r[2])
    elif _r[2] not in _items:
        _exp.append((_r[0], "ItemNotFoundError"))
    elif _r[3] not in _members:
        _exp.append((_r[0], "UnknownMemberError"))
    elif not _items[_r[2]]:
        _exp.append((_r[0], "ItemUnavailableError"))
    else:
        _items[_r[2]] = False
assert failures == _exp, f"on this evidence failures should be {_exp}, got {failures!r}"''',
                "tips": [
                    "Each class is two lines: `class ItemNotFoundError(BookVaultError):` and an indented `pass`. Give `ItemUnavailableError` both parents: `class ItemUnavailableError(BookVaultError, ValueError):`.",
                    "In `borrow`, check before you look up: `if item_id not in self.items: raise ItemNotFoundError(item_id)`, then the member check, then `raise ItemUnavailableError(...)`. In `add_item`, swap `ValueError` for `DuplicateItemError`.",
                ],
                "reveal": "Now the log reads like a charge sheet: not-found items, unknown cards, double adds. One clerk's name keeps coming up.",
            },
            {
                "notes": """Assignment Q6 asks for four tests, one per error:
- borrowing an unknown item raises `ItemNotFoundError`
- borrowing for an unknown member raises `UnknownMemberError`
- borrowing an unavailable item raises `ItemUnavailableError`
- adding a duplicate item raises `DuplicateItemError`

A test **fails** when the error it expects is not raised, or when a different error escapes.""",
                "question": """**Goal:** pin the new behaviour down with tests, then name the clerk behind the most failed requests.

**You have:** everything from step 1 in the editor (the errors, `Book`, `Library`, `replay`), the `raises` helper and `run_tests(namespace)` from the lessons, and `failures = replay(requests)`.

Two of the four tests are already written (`test_unknown_item_raises`, `test_duplicate_item_raises`); copy their shape.

**Write** the other two test functions. Each makes its own `Library("Test Locker")`, sets up only what it needs, and expects the **exact** error class (not `BookVaultError`, which would also pass for the wrong error):
- `test_unknown_member_raises`: add an item, then expect `UnknownMemberError` when borrowing it for a member id that was never registered
- `test_unavailable_item_raises`: add an item and a member, borrow once, then expect `ItemUnavailableError` on the second borrow

**Then** store `culprit`: the clerk who appears most often in `failures` (a string). `run_tests(globals())` should print `4 passed, 0 failed`.

**Example:** if `failures` were `[("Ana", "ItemNotFoundError"), ("Ben", "DuplicateItemError"), ("Ana", "UnknownMemberError")]`, `culprit` would be `"Ana"`.""",
                "starter": r'''from contextlib import contextmanager
from dataclasses import dataclass

@dataclass
class Book:
    item_id: str
    available: bool = True

class BookVaultError(Exception):
    """Base class for BookVault domain errors."""

class ItemNotFoundError(BookVaultError):
    pass

class ItemUnavailableError(BookVaultError, ValueError):
    pass

class UnknownMemberError(BookVaultError):
    pass

class DuplicateItemError(BookVaultError):
    pass

class Library:
    def __init__(self, name):
        self.name = name
        self.items = {}
        self.members = set()

    def add_item(self, item):
        if item.item_id in self.items:
            raise DuplicateItemError(f"{item.item_id} already exists")
        self.items[item.item_id] = item

    def add_member(self, member_id):
        self.members.add(member_id)

    def borrow(self, item_id, member_id):
        if item_id not in self.items:
            raise ItemNotFoundError(item_id)
        if member_id not in self.members:
            raise UnknownMemberError(member_id)
        item = self.items[item_id]
        if not item.available:
            raise ItemUnavailableError(f"{item_id} is unavailable")
        item.available = False

def replay(requests):
    lib = Library("Evidence Locker")
    failures = []
    for request in requests:
        clerk, action = request[0], request[1]
        try:
            if action == "add":
                lib.add_item(Book(request[2]))
            elif action == "join":
                lib.add_member(request[2])
            else:
                lib.borrow(request[2], request[3])
        except BookVaultError as e:
            failures.append((clerk, type(e).__name__))
    return failures

# ---- mini pytest (a stand-in; real pytest does this for you) ----

@contextmanager
def raises(error, match=""):
    try:
        yield
    except error as e:
        assert match in str(e), f"{match!r} is not in the message {str(e)!r}"
        return
    raise AssertionError(f"DID NOT RAISE {error.__name__}")

def run_tests(namespace):
    passed = 0
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"{name} PASSED")
                passed += 1
            except Exception as e:
                print(f"{name} FAILED: {type(e).__name__}: {e}")
                failed += 1
    print(f"===== {passed} passed, {failed} failed =====")

# ---- the tests start here ----

def test_unknown_item_raises():
    lib = Library("Test Locker")
    with raises(ItemNotFoundError):        # the item is checked before the member
        lib.borrow("B404", "M404")

def test_duplicate_item_raises():
    lib = Library("Test Locker")
    lib.add_item(Book("B001"))
    with raises(DuplicateItemError):
        lib.add_item(Book("B001"))

# write test_unknown_member_raises and test_unavailable_item_raises here


run_tests(globals())
failures = replay(requests)
culprit = ...
print(failures)
print(culprit)
''',
                "solution": r'''from contextlib import contextmanager
from dataclasses import dataclass

@dataclass
class Book:
    item_id: str
    available: bool = True

class BookVaultError(Exception):
    """Base class for BookVault domain errors."""

class ItemNotFoundError(BookVaultError):
    pass

class ItemUnavailableError(BookVaultError, ValueError):
    pass

class UnknownMemberError(BookVaultError):
    pass

class DuplicateItemError(BookVaultError):
    pass

class Library:
    def __init__(self, name):
        self.name = name
        self.items = {}
        self.members = set()

    def add_item(self, item):
        if item.item_id in self.items:
            raise DuplicateItemError(f"{item.item_id} already exists")
        self.items[item.item_id] = item

    def add_member(self, member_id):
        self.members.add(member_id)

    def borrow(self, item_id, member_id):
        if item_id not in self.items:
            raise ItemNotFoundError(item_id)
        if member_id not in self.members:
            raise UnknownMemberError(member_id)
        item = self.items[item_id]
        if not item.available:
            raise ItemUnavailableError(f"{item_id} is unavailable")
        item.available = False

def replay(requests):
    lib = Library("Evidence Locker")
    failures = []
    for request in requests:
        clerk, action = request[0], request[1]
        try:
            if action == "add":
                lib.add_item(Book(request[2]))
            elif action == "join":
                lib.add_member(request[2])
            else:
                lib.borrow(request[2], request[3])
        except BookVaultError as e:
            failures.append((clerk, type(e).__name__))
    return failures

# ---- mini pytest (a stand-in; real pytest does this for you) ----

@contextmanager
def raises(error, match=""):
    try:
        yield
    except error as e:
        assert match in str(e), f"{match!r} is not in the message {str(e)!r}"
        return
    raise AssertionError(f"DID NOT RAISE {error.__name__}")

def run_tests(namespace):
    passed = 0
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"{name} PASSED")
                passed += 1
            except Exception as e:
                print(f"{name} FAILED: {type(e).__name__}: {e}")
                failed += 1
    print(f"===== {passed} passed, {failed} failed =====")

# ---- the tests start here ----

def test_unknown_item_raises():
    lib = Library("Test Locker")
    with raises(ItemNotFoundError):        # the item is checked before the member
        lib.borrow("B404", "M404")

def test_duplicate_item_raises():
    lib = Library("Test Locker")
    lib.add_item(Book("B001"))
    with raises(DuplicateItemError):
        lib.add_item(Book("B001"))

def test_unknown_member_raises():
    lib = Library("Test Locker")
    lib.add_item(Book("B001"))
    with raises(UnknownMemberError):
        lib.borrow("B001", "M404")

def test_unavailable_item_raises():
    lib = Library("Test Locker")
    lib.add_item(Book("B001"))
    lib.add_member("M001")
    lib.borrow("B001", "M001")
    with raises(ItemUnavailableError):
        lib.borrow("B001", "M001")


run_tests(globals())
failures = replay(requests)
counts = {}
for clerk, error in failures:
    counts[clerk] = counts.get(clerk, 0) + 1
culprit = max(counts, key=counts.get)
print(failures)
print(culprit)
''',
                "tests": r'''_names = ["test_unknown_item_raises", "test_unknown_member_raises", "test_unavailable_item_raises", "test_duplicate_item_raises"]
for _n in _names:
    assert callable(globals().get(_n)), f"write a test function called {_n}"
for _n in _names:
    try:
        globals()[_n]()
    except Exception as _e:
        raise AssertionError(f"{_n} should pass on the correct Library, but it failed: {type(_e).__name__}: {_e}")
def _make(_bug):
    class _L:
        def __init__(self, name):
            self.name = name
            self.items = {}
            self.members = set()
        def add_item(self, item):
            if item.item_id in self.items:
                if _bug == "dup":
                    raise ValueError("duplicate")
                if _bug != "dup-silent":
                    raise DuplicateItemError(item.item_id)
            self.items[item.item_id] = item
        def add_member(self, member_id):
            self.members.add(member_id)
        def borrow(self, item_id, member_id):
            if _bug == "member-first" and member_id not in self.members:
                raise UnknownMemberError(member_id)
            if item_id not in self.items:
                if _bug == "nf":
                    raise KeyError(item_id)
                raise ItemNotFoundError(item_id)
            if member_id not in self.members:
                if _bug == "um":
                    raise KeyError(member_id)
                if _bug == "um-nf":
                    raise ItemNotFoundError(member_id)
                if _bug != "um-silent":
                    raise UnknownMemberError(member_id)
            if not self.items[item_id].available:
                if _bug == "ua":
                    raise ValueError("unavailable")
                if _bug == "ua-um":
                    raise UnknownMemberError(member_id)
                raise ItemUnavailableError(item_id)
            self.items[item_id].available = False
    return _L
def _caught(_bug):
    _real = globals()["Library"]
    globals()["Library"] = _make(_bug)
    try:
        for _n in _names:
            try:
                globals()[_n]()
            except Exception:
                return True
        return False
    finally:
        globals()["Library"] = _real
assert not _caught(None), "your tests should all pass on a correct Library"
for _bug, _why in [("nf", "raises KeyError for an unknown item"), ("um", "raises KeyError for an unknown member"), ("um-silent", "lends to unknown members"), ("ua", "raises a plain ValueError for an unavailable item"), ("dup", "raises a plain ValueError for a duplicate"), ("dup-silent", "silently accepts duplicate items"), ("um-nf", "raises ItemNotFoundError for an unknown member"), ("ua-um", "raises UnknownMemberError for an unavailable item"), ("member-first", "checks the member before the item")]:
    assert _caught(_bug), f"your tests should catch a Library that {_why}"
_c = {}
for _cl, _err in failures:
    _c[_cl] = _c.get(_cl, 0) + 1
_who = max(_c, key=_c.get)
assert culprit == _who, f"the clerk with the most failed requests is {_who}, got {culprit!r}"''',
                "tips": [
                    "Copy `test_duplicate_item_raises`: make `lib = Library(\"Test Locker\")`, add what the test needs (`lib.add_item(Book(\"B001\"))`, `lib.add_member(\"M001\")`), then put the failing call inside `with raises(UnknownMemberError):` or `with raises(ItemUnavailableError):`.",
                    "For the culprit, count with a dict: `for clerk, error in failures: counts[clerk] = counts.get(clerk, 0) + 1`, then `culprit = max(counts, key=counts.get)`.",
                ],
                "reveal": "Four green tests guard the new errors, and the tally is clear: one clerk was behind most of the probing, trying every kind of bad request in turn.",
            },
        ],
        "closing": "Case closed. With named errors the locker log turned from a wall of `ValueError` into a pattern: unknown items, forged member cards, double adds, all from one clerk testing where the system would break. The four tests stay in the suite, so nobody can quietly turn the errors back into mush.",
    },
    # ------------------------------------------------------------ decoy-kit
    {
        "id": "coverage-gap",
        "tier": "small",
        "title": "The Coverage Gap",
        "teaser": "The test suite is green. One branch of the fee code has never run. Guess where the bug is.",
        "skills": ["decoy-kit"],
        "story": """The evidence warehouse charges departments a storage fee for every item it keeps, and some departments are being overcharged. The fee code has a test suite, and the suite is green, so nobody looked further.

Forensics marked every branch of `storage_fee(kind, days)` with a `hit("name")` call, like the coverage lesson. Loaded:
- `PROBES`: the branch names in code order, `hits`: the set of branches that ran, `hit(name)`
- `storage_fee(kind, days)`: the fee code exactly as it is in production
- `suite_calls`: every `(kind, days)` call the lab's test suite makes
- `AUTHORS`: a dict from branch name to the technician who last edited that branch""",
        "suspects": [
            {"name": "the fee code's authors", "note": "Each edited one or two branches this year."},
        ],
        "variants": [
            r'''PROBES = ["start", "free", "standard", "cold", "hazmat", "cap"]
AUTHORS = {"start": "Noor", "free": "Noor", "standard": "Olu", "cold": "Pax", "hazmat": "Olu", "cap": "Noor"}
hits = set()

def hit(name):
    hits.add(name)

def storage_fee(kind, days):
    hit("start")
    if days <= 0:
        hit("free")
        return 0
    if kind == "standard":
        hit("standard")
        fee = days * 2
    elif kind == "cold":
        hit("cold")
        fee = days * 3
    else:
        hit("hazmat")
        fee = days * 10
    if fee > 100:
        hit("cap")
        fee = 100
    return fee

suite_calls = [("standard", 4), ("hazmat", 2), ("standard", 0), ("hazmat", 15), ("standard", 9)]
''',
            r'''PROBES = ["start", "free", "standard", "cold", "hazmat", "cap"]
AUTHORS = {"start": "Sol", "free": "Tia", "standard": "Sol", "cold": "Tia", "hazmat": "Sol", "cap": "Ugo"}
hits = set()

def hit(name):
    hits.add(name)

def storage_fee(kind, days):
    hit("start")
    if days <= 0:
        hit("free")
        return 0
    if kind == "standard":
        hit("standard")
        fee = days * 2
    elif kind == "cold":
        hit("cold")
        fee = days * 5
    else:
        hit("hazmat")
        fee = days * 10
    if fee > 100:
        hit("cap")
        fee = 100 + days
    return fee

suite_calls = [("cold", 3), ("standard", 20), ("hazmat", 0), ("hazmat", 6), ("cold", 12), ("standard", 1)]
''',
            r'''PROBES = ["start", "free", "standard", "cold", "hazmat", "cap"]
AUTHORS = {"start": "Wim", "free": "Yara", "standard": "Wim", "cold": "Xeno", "hazmat": "Xeno", "cap": "Wim"}
hits = set()

def hit(name):
    hits.add(name)

def storage_fee(kind, days):
    hit("start")
    if days <= 0:
        hit("free")
        return 5
    if kind == "standard":
        hit("standard")
        fee = days * 2
    elif kind == "cold":
        hit("cold")
        fee = days * 5
    else:
        hit("hazmat")
        fee = days * 10
    if fee > 100:
        hit("cap")
        fee = 100
    return fee

suite_calls = [("hazmat", 30), ("cold", 4), ("standard", 7), ("cold", 25), ("hazmat", 1)]
''',
        ],
        "steps": [
            {
                "notes": """**Coverage** records which parts of the code ran while the tests ran. Here each branch announces itself with `hit("name")`, and `hits` remembers the names.

- **Missing**: the branches in `PROBES` that are not in `hits`, in `PROBES` order. No test ever reached them.
- **Cover**: the share of branches that ran, as a whole percent: `round(100 * (number of branches - number missing) / number of branches)`.

A branch no test reaches is the safest place to hide a bug.""",
                "question": """**Goal:** run the lab's test calls and find the branch they never reach, and who last edited it.

**You have:** `PROBES` (e.g. `["start", "free", ...]`), `hits` (a set), `storage_fee(kind, days)`, `suite_calls` (a list of `(kind, days)` tuples, e.g. `[("standard", 4), ("hazmat", 2)]`) and `AUTHORS` (branch name to technician).

**Write** code that:
- empties `hits` with `hits.clear()`, then calls `storage_fee(kind, days)` once for every tuple in `suite_calls`
- stores `missing`: the list of branch names from `PROBES` that are not in `hits`, in `PROBES` order
- stores `cover`: the whole-number percent from the field notes (an int)
- stores `suspect`: the author (from `AUTHORS`) of the **first** missing branch

**Then** print the three (the starter already does).

**Example:** with `PROBES = ["a", "b", "c", "d"]` and `hits = {"a", "c", "d"}`, `missing` is `["b"]` and `cover` is `75`.""",
                "starter": r'''missing = []
cover = 100
suspect = ...
print("Missing:", missing, "Cover:", cover, "%")
print("Suspect:", suspect)
''',
                "solution": r'''hits.clear()
for kind, days in suite_calls:
    storage_fee(kind, days)
missing = [p for p in PROBES if p not in hits]
cover = round(100 * (len(PROBES) - len(missing)) / len(PROBES))
suspect = AUTHORS[missing[0]]
print("Missing:", missing, "Cover:", cover, "%")
print("Suspect:", suspect)
''',
                "tests": r'''hits.clear()
for _k, _d in suite_calls:
    storage_fee(_k, _d)
_miss = [p for p in PROBES if p not in hits]
assert missing == _miss, f"after running suite_calls the missing branches are {_miss}, got {missing!r}"
_cov = round(100 * (len(PROBES) - len(_miss)) / len(PROBES))
assert cover == _cov, f"cover should be {_cov} (a whole percent), got {cover!r}"
assert suspect == AUTHORS[_miss[0]], f"the first missing branch is {_miss[0]!r}, last edited by {AUTHORS[_miss[0]]}; got {suspect!r}"''',
                "tips": [
                    "`hits.clear()`, then `for kind, days in suite_calls: storage_fee(kind, days)`. After that loop, `hits` holds every branch the suite reached.",
                    "`missing = [p for p in PROBES if p not in hits]`, `cover = round(100 * (len(PROBES) - len(missing)) / len(PROBES))`, `suspect = AUTHORS[missing[0]]`.",
                ],
                "reveal": "The suite looked thorough, yet one branch has never run in any test: the branch nobody tested is the one to look at next.",
            },
            {
                "notes": """The warehouse's fee rules (what `storage_fee(kind, days)` **should** return):
- `days` is 0 or less: the fee is `0`
- `kind` `"standard"`: `2` per day
- `kind` `"cold"`: `5` per day
- any other kind (hazardous material): `10` per day
- the fee is **never more than `100`**: anything above becomes exactly `100`

Coverage only says a branch **ran**. A test proves something only when it **asserts** the right answer.""",
                "question": """**Goal:** write tests that reach every branch **and** check the answer, so the hidden bug shows up as a failing test.

**You have:** everything from the evidence, and in the editor `run_suite(namespace)`: it empties `hits`, runs every `test_` function, prints `PASSED` or `FAILED` for each and the Missing list, and returns the list of names of the tests that failed.

**Write** test functions (names starting with `test_`), each with at least one `assert` comparing `storage_fee(...)` to the right fee from the field notes. Together they must reach **all six** branches: 0 days, standard, cold, hazardous, and a fee above 100 that gets capped.

**Then** store `failed = run_suite(globals())` and print it. With correct expected values, the test that reaches the tampered branch fails and every other test passes.

**Example:** `assert storage_fee("standard", 3) == 6` reaches `start` and `standard`. `assert storage_fee("hazmat", 12) == 100` reaches `hazmat` and `cap`.""",
                "starter": r'''def run_suite(namespace):
    hits.clear()
    failed = []
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(name, "PASSED")
            except Exception as e:
                print(name, "FAILED:", type(e).__name__, e)
                failed.append(name)
    missing = [p for p in PROBES if p not in hits]
    print("Missing:", ", ".join(missing) or "none")
    return failed

# ---- the tests start here ----

def test_standard():
    storage_fee("standard", 3)


failed = run_suite(globals())
print(failed)
''',
                "solution": r'''def run_suite(namespace):
    hits.clear()
    failed = []
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(name, "PASSED")
            except Exception as e:
                print(name, "FAILED:", type(e).__name__, e)
                failed.append(name)
    missing = [p for p in PROBES if p not in hits]
    print("Missing:", ", ".join(missing) or "none")
    return failed

# ---- the tests start here ----

def test_standard():
    assert storage_fee("standard", 3) == 6

def test_free():
    assert storage_fee("cold", 0) == 0

def test_cold():
    assert storage_fee("cold", 4) == 20

def test_hazmat():
    assert storage_fee("hazmat", 2) == 20

def test_cap():
    assert storage_fee("hazmat", 12) == 100


failed = run_suite(globals())
print(failed)
''',
                "tests": r'''_tests = [(_n, _f) for _n, _f in list(globals().items()) if _n.startswith("test_") and callable(_f)]
assert _tests, "write at least one test function whose name starts with test_"
def _good_fee(kind, days):
    hit("start")
    if days <= 0:
        hit("free")
        return 0
    if kind == "standard":
        hit("standard")
        fee = days * 2
    elif kind == "cold":
        hit("cold")
        fee = days * 5
    else:
        hit("hazmat")
        fee = days * 10
    if fee > 100:
        hit("cap")
        fee = 100
    return fee
def _run_with(_fee):
    _real = globals()["storage_fee"]
    globals()["storage_fee"] = _fee
    hits.clear()
    _bad = []
    try:
        for _n, _f in _tests:
            try:
                _f()
            except Exception:
                _bad.append(_n)
    finally:
        globals()["storage_fee"] = _real
    return _bad
_b = _run_with(_good_fee)
assert _b == [], f"on the CORRECT fee code these tests failed: {_b}. Check their expected values against the field notes"
_miss = [p for p in PROBES if p not in hits]
assert _miss == [], f"with the correct fee code your tests never reach: {', '.join(_miss)}. Add tests for those branches"
def _no_cap(kind, days):
    if days <= 0:
        return 0
    return days * (2 if kind == "standard" else 5 if kind == "cold" else 10)
def _rate(r):
    def _f(kind, days):
        if kind == "standard" and days > 0:
            return min(days * r, 100)
        return _good_fee(kind, days)
    return _f
for _fee, _why in [(_no_cap, "has no cap at 100"), (_rate(3), "charges 3 a day for standard"), (lambda k, d: 1 if d <= 0 else _good_fee(k, d), "charges for 0 days"), (lambda k, d: min(d * 4, 100) if k == "cold" and d > 0 else _good_fee(k, d), "charges 4 a day for cold"), (lambda k, d: min(d * 8, 100) if k not in ("standard", "cold") and d > 0 else _good_fee(k, d), "charges 8 a day for hazardous items")]:
    assert _run_with(_fee), f"your tests should catch a fee function that {_why}: assert the exact fee in every test"
_exp = _run_with(storage_fee)
assert failed == _exp, f"on this evidence the failing tests should be {_exp}, got {failed!r}"
assert failed, "at least one test should fail on the tampered storage_fee"''',
                "tips": [
                    "One small test per branch: `def test_cold(): assert storage_fee(\"cold\", 4) == 20`. Work each expected fee out from the field notes, not from what the code returns.",
                    "The cap needs a fee above 100, e.g. `storage_fee(\"hazmat\", 12)` should be `100`. The free branch needs `days` of 0. Keep `failed = run_suite(globals())` at the end.",
                ],
                "reveal": "Every branch now runs and every answer is checked. One test goes red, right on the branch the old suite never touched.",
            },
        ],
        "closing": "Case closed. The old suite was green because it never looked where the change was made. Coverage pointed at the gap, and asserting real answers turned the gap into a failing test. The overcharges are refunded and the branch's last editor has some explaining to do.",
    },
    # ------------------------------------------------------------ task-force (Q12)
    {
        "id": "race-lab",
        "tier": "small",
        "title": "The Race Lab",
        "teaser": "Every scanner beeped. The intake counter says fewer items came in. Whose count vanished first?",
        "skills": ["task-force"],
        "story": """Several technicians scan evidence bags into the lab at the same time, and every scanner adds 1 to one shared intake counter. Tonight the counter is short: bags were scanned, yet the total doesn't add up, and the first bag to vanish was from the warehouse raid.

The scanners run as threads. Forensics recovered `schedule`, the exact order in which the threads touched the counter: a list of `(thread, action)` steps, where `action` is `"read"` or `"write"`.

*(This is the official assignment Q12: the race condition lab.)*""",
        "suspects": [
            {"name": "the scanner threads", "note": "Each is named after the technician who started it."},
        ],
        "variants": [
            r'''schedule = [
    ("Ana", "read"), ("Ben", "read"), ("Ana", "write"), ("Ben", "write"),
    ("Cat", "read"), ("Cat", "write"),
    ("Ana", "read"), ("Ben", "read"), ("Ben", "write"), ("Ana", "write"),
    ("Ben", "read"), ("Cat", "read"), ("Ben", "write"), ("Cat", "write"),
]
''',
            r'''schedule = [
    ("Ink", "read"), ("Ink", "write"),
    ("Jet", "read"), ("Kit", "read"), ("Kit", "write"), ("Jet", "write"),
    ("Kit", "read"), ("Kit", "write"),
    ("Ink", "read"), ("Jet", "read"), ("Ink", "write"), ("Jet", "write"),
    ("Jet", "read"), ("Jet", "write"),
]
''',
            r'''schedule = [
    ("Abe", "read"), ("Abe", "write"), ("Bo", "read"), ("Bo", "write"),
    ("Cy", "read"), ("Dee", "read"), ("Cy", "write"),
    ("Abe", "read"), ("Abe", "write"), ("Dee", "write"),
    ("Bo", "read"), ("Bo", "write"),
]
''',
        ],
        "steps": [
            {
                "notes": """Why `counter += 1` is not safe with threads: it looks like one step but is three: **read** the counter, **add** 1, **write** it back. Another thread can run between the read and the write.

In `schedule`:
- `"read"`: the thread copies the current counter into its own private copy
- `"write"`: the thread sets the counter to **its copy + 1**

A write **loses an update** when, at the moment of writing, the counter is no longer the value that thread read: someone else wrote in between, and this write throws their update away. The **victim** is the thread that made the most recent write before it (the update that just got erased).""",
                "question": """**Goal:** find the first moment the night's count went wrong: which step, which thread wrote over whom.

**You have:** `schedule`, a list of `(thread, action)` tuples, e.g. `[("Ana", "read"), ("Ben", "read"), ("Ana", "write"), ("Ben", "write")]`.

**Write** a function `first_lost_update(schedule)`:
- start the counter at 0 and apply the steps in order (field notes), remembering what each thread read and which thread wrote last
- at the **first** write that loses an update, return a tuple `(index, clobberer, victim)`: the position of that step in `schedule` (counting from 0), the thread making that write, and the thread whose write it erased
- if no write ever loses an update, return `None`

**Then** store `index, clobberer, victim = first_lost_update(schedule)` and print them.

**Example:** for `[("A", "read"), ("B", "read"), ("A", "write"), ("B", "write")]` both read 0; A writes 1; then B writes 1 while the counter is already 1, erasing A's update. The answer is `(3, "B", "A")`.""",
                "starter": r'''def first_lost_update(schedule):
    counter = 0
    seen = {}
    last_writer = None
    return None

index, clobberer, victim = first_lost_update(schedule)
print(index, clobberer, victim)
''',
                "solution": r'''def first_lost_update(schedule):
    counter = 0
    seen = {}
    last_writer = None
    for i, (thread, action) in enumerate(schedule):
        if action == "read":
            seen[thread] = counter
        else:
            if counter != seen[thread]:
                return i, thread, last_writer
            counter = seen[thread] + 1
            last_writer = thread
    return None

index, clobberer, victim = first_lost_update(schedule)
print(index, clobberer, victim)
''',
                "tests": r'''def _first(s):
    c, seen, last = 0, {}, None
    for i, (t, a) in enumerate(s):
        if a == "read":
            seen[t] = c
        else:
            if c != seen[t]:
                return i, t, last
            c = seen[t] + 1
            last = t
    return None
_ex = [("A", "read"), ("B", "read"), ("A", "write"), ("B", "write")]
_r = first_lost_update(_ex)
assert _r == (3, "B", "A"), f"for the example the answer is (3, 'B', 'A'), got {_r!r}"
_safe = [("A", "read"), ("A", "write"), ("B", "read"), ("B", "write")]
_r = first_lost_update(_safe)
assert _r is None, f"when no write loses an update, return None; got {_r!r}"
_three = [("A", "read"), ("A", "write"), ("B", "read"), ("C", "read"), ("C", "write"), ("A", "read"), ("A", "write"), ("B", "write")]
_r = first_lost_update(_three)
assert _r == (7, "B", "A"), f"B read 1, then C and A both wrote; B's write erases the latest one, A's: expected (7, 'B', 'A'), got {_r!r}"
_exp = _first(schedule)
assert (index, clobberer, victim) == _exp, f"on this evidence the first lost update is {_exp}, got {(index, clobberer, victim)!r}"''',
                "tips": [
                    "Loop with `for i, (thread, action) in enumerate(schedule):`. On `\"read\"`: `seen[thread] = counter`. On `\"write\"`: check `if counter != seen[thread]:` before you change anything.",
                    "When the check is true, `return i, thread, last_writer`. Otherwise `counter = seen[thread] + 1` and `last_writer = thread`. After the loop, `return None`.",
                ],
                "reveal": "The replay pins the first loss to a single step: one scanner wrote back a copy it had read before another scanner's write, and that count vanished.",
            },
            {
                "notes": """The fix for a read-modify-write race is a **lock**: `lock = threading.Lock()`, then `with lock:` around the read **and** the write. Only one thread can be inside the `with` block at a time, so no other thread can slip in between.

With threads: `start()` every thread first, then `join()` every thread, so all the work is finished before you read the result.

(This browser runs threads one after another, so it can't show a real race; the replay in step 1 shows what happens on a real machine.)""",
                "question": """**Goal:** rerun the night's scans with real threads and a lock, so no update can be lost.

**You have:** `schedule` (as in step 1) and, in the editor, an unsafe `safe_total` that you must fix.

**Write** `safe_total(counts, lock)`:
- `counts` is a dict from thread name to how many increments that thread does, e.g. `{"Ana": 3, "Ben": 2}`; `lock` is the lock to use (the checker passes its own lock that counts how often it is entered)
- start one `threading.Thread` per entry, running `add_many(n)`
- inside `add_many`, put the read **and** the write of every single increment under `with lock:` (enter the lock once per increment)
- `start()` every thread, then `join()` every thread, then return the final count

**Then** store:
- `writes`: a dict from each thread in `schedule` to its number of `"write"` steps
- `fixed = safe_total(writes, threading.Lock())`; with the lock it equals the total number of writes

**Example:** `safe_total({"x": 5, "y": 7}, threading.Lock())` returns `12`, and enters the lock 12 times.""",
                "starter": r'''import threading

def safe_total(counts, lock):
    tally = {"count": 0}

    def add_many(n):
        for _ in range(n):
            value = tally["count"]
            tally["count"] = value + 1

    threads = [threading.Thread(target=add_many, args=(n,)) for n in counts.values()]
    for t in threads:
        t.start()
    return tally["count"]

writes = {}
fixed = ...
print(writes, fixed)
''',
                "solution": r'''import threading

def safe_total(counts, lock):
    tally = {"count": 0}

    def add_many(n):
        for _ in range(n):
            with lock:
                value = tally["count"]
                tally["count"] = value + 1

    threads = [threading.Thread(target=add_many, args=(n,)) for n in counts.values()]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return tally["count"]

writes = {}
for thread, action in schedule:
    if action == "write":
        writes[thread] = writes.get(thread, 0) + 1
fixed = safe_total(writes, threading.Lock())
print(writes, fixed)
''',
                "tests": r'''class _CountingLock:
    def __init__(self):
        self.entries = 0
        self.held = False
    def __enter__(self):
        assert not self.held, "the lock was entered while already held"
        self.entries += 1
        self.held = True
        return self
    def __exit__(self, *exc):
        self.held = False
        return False
_counts = {"x": 5, "y": 7}
_lk = _CountingLock()
_st = safe_total(_counts, _lk)
assert _st == 12, f"safe_total with x: 5 and y: 7 should return 12, got {_st!r}"
assert _lk.entries == 12, f"the lock should be entered once per increment (12 times), but it was entered {_lk.entries} times: use `with lock:` inside the loop"
_lk = _CountingLock()
_st = safe_total({}, _lk)
assert _st == 0, f"with no threads the total is 0, got {_st!r}"
assert ".join()" in __source__, "join every thread before returning the count"
_w = {}
for _t, _a in schedule:
    if _a == "write":
        _w[_t] = _w.get(_t, 0) + 1
assert writes == _w, f"on this evidence writes should be {_w}, got {writes!r}"
_total = sum(_w.values())
assert fixed == _total, f"with the lock no update is lost: fixed should be {_total}, got {fixed!r}"''',
                "tips": [
                    "Indent the two lines of the loop body under `with lock:`, using the `lock` parameter (don't make a new lock inside `safe_total`).",
                    "After the `start()` loop add `for t in threads: t.join()`. For `writes`, count with `writes[thread] = writes.get(thread, 0) + 1` for every step whose action is `\"write\"`, then `fixed = safe_total(writes, threading.Lock())`.",
                ],
                "reveal": "With the lock, every scan counts: the total matches the number of writes exactly. The bags \"lost\" in the night were never lost, only overwritten.",
            },
        ],
        "closing": "Case closed. `counter += 1` was never one step, and one scanner thread wrote back a stale copy between another's read and write. A lock made the read and the write one unit. (Even safer, and the assignment's bonus: let each thread count on its own and add the totals at the end, so nothing is shared at all.)",
    },
    # ------------------------------------------------------------ task-force (Q13)
    {
        "id": "heavy-lifting",
        "tier": "small",
        "title": "Heavy Lifting",
        "teaser": "The lab's analytics crawl. A process pool would help, if someone hadn't slipped in a job it can't carry.",
        "skills": ["task-force"],
        "story": """The lab scores how hard every seized ledger is to analyse, and the job takes ages. Pure calculation like this is **CPU-bound**, so the plan is a process pool. But last week's pool run crashed: one technician's scoring function could not be sent to the worker processes.

Forensics loaded:
- `books`: the ledgers to score, as dicts like `{"id": "L1", "pages": 12}`
- `submitted`: a dict from technician name to the scoring function they handed in for the pool run

*(This is the official assignment Q13: `ProcessPoolExecutor` for CPU-bound analytics.)*""",
        "suspects": [
            {"name": "the technicians who submitted jobs", "note": "Each says their function works fine when they run it themselves."},
        ],
        "variants": [
            r'''books = [
    {"id": "L1", "pages": 12}, {"id": "L2", "pages": 30}, {"id": "L3", "pages": 7},
    {"id": "L4", "pages": 25}, {"id": "L5", "pages": 18}, {"id": "L6", "pages": 9},
]

def score_by_pages(book):
    return book["pages"] * 3

def _fast_score_v2(book):
    return book["pages"] % 11

submitted = {
    "Asha": score_by_pages,
    "Bram": lambda book: book["pages"] % 7,
    "Cass": _fast_score_v2,
}
''',
            r'''books = [
    {"id": "M1", "pages": 40}, {"id": "M2", "pages": 5}, {"id": "M3", "pages": 22},
    {"id": "M4", "pages": 33}, {"id": "M5", "pages": 14},
]

def page_score(book):
    return book["pages"] * 2

def make_scorer(weight):
    def weighted(book):
        return book["pages"] * weight
    return weighted

weighted = make_scorer(3)
weighted.__qualname__ = "make_scorer.<locals>.weighted"   # what CPython reports (the browser's Python shortens it)

submitted = {
    "Dov": weighted,
    "Elin": page_score,
    "Fay": len,
}
''',
            r'''books = [
    {"id": "N1", "pages": 16}, {"id": "N2", "pages": 16}, {"id": "N3", "pages": 48},
    {"id": "N4", "pages": 3}, {"id": "N5", "pages": 27}, {"id": "N6", "pages": 11},
    {"id": "N7", "pages": 20},
]

def ledger_score(book):
    return book["pages"] + 1

def build_job():
    def job(book):
        return book["pages"] * 5
    return job

job = build_job()
job.__qualname__ = "build_job.<locals>.job"   # what CPython reports (the browser's Python shortens it)

submitted = {
    "Gwen": ledger_score,
    "Hugo": lambda book: book["pages"],
    "Ines": job,
    "Joss": ledger_score,
}
''',
        ],
        "steps": [
            {
                "notes": """The lab's difficulty score (assignment Q13, scaled down so it runs in the browser): for a book with `pages` pages, add up `(i * i) % 97` for every `i` from `0` up to (not including) `pages * 100`.

Timing in this case: scoring one book takes `pages * 10` milliseconds of CPU time.
- **One after another**, the total time is the sum of all the books' times.
- In a **pool of 3 workers**, each book goes to the worker that is free soonest; the batch takes as long as the busiest worker. The `MiniExecutor` in the editor works this out (its `free_at` list holds when each worker is next free).
- **Speed-up** = time one after another / time with the pool.""",
                "question": """**Goal:** score every ledger and measure how much a 3-worker pool would save.

**You have:** `books`, a list of dicts like `{"id": "L1", "pages": 12}`. In the editor: the lesson's `MiniFuture` and `MiniExecutor` (`pool.map(fn, args, takes_ms)` returns the results in input order).

**Write** a function `difficulty_score(book)` that returns the score from the field notes (an int).

**Then** store:
- `takes`: a list with each book's time in ms (`pages * 10`), in the order of `books`
- `pool = MiniExecutor(max_workers=3)` and `scores = pool.map(difficulty_score, books, takes)`
- `sequential_ms`: the time one after another (an int)
- `pool_ms`: the time with the pool, `max(pool.free_at)`
- `speedup`: `sequential_ms / pool_ms` rounded to 2 decimals

**Example:** `difficulty_score({"pages": 1})` adds `(i * i) % 97` for `i` from 0 to 99 and gives `4661`.""",
                "starter": r'''class MiniFuture:
    def __init__(self, fn, arg, finish_ms):
        self.finish_ms = finish_ms
        try:
            self._value, self._error = fn(arg), None
        except Exception as e:
            self._value, self._error = None, e

    def result(self):
        if self._error is not None:
            raise self._error
        return self._value

class MiniExecutor:
    """A pretend pool: each job says how long it takes; nothing really waits."""
    def __init__(self, max_workers):
        self.free_at = [0] * max_workers

    def submit(self, fn, arg, takes_ms):
        w = self.free_at.index(min(self.free_at))
        self.free_at[w] += takes_ms
        return MiniFuture(fn, arg, self.free_at[w])

    def map(self, fn, args, takes_ms):
        futures = [self.submit(fn, a, t) for a, t in zip(args, takes_ms)]
        return [f.result() for f in futures]

def difficulty_score(book):
    return 0

takes = []
scores = []
sequential_ms = 0
pool_ms = 1
speedup = ...
print(scores)
print(sequential_ms, "ms one after another,", pool_ms, "ms with 3 workers, speed-up", speedup)
''',
                "solution": r'''class MiniFuture:
    def __init__(self, fn, arg, finish_ms):
        self.finish_ms = finish_ms
        try:
            self._value, self._error = fn(arg), None
        except Exception as e:
            self._value, self._error = None, e

    def result(self):
        if self._error is not None:
            raise self._error
        return self._value

class MiniExecutor:
    """A pretend pool: each job says how long it takes; nothing really waits."""
    def __init__(self, max_workers):
        self.free_at = [0] * max_workers

    def submit(self, fn, arg, takes_ms):
        w = self.free_at.index(min(self.free_at))
        self.free_at[w] += takes_ms
        return MiniFuture(fn, arg, self.free_at[w])

    def map(self, fn, args, takes_ms):
        futures = [self.submit(fn, a, t) for a, t in zip(args, takes_ms)]
        return [f.result() for f in futures]

def difficulty_score(book):
    total = 0
    for i in range(book["pages"] * 100):
        total += (i * i) % 97
    return total

takes = [book["pages"] * 10 for book in books]
pool = MiniExecutor(max_workers=3)
scores = pool.map(difficulty_score, books, takes)
sequential_ms = sum(takes)
pool_ms = max(pool.free_at)
speedup = round(sequential_ms / pool_ms, 2)
print(scores)
print(sequential_ms, "ms one after another,", pool_ms, "ms with 3 workers, speed-up", speedup)
''',
                "tests": r'''def _score(b):
    _t = 0
    for _i in range(b["pages"] * 100):
        _t += (_i * _i) % 97
    return _t
_ds = difficulty_score({"pages": 1})
assert _ds == 4661, f"difficulty_score({{'pages': 1}}) should be 4661, got {_ds!r}"
assert difficulty_score({"pages": 3}) == _score({"pages": 3}), "difficulty_score should loop over range(pages * 100)"
assert difficulty_score({"pages": 0}) == 0, "a book with 0 pages scores 0"
_tk = [b["pages"] * 10 for b in books]
assert takes == _tk, f"takes should be {_tk}, got {takes!r}"
_exp = [_score(b) for b in books]
assert scores == _exp, f"scores should be the difficulty of each book in the order of books: {_exp}, got {scores!r}"
_free = [0, 0, 0]
for _t in _tk:
    _w = _free.index(min(_free))
    _free[_w] += _t
assert sequential_ms == sum(_tk), f"one after another takes {sum(_tk)} ms, got {sequential_ms!r}"
assert pool_ms == max(_free), f"with 3 workers the batch takes {max(_free)} ms, got {pool_ms!r}"
assert speedup == round(sum(_tk) / max(_free), 2), f"speedup should be {round(sum(_tk) / max(_free), 2)}, got {speedup!r}"''',
                "tips": [
                    "Start `total = 0`, then `for i in range(book[\"pages\"] * 100): total += (i * i) % 97`, and return `total`.",
                    "`takes = [book[\"pages\"] * 10 for book in books]`. After `scores = pool.map(difficulty_score, books, takes)`, the pool's `free_at` list holds each worker's finishing time, so `pool_ms = max(pool.free_at)`.",
                ],
                "reveal": "On paper the pool cuts the run to a fraction of the time. So why did last week's real pool run crash?",
            },
            {
                "notes": """A process pool sends each job to another Python process by **pickling** it (turning it into bytes). That works for functions defined at the **top level** of a file, and for built-ins like `len`. It fails for:
- a **lambda**: its `__name__` is `"<lambda>"`
- a function defined **inside another function**: its `__qualname__` (its full name) contains `"<locals>"`, e.g. `"make_scorer.<locals>.weighted"`

(This name check is a quick test, not the full rule: open files and locks can't be pickled either.)

Each worker process **imports** your file. Code that starts the pool must sit under `if __name__ == "__main__":`, or the workers would try to start pools of their own; on Windows and macOS Python stops with a `RuntimeError`.""",
                "question": """**Goal:** find which submitted functions can't be sent to a process pool, with the run safely behind the main guard.

**You have:** `submitted`, a dict from technician name to a function, e.g. `{"Asha": score_by_pages, "Bram": <a lambda>}`.

**Write:**
- `can_send_to_process(fn)`: returns `False` if `fn.__name__` is `"<lambda>"` or `"<locals>"` is in `fn.__qualname__`, otherwise `True`
- `main()`: returns a **sorted** list of the names in `submitted` whose function can't be sent

**Then** move the last line, `rejected = main()`, under an `if __name__ == "__main__":` guard (indented), and print `rejected` inside the guard too.

**Example:** `can_send_to_process(len)` is `True`; `can_send_to_process(lambda b: 1)` is `False`.""",
                "starter": r'''def can_send_to_process(fn):
    return True

def main():
    return []

rejected = main()
print(rejected)
''',
                "solution": r'''def can_send_to_process(fn):
    return not (fn.__name__ == "<lambda>" or "<locals>" in fn.__qualname__)

def main():
    return sorted(name for name, fn in submitted.items() if not can_send_to_process(fn))

if __name__ == "__main__":
    rejected = main()
    print(rejected)
''',
                "tests": r'''def _outer():
    def _inner(x):
        return x
    return _inner
_nested = _outer()
_nested.__qualname__ = "_outer.<locals>._inner"   # what CPython reports (the browser's Python shortens it)
def _top(b):
    return b
assert can_send_to_process(_top) is True, "a top-level function can be pickled"
assert can_send_to_process(len) is True, "built-in functions like len can be pickled"
assert can_send_to_process(lambda b: b) is False, "a lambda can't be pickled"
assert can_send_to_process(_nested) is False, "a function defined inside another function can't be pickled"
assert 'if __name__ == "__main__":' in __source__ or "if __name__ == '__main__':" in __source__, 'put the run under if __name__ == "__main__":'
assert "\nrejected = main()" not in __source__, "call main() only inside the guard: indent `rejected = main()` under the if line"
_exp = sorted(_n for _n, _f in submitted.items() if _f.__name__ == "<lambda>" or "<locals>" in _f.__qualname__)
assert rejected == _exp, f"on this evidence the functions that can't be sent belong to {_exp}, got {rejected!r}"''',
                "tips": [
                    "`fn.__name__` and `fn.__qualname__` are plain strings: `return not (fn.__name__ == \"<lambda>\" or \"<locals>\" in fn.__qualname__)`.",
                    "`main` is one line: `return sorted(name for name, fn in submitted.items() if not can_send_to_process(fn))`. At the bottom write `if __name__ == \"__main__\":` and indent the two lines under it.",
                ],
                "reveal": "The pool can carry every job except the ones that only exist inside another function or as a lambda. Those crashed the run, and they came from the people who \"tested it themselves\" without a pool.",
            },
        ],
        "closing": "Case closed. The pool itself was fine; it was handed functions that can't travel between processes. Rewritten as top-level functions and run behind the `__main__` guard, the analytics finish in a fraction of the time.",
    },
    # ------------------------------------------------------------ switchboard
    {
        "id": "crossed-lines",
        "tier": "small",
        "title": "Crossed Lines",
        "teaser": "One switchboard, many calls, all waiting on each other. Somebody's call never lets go of the line.",
        "skills": ["switchboard"],
        "story": """The Bureau's switchboard runs every operator's call as a task on one **event loop**. Tonight every call connected late, by the same amount, as if the whole board froze for a while. On an event loop that only happens when a task blocks instead of awaiting.

Forensics loaded `OPERATORS`: a dict from operator name to that operator's task function. Each task function takes the loop, works like the lesson's `fetch` (a generator: `yield ms` means \"await for ms milliseconds\") and returns which line it connected. The helpers the tasks call are in the evidence too.""",
        "suspects": [
            {"name": "the night operators", "note": "Each says their call \"just takes a while\"."},
        ],
        "variants": [
            r'''def async_lookup(ms):
    return ms

def sync_lookup(loop, ms):
    loop.now += ms

def ama(loop):
    loop.say("Ama: connecting line 4")
    yield async_lookup(300)
    loop.say("Ama: line 4 connected")
    return "line 4"

def bea(loop):
    loop.say("Bea: rerouting the archive line")
    sync_lookup(loop, 900)
    yield 0
    loop.say("Bea: archive line rerouted")
    return "archive"

def cal(loop):
    loop.say("Cal: paging the night desk")
    yield async_lookup(1200)
    loop.say("Cal: night desk answered")
    return "night desk"

def dot(loop):
    loop.say("Dot: testing line 7")
    yield 200
    loop.say("Dot: line 7 half way")
    yield 200
    loop.say("Dot: line 7 ok")
    return "line 7"

OPERATORS = {"Ama": ama, "Bea": bea, "Cal": cal, "Dot": dot}
''',
            r'''def async_lookup(ms):
    return ms

def sync_lookup(loop, ms):
    loop.now += ms

def eda(loop):
    loop.say("Eda: calling the harbour")
    yield async_lookup(700)
    loop.say("Eda: harbour answered")
    return "harbour"

def fil(loop):
    loop.say("Fil: checking line 2")
    yield 100
    loop.say("Fil: line 2 clear")
    return "line 2"

def gus(loop):
    loop.say("Gus: opening the vault line")
    yield async_lookup(200)
    sync_lookup(loop, 600)
    yield 0
    loop.say("Gus: vault line open")
    return "vault"

OPERATORS = {"Eda": eda, "Fil": fil, "Gus": gus}
''',
            r'''def async_lookup(ms):
    return ms

def sync_lookup(loop, ms):
    loop.now += ms

def hal(loop):
    loop.say("Hal: tracing call 31")
    sync_lookup(loop, 400)
    yield 0
    loop.say("Hal: call 31 traced")
    return "trace 31"

def ida(loop):
    loop.say("Ida: patching the lab")
    yield async_lookup(700)
    loop.say("Ida: lab patched")
    return "lab"

def jon(loop):
    loop.say("Jon: dialling the morgue")
    yield async_lookup(300)
    loop.say("Jon: morgue on hold")
    sync_lookup(loop, 500)
    yield 0
    loop.say("Jon: morgue connected")
    return "morgue"

def kai(loop):
    loop.say("Kai: line 9 check")
    yield 250
    loop.say("Kai: line 9 ok")
    return "line 9"

OPERATORS = {"Hal": hal, "Ida": ida, "Jon": jon, "Kai": kai}
''',
        ],
        "steps": [
            {
                "notes": """How the model maps to real asyncio:
- `yield ms` in a task = `await asyncio.sleep(...)` or any awaited call: the task **pauses** and the loop runs other tasks while it waits.
- A task that makes time pass **without** yielding (here: anything that changes `loop.now` itself, like a sync library call or `time.sleep`) is **blocking**: no other task can run until it is done.

How to catch a blocker: drive the task by hand with `next(task)` on a fresh loop. The loop never moves its own clock while you do that, so if `loop.now` changes during one `next(task)` call, the task itself made time pass: it blocks. A finished task raises `StopIteration`.""",
                "question": """**Goal:** find the operators whose tasks block the switchboard, and measure the night's total time.

**You have:** `OPERATORS`, a dict from operator name to a task function that takes a loop, e.g. `{"Ama": ama, "Bea": bea}`. In the editor: the lesson's `Loop` class (`now`, `say`, `run(tasks)`).

**Write** a function `blocks(task_fn)`:
- make a fresh `loop = Loop()` and `task = task_fn(loop)`
- call `next(task)` again and again until it raises `StopIteration`
- return `True` if `loop.now` changed during any of those calls, otherwise `False`

**Then** store:
- `blockers`: a **sorted** list of the operator names whose task blocks
- `together = Loop()` and `results = together.run([fn(together) for fn in OPERATORS.values()])`
- `total_ms`: `together.now` after that run (how long all the calls took together)

**Example:** a task that does `yield 500` and returns is not a blocker; a task that does `loop.now += 50` before its `yield 0` is.""",
                "starter": r'''class Loop:
    """A model of asyncio's event loop: one thread, a list of tasks, a pretend clock."""
    def __init__(self):
        self.now = 0
        self.log = []

    def say(self, text):
        self.log.append(f"{self.now:>5} ms  {text}")

    def run(self, tasks):
        waiting = [(0, n, task) for n, task in enumerate(tasks)]
        results = [None] * len(tasks)
        while waiting:
            waiting.sort(key=lambda w: (w[0], w[1]))
            wake, n, task = waiting.pop(0)
            self.now = max(self.now, wake)
            try:
                wait_ms = next(task)
                waiting.append((self.now + wait_ms, n, task))
            except StopIteration as finished:
                results[n] = finished.value
        return results

def blocks(task_fn):
    return False

blockers = []
results = []
total_ms = ...
print(blockers, results, total_ms)
''',
                "solution": r'''class Loop:
    """A model of asyncio's event loop: one thread, a list of tasks, a pretend clock."""
    def __init__(self):
        self.now = 0
        self.log = []

    def say(self, text):
        self.log.append(f"{self.now:>5} ms  {text}")

    def run(self, tasks):
        waiting = [(0, n, task) for n, task in enumerate(tasks)]
        results = [None] * len(tasks)
        while waiting:
            waiting.sort(key=lambda w: (w[0], w[1]))
            wake, n, task = waiting.pop(0)
            self.now = max(self.now, wake)
            try:
                wait_ms = next(task)
                waiting.append((self.now + wait_ms, n, task))
            except StopIteration as finished:
                results[n] = finished.value
        return results

def blocks(task_fn):
    loop = Loop()
    task = task_fn(loop)
    while True:
        before = loop.now
        try:
            next(task)
        except StopIteration:
            return loop.now != before
        if loop.now != before:
            return True

blockers = sorted(name for name, fn in OPERATORS.items() if blocks(fn))
together = Loop()
results = together.run([fn(together) for fn in OPERATORS.values()])
total_ms = together.now
for line in together.log:
    print(line)
print(blockers, results, total_ms)
''',
                "tests": r'''class _L:
    def __init__(self):
        self.now = 0
        self.log = []
    def say(self, text):
        self.log.append(text)
    def run(self, tasks):
        waiting = [(0, n, t) for n, t in enumerate(tasks)]
        res = [None] * len(tasks)
        while waiting:
            waiting.sort(key=lambda w: (w[0], w[1]))
            wake, n, t = waiting.pop(0)
            self.now = max(self.now, wake)
            try:
                waiting.append((self.now + next(t), n, t))
            except StopIteration as fin:
                res[n] = fin.value
        return res
def _blk(fn):
    lp = _L()
    t = fn(lp)
    while True:
        b = lp.now
        try:
            next(t)
        except StopIteration:
            return lp.now != b
        if lp.now != b:
            return True
def _waits(loop):
    yield 500
    return "ok"
def _late_block(loop):
    yield 100
    loop.now += 50
    yield 0
    return "x"
def _end_block(loop):
    yield 100
    loop.now += 30
    return "y"
assert blocks(_waits) is False, "a task that only yields is not a blocker"
assert blocks(_late_block) is True, "a task that moves loop.now itself after its first yield is a blocker"
assert blocks(_end_block) is True, "a task that blocks in its last part (just before it returns) is a blocker too"
_exp = sorted(_n for _n, _f in OPERATORS.items() if _blk(_f))
assert blockers == _exp, f"on this evidence the blockers are {_exp}, got {blockers!r}"
_lp = _L()
_res = _lp.run([_f(_lp) for _f in OPERATORS.values()])
assert results == _res, f"results should be {_res}, got {results!r}"
assert total_ms == _lp.now, f"all the calls together take {_lp.now} ms, got {total_ms!r}"''',
                "tips": [
                    "Inside `while True:` save `before = loop.now`, then call `next(task)` inside `try` / `except StopIteration:`. Compare `loop.now` with `before` after every call, including the last one that raises.",
                    "`blockers = sorted(name for name, fn in OPERATORS.items() if blocks(fn))`. For the full night: `together = Loop()`, then `together.run([fn(together) for fn in OPERATORS.values()])` and `total_ms = together.now`.",
                ],
                "reveal": "Every waiting task was ready on time; the board was frozen by calls that made a slow lookup without awaiting it. Read `together.log`: everyone else's lines arrive late by exactly the blocked time.",
            },
        ],
        "closing": "Case closed. The blocking calls looked just like the others, but used the sync lookup instead of the awaitable one. On one event loop a single blocking call freezes everybody. The operators now await their lookups (or push sync work to a thread with `asyncio.to_thread`), and the board runs free.",
    },
    # ------------------------------------------------------------ field-resilience
    {
        "id": "second-attempt",
        "tier": "small",
        "title": "The Second Attempt",
        "teaser": "Evidence uploads fail at night. Most are bad luck. One was refused on purpose.",
        "skills": ["field-resilience"],
        "story": """Every night each technician's workstation uploads its evidence files to the central archive. The network is flaky, so uploads **retry** with exponential backoff, up to a set number of attempts. Last night some uploads never arrived, and one of them was the photo set from the vault break-in.

Forensics replayed what the archive answered each workstation:
- `ATTEMPTS`: how many tries the upload client was configured to make that night
- `HTTPError`: the error the archive client raises; its `status` is the HTTP code
- `uploads`: a dict from technician name to the list of replies the archive gave that technician's upload, in order (an error to raise, or a receipt string on success). Replies after the client stopped were never read.""",
        "suspects": [
            {"name": "the technicians whose uploads failed", "note": "All blame the network."},
        ],
        "variants": [
            r'''class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

ATTEMPTS = 4
uploads = {
    "Ola": [HTTPError(503), "receipt-881"],
    "Pim": [HTTPError(500), HTTPError(403)],
    "Quin": [TimeoutError(), TimeoutError(), TimeoutError(), TimeoutError()],
    "Rae": ["receipt-882"],
}
''',
            r'''class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

ATTEMPTS = 3
uploads = {
    "Tam": [HTTPError(401)],
    "Sid": [HTTPError(429), HTTPError(429), "receipt-12"],
    "Uri": [HTTPError(502), HTTPError(504), HTTPError(503), "receipt-14"],
    "Val": [TimeoutError(), "receipt-13"],
}
''',
            r'''class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

ATTEMPTS = 5
uploads = {
    "Wes": [HTTPError(503), HTTPError(503), HTTPError(503), HTTPError(503), HTTPError(503)],
    "Yev": [TimeoutError(), HTTPError(500), HTTPError(500), HTTPError(500), HTTPError(500), "receipt-90"],
    "Zia": [HTTPError(504), HTTPError(504), TimeoutError(), TimeoutError(), TimeoutError()],
    "Xan": [TimeoutError(), HTTPError(500), HTTPError(400)],
}
''',
        ],
        "steps": [
            {
                "notes": """**Transient** errors may work on another try: a `TimeoutError`, or an `HTTPError` with status **429, 500, 502, 503 or 504**. Everything else is **permanent** (for example 400 bad request, 401, 403 forbidden, 404): trying again gives the same answer.

The upload client's rule:
- try at most `attempts` times
- a reply that is not an error is the receipt: stop, the upload worked
- a **permanent** error: stop at once, without waiting; the outcome is `"refused"`
- a **transient** error on the last allowed try: stop; the outcome is `"gave up"` (bad luck, all tries used)
- a transient error with tries left: wait `backoff(n)` seconds, where `n` counts the waits from 0, so the waits are 0.1, 0.2, 0.4, 0.8 ... (`backoff(n) = min(2.0, 0.1 * 2 ** n)`), then try again""",
                "question": """**Goal:** replay every upload under the night's retry settings, and find the one the archive refused outright.

**You have:** `ATTEMPTS` (an int), `HTTPError` and `uploads` (e.g. `{"Ola": [HTTPError(503), "receipt-881"]}`). In the editor: `is_transient(error)`, `backoff(n)` and `fake_server(*replies)` (each call gives the next reply, raising it if it is an error).

**Write** a function `upload(call, attempts, sleep)` that returns a tuple `(outcome, tries)` and never raises:
- call `call()` inside `try` / `except`, following the client's rule in the field notes
- `outcome` is the receipt, `"refused"` or `"gave up"`; `tries` is how many times `call()` was called
- wait with `sleep(seconds)`, the function passed in (never `time.sleep`)

**Then** for every technician, in `uploads` order, make `waits = []`, run `upload(fake_server(*replies), ATTEMPTS, waits.append)` and store:
- `outcomes`: a dict from name to the outcome
- `tries`: a dict from name to the number of tries
- `slept`: a dict from name to the total seconds waited, `round(sum(waits), 2)`
- `culprit`: the one name whose outcome is `"refused"`

**Example:** with 4 attempts, replies `[HTTPError(503), TimeoutError(), "ok"]` give `("ok", 3)` after waiting `[0.1, 0.2]`; replies `[HTTPError(500), HTTPError(404)]` give `("refused", 2)` after waiting `[0.1]`.""",
                "starter": r'''TRANSIENT = {429, 500, 502, 503, 504}

def is_transient(error):
    if isinstance(error, TimeoutError):
        return True
    return isinstance(error, HTTPError) and error.status in TRANSIENT

def backoff(n, base=0.1, cap=2.0):
    return min(cap, base * 2 ** n)

def fake_server(*replies):
    replies = list(replies)
    def call():
        reply = replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return reply
    return call

def upload(call, attempts, sleep):
    return call(), 1

outcomes = {}
tries = {}
slept = {}
culprit = ...
print(outcomes)
print(tries)
print(slept)
print(culprit)
''',
                "solution": r'''TRANSIENT = {429, 500, 502, 503, 504}

def is_transient(error):
    if isinstance(error, TimeoutError):
        return True
    return isinstance(error, HTTPError) and error.status in TRANSIENT

def backoff(n, base=0.1, cap=2.0):
    return min(cap, base * 2 ** n)

def fake_server(*replies):
    replies = list(replies)
    def call():
        reply = replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return reply
    return call

def upload(call, attempts, sleep):
    for n in range(attempts):
        try:
            return call(), n + 1
        except Exception as error:
            if not is_transient(error):
                return "refused", n + 1
            if n == attempts - 1:
                return "gave up", n + 1
            sleep(backoff(n))

outcomes = {}
tries = {}
slept = {}
for name, replies in uploads.items():
    waits = []
    outcomes[name], tries[name] = upload(fake_server(*replies), ATTEMPTS, waits.append)
    slept[name] = round(sum(waits), 2)
culprit = [name for name, outcome in outcomes.items() if outcome == "refused"][0]
print(outcomes)
print(tries)
print(slept)
print(culprit)
''',
                "tests": r'''_w = []
_r = upload(fake_server(HTTPError(503), TimeoutError(), "ok"), 4, _w.append)
assert _r == ("ok", 3), f"two transient errors then 'ok' should give ('ok', 3), got {_r!r}"
assert _w == [0.1, 0.2], f"the waits should be [0.1, 0.2], got {_w}"
_w = []
_r = upload(fake_server(HTTPError(404), "never"), 4, _w.append)
assert _r == ("refused", 1), f"a 404 should give ('refused', 1) at once, got {_r!r}"
assert _w == [], "a permanent error must not be waited for"
_w = []
_r = upload(fake_server(HTTPError(500), HTTPError(403)), 4, _w.append)
assert _r == ("refused", 2), f"a 500 then a 403 should give ('refused', 2), got {_r!r}"
assert _w == [0.1], f"one wait after the 500, none after the 403: [0.1], got {_w}"
_w = []
_r = upload(fake_server(HTTPError(503), HTTPError(503), HTTPError(503), "late"), 3, _w.append)
assert _r == ("gave up", 3), f"with 3 attempts, three 503s give ('gave up', 3) and the 4th reply is never read; got {_r!r}"
assert _w == [0.1, 0.2], f"3 attempts wait twice: [0.1, 0.2], got {_w}"
_w = []
_r = upload(fake_server(TimeoutError(), TimeoutError(), TimeoutError(), TimeoutError(), TimeoutError(), "x"), 5, _w.append)
assert _r == ("gave up", 5) and _w == [0.1, 0.2, 0.4, 0.8], f"5 attempts of timeouts should wait [0.1, 0.2, 0.4, 0.8] and give up after 5 tries; got {_r!r} and {_w}"
def _up(replies, attempts):
    _ws = []
    _call = fake_server(*replies)
    for _n in range(attempts):
        try:
            return _call(), _n + 1, _ws
        except Exception as _e:
            if not is_transient(_e):
                return "refused", _n + 1, _ws
            if _n == attempts - 1:
                return "gave up", _n + 1, _ws
            _ws.append(min(2.0, 0.1 * 2 ** _n))
_oc, _tr, _sl = {}, {}, {}
for _nm, _rp in uploads.items():
    _o, _t, _ws = _up(_rp, ATTEMPTS)
    _oc[_nm], _tr[_nm], _sl[_nm] = _o, _t, round(sum(_ws), 2)
assert outcomes == _oc, f"with ATTEMPTS = {ATTEMPTS} the outcomes should be {_oc}, got {outcomes!r}"
assert tries == _tr, f"with ATTEMPTS = {ATTEMPTS} the tries should be {_tr}, got {tries!r}"
assert slept == _sl, f"on this evidence slept should be {_sl}, got {slept!r}"
_who = [_nm for _nm, _o in _oc.items() if _o == "refused"][0]
assert culprit == _who, f"the refused upload belongs to {_who}, got {culprit!r}"''',
                "tips": [
                    "Loop `for n in range(attempts):` with `try: return call(), n + 1`. In `except Exception as error:` return `(\"refused\", n + 1)` if `not is_transient(error)`, return `(\"gave up\", n + 1)` if `n == attempts - 1`, otherwise `sleep(backoff(n))`.",
                    "A function that returns a tuple can fill two dicts at once: `outcomes[name], tries[name] = upload(fake_server(*replies), ATTEMPTS, waits.append)`. Then `slept[name] = round(sum(waits), 2)`.",
                ],
                "reveal": "Most failures were the network: the retries either got through or ran out after the full backoff. One upload was different: after a transient hiccup the archive answered with a permanent refusal, and no amount of retrying would have helped.",
            },
        ],
        "closing": "Case closed. Retrying only the right errors, with backoff and an injected sleep, separated bad luck from sabotage in milliseconds of test time. The refused upload came from a workstation whose archive credentials had been swapped: the break-in photos were never meant to arrive.",
    },
]

"""Detective X Day 2: the three big cases, one chapter finale each (4-6 steps).

Case format (see .claude/skills/write-cases/SKILL.md for the full rules):
  id, tier ("small" | "medium" | "big"), title, teaser, skills, story, suspects,
  variants  2-3 evidence scripts; the trainee's code runs on each, answers must differ
  steps     [{notes, question, starter, solution, tests, tips: [2 tips], reveal}]
  closing   text shown when the case is closed; "fragment" is the case's X clue (Day 2 holds 5-7)
Steps are independent: when a step needs an earlier result, its starter already computes it.
Check with:  python engine/build_game.py --check cases_big --day day2
"""

# ======================================================================
# Chapter 4 finale: The Phantom Fines
# ======================================================================

_FINES_V1 = '''log_text = """{"ts": "2026-11-19T01:00:00", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-301", "handler": "fines.nightly_sweep"}
{"ts": "2026-11-19T01:00:01", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-301", "loan_id": "L110", "member_id": "M003", "amount": 1.5, "returned_on": null}
{"ts": "2026-11-19T01:00:02", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-302", "handler": "fines.manual_review"}
{"ts": "2026-11-19T01:00:02", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-301", "loan_id": "L114", "member_id": "M006", "amount": 3.0, "returned_on": null}
{"ts": "2026-11-19T01:00:03", "level": "ERROR", "logger": "bookvault.fines", "event": "email_failed", "request_id": "req-302", "member_id": "M002"}
{"ts": "2026-11-19T01:00:04", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-301", "duration_ms": 3120}
{"ts": "2026-11-19T01:00:05", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-302", "loan_id": "L099", "member_id": "M002", "amount": 4.0, "returned_on": null}
{"ts": "2026-11-19T01:00:06", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-302", "duration_ms": 4410}
printing loans... 212 found
{"ts": "2026-11-20T01:00:00", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-388", "handler": "fines.nightly_sweep"}
{"ts": "2026-11-20T01:00:01", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-389", "handler": "fines.renewal_check"}
{"ts": "2026-11-20T01:00:01", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-388", "loan_id": "L114", "member_id": "M006", "amount": 3.5, "returned_on": null}
{"ts": "2026-11-20T01:00:02", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-389", "loan_id": "L130", "member_id": "M001", "amount": 0.5, "returned_on": "2026-11-17"}
{"ts": "2026-11-20T01:00:02", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-388", "loan_id": "L121", "member_id": "M004", "amount": 2.5, "returned_on": "2026-11-15"}
{"ts": "2026-11-20T01:00:03", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-390", "handler": "fines.manual_review"}
{"ts": "2026-11-20T01:00:03", "level": "ERROR", "logger": "bookvault.fines", "event": "email_failed", "request_id": "req-390", "member_id": "M002"}
{"ts": "2026-11-20T01:00:03", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-388", "loan_id": "L117", "member_id": "M009", "amount": 1.0, "returned_on": "2026-11-18"}
{"ts": "2026-11-20T01:00:04", "level": "ERROR", "logger": "bookvault.fines", "event": "email_failed", "request_id": "req-390", "member_id": "M007"}
{"ts": "2026-11-20T01:00:04", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-388", "loan_id": "L125", "member_id": "M004", "amount": 2.0, "returned_on": "2026-11-19"}
{"ts": "2026-11-20T01:00:05", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-389", "duration_ms": 1210}
{"ts": "2026-11-20T01:00:05", "level": "ERROR", "logger": "bookvault.fines", "event": "email_failed", "request_id": "req-390", "member_id": "M005"}
{"ts": "2026-11-20T01:00:06", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-388", "duration_ms": 3980}

{"ts": "2026-11-20T01:00:07", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-390", "duration_ms": 5020}
"""

patches = [
    {"clerk": "Kofi Mensah", "handler": "fines.nightly_sweep", "deployed": "2026-11-20T09:30:00", "note": "tidy imports"},
    {"clerk": "Ines Duarte", "handler": "fines.nightly_sweep", "deployed": "2026-11-18T16:00:00", "note": "faster loan query"},
    {"clerk": "Tomas Reyes", "handler": "fines.manual_review", "deployed": "2026-11-19T23:50:00", "note": "new email template"},
    {"clerk": "Wen Zhao", "handler": "fines.nightly_sweep", "deployed": "2026-11-19T18:15:00", "note": "refactor sweep loop"},
]
'''

_FINES_V2 = '''log_text = """{"ts": "2026-11-19T02:00:00", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-511", "handler": "fines.renewal_check"}
{"ts": "2026-11-19T02:00:00", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-512", "handler": "fines.nightly_sweep"}
{"ts": "2026-11-19T02:00:01", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-511", "loan_id": "L040", "member_id": "M008", "amount": 1.0, "returned_on": null}
{"ts": "2026-11-19T02:00:01", "level": "ERROR", "logger": "bookvault.fines", "event": "db_timeout", "request_id": "req-512", "member_id": "M003"}
{"ts": "2026-11-19T02:00:02", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-512", "loan_id": "L044", "member_id": "M003", "amount": 2.5, "returned_on": null}
{"ts": "2026-11-19T02:00:03", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-511", "duration_ms": 2050}
{"ts": "2026-11-19T02:00:04", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-512", "duration_ms": 3900}

{"ts": "2026-11-20T02:00:00", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-577", "handler": "fines.nightly_sweep"}
{"ts": "2026-11-20T02:00:00", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-578", "handler": "fines.renewal_check"}
{"ts": "2026-11-20T02:00:00", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-577", "loan_id": "L049", "member_id": "M010", "amount": 2.0, "returned_on": "2026-11-18"}
{"ts": "2026-11-20T02:00:01", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-578", "loan_id": "L052", "member_id": "M011", "amount": 3.0, "returned_on": "2026-11-14"}
{"ts": "2026-11-20T02:00:01", "level": "ERROR", "logger": "bookvault.fines", "event": "db_timeout", "request_id": "req-577", "member_id": "M003"}
{"ts": "2026-11-20T02:00:02", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-578", "loan_id": "L040", "member_id": "M008", "amount": 1.5, "returned_on": null}
{"ts": "2026-11-20T02:00:02", "level": "ERROR", "logger": "bookvault.fines", "event": "db_timeout", "request_id": "req-577", "member_id": "M010"}
renewal batch size = 64
{"ts": "2026-11-20T02:00:03", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-577", "loan_id": "L044", "member_id": "M003", "amount": 3.0, "returned_on": null}
{"ts": "2026-11-20T02:00:03", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-578", "loan_id": "L058", "member_id": "M002", "amount": 0.5, "returned_on": "2026-11-19"}
{"ts": "2026-11-20T02:00:04", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-579", "handler": "fines.manual_review"}
{"ts": "2026-11-20T02:00:04", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-578", "loan_id": "L061", "member_id": "M011", "amount": 1.5, "returned_on": "2026-11-17"}
{"ts": "2026-11-20T02:00:05", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-579", "loan_id": "L070", "member_id": "M006", "amount": 4.0, "returned_on": null}
{"ts": "2026-11-20T02:00:05", "level": "ERROR", "logger": "bookvault.fines", "event": "db_timeout", "request_id": "req-577", "member_id": "M012"}
{"ts": "2026-11-20T02:00:06", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-578", "duration_ms": 2840}
{"ts": "2026-11-20T02:00:06", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-579", "duration_ms": 1730}
{"ts": "2026-11-20T02:00:07", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-577", "duration_ms": 6610}
"""

patches = [
    {"clerk": "Wen Zhao", "handler": "fines.nightly_sweep", "deployed": "2026-11-19T23:30:00", "note": "retry on db timeout"},
    {"clerk": "Tomas Reyes", "handler": "fines.renewal_check", "deployed": "2026-11-20T08:00:00", "note": "add request ids"},
    {"clerk": "Kofi Mensah", "handler": "fines.renewal_check", "deployed": "2026-11-19T20:05:00", "note": "refactor renewal loop"},
    {"clerk": "Ines Duarte", "handler": "fines.renewal_check", "deployed": "2026-11-18T12:00:00", "note": "faster renewal query"},
]
'''

_FINES_V3 = '''log_text = """{"ts": "2026-11-19T00:30:00", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-720", "handler": "fines.manual_review"}
{"ts": "2026-11-19T00:30:01", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-720", "loan_id": "L300", "member_id": "M014", "amount": 2.0, "returned_on": null}
{"ts": "2026-11-19T00:30:02", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-721", "handler": "fines.renewal_check"}
{"ts": "2026-11-19T00:30:02", "level": "ERROR", "logger": "bookvault.fines", "event": "renewal_rejected", "request_id": "req-721", "member_id": "M001"}
{"ts": "2026-11-19T00:30:03", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-720", "duration_ms": 2600}
{"ts": "2026-11-19T00:30:04", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-721", "duration_ms": 1900}

{"ts": "2026-11-20T00:30:00", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-760", "handler": "fines.renewal_check"}
{"ts": "2026-11-20T00:30:01", "level": "ERROR", "logger": "bookvault.fines", "event": "renewal_rejected", "request_id": "req-760", "member_id": "M001"}
{"ts": "2026-11-20T00:30:01", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-761", "handler": "fines.manual_review"}
{"ts": "2026-11-20T00:30:02", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-761", "loan_id": "L300", "member_id": "M014", "amount": 2.5, "returned_on": null}
{"ts": "2026-11-20T00:30:02", "level": "ERROR", "logger": "bookvault.fines", "event": "renewal_rejected", "request_id": "req-760", "member_id": "M013"}
{"ts": "2026-11-20T00:30:03", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-761", "loan_id": "L305", "member_id": "M007", "amount": 5.0, "returned_on": "2026-11-16"}
{"ts": "2026-11-20T00:30:03", "level": "INFO", "logger": "bookvault.fines", "event": "request_started", "request_id": "req-762", "handler": "fines.nightly_sweep"}
{"ts": "2026-11-20T00:30:04", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-762", "loan_id": "L310", "member_id": "M002", "amount": 1.0, "returned_on": null}
{"ts": "2026-11-20T00:30:04", "level": "ERROR", "logger": "bookvault.fines", "event": "renewal_rejected", "request_id": "req-760", "member_id": "M009"}
{"ts": "2026-11-20T00:30:05", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-761", "loan_id": "L308", "member_id": "M013", "amount": 0.5, "returned_on": "2026-11-19"}
{"ts": "2026-11-20T00:30:05", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-762", "loan_id": "L311", "member_id": "M002", "amount": 0.5, "returned_on": "2026-11-19"}
Traceback (most recent call last): see stderr
{"ts": "2026-11-20T00:30:05", "level": "INFO", "logger": "bookvault.fines", "event": "fine_issued", "request_id": "req-761", "loan_id": "L312", "member_id": "M007", "amount": 1.5, "returned_on": "2026-11-18"}
{"ts": "2026-11-20T00:30:06", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-762", "duration_ms": 1500}
{"ts": "2026-11-20T00:30:06", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-760", "duration_ms": 3300}
{"ts": "2026-11-20T00:30:07", "level": "INFO", "logger": "bookvault.fines", "event": "request_finished", "request_id": "req-761", "duration_ms": 4100}
"""

patches = [
    {"clerk": "Ines Duarte", "handler": "fines.manual_review", "deployed": "2026-11-19T21:40:00", "note": "merge duplicate checks"},
    {"clerk": "Wen Zhao", "handler": "fines.manual_review", "deployed": "2026-11-20T10:15:00", "note": "fix typo in email"},
    {"clerk": "Tomas Reyes", "handler": "fines.manual_review", "deployed": "2026-11-17T10:00:00", "note": "bigger review page"},
    {"clerk": "Kofi Mensah", "handler": "fines.renewal_check", "deployed": "2026-11-19T23:55:00", "note": "new rejection rules"},
]
'''

_FINES_READ_LOG = '''import json


def read_log(text):
    events = []
    for line in text.splitlines():
        if not line.strip():
            continue
        try:
            events.append(json.loads(line))
        except ValueError:
            continue
    return events


events = read_log(log_text)
'''

_FINES_PHANTOM = _FINES_READ_LOG + '''phantom = [e for e in events if e["event"] == "fine_issued" and e["returned_on"] is not None]
'''

_FINES_GUILTY = _FINES_PHANTOM + '''handler_of = {}
for e in events:
    if e["event"] == "request_started":
        handler_of[e["request_id"]] = e["handler"]
phantom_by_handler = {}
for fine in phantom:
    h = handler_of[fine["request_id"]]
    phantom_by_handler[h] = phantom_by_handler.get(h, 0) + 1
guilty_handler = max(phantom_by_handler, key=phantom_by_handler.get)
'''

_FINES_CULPRIT = _FINES_GUILTY + '''first_bad = None
for fine in phantom:
    if handler_of[fine["request_id"]] == guilty_handler:
        first_bad = fine["ts"]
        break
best = None
for p in patches:
    if p["handler"] == guilty_handler and p["deployed"] < first_bad:
        if best is None or p["deployed"] > best["deployed"]:
            best = p
culprit = best["clerk"]
'''

# What the tests recompute from the evidence (never from the trainee's variables).
_FINES_TRUTH = r'''import json as _json
_events = []
for _l in log_text.splitlines():
    if _l.strip():
        try:
            _events.append(_json.loads(_l))
        except ValueError:
            pass
_phantom = [_e for _e in _events if _e["event"] == "fine_issued" and _e["returned_on"] is not None]
_handler_of = {_e["request_id"]: _e["handler"] for _e in _events if _e["event"] == "request_started"}
_by_handler = {}
for _e in _phantom:
    _h = _handler_of[_e["request_id"]]
    _by_handler[_h] = _by_handler.get(_h, 0) + 1
_guilty = max(_by_handler, key=_by_handler.get)
_first_bad = [_e["ts"] for _e in _phantom if _handler_of[_e["request_id"]] == _guilty][0]
_before = [_p for _p in patches if _p["handler"] == _guilty and _p["deployed"] < _first_bad]
_culprit = max(_before, key=lambda _p: _p["deployed"])["clerk"]
_refunds = {}
for _e in _phantom:
    _refunds[_e["member_id"]] = round(_refunds.get(_e["member_id"], 0) + _e["amount"], 2)
'''

_FINES_REFUNDS = _FINES_CULPRIT + '''refunds = {}
for fine in phantom:
    member = fine["member_id"]
    refunds[member] = round(refunds.get(member, 0) + fine["amount"], 2)
'''

PHANTOM_FINES = {
    "id": "phantom-fines",
    "tier": "big",
    "title": "The Phantom Fines",
    "teaser": "Patrons are being fined for books they already returned. The fine service's own log knows why.",
    "skills": ["lab-bench", "microscope", "logbook"],
    "story": (
        "Overnight, BookVault's fine service charged patrons for books that were **already back on the shelf**. "
        "The help desk is drowning in complaints, and the Chief wants to know which code did it and who changed it.\n\n"
        "The fine service writes a **structured JSON log**: one JSON object per line, each with a timestamp `ts`, a `level`, "
        "an `event` name and a `request_id`. Several requests run at the same time, so their lines are mixed together. "
        "The Lab copied it for you:\n"
        "- `log_text`: the whole log as one string, two nights of it. A few lines are not JSON at all: someone left a `print()` in the code.\n"
        "- `patches`: every change deployed to the fine service this week: which `clerk` wrote it, which `handler` "
        "(code path) it changed, when it was `deployed`, and the clerk's `note`. The list is **not** in time order.\n\n"
        "One code path stopped asking whether a loan had been returned. The night shift says the code path that logs "
        "the most errors must be the broken one. The log may say otherwise.\n\n"
        "One more thing nags at the Chief: ever since BookVault went live, its logs have shown a borrower ID that is just the letter **X**."
    ),
    "suspects": [
        {"name": "Ines Duarte", "note": "Senior clerk. Knows the fine service better than anyone."},
        {"name": "Tomas Reyes", "note": "Says his changes this week were harmless."},
        {"name": "Wen Zhao", "note": "Says she only ever tidies code, never changes what it does."},
        {"name": "Kofi Mensah", "note": "Says nothing he touched could issue a fine."},
    ],
    "variants": [_FINES_V1, _FINES_V2, _FINES_V3],
    "steps": [
        {
            "notes": "**A JSON Lines log.** Each line of the log is one complete JSON object, for example `{\"ts\": \"2026-11-19T01:00:00\", \"level\": \"INFO\", \"event\": \"request_started\", \"request_id\": \"req-301\", \"handler\": \"fines.nightly_sweep\"}`.\n\n"
                     "- `json.loads(line)` turns one line into a dictionary. JSON `null` becomes Python `None`.\n"
                     "- Some lines are **not** events: a blank line, or text that a stray `print()` wrote. They are not JSON, so `json.loads` raises `ValueError` on them (`json.JSONDecodeError` is a kind of `ValueError`). Skip those lines; they are not part of the log.",
            "question": "**Goal:** turn the raw log into a list of events you can search.\n\n"
                        "**You have:** `log_text`, one string holding the whole log, one event per line (see the field notes).\n\n"
                        "**Write** a function `read_log(text)`:\n"
                        "- `text` is the whole log as one string\n"
                        "- go through its lines (`text.splitlines()`)\n"
                        "- skip a line that is empty or only spaces\n"
                        "- turn every other line into a dictionary with `json.loads`\n"
                        "- a line that is not valid JSON is skipped: catch the `ValueError`, don't crash\n"
                        "- return the list of dictionaries, in the order of the log\n\n"
                        "**Then** store `events = read_log(log_text)` and print how many there are. The starter already does both.\n\n"
                        "**Example:** `read_log('{\"a\": 1}\\n\\nhello\\n{\"a\": 2}')` gives `[{\"a\": 1}, {\"a\": 2}]`.",
            "starter": "import json\n\n\ndef read_log(text):\n    ...  # your code here\n\n\nevents = read_log(log_text)\nprint(len(events), \"events\")\n",
            "solution": _FINES_READ_LOG + "print(len(events), \"events\")\n",
            "tests": _FINES_TRUTH + r'''_small = read_log('{"a": 1}\n\n   \nhello\n{"a": 2}')
assert _small == [{"a": 1}, {"a": 2}], "read_log should skip blank lines and lines that aren't JSON: for the lines JSON, blank, spaces, 'hello', JSON it should return the two dictionaries, got " + repr(_small)
assert isinstance(events, list), "events should be the list that read_log(log_text) returns"
assert events == _events, f"this log has {len(_events)} JSON events, but events has {len(events)}. Skip blank lines and lines that aren't JSON; keep every other line, in order."''',
            "tips": [
                "Loop with `for line in text.splitlines():`. First `if not line.strip(): continue`, then put `events.append(json.loads(line))` inside a `try:`.",
                "`except ValueError: continue` skips the line that isn't JSON. Create `events = []` before the loop and `return events` after it.",
            ],
            "reveal": "Two nights of the fine service, now searchable. Most lines are dull: requests start, fines go out, requests finish. A few of the fines are not dull at all.",
        },
        {
            "notes": "**A phantom fine** is a `fine_issued` event whose `returned_on` is **not** `None`: the book had already come back, so the patron should never have been fined. A `fine_issued` event with `returned_on` equal to `None` is a real fine for a book still out.\n\n"
                     "Only `fine_issued` events have a `returned_on` key; other events don't have it at all.\n\n"
                     "In VS Code you would find these with a **conditional breakpoint** on `returned_on is not None`. Here you build that breakpoint yourself: a check that runs on every event and stops only when its condition is true.",
            "question": "**Goal:** stop on exactly the phantom fines, the way a conditional breakpoint would.\n\n"
                        "**You have:** `events`, the list of event dictionaries from step 1 (the starter builds it again).\n\n"
                        "**Write** a function `breakpoint_hits(events, condition)`:\n"
                        "- `condition` is a function that takes one event and returns `True` or `False`\n"
                        "- for every event where `condition(event)` is `True`: print `PAUSED at ` followed by its `request_id`, and keep the event\n"
                        "- return the list of kept events, in log order\n"
                        "- the function must work for **any** condition, not only this one\n\n"
                        "**Then** store `phantom = breakpoint_hits(events, ...)`, passing a `lambda` that is `True` only for phantom fines (see the field notes). The starter prints how many you found.\n\n"
                        "**Example:** `breakpoint_hits([{\"request_id\": \"r1\", \"n\": 1}, {\"request_id\": \"r2\", \"n\": 5}], lambda e: e[\"n\"] > 2)` prints `PAUSED at r2` and returns `[{\"request_id\": \"r2\", \"n\": 5}]`.",
            "starter": _FINES_READ_LOG + "\n\ndef breakpoint_hits(events, condition):\n    hits = []\n    # check every event here\n    return hits\n\n\nphantom = breakpoint_hits(events, lambda e: False)\nprint(len(phantom), \"phantom fines\")\n",
            "solution": _FINES_READ_LOG + "\n\ndef breakpoint_hits(events, condition):\n    hits = []\n    for event in events:\n        if condition(event):\n            print(\"PAUSED at\", event[\"request_id\"])\n            hits.append(event)\n    return hits\n\n\nphantom = breakpoint_hits(events, lambda e: e[\"event\"] == \"fine_issued\" and e[\"returned_on\"] is not None)\nprint(len(phantom), \"phantom fines\")\n",
            "tests": _FINES_TRUTH + r'''_toy = [{"request_id": "r1", "n": 1}, {"request_id": "r2", "n": 5}, {"request_id": "r3", "n": 9}]
_got = breakpoint_hits(_toy, lambda _e: _e["n"] > 2)
assert _got == _toy[1:], f"breakpoint_hits should keep every event where the condition is True; with n > 2 it should return the r2 and r3 events, got {_got!r}"
assert breakpoint_hits(_toy, lambda _e: False) == [], "with a condition that is never True, breakpoint_hits should return []"
assert phantom == _phantom, f"this log has {len(_phantom)} phantom fines (fine_issued with returned_on not None), but phantom has {len(phantom)}"
for _e in _phantom:
    assert f"PAUSED at {_e['request_id']}" in __output__, f"print 'PAUSED at {_e['request_id']}' when the breakpoint stops on that fine"''',
            "tips": [
                "Inside the function: `for event in events:` then `if condition(event):`, and in there `print(\"PAUSED at\", event[\"request_id\"])` and `hits.append(event)`.",
                "The condition: `lambda e: e[\"event\"] == \"fine_issued\" and e[\"returned_on\"] is not None`. `and` stops early on other events, so it never looks up a `returned_on` key they don't have.",
            ],
            "reveal": "The breakpoint fires on the second night only. Each hit is a fine for a book that was already back. Now: which code issued them?",
        },
        {
            "notes": "**Tracing a request.** Every line from the same request carries the same `request_id`, even when several requests run at once and their lines are mixed together.\n\n"
                     "Only the `request_started` line of a request names its `handler`: the code path that ran the request (for example `\"fines.nightly_sweep\"`). The `fine_issued` lines do **not** name it. So to learn which code path issued a fine, find the `request_started` event with the same `request_id`.",
            "question": "**Goal:** find which code path issued the phantom fines.\n\n"
                        "**You have:** `events` and `phantom` (the list of phantom fine events from step 2). The starter builds both.\n\n"
                        "**Write** three variables:\n"
                        "- `handler_of`: a dictionary from `request_id` to `handler`, with one entry for every `request_started` event\n"
                        "- `phantom_by_handler`: a dictionary from handler to how many phantom fines its requests issued; only handlers with at least one phantom fine appear\n"
                        "- `guilty_handler`: the handler (a string) with the most phantom fines. Use `max(phantom_by_handler, key=phantom_by_handler.get)`; if two handlers tie, `max` keeps the one that comes first in the dictionary\n\n"
                        "**Then** print `guilty_handler` (the starter already does).\n\n"
                        "**Example:** `request_started` events `{\"request_id\": \"r1\", \"handler\": \"a\"}` and `{\"request_id\": \"r2\", \"handler\": \"b\"}`, and phantom fines from requests `r2`, `r2`, `r1`, give `handler_of == {\"r1\": \"a\", \"r2\": \"b\"}`, `phantom_by_handler == {\"b\": 2, \"a\": 1}` and `guilty_handler == \"b\"`.",
            "starter": _FINES_PHANTOM + "\nhandler_of = {}\nphantom_by_handler = {}\nguilty_handler = None\n# your code here\n\nprint(\"Phantom fines per handler:\", phantom_by_handler)\nprint(\"Guilty code path:\", guilty_handler)\n",
            "solution": _FINES_PHANTOM + "\nhandler_of = {}\nfor e in events:\n    if e[\"event\"] == \"request_started\":\n        handler_of[e[\"request_id\"]] = e[\"handler\"]\n\nphantom_by_handler = {}\nfor fine in phantom:\n    h = handler_of[fine[\"request_id\"]]\n    phantom_by_handler[h] = phantom_by_handler.get(h, 0) + 1\n\nguilty_handler = max(phantom_by_handler, key=phantom_by_handler.get)\n\nprint(\"Phantom fines per handler:\", phantom_by_handler)\nprint(\"Guilty code path:\", guilty_handler)\n",
            "tests": _FINES_TRUTH + r'''assert handler_of == _handler_of, f"handler_of should map each request_id to the handler on its request_started line: expected {_handler_of}, got {handler_of}"
assert phantom_by_handler == _by_handler, f"phantom_by_handler should be {_by_handler} on this log, got {phantom_by_handler}"
assert guilty_handler == _guilty, f"the handler with the most phantom fines here is {_guilty!r}, got {guilty_handler!r}. The handler with the most ERROR lines is a different question."''',
            "tips": [
                "Build `handler_of` with a loop over `events` and `if e[\"event\"] == \"request_started\":`. Then for each fine in `phantom`, `h = handler_of[fine[\"request_id\"]]` is its code path.",
                "Count with `phantom_by_handler[h] = phantom_by_handler.get(h, 0) + 1`. The biggest count: `max(phantom_by_handler, key=phantom_by_handler.get)`.",
            ],
            "reveal": "Most of the phantom fines came out of one code path, and it isn't the one with the most ERROR lines. The guilty handler logged nothing but cheerful INFO lines while it fined people for books already on the shelf.",
        },
        {
            "notes": "**Which patch broke it.** Each patch in `patches` changed one `handler` and went live at the time `deployed`. The guilty patch is the one that:\n"
                     "- changed the guilty handler, and\n"
                     "- was deployed **before** the first phantom fine **that the guilty handler issued** (strictly earlier than its `ts`), and\n"
                     "- is the **latest** patch that fits both rules. Older patches to that handler were followed by a clean night; a patch deployed after that first phantom fine came too late to cause it.\n\n"
                     "A stray phantom fine from some other handler doesn't count when you look for the first one.\n\n"
                     "**Timestamps** are text like `\"2026-11-19T18:15:00\"`, always the same length, so comparing them as text with `<` and `>` compares the times.",
            "question": "**Goal:** name the clerk whose patch dropped the `returned_on` check.\n\n"
                        "**You have:**\n"
                        "- `phantom` (the phantom fines in log order), `handler_of` and `guilty_handler` from step 3. The starter computes them.\n"
                        "- `patches`, a list of dictionaries **not** in time order, e.g. `{\"clerk\": \"Wen Zhao\", \"handler\": \"fines.nightly_sweep\", \"deployed\": \"2026-11-19T18:15:00\", \"note\": \"refactor sweep loop\"}`.\n\n"
                        "**Write** two variables:\n"
                        "- `first_bad`: the `ts` (a string) of the first phantom fine whose request's handler is `guilty_handler`\n"
                        "- `culprit`: the `clerk` (a string) of the guilty patch (see the field notes)\n\n"
                        "**Then** print them; the starter's last two lines already do.\n\n"
                        "**Example:** guilty handler `\"a\"`, `first_bad = \"2026-01-02T01:00:00\"`, and patches X on `\"a\"` at `\"2026-01-01T09:00:00\"`, Y on `\"a\"` at `\"2026-01-01T20:00:00\"`, Z on `\"b\"` at `\"2026-01-01T23:00:00\"`, W on `\"a\"` at `\"2026-01-02T08:00:00\"`: the culprit is `\"Y\"`. Z was later but changed another handler; W came after the damage.",
            "starter": _FINES_GUILTY + "\nfirst_bad = None\nculprit = None\n# your code here\n\nprint(\"First phantom fine:\", first_bad)\nprint(\"The patch came from\", culprit)\n",
            "solution": _FINES_CULPRIT + "\nprint(\"First phantom fine:\", first_bad)\nprint(\"The patch came from\", culprit)\n",
            "tests": _FINES_TRUTH + r'''assert first_bad == _first_bad, f"first_bad should be the ts of the first phantom fine issued by {_guilty}: {_first_bad!r}, got {first_bad!r}"
assert culprit is not None, "culprit is still None: loop over patches and keep the latest one that fits all the rules"
assert culprit == _culprit, f"wrong clerk. On this evidence the guilty patch changed {_guilty!r} and is the latest one deployed before {_first_bad}. The patch closest in time may have changed a different handler."
assert str(culprit) in __output__, "print the clerk's name"''',
            "tips": [
                "`first_bad`: loop over `phantom`, and at the first fine where `handler_of[fine[\"request_id\"]] == guilty_handler`, store its `ts` and `break`. Then keep the best patch so far in `best = None`; a patch fits if `p[\"handler\"] == guilty_handler and p[\"deployed\"] < first_bad`.",
                "Replace `best` when it is still `None` or the patch is later: `if best is None or p[\"deployed\"] > best[\"deployed\"]: best = p`. After the loop, `culprit = best[\"clerk\"]`.",
            ],
            "reveal": "One patch, deployed hours before the first phantom fine, changed the guilty handler. The old version asked whether `returned_on` was set; the new one never does. The patch note doesn't mention it at all.",
        },
        {
            "notes": "**Refunds.** Every phantom fine is paid back to its member, whichever handler issued it. A member's refund is the **sum** of the `amount` of all their phantom fines, rounded to 2 decimal places with `round(..., 2)`.",
            "question": "**Goal:** work out how much each wronged patron gets back.\n\n"
                        "**You have:** `phantom`, the list of phantom fine events (the starter builds it, along with everything from steps 1 to 4). Each has a `member_id` and an `amount`, e.g. `{\"event\": \"fine_issued\", \"member_id\": \"M004\", \"amount\": 2.5, ...}`.\n\n"
                        "**Write** a variable `refunds`:\n"
                        "- a dictionary from `member_id` to that member's refund (see the field notes)\n"
                        "- only members with at least one phantom fine appear\n\n"
                        "**Then** print `refunds` (the starter already does).\n\n"
                        "**Example:** phantom fines of `2.5` and `2.0` for `M004` and `1.0` for `M009` give `refunds == {\"M004\": 4.5, \"M009\": 1.0}`.",
            "starter": _FINES_CULPRIT + "\nrefunds = {}\n# add up each member's phantom fines here\n\nprint(\"Refunds:\", refunds)\n",
            "solution": _FINES_REFUNDS + "\nprint(\"Refunds:\", refunds)\n",
            "tests": _FINES_TRUTH + r'''assert refunds == _refunds, f"refunds should be {_refunds} on this evidence, got {refunds}"''',
            "tips": [
                "Loop with `for fine in phantom:` and read `member = fine[\"member_id\"]`.",
                "Add with `refunds[member] = round(refunds.get(member, 0) + fine[\"amount\"], 2)`: `.get(member, 0)` starts a new member at 0.",
            ],
            "reveal": "Every wronged patron has a figure next to their name. Now the Lab has to put it on the record.",
        },
        {
            "notes": "**The Lab's log format.** The Lab files its report as a structured log: one JSON object per line, with these keys:\n"
                     "- `level`: the level name, e.g. `\"WARNING\"`\n"
                     "- `event`: the event name (the log message), e.g. `\"refund_due\"`\n"
                     "- then each name in the formatter's `FIELDS` that the record actually has, e.g. `\"member_id\"` and `\"amount\"`\n\n"
                     "Two kinds of line: one `refund_due` line at WARNING level per member, and one `culprit_named` line at ERROR level.",
            "question": "**Goal:** file the case in the Lab's structured log: a refund line for every wronged member, then the accusation.\n\n"
                        "**You have:** `refunds`, `guilty_handler` and `culprit` from the earlier steps, and a logger `lab_log` (name `\"lab.phantom-fines\"`, level INFO, `propagate = False`) whose handler writes into `report`, an `io.StringIO`. All of this is already in the starter.\n\n"
                        "**Write:**\n"
                        "- the body of `JsonFormatter.format(self, record)`: build a dict with `\"level\"` (`record.levelname`) and `\"event\"` (`record.getMessage()`), add each name in `self.FIELDS` that the record has (`hasattr(record, name)`) with its value (`getattr(record, name)`), and return `json.dumps(...)` of the dict\n"
                        "- for each member in **sorted** order of `member_id`: `lab_log.warning(\"refund_due\", extra={\"member_id\": ..., \"amount\": ...})`\n"
                        "- after those: `lab_log.error(\"culprit_named\", extra={\"clerk\": culprit, \"handler\": guilty_handler})`\n\n"
                        "**Then** print the report: the starter's last line already does `print(report.getvalue())`.\n\n"
                        "**Example:** with `refunds == {\"M009\": 1.0, \"M004\": 4.5}`, the first report line is `{\"level\": \"WARNING\", \"event\": \"refund_due\", \"member_id\": \"M004\", \"amount\": 4.5}` and the last one is the `culprit_named` line.",
            "starter": _FINES_REFUNDS + "\nimport io\nimport logging\n\n\nclass JsonFormatter(logging.Formatter):\n    FIELDS = (\"member_id\", \"amount\", \"clerk\", \"handler\")\n\n    def format(self, record):\n        ...  # your code here\n\n\nreport = io.StringIO()\nstream_handler = logging.StreamHandler(report)\nstream_handler.setFormatter(JsonFormatter())\nlab_log = logging.getLogger(\"lab.phantom-fines\")\nlab_log.handlers.clear()\nlab_log.addHandler(stream_handler)\nlab_log.propagate = False\nlab_log.setLevel(logging.INFO)\n\n# log the refund lines and the accusation here\n\nprint(report.getvalue())\n",
            "solution": _FINES_REFUNDS + "\nimport io\nimport logging\n\n\nclass JsonFormatter(logging.Formatter):\n    FIELDS = (\"member_id\", \"amount\", \"clerk\", \"handler\")\n\n    def format(self, record):\n        data = {\"level\": record.levelname, \"event\": record.getMessage()}\n        for name in self.FIELDS:\n            if hasattr(record, name):\n                data[name] = getattr(record, name)\n        return json.dumps(data)\n\n\nreport = io.StringIO()\nstream_handler = logging.StreamHandler(report)\nstream_handler.setFormatter(JsonFormatter())\nlab_log = logging.getLogger(\"lab.phantom-fines\")\nlab_log.handlers.clear()\nlab_log.addHandler(stream_handler)\nlab_log.propagate = False\nlab_log.setLevel(logging.INFO)\n\nfor member in sorted(refunds):\n    lab_log.warning(\"refund_due\", extra={\"member_id\": member, \"amount\": refunds[member]})\nlab_log.error(\"culprit_named\", extra={\"clerk\": culprit, \"handler\": guilty_handler})\n\nprint(report.getvalue())\n",
            "tests": _FINES_TRUTH + r'''_lines = [_l for _l in report.getvalue().splitlines() if _l.strip()]
_got = []
for _l in _lines:
    try:
        _got.append(_json.loads(_l))
    except ValueError:
        raise AssertionError("every report line must be JSON from JsonFormatter.format, but this one isn't: " + repr(_l))
_exp = [{"level": "WARNING", "event": "refund_due", "member_id": _m, "amount": _refunds[_m]} for _m in sorted(_refunds)]
_last = {"level": "ERROR", "event": "culprit_named", "clerk": _culprit, "handler": _guilty}
_exp.append(_last)
assert len(_got) == len(_exp), f"the report should have {len(_exp)} lines ({len(_exp) - 1} refund_due lines, then culprit_named), got {len(_got)}"
for _i in range(len(_exp)):
    _want = _exp[_i]
    assert _got[_i] == _want, f"report line {_i + 1} should be {_want}, got {_got[_i]}"''',
            "tips": [
                "In `format`: `data = {\"level\": record.levelname, \"event\": record.getMessage()}`, then `for name in self.FIELDS:` and `if hasattr(record, name): data[name] = getattr(record, name)`. End with `return json.dumps(data)`.",
                "`for member in sorted(refunds):` logs one warning each, with `extra={\"member_id\": member, \"amount\": refunds[member]}`. The error line comes once, after the loop.",
            ],
            "reveal": "The report is filed: every wronged patron gets their money back, and one clerk's name sits in the Lab's log at ERROR level. Inside the bad patch, the Lab finds one more line, a comment that does nothing at all: `# X`.",
        },
    ],
    "closing": "Case closed. The clerk swears they never wrote that line, and the Lab believes them: the commit that dropped the `returned_on` check was not made from their machine. It came from the shared laptop in the **staff room**, the one that only unlocks with a Bureau **staff badge**, at an hour when the clerk was at home. Its only message is a single letter: **X**. Whoever X is, they can walk into the Bureau's staff room.",
    "fragment": "The bad patch was committed from the staff-room laptop, which only unlocks with a Bureau staff badge: X has, or borrows, a staff badge.",
}

# ======================================================================
# Chapter 5 finale: The Rigged Verdict
# ======================================================================

# Three styles of fine desk. NAME is replaced by the clerk's class name in each variant.
_DESK_GOOD_1 = '''class NAME:
    def __init__(self, clock):
        self.clock = clock
        self.fines = {}

    def charge(self, member_id, due):
        if not isinstance(due, date):
            raise ValueError("due must be a date")
        days = (self.clock() - due).days
        fee = min(20.0, max(0, days) * 0.5)
        self.fines[member_id] = self.fines.get(member_id, 0.0) + fee
        return fee

    def total(self, member_id):
        return self.fines.get(member_id, 0.0)
'''

_DESK_GOOD_2 = '''class NAME:
    RATE = 0.5
    CAP = 20.0

    def __init__(self, clock):
        self.clock = clock
        self.fines = {}

    def charge(self, member_id, due):
        if not isinstance(due, date):
            raise ValueError(f"bad due date: {due!r}")
        days_late = (self.clock() - due).days
        if days_late <= 0:
            fee = 0.0
        else:
            fee = min(self.CAP, days_late * self.RATE)
        self.fines[member_id] = self.total(member_id) + fee
        return fee

    def total(self, member_id):
        return self.fines.get(member_id, 0.0)
'''

_DESK_SHARED = '''class NAME:
    fines = {}

    def __init__(self, clock):
        self.clock = clock

    def charge(self, member_id, due):
        if not isinstance(due, date):
            raise ValueError("due must be a date")
        days = (self.clock() - due).days
        fee = min(20.0, max(0, days) * 0.5)
        self.fines[member_id] = self.fines.get(member_id, 0.0) + fee
        return fee

    def total(self, member_id):
        return self.fines.get(member_id, 0.0)
'''

_DESK_REAL_CLOCK = '''class NAME:
    def __init__(self, clock):
        self.clock = clock
        self.fines = {}

    def charge(self, member_id, due):
        if not isinstance(due, date):
            raise ValueError("due must be a date")
        today = date.today()
        days = (today - due).days
        fee = min(20.0, max(0, days) * 0.5)
        self.fines[member_id] = self.fines.get(member_id, 0.0) + fee
        return fee

    def total(self, member_id):
        return self.fines.get(member_id, 0.0)
'''

_DESK_SWALLOW = '''class NAME:
    def __init__(self, clock):
        self.clock = clock
        self.fines = {}

    def charge(self, member_id, due):
        try:
            days = (self.clock() - due).days
            fee = min(20.0, max(0, days) * 0.5)
        except Exception:
            fee = 0.0
        self.fines[member_id] = self.fines.get(member_id, 0.0) + fee
        return fee

    def total(self, member_id):
        return self.fines.get(member_id, 0.0)
'''

# The old suite's checks. Some really check something; the "toothless" ones pass whatever the desk does.
_OLD_CHECKS = {
    "check_desk_opens": '''def check_desk_opens(desk_class):
    desk = desk_class(clock=lambda: date(2026, 5, 18))
    assert desk is not None
''',
    "check_charge_runs": '''def check_charge_runs(desk_class):
    desk = desk_class(clock=lambda: date(2026, 5, 18))
    desk.charge("M001", date(2026, 5, 10))
''',
    "check_total_exists": '''def check_total_exists(desk_class):
    desk = desk_class(clock=lambda: date(2026, 5, 18))
    desk.charge("M001", date(2026, 5, 10))
    assert desk.total("M001") is not None
''',
    "check_fee_never_crashes": '''def check_fee_never_crashes(desk_class):
    desk = desk_class(clock=lambda: date(2026, 5, 18))
    try:
        assert desk.charge("M001", date(2026, 5, 1)) == 8.5
    except AssertionError:
        pass
''',
    "check_on_time_is_free": '''def check_on_time_is_free(desk_class):
    desk = desk_class(clock=lambda: date(2026, 5, 18))
    assert desk.charge("M001", date(2026, 5, 18)) == 0.0
''',
    "check_four_days_late": '''def check_four_days_late(desk_class):
    desk = desk_class(clock=lambda: date(2026, 5, 18))
    assert desk.charge("M001", date(2026, 5, 14)) == 2.0
''',
    "check_cap": '''def check_cap(desk_class):
    desk = desk_class(clock=lambda: date(2026, 5, 18))
    assert desk.charge("M001", date(2026, 1, 1)) == 20.0
''',
    "check_future_due_is_free": '''def check_future_due_is_free(desk_class):
    desk = desk_class(clock=lambda: date(2026, 5, 18))
    assert desk.charge("M001", date(2099, 1, 1)) == 0.0
''',
    "check_bad_due_rejected": '''def check_bad_due_rejected(desk_class):
    desk = desk_class(clock=lambda: date(2026, 5, 18))
    try:
        desk.charge("M001", None)
    except ValueError:
        return
    raise AssertionError("charge(None) should raise ValueError")
''',
}


def _rv_variant(desks, scapegoat, checks):
    src = "from datetime import date\n\n\n"
    for cls_name, template in desks:
        src += template.replace("NAME", cls_name) + "\n\n"
    src += "suspects = {\"Asha Rao\": AshaDesk, \"Bram Olsen\": BramDesk, \"Chidi Eze\": ChidiDesk}\n"
    src += f"scapegoat = {scapegoat!r}\n\n\n# The old test suite: green for every desk.\n"
    for name in checks:
        src += _OLD_CHECKS[name] + "\n\n"
    src += "old_suite = [" + ", ".join(checks) + "]\n"
    return src


_RV_V1 = _rv_variant(
    [("AshaDesk", _DESK_GOOD_1), ("BramDesk", _DESK_SHARED), ("ChidiDesk", _DESK_GOOD_2)], "Asha Rao",
    ["check_desk_opens", "check_four_days_late", "check_charge_runs", "check_cap", "check_fee_never_crashes"])
_RV_V2 = _rv_variant(
    [("AshaDesk", _DESK_GOOD_2), ("BramDesk", _DESK_GOOD_1), ("ChidiDesk", _DESK_REAL_CLOCK)], "Bram Olsen",
    ["check_future_due_is_free", "check_total_exists", "check_bad_due_rejected", "check_desk_opens"])
_RV_V3 = _rv_variant(
    [("AshaDesk", _DESK_SWALLOW), ("BramDesk", _DESK_GOOD_2), ("ChidiDesk", _DESK_GOOD_1)], "Chidi Eze",
    ["check_on_time_is_free", "check_charge_runs", "check_fee_never_crashes", "check_total_exists", "check_four_days_late"])

# The mini test runner every later step's starter contains (machinery: the trainee doesn't write it).
_RV_RUNNER = '''import inspect
from contextlib import contextmanager
from datetime import date
from unittest.mock import MagicMock

# ---- mini pytest (a stand-in; you don't need to change it) ----

FIXTURES = {}


def fixture(fn):
    FIXTURES[fn.__name__] = fn
    return fn


def parametrize(argnames, rows):
    def mark(fn):
        fn.argnames = [name.strip() for name in argnames.split(",")]
        if "," in argnames:
            fn.rows = list(rows)
        else:
            fn.rows = [(row,) for row in rows]
        return fn
    return mark


@contextmanager
def raises(error):
    try:
        yield
    except error:
        return
    raise AssertionError(f"DID NOT RAISE {error.__name__}")


def build(name, made):
    if name not in made:
        fx = FIXTURES[name]
        made[name] = fx(**{p: build(p, made) for p in inspect.signature(fx).parameters})
    return made[name]


def run_suite(namespace, desk_class):
    """Run every test_ function against one desk class; return the labels that failed."""
    failed = []
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            for row in getattr(fn, "rows", [()]):
                label = f"{name}{list(row)}" if row else name
                made = {"desk_class": desk_class}
                made.update(zip(getattr(fn, "argnames", []), row))
                try:
                    fn(**{p: build(p, made) for p in inspect.signature(fn).parameters})
                except Exception as e:
                    failed.append(label)
                    print(f"  {label} FAILED: {type(e).__name__}: {e}")
    return failed

# ---- your tests start here ----

TODAY = date(2031, 3, 10)
'''

_RV_FEE_TEST = '''

@parametrize("due, expected", [
    (date(2031, 3, 10), 0.0),
    (date(2031, 3, 7), 1.5),
    (date(2031, 3, 20), 0.0),
    (date(2030, 12, 1), 20.0),
])
def test_fee(desk_class, due, expected):
    clock = MagicMock(return_value=TODAY)
    desk = desk_class(clock=clock)
    assert desk.charge("M001", due) == expected
    clock.assert_called()
'''

_RV_FIXTURES = '''

@fixture
def clock():
    return lambda: TODAY


@fixture
def desk(desk_class, clock):
    return desk_class(clock=clock)
'''

_RV_SHARE_TESTS = '''

@fixture
def other_desk(desk_class, clock):
    return desk_class(clock=clock)


def test_total_adds_up(desk):
    desk.charge("M001", date(2031, 3, 7))
    desk.charge("M001", date(2031, 3, 9))
    assert desk.total("M001") == 2.0


def test_desks_do_not_share(desk, other_desk):
    desk.charge("M001", date(2031, 3, 7))
    assert other_desk.total("M001") == 0.0
'''

_RV_BAD_TEST = '''

@parametrize("bad", [None, "2031-03-07", 20310307])
def test_bad_due_raises(desk, bad):
    with raises(ValueError):
        desk.charge("M001", bad)
'''


def _rv_loop(var):
    return (f"\n\n{var} = {{}}\nfor name, desk_class in suspects.items():\n    print(name)\n"
            f"    {var}[name] = run_suite(globals(), desk_class)\nprint({var})\n")


# Reference desks and checks the tests use to judge the trainee's tests (never the trainee's variables).
_RV_TRUTH = r'''from datetime import date as _date
from unittest.mock import MagicMock as _MM

_TODAY = _date(2031, 3, 10)


class _Good:
    def __init__(self, clock):
        self.clock = clock
        self.fines = {}

    def charge(self, member_id, due):
        if not isinstance(due, _date):
            raise ValueError("due must be a date")
        _fee = min(20.0, max(0, (self.clock() - due).days) * 0.5)
        self.fines[member_id] = self.fines.get(member_id, 0.0) + _fee
        return _fee

    def total(self, member_id):
        return self.fines.get(member_id, 0.0)


class _RealClock(_Good):
    def charge(self, member_id, due):
        if not isinstance(due, _date):
            raise ValueError("due must be a date")
        _fee = min(20.0, max(0, (_date.today() - due).days) * 0.5)
        self.fines[member_id] = self.fines.get(member_id, 0.0) + _fee
        return _fee


class _NoCap(_Good):
    def charge(self, member_id, due):
        if not isinstance(due, _date):
            raise ValueError("due must be a date")
        self.clock()
        return max(0, (self.clock() - due).days) * 0.5


class _NoFloor(_Good):
    def charge(self, member_id, due):
        if not isinstance(due, _date):
            raise ValueError("due must be a date")
        return min(20.0, (self.clock() - due).days * 0.5)


class _Shared(_Good):
    pool = {}

    def __init__(self, clock):
        self.clock = clock
        self.fines = _Shared.pool


class _Swallow(_Good):
    def charge(self, member_id, due):
        try:
            return _Good.charge(self, member_id, due)
        except Exception:
            return 0.0


class _WrongRate(_Good):
    def charge(self, member_id, due):
        if not isinstance(due, _date):
            raise ValueError("due must be a date")
        _fee = min(20.0, max(0, (self.clock() - due).days) * 1.0)
        self.fines[member_id] = self.fines.get(member_id, 0.0) + _fee
        return _fee


class _LastOnly(_Good):
    def charge(self, member_id, due):
        _fee = _Good.charge(self, member_id, due)
        self.fines[member_id] = _fee
        return _fee


def _shared_class():
    class _SharedFresh(_Good):
        pool = {}

        def __init__(self, clock):
            self.clock = clock
            self.fines = _SharedFresh.pool
    return _SharedFresh


def _share_only_ok(cls):
    try:
        _b = cls(clock=lambda: _TODAY)
        _c = cls(clock=lambda: _TODAY)
        _b.charge("M001", _date(2031, 3, 7))
        return _c.total("M001") == 0.0
    except Exception:
        return False


def _fee_ok(cls):
    try:
        for _d, _x in [(_date(2031, 3, 10), 0.0), (_date(2031, 3, 7), 1.5), (_date(2031, 3, 20), 0.0), (_date(2030, 12, 1), 20.0)]:
            _c = _MM(return_value=_TODAY)
            if cls(clock=_c).charge("M001", _d) != _x or not _c.called:
                return False
        return True
    except Exception:
        return False


def _share_ok(cls):
    try:
        _a = cls(clock=lambda: _TODAY)
        _a.charge("M001", _date(2031, 3, 7))
        _a.charge("M001", _date(2031, 3, 9))
        if _a.total("M001") != 2.0:
            return False
        _b = cls(clock=lambda: _TODAY)
        _c = cls(clock=lambda: _TODAY)
        _b.charge("M001", _date(2031, 3, 7))
        return _c.total("M001") == 0.0
    except Exception:
        return False


def _bad_ok(cls):
    for _v in (None, "2031-03-07", 20310307):
        try:
            cls(clock=lambda: _TODAY).charge("M001", _v)
            return False
        except ValueError:
            pass
        except Exception:
            return False
    return True


def _failing(results):
    assert isinstance(results, dict) and set(results) == set(suspects), f"store a dict with one entry per suspect: {sorted(suspects)}"
    return {_n for _n, _f in results.items() if _f}
'''

RIGGED_VERDICT = {
    "id": "rigged-verdict",
    "tier": "big",
    "title": "The Rigged Verdict",
    "teaser": "The test suite was green for every fine desk, so the Board blamed a clerk. The suite was lying.",
    "skills": ["lab-bench", "microscope", "logbook", "test-bench", "decoy-kit"],
    "story": (
        "After the phantom fines, three clerks each wrote a new **fine desk** for the branches: a class that charges late fees "
        "and keeps a running total per member. Last week patrons were billed wrongly again. The Board ran the Lab's old test suite: "
        "**green for all three desks**. \"The code is fine, so the clerk is to blame,\" they said, and suspended one of the clerks, the `scapegoat`.\n\n"
        "The Lab doesn't believe a green suite that convicts people. Your job: find out what the old suite really checks, write "
        "tests that would catch a broken desk, and run them against every suspect.\n\n"
        "The evidence locker holds:\n"
        "- `AshaDesk`, `BramDesk`, `ChidiDesk`: the three desks, and `suspects`, a dictionary from each clerk's name to their class.\n"
        "- `scapegoat`: the name of the clerk the Board suspended.\n"
        "- `old_suite`: the old tests, as a list of functions. Each takes the desk **class** to test, e.g. `check_cap(desk_class)`.\n\n"
        "Every desk is built as `SomeDesk(clock=...)`, where `clock` is a function that returns today's date. Exactly one desk is really broken."
    ),
    "suspects": [
        {"name": "Asha Rao", "note": "Says her desk passes every test the Board ever ran."},
        {"name": "Bram Olsen", "note": "Wanted one ledger \"for the whole network\"."},
        {"name": "Chidi Eze", "note": "Newest on the team. Asked why his desk needs a clock at all."},
    ],
    "variants": [_RV_V1, _RV_V2, _RV_V3],
    "steps": [
        {
            "notes": "**A decoy.** `MagicMock()` (from `unittest.mock`) accepts any call and returns another MagicMock. Passed in as the desk class, `desk_class(clock=...)` gives a fake desk, and `desk.charge(...)` and `desk.total(...)` give MagicMocks too, never real numbers.\n\n"
                     "- A test that **really checks** something fails against the decoy: a MagicMock is never equal to `2.0`, and it never raises `ValueError`.\n"
                     "- A test that still **passes** against the decoy checks nothing at all. It is **toothless**: it stays green whatever the desk does.\n\n"
                     "A test **fails** when it raises any exception (an `assert` that is false raises `AssertionError`); it **passes** when it finishes without one.",
            "question": "**Goal:** find which tests in the old suite check nothing at all.\n\n"
                        "**You have:** `old_suite`, a list of test functions. Each takes one argument, the desk class to test, e.g. `check_cap(desk_class)`. A function's name is `fn.__name__`.\n\n"
                        "**Write** a variable `toothless`:\n"
                        "- run every test in `old_suite` with a **new** decoy, `test(MagicMock())`\n"
                        "- if it finishes without an exception, it is toothless: keep its name (`test.__name__`)\n"
                        "- if it raises any `Exception`, it has teeth: skip it, and don't let the error stop the loop\n"
                        "- `toothless` is a list of names (strings), **sorted** alphabetically\n\n"
                        "**Then** print `toothless` (the starter already does).\n\n"
                        "**Example:** for `def check_a(desk_class): desk_class(clock=None)` and `def check_b(desk_class): assert desk_class(clock=None).total(\"M1\") == 0.0`, only `check_a` passes against a decoy, so `toothless == [\"check_a\"]`.",
            "starter": "from unittest.mock import MagicMock\n\ntoothless = []\n# run every test in old_suite against a decoy here\n\nprint(\"Tests that check nothing:\", toothless)\n",
            "solution": "from unittest.mock import MagicMock\n\ntoothless = []\nfor test in old_suite:\n    try:\n        test(MagicMock())\n    except Exception:\n        continue\n    toothless.append(test.__name__)\ntoothless.sort()\n\nprint(\"Tests that check nothing:\", toothless)\n",
            "tests": r'''from unittest.mock import MagicMock as _MM
_exp = []
for _t in old_suite:
    try:
        _t(_MM())
    except Exception:
        continue
    _exp.append(_t.__name__)
_exp.sort()
assert toothless == _exp, f"on this evidence the toothless tests are {_exp}, got {toothless}. Run each test with a new MagicMock() and keep the names of the ones that raise nothing, sorted."''',
            "tips": [
                "Loop with `for test in old_suite:` and call `test(MagicMock())` inside a `try:`. `except Exception: continue` skips the tests that have teeth.",
                "After the `try`/`except`, `toothless.append(test.__name__)` runs only when nothing was raised. Sort at the end with `toothless.sort()`.",
            ],
            "reveal": "Some of the old tests would pass for a desk made of thin air: they never compare the desk against a real number, or they catch their own failure and carry on. The suite was green because it was built to be green.",
        },
        {
            "notes": "**The fee rule** for every desk:\n"
                     "- days late = today (from the desk's `clock`) minus the `due` date, in days\n"
                     "- the fee is **0.5 per day late**, never below `0.0` (on time or early costs nothing) and never above `20.0`\n"
                     "- `charge(member_id, due)` returns that fee\n\n"
                     "**A fake clock.** The desk must ask its injected `clock` for today. If the clock is a `MagicMock(return_value=TODAY)`, the test controls the date, and `clock.assert_called()` raises `AssertionError` if the desk never asked it (because it read the real date instead).\n\n"
                     "Here `TODAY` is `date(2031, 3, 10)`, years away from the real date, so a desk that reads the real calendar gets the wrong fee.\n\n"
                     "**Row labels.** The runner reports each row of a parametrized test as the test's name followed by the row's values in brackets, e.g. `test_fee[datetime.date(2031, 3, 7), 1.5]`.",
            "question": "**Goal:** a table-driven test that catches a desk that ignores its clock or gets the fee rule wrong.\n\n"
                        "**You have:** a mini pytest in the starter (`parametrize`, `fixture`, `raises` and `run_suite`; you don't change it), `TODAY = date(2031, 3, 10)`, and `suspects`. "
                        "`run_suite(globals(), desk_class)` runs every `test_` function against one desk class, filling a parameter named `desk_class` with that class; it prints and returns the list of failed labels.\n\n"
                        "**Write** the test `test_fee(desk_class, due, expected)` with a `@parametrize(\"due, expected\", [...])` table above it:\n"
                        "- the table needs at least four rows `(due, expected)`, and **you choose the dates**: one due exactly on `TODAY`, one a few days late (still under the cap), one due **after** `TODAY`, and one so late that the cap applies\n"
                        "- work out each `expected` fee yourself from the field notes\n"
                        "- the test must prove two things: the desk charges `expected` for `due` when today is `TODAY`, and the desk really asked its clock (use a `MagicMock` clock, see the field notes)\n"
                        "- charge the member `\"M001\"`\n\n"
                        "**Then** the starter's loop runs your test against every suspect and stores `fee_failures` (a dict from clerk to failed labels); leave it as it is.\n\n"
                        "**Example:** with today on 10 March, due on 4 March is 6 days late: `3.0`. A desk that charges `3.0` but never calls its clock still fails, on the `assert_called()` check.",
            "starter": _RV_RUNNER + "\n\n@parametrize(\"due, expected\", [\n    # your rows here, each a tuple (due, expected)\n])\ndef test_fee(desk_class, due, expected):\n    ...  # your code here\n" + _rv_loop("fee_failures"),
            "solution": _RV_RUNNER + _RV_FEE_TEST + _rv_loop("fee_failures"),
            "tests": _RV_TRUTH + r'''assert "test_fee" in globals() and len(getattr(test_fee, "rows", [])) >= 4, "write test_fee under @parametrize with at least four rows: on time, a few days late, early, and over the cap"
_honest = run_suite(globals(), _Good)
assert _honest == [], f"your test_fee fails on an honest desk: check the expected fee in these rows: {_honest}"
for _cls, _why in ((_RealClock, "reads the real date instead of its clock"), (_NoCap, "never caps the fee at 20.0"), (_NoFloor, "charges a negative fee when the book is due after today"), (_WrongRate, "charges 1.0 a day instead of 0.5")):
    assert run_suite(globals(), _cls) != [], f"your test_fee doesn't catch a desk that {_why}: check you have all four kinds of row, and that you call clock.assert_called()"
_exp = {_n for _n, _c in suspects.items() if not _fee_ok(_c)}
assert _failing(fee_failures) == _exp, f"on this evidence the desks failing test_fee should be {sorted(_exp) or 'none'}, got {sorted(_failing(fee_failures)) or 'none'}"''',
            "tips": [
                "Each row is a tuple, e.g. `(date(2031, 3, 4), 3.0),` for 6 days late. For the cap you need more than 40 days late, e.g. a due date in 2030.",
                "The body: `clock = MagicMock(return_value=TODAY)`, `desk = desk_class(clock=clock)`, `assert desk.charge(\"M001\", due) == expected`, then `clock.assert_called()`.",
            ],
            "reveal": "The fee table runs against all three desks. On some evidence it catches a desk reading the wall calendar instead of the clock it was handed; on other evidence every desk passes, and the problem is somewhere else.",
        },
        {
            "notes": "**Fresh state.** Every desk keeps its **own** running totals: `total(member_id)` is the sum of every fee that this desk charged that member (`0.0` if none). Two desks must never share totals: a fee charged at one branch must not show up at another.\n\n"
                     "**Fixtures.** A fixture is a function marked `@fixture`. A test asks for it by naming it as a parameter, and the runner builds a new one for every test. A fixture can ask for other fixtures, or for `desk_class`, the same way.\n\n"
                     "The fee rule is the same as in step 2: 0.5 per day late after `TODAY = date(2031, 3, 10)`, between `0.0` and `20.0`.",
            "question": "**Goal:** catch a desk whose totals are wrong, or leak from one desk into another.\n\n"
                        "**You have:** the mini pytest and `TODAY` as in step 2, and a finished fixture `clock()` that returns `lambda: TODAY`.\n\n"
                        "**Write** two fixtures and two tests:\n"
                        "- fixture `desk(desk_class, clock)`: returns a desk built from `desk_class` with that clock\n"
                        "- fixture `other_desk(desk_class, clock)`: a second, separate desk, built the same way\n"
                        "- `test_total_adds_up(desk)`: proves that charging the same member twice, for two **different** late due dates, makes `total` equal the sum of both fees (work the fees out from the rule)\n"
                        "- `test_desks_do_not_share(desk, other_desk)`: proves that a fee of more than `0.0` charged on `desk` does **not** appear in `other_desk`'s total for that member (it must still be `0.0`)\n"
                        "- put `@fixture` above each fixture, and nothing above the tests\n\n"
                        "**Then** the starter's loop stores `share_failures`, like step 2.\n\n"
                        "**Example:** if a desk keeps its `fines` dictionary on the class instead of on `self`, every desk shares it: charge 1.5 on one desk and the other desk's total is `1.5`, not `0.0`.",
            "starter": _RV_RUNNER + "\n\n@fixture\ndef clock():\n    return lambda: TODAY\n\n\n@fixture\ndef desk(desk_class, clock):\n    ...  # your code here\n\n\n# write the other_desk fixture and the two tests here\n" + _rv_loop("share_failures"),
            "solution": _RV_RUNNER + _RV_FIXTURES + _RV_SHARE_TESTS + _rv_loop("share_failures"),
            "tests": _RV_TRUTH + r'''for _t in ("test_total_adds_up", "test_desks_do_not_share"):
    assert _t in globals(), f"write the test {_t}"
for _f in ("desk", "other_desk"):
    assert _f in FIXTURES, f"mark {_f} with @fixture"
_honest = run_suite(globals(), _Good)
assert _honest == [], f"your tests fail on an honest desk: check the fees you expect in {_honest}"
_only_total = {"test_total_adds_up": test_total_adds_up}
_only_share = {"test_desks_do_not_share": test_desks_do_not_share}
assert run_suite(_only_total, _LastOnly) != [], "test_total_adds_up doesn't catch a desk whose total only keeps the last fee: charge twice, with two late dates, and check the sum"
assert run_suite(_only_share, _shared_class()) != [], "test_desks_do_not_share doesn't catch desks that share one fines dictionary: charge a fee above 0.0 on desk, then check other_desk.total is 0.0"
_must = {_n for _n, _c in suspects.items() if not _share_only_ok(_c)}
_may = {_n for _n, _c in suspects.items() if not _fee_ok(_c)}
_got = _failing(share_failures)
assert _must <= _got <= (_must | _may), f"on this evidence these desks must fail your tests: {sorted(_must) or 'none'}; you got failures for {sorted(_got) or 'none'}"''',
            "tips": [
                "Both fixtures are one line each: `return desk_class(clock=clock)`. Because they are two different fixtures, the runner builds two different desks.",
                "Due `date(2031, 3, 7)` is 3 days late (1.5) and `date(2031, 3, 9)` is 1 day late (0.5), so their total is 2.0. For the sharing test, charge on `desk`, then `assert other_desk.total(\"M001\") == 0.0`.",
            ],
            "reveal": "Two desks, one test. When a fee charged at one branch turns up at another, that desk keeps its ledger on the class itself, so every desk in the network writes into the same book.",
        },
        {
            "notes": "**Bad input.** `charge(member_id, due)` must raise `ValueError` when `due` is not a `date`: for example `None`, the text `\"2031-03-07\"`, or the number `20310307`. A desk that catches the error and quietly charges `0.0` instead **swallows** it: the bad record looks like a free, on-time return, and nobody ever hears about it.\n\n"
                     "`with raises(ValueError):` (in the starter) passes only if the code inside the block raises `ValueError`; otherwise it raises `AssertionError(\"DID NOT RAISE ValueError\")`.",
            "question": "**Goal:** catch a desk that swallows bad due dates instead of raising.\n\n"
                        "**You have:** the mini pytest, `TODAY`, and the finished fixtures `clock` and `desk` from step 3.\n\n"
                        "**Write** the test `test_bad_due_raises(desk, bad)`:\n"
                        "- above it, `@parametrize(\"bad\", [...])` with at least three bad values that you choose: `None`, a date written as text (a string), and a date written as a number (an int)\n"
                        "- the test must prove that charging member `\"M001\"` with a bad `due` raises `ValueError` (use `raises`, see the field notes)\n\n"
                        "**Then** the starter's loop stores `bad_failures`, like step 2.\n\n"
                        "**Example:** a desk whose `charge` wraps everything in `try:` / `except Exception: fee = 0.0` returns `0.0` for `None`, so the row `[None]` fails with `DID NOT RAISE ValueError`.",
            "starter": _RV_RUNNER + _RV_FIXTURES + "\n\n@parametrize(\"bad\", [None])\ndef test_bad_due_raises(desk, bad):\n    ...  # your code here\n" + _rv_loop("bad_failures"),
            "solution": _RV_RUNNER + _RV_FIXTURES + _RV_BAD_TEST + _rv_loop("bad_failures"),
            "tests": _RV_TRUTH + r'''assert "test_bad_due_raises" in globals(), "write the test test_bad_due_raises"
_rows = [_r[0] for _r in getattr(test_bad_due_raises, "rows", [])]
assert None in _rows and any(isinstance(_r, str) for _r in _rows) and any(isinstance(_r, int) and not isinstance(_r, bool) for _r in _rows), "the table needs at least three kinds of bad value: None, a date as text (e.g. \"2031-03-07\") and a date as a number (e.g. 20310307)"
assert run_suite(globals(), _Good) == [], "your test fails on an honest desk that raises ValueError: put the charge call inside with raises(ValueError):"
assert run_suite(globals(), _Swallow) != [], "your test doesn't catch a desk that swallows the error and returns 0.0"
_exp = {_n for _n, _c in suspects.items() if not _bad_ok(_c)}
assert _failing(bad_failures) == _exp, f"on this evidence the desks failing this test should be {sorted(_exp) or 'none'}, got {sorted(_failing(bad_failures)) or 'none'}"''',
            "tips": [
                "With one name, the rows are just the values, e.g. `@parametrize(\"bad\", [None, \"2031-03-07\", 20310307])`.",
                "The body is two lines: `with raises(ValueError):` and, indented under it, `desk.charge(\"M001\", bad)`.",
            ],
            "reveal": "Feed a desk garbage and an honest one complains loudly. On some evidence one desk just smiles and charges nothing, so every corrupted loan record sails through as a free return.",
        },
        {
            "notes": "**Reading the verdict.** Exactly one desk fails the full suite. Name its bug from the labels it failed, checking in this order and stopping at the first match:\n"
                     "1. any label starting with `\"test_fee\"`: `\"real clock\"`\n"
                     "2. any label starting with `\"test_desks_do_not_share\"`: `\"shared state\"`\n"
                     "3. any label starting with `\"test_bad_due_raises\"`: `\"swallowed error\"`\n\n"
                     "(A desk with the real-clock bug also fails `test_total_adds_up`, which is why the order matters.)\n\n"
                     "**Cleared** clerks are the ones whose desk failed **no** test at all. The `scapegoat` is cleared if their name is among them.",
            "question": "**Goal:** run the whole new suite against every desk and deliver the real verdict.\n\n"
                        "**You have:** the mini pytest and **all** your tests and fixtures from steps 2 to 4, already in the starter. `suspects` and `scapegoat` come from the evidence.\n\n"
                        "**Write** four variables:\n"
                        "- `verdict`: a dict from each clerk's name to `run_suite(globals(), their_class)` (the list of failed labels)\n"
                        "- `culprit`: the name of the one clerk whose list is not empty\n"
                        "- `bug`: `\"real clock\"`, `\"shared state\"` or `\"swallowed error\"`, from the culprit's failed labels (see the field notes)\n"
                        "- `cleared`: a list of the names of every clerk whose list is empty, **sorted** alphabetically\n\n"
                        "**Then** print them; the starter's last three lines already do.\n\n"
                        "**Example:** `verdict == {\"A\": [], \"B\": [\"test_desks_do_not_share\", \"test_total_adds_up\"], \"C\": []}` with scapegoat `\"A\"` gives `culprit == \"B\"`, `bug == \"shared state\"` and `cleared == [\"A\", \"C\"]`, so the scapegoat A is cleared.",
            "starter": _RV_RUNNER + _RV_FEE_TEST + _RV_FIXTURES + _RV_SHARE_TESTS + _RV_BAD_TEST + "\n\nverdict = {}\nculprit = None\nbug = None\ncleared = None\n# your code here\n\nprint(\"Verdict:\", verdict)\nprint(\"Guilty desk:\", culprit, \"-\", bug)\nprint(\"Cleared:\", cleared)\n",
            "solution": _RV_RUNNER + _RV_FEE_TEST + _RV_FIXTURES + _RV_SHARE_TESTS + _RV_BAD_TEST + "\n\nverdict = {}\nfor name, desk_class in suspects.items():\n    print(name)\n    verdict[name] = run_suite(globals(), desk_class)\n\nculprit = None\nfor name, failed in verdict.items():\n    if failed:\n        culprit = name\n\nlabels = verdict[culprit]\nif any(label.startswith(\"test_fee\") for label in labels):\n    bug = \"real clock\"\nelif any(label.startswith(\"test_desks_do_not_share\") for label in labels):\n    bug = \"shared state\"\nelse:\n    bug = \"swallowed error\"\n\ncleared = sorted(name for name, failed in verdict.items() if not failed)\n\nprint(\"Verdict:\", verdict)\nprint(\"Guilty desk:\", culprit, \"-\", bug)\nprint(\"Cleared:\", cleared)\n",
            "tests": _RV_TRUTH + r'''_fails = {_n: (not _fee_ok(_c), not _share_ok(_c), not _bad_ok(_c)) for _n, _c in suspects.items()}
_guilty = [_n for _n, _f in _fails.items() if any(_f)]
assert len(_guilty) == 1
_g = _guilty[0]
_bug = "real clock" if _fails[_g][0] else ("shared state" if _fails[_g][1] else "swallowed error")
assert _failing(verdict) == {_g}, f"verdict should show exactly one failing desk, {_g!r}'s; got failures for {sorted(_failing(verdict))}"
assert culprit == _g, f"the broken desk on this evidence belongs to {_g!r}, got {culprit!r}"
assert bug == _bug, f"{_g}'s desk fails because of: {_bug!r}, got {bug!r}. Check the labels in the order the field notes give."
_clear = sorted(_n for _n, _f in _fails.items() if not any(_f))
assert cleared == _clear, f"cleared should list every clerk whose desk failed nothing, sorted alphabetically: {_clear} on this evidence, got {cleared!r}"
assert str(culprit) in __output__ and str(bug) in __output__, "print the verdict"''',
            "tips": [
                "Build `verdict` with the same loop as steps 2 to 4. Then `for name, failed in verdict.items(): if failed: culprit = name`.",
                "`labels = verdict[culprit]`, then `if any(label.startswith(\"test_fee\") for label in labels):` ... `elif` ... `else`. Finally `cleared = sorted(name for name, failed in verdict.items() if not failed)`.",
            ],
            "reveal": "The new suite is red for exactly one desk, and it isn't the scapegoat's. The Board lifts the suspension. Someone checks who last edited the old suite, and finds every toothless test ends with the same comment: `# X`.",
        },
    ],
    "closing": "Case closed. The guilty clerk's bug was real, but careless, not criminal. The old suite was another matter: the file history shows it was rewritten on the Lab's own evidence terminal, from an account that was deleted years ago. The Bureau's archive still has that account's record: it was a **trainee detective** account, opened for a recruit at the **Bureau Academy**. Every test that checked nothing carries the comment `# X`. X didn't break the code this time. X broke the **tests**, so that the Lab would trust broken code and blame the wrong person.",
    "fragment": "The old suite was rigged from a deleted Bureau Academy trainee account: X once trained as a detective at the Bureau itself.",
}

# ======================================================================
# Chapter 6 finale: The Midnight Ledger
# ======================================================================

_LEDGER_TOOLS = '''

# The bank link's tools (from the Retry lesson).
class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status


TRANSIENT = {429, 500, 502, 503, 504}


def is_transient(error):
    if isinstance(error, TimeoutError):
        return True
    return isinstance(error, HTTPError) and error.status in TRANSIENT


def backoff(attempt, base=0.1, cap=2.0):
    return min(cap, base * 2 ** attempt)


def fake_server(*replies):
    replies = list(replies)
    def call():
        reply = replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return reply
    return call
'''

_LEDGER_V1 = '''start_balance = 1000

# The replayed night: (teller, action, amount), in the order it really happened.
schedule = [
    ("Mara", "read", None),
    ("Mara", "write", 200),
    ("Osei", "read", None),
    ("Lena", "read", None),
    ("Lena", "write", 500),
    ("Mara", "read", None),
    ("Mara", "write", 150),
    ("Osei", "write", 50),
    ("Ravi", "read", None),
    ("Ravi", "write", 300),
    ("Lena", "read", None),
    ("Mara", "read", None),
    ("Lena", "write", 80),
    ("Mara", "write", 120),
]
''' + _LEDGER_TOOLS + '''

transfers = [
    {"id": "TR-1", "teller": "Ravi", "amount": 400, "replies": [HTTPError(404)]},
    {"id": "TR-2", "teller": "Mara", "amount": 150, "replies": ["ok"]},
    {"id": "TR-3", "teller": "Lena", "amount": 220, "replies": [HTTPError(503), TimeoutError(), "ok"]},
    {"id": "TR-4", "teller": "Ravi", "amount": 90, "replies": [HTTPError(502), HTTPError(502), HTTPError(502), HTTPError(502)]},
]
'''

_LEDGER_V2 = '''start_balance = 2500

# The replayed night: (teller, action, amount), in the order it really happened.
schedule = [
    ("Ravi", "read", None),
    ("Osei", "read", None),
    ("Ravi", "write", 400),
    ("Lena", "read", None),
    ("Osei", "write", 250),
    ("Mara", "read", None),
    ("Mara", "write", 600),
    ("Ravi", "read", None),
    ("Ravi", "write", 90),
    ("Lena", "write", 700),
    ("Osei", "read", None),
    ("Osei", "write", 60),
]
''' + _LEDGER_TOOLS + '''

transfers = [
    {"id": "TR-1", "teller": "Osei", "amount": 300, "replies": [TimeoutError(), TimeoutError(), TimeoutError(), TimeoutError()]},
    {"id": "TR-2", "teller": "Mara", "amount": 120, "replies": [HTTPError(429), "ok"]},
    {"id": "TR-3", "teller": "Osei", "amount": 75, "replies": [HTTPError(403)]},
    {"id": "TR-4", "teller": "Ravi", "amount": 500, "replies": ["ok"]},
]
'''

_LEDGER_V3 = '''start_balance = 800

# The replayed night: (teller, action, amount), in the order it really happened.
schedule = [
    ("Lena", "read", None),
    ("Lena", "write", 120),
    ("Ravi", "read", None),
    ("Mara", "read", None),
    ("Mara", "write", 300),
    ("Osei", "read", None),
    ("Ravi", "write", 45),
    ("Osei", "write", 500),
    ("Lena", "read", None),
    ("Ravi", "read", None),
    ("Lena", "write", 75),
    ("Ravi", "write", 210),
    ("Mara", "read", None),
    ("Ravi", "read", None),
    ("Mara", "write", 40),
    ("Ravi", "write", 30),
]
''' + _LEDGER_TOOLS + '''

transfers = [
    {"id": "TR-1", "teller": "Lena", "amount": 60, "replies": ["ok"]},
    {"id": "TR-2", "teller": "Mara", "amount": 310, "replies": [HTTPError(500), HTTPError(500), HTTPError(500), "ok"]},
    {"id": "TR-3", "teller": "Mara", "amount": 45, "replies": [HTTPError(401)]},
    {"id": "TR-4", "teller": "Osei", "amount": 200, "replies": [TimeoutError(), "ok"]},
]
'''

_LEDGER_EXPECTED = '''expected_balance = start_balance + sum(amount for teller, action, amount in schedule if action == "write")
'''

_LEDGER_TRACE = '''def trace(schedule):
    """Every write in order, with the set of write numbers the vault holds right after it."""
    vault = set()
    copies = {}
    writes = []
    for teller, action, amount in schedule:
        if action == "read":
            copies[teller] = set(vault)
        else:
            n = len(writes)
            vault = copies[teller] | {n}
            writes.append({"teller": teller, "amount": amount, "contains": vault})
    return writes


writes = trace(schedule)
'''

_LEDGER_TELLER = '''def teller(name, shared, amounts, use_lock):
    for amount in amounts:
        while use_lock and shared["lock"] not in (None, name):
            yield
        if use_lock:
            shared["lock"] = name
        copy = shared["balance"]
        yield
        shared["balance"] = copy + amount
        shared["lock"] = None
        yield
'''

_LEDGER_RUNNER = '''night = {}
for name, action, amount in schedule:
    if action == "write":
        night.setdefault(name, []).append(amount)


def run_turns(tasks):
    """Round robin: each teller takes one turn (up to its next yield), then the next teller."""
    while tasks:
        for task in list(tasks):
            try:
                next(task)
            except StopIteration:
                tasks.remove(task)


def replay_night(use_lock):
    shared = {"balance": start_balance, "lock": None}
    run_turns([teller(name, shared, amounts, use_lock) for name, amounts in night.items()])
    return shared["balance"]
'''

_LEDGER_RETRY = '''def retry(call, *, attempts=4, sleep):
    """The Retry lesson's retry loop (finished: you don't need to change it)."""
    for attempt in range(attempts):
        try:
            return call()
        except Exception as error:
            if not is_transient(error) or attempt == attempts - 1:
                raise
            sleep(backoff(attempt))
'''

_LEDGER_POSTING = '''for t in transfers:
    try:
        retry(fake_server(*t["replies"]), sleep=waits.append)
    except Exception as e:
        bounced[t["id"]] = type(e).__name__
        bounced_by_teller[t["teller"]] = bounced_by_teller.get(t["teller"], 0) + 1
        continue
    cleared.append(t["id"])
    vault += t["amount"]
'''

_LEDGER_POST_VARS = '''vault = expected_balance
waits = []
cleared = []
bounced = {}
bounced_by_teller = {}
'''

_LEDGER_POST_PRINT = '''print("cleared:", cleared, "bounced:", bounced)
print("bounced per teller:", bounced_by_teller)
print("waits:", waits)
print("vault:", vault)
'''

# What the tests recompute from the evidence.
_LEDGER_TRUTH = r'''_bal = start_balance
_copy = {}
_vault = set()
_copyset = {}
_writes = []
for _t, _a, _amt in schedule:
    if _a == "read":
        _copy[_t] = _bal
        _copyset[_t] = set(_vault)
    else:
        _bal = _copy[_t] + _amt
        _vault = _copyset[_t] | {len(_writes)}
        _writes.append((_t, _amt, _vault))
_final = _bal
_expected = start_balance + sum(_w[1] for _w in _writes)
_lost = [(_w[0], _w[1]) for _n, _w in enumerate(_writes) if _n not in _vault]
_erased = {}
for _n in range(len(_writes)):
    if _n in _vault:
        continue
    for _later in _writes[_n + 1:]:
        if _n not in _later[2]:
            _erased[_later[0]] = _erased.get(_later[0], 0) + 1
            break
_culprit = max(_erased, key=_erased.get)
'''

MIDNIGHT_LEDGER = {
    "id": "midnight-ledger",
    "tier": "big",
    "title": "The Midnight Ledger",
    "teaser": "The vault took deposits all night. In the morning, the ledger was short. Nobody stole a coin.",
    "skills": ["lab-bench", "microscope", "logbook", "test-bench", "decoy-kit", "task-force", "switchboard", "field-resilience"],
    "story": (
        "The Bureau's vault ledger runs four tellers at once overnight. Each deposit is a **read-modify-write**: the teller "
        "reads the balance, adds the deposit to their copy, and writes it back. There is no lock. In the morning, the balance was short, "
        "although every deposit slip is accounted for.\n\n"
        "The Lab replayed the night from the tellers' logs:\n"
        "- `start_balance`: the balance at midnight.\n"
        "- `schedule`: every step that happened, in order, as `(teller, action, amount)`. `\"read\"` means the teller copied the balance "
        "(amount `None`); `\"write\"` means the teller stored **their copy + amount**.\n"
        "- `transfers`: the bank transfers still waiting to be posted, each with the `replies` the flaky bank link will give, in order.\n"
        "- `HTTPError`, `is_transient`, `backoff` and `fake_server`: the bank link's tools, exactly as in the Retry lesson.\n\n"
        "The night shift blames the teller whose bank transfers keep bouncing. The schedule tells a different story."
    ),
    "suspects": [
        {"name": "Mara", "note": "At least one of her deposits never showed up. She wants to know where it went."},
        {"name": "Osei", "note": "Says the vault software was \"acting strange\" all week."},
        {"name": "Lena", "note": "Took long breaks between reading the balance and writing it."},
        {"name": "Ravi", "note": "Ran a long report on his terminal all night."},
    ],
    "variants": [_LEDGER_V1, _LEDGER_V2, _LEDGER_V3],
    "steps": [
        {
            "notes": "**Replaying the schedule.** The vault starts at `start_balance`. Each teller keeps their own **copy**:\n"
                     "- `(teller, \"read\", None)`: the teller's copy becomes the current balance\n"
                     "- `(teller, \"write\", amount)`: the balance becomes **that teller's copy + amount**, even if the balance changed since they read it\n\n"
                     "**Expected balance**: `start_balance` plus every write's amount, as if no deposit were lost. **Missing**: expected minus final.",
            "question": "**Goal:** replay the night and measure how much money the ledger lost.\n\n"
                        "**You have:**\n"
                        "- `start_balance`, a number, e.g. `1000`\n"
                        "- `schedule`, a list of tuples `(teller, action, amount)`, e.g. `[(\"Mara\", \"read\", None), (\"Mara\", \"write\", 200)]`\n\n"
                        "**Write:**\n"
                        "- a function `replay(schedule, start)` that returns the final balance (see the field notes)\n"
                        "- `final_balance = replay(schedule, start_balance)`\n"
                        "- `expected_balance`: `start_balance` plus the amounts of all writes\n"
                        "- `missing`: `expected_balance - final_balance`\n\n"
                        "**Then** print the three numbers (the starter already does).\n\n"
                        "**Example:** with start `100` and schedule `A read, B read, A write 10, B write 20`: A writes 100 + 10 = 110, then B writes **their** copy 100 + 20 = 120. `replay` gives `120`, expected is `130`, missing is `10`.",
            "starter": "def replay(schedule, start):\n    ...  # your code here\n\n\nfinal_balance = replay(schedule, start_balance)\nexpected_balance = None\nmissing = None\n\nprint(\"final:\", final_balance, \"expected:\", expected_balance, \"missing:\", missing)\n",
            "solution": "def replay(schedule, start):\n    balance = start\n    copies = {}\n    for teller, action, amount in schedule:\n        if action == \"read\":\n            copies[teller] = balance\n        else:\n            balance = copies[teller] + amount\n    return balance\n\n\nfinal_balance = replay(schedule, start_balance)\nexpected_balance = start_balance + sum(amount for teller, action, amount in schedule if action == \"write\")\nmissing = expected_balance - final_balance\n\nprint(\"final:\", final_balance, \"expected:\", expected_balance, \"missing:\", missing)\n",
            "tests": _LEDGER_TRUTH + r'''_toy = [("A", "read", None), ("B", "read", None), ("A", "write", 10), ("B", "write", 20)]
assert replay(_toy, 100) == 120, f"replay of 'A read, B read, A write 10, B write 20' from 100 should be 120 (B writes their old copy + 20), got {replay(_toy, 100)!r}"
assert final_balance == _final, f"replaying this night gives {_final}, got {final_balance!r}"
assert expected_balance == _expected, f"expected_balance should be {_expected} (start plus every write's amount), got {expected_balance!r}"
assert missing == _expected - _final, f"missing should be {_expected - _final}, got {missing!r}"''',
            "tips": [
                "Keep `balance = start` and a dict `copies = {}`. On a read, `copies[teller] = balance`; on a write, `balance = copies[teller] + amount`.",
                "`sum(amount for teller, action, amount in schedule if action == \"write\")` adds up every deposit.",
            ],
            "reveal": "The vault is short, and the replay proves it without a single coin leaving the building. Deposits were written over by tellers holding stale copies.",
        },
        {
            "notes": "**Which deposits were lost.** Number the writes `0, 1, 2 ...` in schedule order. Think of the balance as also carrying a **set** of the write numbers that are inside it. At midnight it is the empty set.\n"
                     "- read: the teller copies the balance **and** a copy of its set\n"
                     "- write number `n`: the vault's new set is **the teller's copied set plus `n`** (whatever was added since that teller's read is gone)\n\n"
                     "A deposit is **lost** if its write number is **not** in the set after the last write. Every other deposit survived, even one that was wiped out for a while and came back because a later teller's copy still had it.",
            "question": "**Goal:** list exactly which deposits never made it into the morning balance.\n\n"
                        "**You have:** `schedule`, as in step 1.\n\n"
                        "**Write:**\n"
                        "- a function `lost_deposits(schedule)` that returns a list of `(teller, amount)` tuples, one per lost write, in schedule order (see the field notes)\n"
                        "- `lost = lost_deposits(schedule)`\n"
                        "- `lost_count`: how many deposits were lost\n\n"
                        "**Then** print them (the starter already does).\n\n"
                        "**Example:** `A read, B read, A write 10, B write 20`: A's write is number 0 and leaves the set `{0}`; B's copy was `set()`, so B's write leaves `{1}`. Write 0 is not in the final set, so `lost == [(\"A\", 10)]` and `lost_count == 1`.",
            "starter": "def lost_deposits(schedule):\n    ...  # your code here\n\n\nlost = lost_deposits(schedule)\nlost_count = None\n\nprint(lost_count, \"lost deposits:\", lost)\n",
            "solution": "def lost_deposits(schedule):\n    vault = set()\n    copies = {}\n    writes = []\n    for teller, action, amount in schedule:\n        if action == \"read\":\n            copies[teller] = set(vault)\n        else:\n            n = len(writes)\n            writes.append((teller, amount))\n            vault = copies[teller] | {n}\n    return [writes[n] for n in range(len(writes)) if n not in vault]\n\n\nlost = lost_deposits(schedule)\nlost_count = len(lost)\n\nprint(lost_count, \"lost deposits:\", lost)\n",
            "tests": _LEDGER_TRUTH + r'''_toy = [("A", "read", None), ("B", "read", None), ("A", "write", 10), ("B", "write", 20)]
assert lost_deposits(_toy) == [("A", 10)], f"for 'A read, B read, A write 10, B write 20' the lost deposit is [('A', 10)], got {lost_deposits(_toy)!r}"
_back = [("A", "read", None), ("A", "write", 5), ("B", "read", None), ("C", "read", None), ("C", "write", 7), ("B", "write", 3)]
assert lost_deposits(_back) == [("C", 7)], f"in 'A read, A write 5, B read, C read, C write 7, B write 3', B's copy already held A's 5, so only C's 7 is lost; got {lost_deposits(_back)!r}"
assert lost == _lost, f"on this night the lost deposits are {_lost}, got {lost!r}"
assert lost_count == len(_lost), f"lost_count should be {len(_lost)}, got {lost_count!r}"
assert sum(_x[1] for _x in _lost) == _expected - _final''',
            "tips": [
                "Keep `vault = set()`, `copies = {}` and a list `writes`. On a read, `copies[teller] = set(vault)`. On a write, `n = len(writes)`, append `(teller, amount)`, then `vault = copies[teller] | {n}`.",
                "At the end: `[writes[n] for n in range(len(writes)) if n not in vault]`. `lost_count` is just `len(lost)`.",
            ],
            "reveal": "The lost deposits add up to the missing money, coin for coin. They belong to several different tellers, so the question isn't whose money vanished, but whose stale write wiped it out.",
        },
        {
            "notes": "**A lock.** While a teller holds the lock, no other teller may read or write the balance; they wait their turn. So a teller's read and write can no longer have anyone else's write in between, and no deposit can be lost.\n\n"
                     "**The replay machine.** Each teller is a **generator**: every `yield` hands the turn to the next teller, like a thread being paused. `run_turns` (in the starter) gives each teller one turn at a time, round robin, until all are finished.\n\n"
                     "**Not the same night.** `replay_night` uses its own round-robin turns, not the exact order of `schedule`. So its total without the lock is usually **different** from `final_balance` in step 1, and that is fine: it is short in its own way. Only the locked total has to equal `expected_balance`.",
            "question": "**Goal:** prove that a lock would have saved every deposit.\n\n"
                        "**You have:** in the starter: `night`, a dict from teller to the list of their deposit amounts (built from `schedule`); `run_turns(tasks)`; and `replay_night(use_lock)`, which runs one `teller(...)` generator per teller on a shared dict `{\"balance\": start_balance, \"lock\": None}` and returns the final balance. `expected_balance` is computed too.\n\n"
                        "**Write** the generator `teller(name, shared, amounts, use_lock)`. For each `amount` in `amounts`, in this exact order:\n"
                        "1. `while use_lock and shared[\"lock\"] not in (None, name):` → `yield` (wait for the lock)\n"
                        "2. if `use_lock`: take the lock: `shared[\"lock\"] = name`\n"
                        "3. read: `copy = shared[\"balance\"]`, then `yield` (another teller may run here)\n"
                        "4. write: `shared[\"balance\"] = copy + amount`, release: `shared[\"lock\"] = None`, then `yield`\n\n"
                        "**Then** store `unlocked = replay_night(False)`, `locked = replay_night(True)` and `balanced = locked == expected_balance`. The starter prints them.\n\n"
                        "**Example:** two tellers depositing `[10]` and `[20]` from `0`: without the lock both read `0` and the balance ends at `20`; with the lock it ends at `30`.",
            "starter": _LEDGER_EXPECTED + "\n\ndef teller(name, shared, amounts, use_lock):\n    ...  # your code here\n    yield\n\n\n" + _LEDGER_RUNNER + "\n\nunlocked = None\nlocked = None\nbalanced = None\n\nprint(\"without a lock:\", unlocked, \"with a lock:\", locked, \"expected:\", expected_balance, \"balanced:\", balanced)\n",
            "solution": _LEDGER_EXPECTED + "\n\n" + _LEDGER_TELLER + "\n\n" + _LEDGER_RUNNER + "\n\nunlocked = replay_night(False)\nlocked = replay_night(True)\nbalanced = locked == expected_balance\n\nprint(\"without a lock:\", unlocked, \"with a lock:\", locked, \"expected:\", expected_balance, \"balanced:\", balanced)\n",
            "tests": _LEDGER_TRUTH + r'''def _ref_teller(name, shared, amounts, use_lock):
    for _amt in amounts:
        while use_lock and shared["lock"] not in (None, name):
            yield
        if use_lock:
            shared["lock"] = name
        _c = shared["balance"]
        yield
        shared["balance"] = _c + _amt
        shared["lock"] = None
        yield
def _ref_night(use_lock):
    _sh = {"balance": start_balance, "lock": None}
    _ts = [_ref_teller(_n, _sh, _a, use_lock) for _n, _a in night.items()]
    while _ts:
        for _t in list(_ts):
            try:
                next(_t)
            except StopIteration:
                _ts.remove(_t)
    return _sh["balance"]
_sh = {"balance": 0, "lock": None}
_ts = [teller("A", _sh, [10], False), teller("B", _sh, [20], False)]
run_turns(_ts)
assert _sh["balance"] == 20, f"without the lock, tellers A [10] and B [20] from 0 should end at 20 (both read 0), got {_sh['balance']}: read, yield, then write"
_sh = {"balance": 0, "lock": None}
run_turns([teller("A", _sh, [10, 5], True), teller("B", _sh, [20], True)])
assert _sh["balance"] == 35, f"with the lock, A [10, 5] and B [20] from 0 should end at 35, got {_sh['balance']}"
assert unlocked == _ref_night(False), f"without the lock this night should end at {_ref_night(False)}, got {unlocked!r}. Follow the four steps in order, with a yield after the read and after the write."
assert locked == _expected, f"with the lock every deposit should survive: {_expected}, got {locked!r}"
assert balanced is True, "balanced should be True when locked equals expected_balance"''',
            "tips": [
                "Start with `for amount in amounts:`. The waiting loop is `while use_lock and shared[\"lock\"] not in (None, name): yield`.",
                "Then `if use_lock: shared[\"lock\"] = name`, `copy = shared[\"balance\"]`, `yield`, `shared[\"balance\"] = copy + amount`, `shared[\"lock\"] = None`, `yield`.",
            ],
            "reveal": "Same tellers, same deposits. Without the lock the ledger comes up short again; with it, every coin lands. The vault's code gets its lock tonight.",
        },
        {
            "notes": "**Retry rules** (as in the Retry lesson):\n"
                     "- a call is tried at most `attempts` times (here 4); attempts are numbered from 0\n"
                     "- after a **transient** error (`is_transient(error)` is `True`: HTTP 429, 500, 502, 503, 504 or a timeout), if attempts are left, wait `backoff(attempt)` seconds and try again\n"
                     "- after a **permanent** error, or on the last attempt, give up and re-raise the error\n\n"
                     "**Posting a transfer.** If the bank link finally says `\"ok\"`, the transfer is **cleared** and its amount goes into the vault. If it gives up, the transfer **bounced**: record the error's class name (`type(e).__name__`, e.g. `\"HTTPError\"` or `\"TimeoutError\"`) and post nothing.",
            "question": "**Goal:** post the waiting bank transfers through the flaky link, and test the night shift's theory about the teller whose transfers keep bouncing.\n\n"
                        "**You have:**\n"
                        "- `transfers`, a list of dicts like `{\"id\": \"TR-2\", \"teller\": \"Mara\", \"amount\": 120, \"replies\": [HTTPError(429), \"ok\"]}`\n"
                        "- `fake_server(*replies)`, which returns a call that gives those replies one by one\n"
                        "- `retry(call, *, attempts=4, sleep)`, finished in the starter: it follows the field notes, returns `call()`'s result, or re-raises the error when it gives up. It waits by calling `sleep(seconds)`, never by really sleeping\n"
                        "- `vault`, which the starter sets to the corrected balance from step 3, and the empty `waits`, `cleared`, `bounced` and `bounced_by_teller`\n\n"
                        "**Write** a loop over `transfers`, in order. For each transfer `t`:\n"
                        "- call `retry(fake_server(*t[\"replies\"]), sleep=waits.append)` inside a `try`\n"
                        "- if it succeeds: append `t[\"id\"]` to `cleared` and add `t[\"amount\"]` to `vault`\n"
                        "- if it raises: store `bounced[t[\"id\"]] = type(e).__name__` and add 1 to that teller's count in `bounced_by_teller`\n"
                        "- `bounced_by_teller` is a dict from teller to how many of their transfers bounced; tellers with none don't appear\n\n"
                        "**Then** print them (the starter already does). `waits` ends up holding every delay, in order.\n\n"
                        "**Example:** replies `[HTTPError(503), TimeoutError(), \"ok\"]` clear on the third try after waits of `0.1` and `0.2`. Replies `[HTTPError(404)]` bounce at once with no wait, recorded as `\"HTTPError\"`.",
            "starter": _LEDGER_EXPECTED + "\n\n" + _LEDGER_RETRY + "\n\n" + _LEDGER_POST_VARS + "# post every transfer here\n\n" + _LEDGER_POST_PRINT,
            "solution": _LEDGER_EXPECTED + "\n\n" + _LEDGER_RETRY + "\n\n" + _LEDGER_POST_VARS + _LEDGER_POSTING + "\n" + _LEDGER_POST_PRINT,
            "tests": _LEDGER_TRUTH + r'''_w = []
_ok = []
_bad = {}
_byt = {}
_v = _expected
for _t in transfers:
    _r = list(_t["replies"])
    for _att in range(4):
        _rep = _r.pop(0)
        if not isinstance(_rep, Exception):
            _ok.append(_t["id"])
            _v += _t["amount"]
            break
        if not is_transient(_rep) or _att == 3:
            _bad[_t["id"]] = type(_rep).__name__
            _byt[_t["teller"]] = _byt.get(_t["teller"], 0) + 1
            break
        _w.append(backoff(_att))
assert cleared == _ok, f"the cleared transfers should be {_ok}, got {cleared}"
assert bounced == _bad, f"the bounced transfers should be {_bad}, got {bounced}"
assert bounced_by_teller == _byt, f"bounced_by_teller should be {_byt} on this evidence, got {bounced_by_teller}"
assert waits == _w, f"waits should be {_w}: pass sleep=waits.append to every retry call; got {waits}"
assert vault == _v, f"after posting, the vault should hold {_v}, got {vault}"''',
            "tips": [
                "`for t in transfers:` then `try:` with the `retry(...)` call inside. `except Exception as e:` stores `bounced[t[\"id\"]] = type(e).__name__`, counts the teller, then `continue`s to the next transfer.",
                "Count with `bounced_by_teller[t[\"teller\"]] = bounced_by_teller.get(t[\"teller\"], 0) + 1`. After the `try`/`except` (only reached on success): `cleared.append(t[\"id\"])` and `vault += t[\"amount\"]`.",
            ],
            "reveal": "Some transfers needed a few patient retries; some bounced for good. A bounce is the bank link refusing a transfer: it never touches the vault's balance, so bounced transfers can't explain the lost deposits. The night shift's theory proves nothing. The books balance. Now for whoever broke them.",
        },
        {
            "notes": "**Who erased a deposit.** Take a **lost** deposit, write number `n`. Look at the writes **after** it, in order. The first one whose set does **not** contain `n` was built on a stale copy: it wiped deposit `n` out of the vault. That write's teller is the **eraser** of deposit `n`.\n\n"
                     "Only lost deposits count: a deposit that was wiped out for a while and came back is not counted for anyone.\n\n"
                     "The **culprit** is the teller who erased the most lost deposits. If two tellers tie, the one who comes first in `erased` wins: that is what `max(erased, key=erased.get)` gives.",
            "question": "**Goal:** name the teller whose stale writes wiped out the night's deposits.\n\n"
                        "**You have:** `writes`, already in the starter: one dict per write, in schedule order, e.g. `{\"teller\": \"Osei\", \"amount\": 50, \"contains\": {0, 3}}`. Write number `n` is `writes[n]`, and `\"contains\"` is the vault's set right after that write (step 2's idea). The set after the last write is `writes[-1][\"contains\"]`.\n\n"
                        "**Write:**\n"
                        "- `erased`: a dict from teller to how many **lost** deposits they erased (see the field notes); tellers who erased none don't appear\n"
                        "- `culprit`: the teller with the most, using `max(erased, key=erased.get)` (it gives the key with the biggest value)\n\n"
                        "**Then** print the accusation (the starter already does).\n\n"
                        "**Example:** writes with sets `{0}` (A), `{1}` (B), `{1, 2}` (C) and `{0, 3}` (D). Final set `{0, 3}`, so writes 1 and 2 are lost. Write 1's first later write without 1 is write 3: D. Write 2's is also write 3: D. So `erased == {\"D\": 2}` and `culprit == \"D\"`. Write 0 was wiped by B but came back, so it doesn't count.",
            "starter": _LEDGER_TRACE + "\nerased = {}\nculprit = None\n# your code here\n\nprint(\"Deposits erased:\", erased)\nprint(\"The ledger was broken by\", culprit)\n",
            "solution": _LEDGER_TRACE + "\nerased = {}\nfinal = writes[-1][\"contains\"]\nfor n in range(len(writes)):\n    if n in final:\n        continue\n    for later in writes[n + 1:]:\n        if n not in later[\"contains\"]:\n            erased[later[\"teller\"]] = erased.get(later[\"teller\"], 0) + 1\n            break\n\nculprit = max(erased, key=erased.get)\n\nprint(\"Deposits erased:\", erased)\nprint(\"The ledger was broken by\", culprit)\n",
            "tests": _LEDGER_TRUTH + r'''assert erased == _erased, f"on this night the erasers are {_erased}, got {erased}. Only count deposits missing from the final set, and only the FIRST later write that doesn't contain them."
assert culprit == _culprit, f"the teller who erased the most lost deposits here is {_culprit!r}, got {culprit!r}"
assert str(culprit) in __output__, "print your accusation"''',
            "tips": [
                "Loop `for n in range(len(writes)):` and skip `if n in final: continue`. Then `for later in writes[n + 1:]:` and stop at the first one where `n not in later[\"contains\"]`.",
                "Count with `erased[later[\"teller\"]] = erased.get(later[\"teller\"], 0) + 1`, then `break`. At the end: `culprit = max(erased, key=erased.get)`.",
            ],
            "reveal": "One teller's writes land again and again on copies read long before, and each one wipes out somebody's deposit. On their terminal, the Lab finds a script nobody admits to writing: it reads the balance, waits, then writes, every few seconds, all night.",
        },
    ],
    "closing": "Case closed. The teller swears the script isn't theirs: it appeared on their terminal the day the vault software was updated, under a service account called **svc_vault**, and its only comment is a chalk-style **X** drawn in ASCII. The Lab believes them: the script was typed at that terminal in person, and whoever typed it had swapped the mouse buttons to the **left-handed** setting and forgot to swap them back. The teller is right-handed. The chalk X on shelf 7 was drawn with the left hand. A patched check, a rigged test suite, a ledger with no lock: X has spent the whole week inside the Lab's own tools. Day 2 is over, Detective. X knows how the Bureau proves things now. The question is what X will do with that.",
    "fragment": "The vault script (account 'svc_vault') was typed in person at a teller's terminal set up for a left-handed user: X is left-handed, and was inside the Lab.",
}

CASES = [PHANTOM_FINES, RIGGED_VERDICT, MIDNIGHT_LEDGER]

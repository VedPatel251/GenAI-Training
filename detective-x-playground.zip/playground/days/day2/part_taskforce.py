"""Day 2 · Task Force: Academy lessons (concurrency-concepts ... provider-injection).

Same lesson format as lessons.py describes. `part` is set by lessons.py, so leave it out here.
Check with:  python engine/build_game.py --day day2 --no-write

The browser's Python can't run real concurrency (see docs/day2/OUTLINE.md): no concurrent.futures
pools, no time.sleep, threads run one after another, async code can't run. So these lessons model
the ideas in plain Python (an interleaving scheduler, a mini executor, an event loop made of
generators, an injected fake sleep) and show the real libraries on `local` cards.
"""

LESSONS = [
    # ------------------------------------------------------------------ concurrency concepts
    {
        "id": "concurrency-concepts",
        "title": "Concurrency, parallelism and the GIL",
        "slides": "28-32",
        "idea": "Before you speed anything up, ask one question: is the job **I/O-bound** (mostly *waiting* for the network, a disk or a database) or **CPU-bound** (mostly *computing*)? The answer picks the tool.\n\n**Concurrency** means juggling several jobs by switching between them while each one waits, like a chef chopping vegetables while the soup simmers. **Parallelism** means several jobs really run at the same instant on different CPU cores, like five chefs each cooking a dish. Most \"fast\" Python code is concurrent, and that is fine for waiting jobs.\n\nStandard Python (CPython) has the **GIL** (Global Interpreter Lock): only one thread runs Python code at a time, even on a 16-core laptop. But a thread that is waiting lets go of the GIL, so the other threads run meanwhile. That is why threads speed up downloads but not number crunching.\n\n- I/O-bound with many calls (50+ API calls, a web server): `asyncio`\n- I/O-bound with a few calls (5 to 20 downloads, libraries that aren't async): threads, via `ThreadPoolExecutor`\n- CPU-bound (scoring 100 books, resizing images): processes, via `ProcessPoolExecutor`, one per CPU core\n- With the GIL, waiting overlaps but computing adds up: four 1-second calculations on four threads still take about 4 seconds\n- Python 3.14 officially supports an optional **free-threaded** build without the GIL; the normal download still has it",
        "predict": {
            "q": "Four threads each spend 1 second computing prime numbers (no waiting at all). On a normal Python install, about how long do all four take together?",
            "options": ["About 1 second", "About 4 seconds", "About 0.25 seconds"],
            "answer": 1,
            "why": "The GIL lets only one thread compute at a time, so the four seconds of work add up. Threads only help when the jobs spend their time waiting.",
        },
        "code": '''jobs = [
    {"name": "download 20 cover images", "wait_ms": 4000, "cpu_ms": 50, "calls": 20},
    {"name": "ask an LLM about 500 books", "wait_ms": 90000, "cpu_ms": 200, "calls": 500},
    {"name": "score 100 books for difficulty", "wait_ms": 0, "cpu_ms": 30000, "calls": 100},
]

def kind(job):
    return "I/O-bound" if job["wait_ms"] > job["cpu_ms"] else "CPU-bound"

def choose_tool(job):
    if kind(job) == "CPU-bound":
        return "processes (ProcessPoolExecutor)"
    if job["calls"] >= 50:
        return "asyncio"
    return "threads (ThreadPoolExecutor)"

for job in jobs:
    print(f"{job['name']}: {kind(job)} -> {choose_tool(job)}")

# Four jobs of 1000 ms each on four threads, with the GIL:
durations = [1000, 1000, 1000, 1000]
print("if they wait, the waits overlap:", max(durations), "ms")
print("if they compute, the work adds up:", sum(durations), "ms")
''',
        "walkthrough": [
            ['{"name": "download 20 cover images", "wait_ms": 4000, "cpu_ms": 50, "calls": 20},', "Each job says how long it spends waiting (`wait_ms`), how long it spends computing (`cpu_ms`) and how many separate calls it makes."],
            ['return "I/O-bound" if job["wait_ms"] > job["cpu_ms"] else "CPU-bound"', "The single most important question: is the time spent waiting or computing? Downloads wait; scoring books computes."],
            ['if kind(job) == "CPU-bound":', "Computing work needs real parallelism, so it goes to separate processes. Each process has its own GIL, so each can use its own core."],
            ['if job["calls"] >= 50:', "Lots of waiting calls: `asyncio` handles thousands of them on one thread cheaply."],
            ['return "threads (ThreadPoolExecutor)"', "A handful of waiting calls: threads are simpler and work with ordinary (non-async) libraries."],
            ['print("if they wait, the waits overlap:", max(durations), "ms")', "Waiting threads let go of the GIL, so four 1-second waits finish in about 1 second: the slowest one."],
            ['print("if they compute, the work adds up:", sum(durations), "ms")', "Computing threads take turns holding the GIL, so their times add up, just as if you ran them one after another."],
        ],
        "mistakes": [
            "Using threads to speed up number crunching: with the GIL, CPU work on threads is no faster (use processes).",
            "Thinking threads are useless because of the GIL: the GIL is released while a thread waits, so threads are great for downloads and API calls.",
            "Reaching for `asyncio` for a one-off script that makes 3 calls: plain code or a few threads is simpler.",
            "Assuming every Python is free-threaded: the no-GIL build is a separate, optional install (officially supported from Python 3.14).",
        ],
        "local": [{
            "title": "See the GIL on your machine",
            "note": "Save as `gil_check.py` and run it with your project's Python. Four CPU-heavy jobs take the same time on four threads as one after another. Your timings will differ; on a free-threaded build the last line drops.",
            "code": '''import sys
import sysconfig
import threading
import time

print("Python", sys.version.split()[0])
print("free-threaded build:", bool(sysconfig.get_config_var("Py_GIL_DISABLED")))

def crunch():
    return sum(i * i for i in range(3_000_000))

t0 = time.perf_counter()
for _ in range(4):
    crunch()
print(f"4 jobs one after another: {time.perf_counter() - t0:.2f}s")

t0 = time.perf_counter()
threads = [threading.Thread(target=crunch) for _ in range(4)]
for t in threads:
    t.start()
for t in threads:
    t.join()
print(f"4 jobs on 4 threads:      {time.perf_counter() - t0:.2f}s")''',
            "output": '''Python 3.14.0
free-threaded build: False
4 jobs one after another: 0.94s
4 jobs on 4 threads:      0.94s''',
        }],
        "challenge": {
            "task": "Write `classify(job)`, which returns `\"io\"` when `job[\"wait_ms\"]` is greater than `job[\"cpu_ms\"]` and `\"cpu\"` otherwise. Then write `choose_tool(job)` following the decision tree: a CPU-bound job gets `\"processes\"`; an I/O-bound job with 50 or more `calls` gets `\"asyncio\"`; any other I/O-bound job gets `\"threads\"`.",
            "hints": [
                "Call `classify(job)` inside `choose_tool` and check the CPU case first, then the number of calls.",
                "`if classify(job) == \"cpu\": return \"processes\"`, then `if job[\"calls\"] >= 50: return \"asyncio\"`, then `return \"threads\"`.",
            ],
            "starter": '''def classify(job):
    ...

def choose_tool(job):
    ...

report = {"wait_ms": 3000, "cpu_ms": 100, "calls": 8}
print(classify(report), choose_tool(report))
''',
            "solution": '''def classify(job):
    if job["wait_ms"] > job["cpu_ms"]:
        return "io"
    return "cpu"

def choose_tool(job):
    if classify(job) == "cpu":
        return "processes"
    if job["calls"] >= 50:
        return "asyncio"
    return "threads"

report = {"wait_ms": 3000, "cpu_ms": 100, "calls": 8}
print(classify(report), choose_tool(report))
''',
            "tests": '''_few = {"wait_ms": 3000, "cpu_ms": 100, "calls": 8}
_many = {"wait_ms": 60000, "cpu_ms": 500, "calls": 300}
_crunch = {"wait_ms": 10, "cpu_ms": 9000, "calls": 100}
assert classify(_few) == "io", "a job that mostly waits should be \\"io\\""
assert classify(_crunch) == "cpu", "a job that mostly computes should be \\"cpu\\""
assert choose_tool(_crunch) == "processes", "CPU-bound work needs processes, whatever the number of calls"
assert choose_tool(_many) == "asyncio", "an I/O-bound job with 50 or more calls should use asyncio"
assert choose_tool(_few) == "threads", "an I/O-bound job with fewer than 50 calls should use threads"
assert choose_tool({"wait_ms": 900, "cpu_ms": 100, "calls": 50}) == "asyncio", "exactly 50 calls counts as many: use >= 50"''',
        },
        "practice": [
            {
                "task": "Write `thread_time(durations, kind, gil=True)`: how many milliseconds a list of jobs takes when each job gets its own thread. Waiting jobs (`kind == \"io\"`) overlap, so the answer is the longest one. Computing jobs (`kind == \"cpu\"`) add up while the GIL is on. On a free-threaded build (`gil=False`) computing jobs also overlap. An empty list takes `0`.",
                "hints": [
                    "Handle the empty list first. Then there are only two answers: `max(durations)` or `sum(durations)`.",
                    "`if kind == \"cpu\" and gil: return sum(durations)`, otherwise `return max(durations)`.",
                ],
                "starter": '''def thread_time(durations, kind, gil=True):
    return sum(durations)

print(thread_time([300, 500, 200], "io"))
''',
                "solution": '''def thread_time(durations, kind, gil=True):
    if not durations:
        return 0
    if kind == "cpu" and gil:
        return sum(durations)
    return max(durations)

print(thread_time([300, 500, 200], "io"))
''',
                "tests": '''assert thread_time([300, 500, 200], "io") == 500, "waiting jobs overlap: the batch takes as long as the slowest job"
assert thread_time([300, 500, 200], "cpu") == 1000, "with the GIL, computing jobs take turns, so their times add up"
assert thread_time([300, 500, 200], "cpu", gil=False) == 500, "without the GIL, computing threads run on separate cores and overlap"
assert thread_time([], "io") == 0 and thread_time([], "cpu") == 0, "an empty list of jobs takes 0 ms"''',
            },
            {
                "task": "A `timeline` lists, for each moment, which jobs were running at that moment, for example `[[\"A\"], [\"B\"], [\"A\"]]`. Write `describe(timeline)` that returns `\"parallel\"` if any moment has two or more jobs running, `\"concurrent\"` if a job comes back after another job ran in between (switching), and `\"sequential\"` otherwise (each job runs to the end before the next starts).",
                "hints": [
                    "First check every moment: `if len(moment) >= 2: return \"parallel\"`. Then walk the single jobs in order and remember the ones you have *left*.",
                    "Keep `left = set()` and `current = None`. For each `[job]`: if `job != current`, add `current` to `left`; if `job in left`, return `\"concurrent\"`; set `current = job`. Return `\"sequential\"` at the end.",
                ],
                "starter": '''def describe(timeline):
    return "sequential"

print(describe([["A"], ["B"], ["A"]]))
''',
                "solution": '''def describe(timeline):
    for moment in timeline:
        if len(moment) >= 2:
            return "parallel"
    left = set()
    current = None
    for moment in timeline:
        job = moment[0]
        if job != current:
            if current is not None:
                left.add(current)
            if job in left:
                return "concurrent"
            current = job
    return "sequential"

print(describe([["A"], ["B"], ["A"]]))
''',
                "tests": '''assert describe([["A"], ["B"], ["A"], ["B"]]) == "concurrent", "A and B take turns on one worker: that is concurrency"
assert describe([["A", "B"], ["A"]]) == "parallel", "A and B running at the same moment is parallelism"
assert describe([["A"], ["A"], ["B"], ["B"]]) == "sequential", "A finishes before B starts: sequential"
assert describe([["A"], ["B"], ["C"], ["B"]]) == "concurrent", "B comes back after C ran: that is switching"
assert describe([]) == "sequential", "an empty timeline is sequential"''',
            },
        ],
    },
    # ------------------------------------------------------------------ threads and locks
    {
        "id": "threads-locks",
        "title": "Threads, race conditions and locks",
        "slides": "33-34",
        "idea": "A **thread** runs a function alongside your main program. `threading.Thread(target=fn, args=(x,))` creates it, `.start()` launches it, and `.join()` waits until it is done. Always pair them: start every thread, then join every thread.\n\nThreads share the same variables, and that is dangerous. `counter += 1` looks like one step but is three: **read** the value, **add** 1, **write** it back. If two threads both read `5` before either writes, both write `6` and one update is **lost**. This is a **race condition**: the result depends on who happens to run first, so it changes from run to run.\n\nThe fix is a **lock**. `lock = threading.Lock()` and then `with lock:` around the read-modify-write: only one thread can be inside the `with` block at a time; the others wait at the door. This browser runs threads one after another, so a real race can't happen here. The demo **replays** two threads taking turns to show exactly where the update is lost.\n\n- `start()` launches, `join()` waits: always do both\n- Read-modify-write on shared data needs a `Lock`, used with `with lock:`\n- `RLock`: a lock the same thread may take again (a locked function calling another locked function)\n- `Semaphore(n)`: up to `n` threads at a time; `Event`: one thread signals the others\n- `queue.Queue`: a thread-safe pipe. Safest design of all: each thread returns its own result and the main thread combines them, so nothing is shared",
        "predict": {
            "q": "A function holds a plain `threading.Lock` and calls another function that tries to take the same lock. What happens?",
            "options": ["It works: the thread already holds the lock", "The thread waits for itself forever (a deadlock)", "Python raises a LockError"],
            "answer": 1,
            "why": "A plain `Lock` doesn't remember who holds it, so the thread blocks waiting for itself. A `threading.RLock` (re-entrant lock) lets the same thread take it again.",
        },
        "code": '''def steps():
    print("  step 1")
    yield                                 # pause here (hands back None)
    print("  step 2")

g = steps()                               # nothing runs yet
next(g)                                   # runs up to the first yield
try:
    next(g)                               # runs on to the end...
except StopIteration:
    print("  finished: StopIteration")    # ...and a finished generator says so

def worker(name, shared, rounds, use_lock):
    for _ in range(rounds):
        while use_lock and shared["lock"] not in (None, name):
            yield                         # lock taken: wait for a later turn
        if use_lock:
            shared["lock"] = name
        value = shared["counter"]         # 1. read
        yield                             # the other thread may run here
        shared["counter"] = value + 1     # 2-3. add 1 and write back
        shared["lock"] = None
        yield

def replay(use_lock, rounds=3):
    shared = {"counter": 0, "lock": None}
    threads = [worker("A", shared, rounds, use_lock), worker("B", shared, rounds, use_lock)]
    while threads:
        for t in list(threads):           # take turns: A, B, A, B ...
            try:
                next(t)
            except StopIteration:
                threads.remove(t)
    return shared["counter"]

print("expected 6, without a lock:", replay(use_lock=False))
print("expected 6, with a lock:   ", replay(use_lock=True))

import threading
lock = threading.Lock()
tally = {"count": 0}

def add_many(n):
    for _ in range(n):
        with lock:                        # one thread at a time in here
            tally["count"] += 1

threads = [threading.Thread(target=add_many, args=(500,)) for _ in range(4)]
for t in threads:
    t.start()
for t in threads:
    t.join()
print("real threads with a real Lock:", tally["count"])
''',
        "walkthrough": [
            ["def steps():", "New tool first: driving a generator by hand. On Day 1 a `for` loop drove generators for you; here we do it one step at a time."],
            ["    yield                                 # pause here (hands back None)", "A bare `yield` hands back no value (`None`). It just marks a place where the generator pauses."],
            ["g = steps()                               # nothing runs yet", "Calling a generator function only creates the paused generator; its body hasn't started."],
            ["next(g)                                   # runs up to the first yield", "`next(g)` runs the body until the next `yield` and stops there: only `step 1` is printed."],
            ["except StopIteration:", "The next `next(g)` runs to the end of the body. A generator with nothing left raises `StopIteration`: that is how you know it finished."],
            ["def worker(name, shared, rounds, use_lock):", "A pretend thread, written as a generator. Each `yield` is a moment where the operating system could switch to the other thread."],
            ['        while use_lock and shared["lock"] not in (None, name):', "With a lock, a thread that finds the lock taken by someone else waits (yields) until it is free. This is what `with lock:` does for real."],
            ['        value = shared["counter"]         # 1. read', "Step 1 of `counter += 1`: read the shared value into a private variable."],
            ["        yield                             # the other thread may run here", "The dangerous moment: between the read and the write, the other thread gets a turn and reads the *same* old value."],
            ['        shared["counter"] = value + 1     # 2-3. add 1 and write back', "Steps 2 and 3: write back the old value plus one. If the other thread wrote in the meantime, its update is overwritten: lost."],
            ["        for t in list(threads):           # take turns: A, B, A, B ...", "The scheduler gives each thread one step in turn, the worst case for a race. `next(t)` runs that thread to its next `yield`; a thread that has finished raises `StopIteration` and is removed."],
            ['print("expected 6, without a lock:", replay(use_lock=False))', "Two threads, 3 increments each, but every round both read the same value: 3 of the 6 updates are lost."],
            ['print("expected 6, with a lock:   ", replay(use_lock=True))', "With the lock, the read and the write happen together, so no update is lost."],
            ["lock = threading.Lock()", "The real thing: one lock shared by every thread. In this browser these threads run one after another, so this part shows the syntax; the local card shows a real race."],
            ["        with lock:                        # one thread at a time in here", "`with lock:` takes the lock on the way in and always gives it back on the way out, even if an error happens."],
            ["threads = [threading.Thread(target=add_many, args=(500,)) for _ in range(4)]", "`target` is the function to run, `args` a tuple of its arguments. Note the comma in `(500,)`: a one-item tuple."],
            ["    t.start()", "Launch every thread first, so they can run at the same time..."],
            ["    t.join()", "...then wait for every thread. Without `join`, you would print the total before the threads have finished."],
        ],
        "mistakes": [
            "Believing `counter += 1` is one step: it is read, add, write, and another thread can run in between.",
            "Calling `lock.acquire()` without a matching `release()`: an error in between leaves the lock taken forever. Use `with lock:`.",
            "Starting threads and never joining them: the main program carries on with half-finished results.",
            "Writing `args=(url)` instead of `args=(url,)`: without the comma it isn't a tuple.",
            "Trusting a race test that passed once: races depend on timing, so they can hide for thousands of runs.",
        ],
        "local": [{
            "title": "A real race, forced with time.sleep(0)",
            "note": "Save as `race_demo.py` and run it. On Python 3.10+ the plain `counter += 1` race from the slides rarely shows, because Python switches threads less often. `time.sleep(0)` between the read and the write forces a switch right there, so the lost updates appear every time. Your number without the lock will differ on each run.",
            "code": '''import threading
import time

counter = 0
lock = threading.Lock()

def increment_unsafe(n):
    global counter
    for _ in range(n):
        value = counter        # 1. read
        time.sleep(0)          # let another thread run right here
        counter = value + 1    # 2-3. add and write back

def increment_safe(n):
    global counter
    for _ in range(n):
        with lock:             # only one thread at a time in here
            value = counter
            time.sleep(0)
            counter = value + 1

def run(target):
    global counter
    counter = 0
    threads = [threading.Thread(target=target, args=(1_000,)) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return counter

print("without lock:", run(increment_unsafe), "(expected 10000)")
print("with lock:   ", run(increment_safe))''',
            "output": '''without lock: 1438 (expected 10000)
with lock:    10000''',
        }, {
            "title": "RLock, Semaphore and Event",
            "note": "Save as `primitives.py` and run it. The RLock lets a locked function call another locked function. The Semaphore lets at most 2 downloads in at once (C starts only when A ends). The Event makes one thread wait until another signals. The order of the start/end lines can vary a little between runs.",
            "code": '''import threading
import time

# RLock: the same thread may take it again
rlock = threading.RLock()

def add_fine(fines, amount):
    with rlock:
        fines.append(amount)

def add_two_fines(fines):
    with rlock:                       # held here...
        add_fine(fines, 2)            # ...and taken again inside: fine with RLock
        add_fine(fines, 3)

fines = []
add_two_fines(fines)
print("RLock re-entry ok:", fines)

# Semaphore(2): at most 2 threads inside at once
sem = threading.Semaphore(2)

def download(name):
    with sem:
        print(f"start {name}")
        time.sleep(0.2)
        print(f"end   {name}")

threads = [threading.Thread(target=download, args=(n,)) for n in "ABCD"]
for t in threads:
    t.start()
for t in threads:
    t.join()

# Event: one thread waits until another signals
ready = threading.Event()

def waiter():
    print("waiter: waiting for the catalog")
    ready.wait()                      # blocks until ready.set()
    print("waiter: catalog is ready, carrying on")

w = threading.Thread(target=waiter)
w.start()
time.sleep(0.2)
print("loader: catalog loaded, signalling")
ready.set()
w.join()''',
            "output": '''RLock re-entry ok: [2, 3]
start A
start B
end   A
start C
end   B
start D
end   C
end   D
waiter: waiting for the catalog
loader: catalog loaded, signalling
waiter: catalog is ready, carrying on''',
        }],
        "challenge": {
            "task": "Replay a race from a written schedule. Each step is `(thread, action)` where action is `\"read\"` (the thread copies the shared counter) or `\"write\"` (the thread stores *its copy + 1* back). Write `replay(schedule)` that starts the counter at 0 and returns its final value, and `lost_updates(schedule)`, which returns how many writes were lost (number of writes minus the final counter).",
            "hints": [
                "Keep `counter = 0` and a dict `seen = {}` of what each thread read. On `\"read\"`: `seen[thread] = counter`. On `\"write\"`: `counter = seen[thread] + 1`.",
                "For `lost_updates`, count the writes with `sum(1 for _, action in schedule if action == \"write\")` and subtract `replay(schedule)`.",
            ],
            "starter": '''def replay(schedule):
    counter = 0
    return counter

def lost_updates(schedule):
    return 0

race = [("A", "read"), ("B", "read"), ("A", "write"), ("B", "write")]
print(replay(race), lost_updates(race))
''',
            "solution": '''def replay(schedule):
    counter = 0
    seen = {}
    for thread, action in schedule:
        if action == "read":
            seen[thread] = counter
        elif action == "write":
            counter = seen[thread] + 1
    return counter

def lost_updates(schedule):
    writes = sum(1 for _, action in schedule if action == "write")
    return writes - replay(schedule)

race = [("A", "read"), ("B", "read"), ("A", "write"), ("B", "write")]
print(replay(race), lost_updates(race))
''',
            "tests": '''_race = [("A", "read"), ("B", "read"), ("A", "write"), ("B", "write")]
_safe = [("A", "read"), ("A", "write"), ("B", "read"), ("B", "write")]
assert replay(_safe) == 2, "when each thread reads and writes before the other reads, the counter should reach 2"
assert replay(_race) == 1, "both threads read 0, so both write 1: replay should return 1"
assert lost_updates(_race) == 1, "two writes but the counter is 1: one update was lost"
assert lost_updates(_safe) == 0, "no update is lost when the steps don't interleave"
_three = [("A", "read"), ("B", "read"), ("C", "read"), ("A", "write"), ("B", "write"), ("C", "write"), ("A", "read"), ("A", "write")]
assert replay(_three) == 2 and lost_updates(_three) == 2, "three threads that all read 0 lose two of their three writes"''',
        },
        "practice": [
            {
                "task": "Five threads each deposit 10 coins 100 times into `vault`. Fix the code: protect the read and the write in `deposit_many` with `with lock:`, then **start** every thread and **join** every thread before printing. The balance must be 5000.",
                "hints": [
                    "Indent the two lines of the loop body under `with lock:`. After the list of threads: one loop calling `t.start()`, then a second loop calling `t.join()`.",
                    "`for _ in range(times):` then `with lock:` then `value = vault[\"balance\"]` and `vault[\"balance\"] = value + amount`. Then `for t in threads: t.start()` and `for t in threads: t.join()`.",
                ],
                "starter": '''import threading

vault = {"balance": 0}
lock = threading.Lock()

def deposit_many(amount, times):
    for _ in range(times):
        value = vault["balance"]
        vault["balance"] = value + amount

threads = [threading.Thread(target=deposit_many, args=(10, 100)) for _ in range(5)]
# start every thread, then wait for every thread

print(vault["balance"])
''',
                "solution": '''import threading

vault = {"balance": 0}
lock = threading.Lock()

def deposit_many(amount, times):
    for _ in range(times):
        with lock:
            value = vault["balance"]
            vault["balance"] = value + amount

threads = [threading.Thread(target=deposit_many, args=(10, 100)) for _ in range(5)]
for t in threads:
    t.start()
for t in threads:
    t.join()

print(vault["balance"])
''',
                "tests": '''assert ".start()" in __source__, "start every thread with t.start()"
assert ".join()" in __source__, "wait for every thread with t.join() before printing"
assert vault["balance"] == 5000, f"5 threads x 100 deposits x 10 coins should make 5000, got {vault['balance']}"
assert "with lock" in __source__, "protect the read and the write with `with lock:`"
assert "acquire(" not in __source__, "use `with lock:` rather than acquire/release by hand"''',
            },
            {
                "task": "The safest design shares nothing. Each thread counts the books on one shelf and **puts** the count on the `results` queue (`queue.Queue` is safe to use from many threads). Write `count_shelf(books)`, start and join one thread per shelf, then take every number off the queue with `results.get()` (while `not results.empty()`) and store their sum in `total`. No lock and no shared counter.",
                "hints": [
                    "`count_shelf` is one line: `results.put(len(books))`. Build the threads with `threading.Thread(target=count_shelf, args=(shelf,))`.",
                    "After joining: `total = 0`, then `while not results.empty(): total += results.get()`.",
                ],
                "starter": '''import queue
import threading

shelves = [["Dune", "Emma"], ["Ulysses"], ["Clean Code", "Refactoring", "Fluent Python"]]
results = queue.Queue()

def count_shelf(books):
    ...

total = 0
print(total)
''',
                "solution": '''import queue
import threading

shelves = [["Dune", "Emma"], ["Ulysses"], ["Clean Code", "Refactoring", "Fluent Python"]]
results = queue.Queue()

def count_shelf(books):
    results.put(len(books))

threads = [threading.Thread(target=count_shelf, args=(shelf,)) for shelf in shelves]
for t in threads:
    t.start()
for t in threads:
    t.join()

total = 0
while not results.empty():
    total += results.get()
print(total)
''',
                "tests": '''assert total == 6, f"the three shelves hold 6 books, got total = {total}"
assert results.empty(), "take every count off the queue"
count_shelf(["a", "b", "c", "d"])
assert results.get() == 4, "count_shelf should put the number of books on the results queue"
assert "Thread(" in __source__ and ".join()" in __source__, "run one thread per shelf, and join them before adding up"
assert "Lock" not in __source__ and "global" not in __source__, "no lock or shared counter needed: each thread only puts its own result on the queue"''',
            },
        ],
    },
    # ------------------------------------------------------------------ executors
    {
        "id": "executors",
        "title": "Pools: map, submit and as_completed",
        "slides": "35-37",
        "idea": "Writing `Thread(...)`, `start()` and `join()` by hand gets old. A **pool executor** keeps a fixed number of workers (`max_workers`) and hands them jobs from a queue: a worker that finishes one job picks up the next. `ThreadPoolExecutor` uses threads (for waiting jobs); `ProcessPoolExecutor` uses separate processes (for computing jobs). They have the **same API**, so switching is one word.\n\n`pool.map(fn, items)` gives results back **in the order of the inputs**, even if a later job finished first. `pool.submit(fn, item)` returns a **Future** at once: a ticket for a result that isn't ready yet. `as_completed(futures)` hands you the futures **in the order they finish**, fastest first. `future.result()` gives the job's return value, or **raises the job's error**, so wrap it in `try`/`except` and one bad job won't sink the batch.\n\nThis browser can't run real pools, so the demo uses a **mini executor** that pretends: each job says how long it would take, and the mini executor works out which worker runs it and when it would finish. The `local` cards show the real pools and real timings.\n\n- `map`: input order. `submit` + `as_completed`: finishing order\n- Keep a dict `{future: input}` so you know which input each finished future belongs to\n- Results in finishing order differ between runs: sort them (for example by file name) for a deterministic report\n- Processes: arguments and return values are sent by **pickling**, so use top-level functions (no lambdas, no functions defined inside functions)\n- Processes: put the pool code under `if __name__ == \"__main__\":`. Each worker imports your file; without the guard, Windows, macOS, and Linux from Python 3.14 stop with a `RuntimeError`\n- Starting processes costs time: small jobs can be slower in a process pool than one after another",
        "code": '''class MiniFuture:
    def __init__(self, fn, arg, finish_ms):
        self.finish_ms = finish_ms             # when this job would be done
        try:
            self._value, self._error = fn(arg), None
        except Exception as e:
            self._value, self._error = None, e

    def result(self):
        if self._error is not None:
            raise self._error                  # the job's error comes back here
        return self._value

class MiniExecutor:
    """A pretend pool: each job says how long it takes; nothing really waits."""
    def __init__(self, max_workers):
        self.free_at = [0] * max_workers       # when each worker is next free

    def submit(self, fn, arg, takes_ms):
        w = self.free_at.index(min(self.free_at))   # the worker free soonest
        self.free_at[w] += takes_ms
        return MiniFuture(fn, arg, self.free_at[w])

    def map(self, fn, args, takes_ms):
        futures = [self.submit(fn, a, t) for a, t in zip(args, takes_ms)]
        return [f.result() for f in futures]   # input order

def as_completed(futures):
    return sorted(futures, key=lambda f: f.finish_ms)   # fastest first

def fetch_cover(isbn):
    if isbn == "978-BAD":
        raise ConnectionError("cover server refused")
    return f"https://covers.example/{isbn}.jpg"

pool = MiniExecutor(max_workers=4)
print(pool.map(fetch_cover, ["978-001", "978-002"], [900, 300]))

isbns = ["978-001", "978-002", "978-BAD", "978-004"]
takes = [900, 300, 500, 100]
pool = MiniExecutor(max_workers=4)
futures = {pool.submit(fetch_cover, i, t): i for i, t in zip(isbns, takes)}
for future in as_completed(futures):
    isbn = futures[future]
    try:
        print(future.finish_ms, "ms  ok  ", future.result())
    except ConnectionError as e:
        print(future.finish_ms, "ms  fail", isbn, e)
print("pool:", max(pool.free_at), "ms; one after another:", sum(takes), "ms")
''',
        "walkthrough": [
            ["class MiniFuture:", "Our stand-in for a real `Future`: it remembers when the job would finish and what it returned (or raised)."],
            ["            self._value, self._error = None, e", "If the job fails, the error is kept, not raised. A real pool does the same: one failing job doesn't crash the pool."],
            ["            raise self._error                  # the job's error comes back here", "`result()` re-raises the job's error, so this is where your `try`/`except` goes."],
            ["        self.free_at = [0] * max_workers       # when each worker is next free", "One clock per worker. With 4 workers, 4 jobs can be in progress at once."],
            ["        w = self.free_at.index(min(self.free_at))   # the worker free soonest", "Like a real pool, the next job goes to whichever worker frees up first."],
            ["        return [f.result() for f in futures]   # input order", "`map` collects results in the order of the inputs, waiting for each one in turn."],
            ["    return sorted(futures, key=lambda f: f.finish_ms)   # fastest first", "`as_completed` hands back the futures in finishing order. Looping over a dict loops over its keys: the futures."],
            ['print(pool.map(fetch_cover, ["978-001", "978-002"], [900, 300]))', "978-002 finishes first (300 ms), yet `map` still lists 978-001 first: input order."],
            ["futures = {pool.submit(fetch_cover, i, t): i for i, t in zip(isbns, takes)}", "Submit every job and keep a dict from each future back to its ISBN. (A real `submit(fn, isbn)` has no `takes_ms`: real jobs just take as long as they take.)"],
            ["for future in as_completed(futures):", "Handle each result as soon as it is ready: 978-004 (100 ms) comes first."],
            ["    except ConnectionError as e:", "The bad ISBN fails on its own; the loop carries on with the rest."],
            ['print("pool:", max(pool.free_at), "ms; one after another:", sum(takes), "ms")', "With 4 workers the batch takes as long as the slowest job (900 ms) instead of the sum (1800 ms)."],
        ],
        "mistakes": [
            "Expecting `pool.map` to give results in finishing order: it keeps input order. Use `submit` + `as_completed` for fastest-first.",
            "Calling `future.result()` without `try`/`except`: one failed job then stops your whole loop.",
            "Passing a lambda or a function defined inside another function to a `ProcessPoolExecutor`: it can't be pickled.",
            "Leaving out `if __name__ == \"__main__\":` around a process pool: on Windows, macOS, and Linux from Python 3.14 each worker re-imports the file and Python stops with a `RuntimeError`.",
            "Writing `future.result(timeout=5)` inside `as_completed`: those futures are already finished, so the timeout never fires.",
            "Using a process pool for tiny jobs: starting processes can cost more than the work itself.",
        ],
        "local": [
            {
                "title": "ThreadPoolExecutor: 20 fake covers (Q11)",
                "note": "Save as `cover_import.py` and run it. `time.sleep(0.2)` stands in for the network. Five workers make it about 5x faster. Fastest-first order can vary between runs.",
                "code": '''import time
from concurrent.futures import ThreadPoolExecutor, as_completed

def fetch_cover_sync(isbn: str) -> tuple[str, str]:
    time.sleep(0.2)                       # pretend network wait
    if isbn == "978-BAD":
        raise ConnectionError("cover server refused")
    return isbn, f"https://covers.example/{isbn}.jpg"

isbns = [f"978-{n:03}" for n in range(1, 21)]

t0 = time.perf_counter()
sequential = dict(fetch_cover_sync(i) for i in isbns)
print(f"sequential: {time.perf_counter() - t0:.2f}s")

t0 = time.perf_counter()
with ThreadPoolExecutor(max_workers=5) as pool:
    covers = dict(pool.map(fetch_cover_sync, isbns))   # results in input order
print(f"5 threads:  {time.perf_counter() - t0:.2f}s, {len(covers)} covers")

with ThreadPoolExecutor(max_workers=5) as pool:
    futures = {pool.submit(fetch_cover_sync, i): i for i in ["978-001", "978-BAD", "978-003"]}
    for future in as_completed(futures):              # fastest first
        isbn = futures[future]
        try:
            print("ok  ", future.result()[1])
        except ConnectionError as e:
            print("fail", isbn, e)''',
                "output": '''sequential: 4.01s
5 threads:  0.81s, 20 covers
ok   https://covers.example/978-001.jpg
ok   https://covers.example/978-003.jpg
fail 978-BAD cover server refused''',
            },
            {
                "title": "ProcessPoolExecutor: CPU-heavy scores (Q13)",
                "note": "Save as `difficulty.py` and run it. `difficulty_score` is defined at the top level so it can be pickled and sent to the workers, and the pool runs only under the `__main__` guard. Timings depend on your CPU. If you change `1_000` to `100`, the jobs are so small that the pool is slower (about 0.3s one after another vs 0.6s with 4 processes): starting processes costs more than the work.",
                "code": '''import random
import time
from concurrent.futures import ProcessPoolExecutor

def difficulty_score(book: dict) -> int:      # top level, so it can be pickled
    total = 0
    for i in range(book["pages"] * 1_000):
        total += (i * i) % 97
    return total

def main():
    random.seed(1)
    books = [{"id": n, "pages": random.randint(100, 900)} for n in range(100)]

    t0 = time.perf_counter()
    seq = [difficulty_score(b) for b in books]
    print(f"sequential:  {time.perf_counter() - t0:.2f}s")

    t0 = time.perf_counter()
    with ProcessPoolExecutor(max_workers=4) as pool:
        par = list(pool.map(difficulty_score, books, chunksize=10))
    print(f"4 processes: {time.perf_counter() - t0:.2f}s")
    print("same results:", seq == par)

if __name__ == "__main__":
    main()''',
                "output": '''sequential:  3.85s
4 processes: 2.75s
same results: True''',
            },
            {
                "title": "What can be pickled, and what the missing guard does",
                "note": "The first script shows which functions a process pool can receive. The second has no `__main__` guard: on Windows and macOS (which start workers with *spawn*) and on Linux from Python 3.14 (*forkserver*) it stops with a `RuntimeError` like the one below, followed by `BrokenProcessPool`. Only on Linux with Python 3.13 or older (*fork*) may it happen to work; write the guard anyway. (3.13 and older print `AttributeError` instead of `PicklingError` for the second function in the first script.)",
                "code": '''# pickle_check.py
import pickle

def top_level(book):
    return book["pages"]

def make_scorer():
    def inner(book):
        return book["pages"]
    return inner

for fn in (top_level, lambda b: b["pages"], make_scorer()):
    try:
        pickle.dumps(fn)
        print("can send:   ", fn.__qualname__)
    except (pickle.PicklingError, AttributeError) as e:
        print("can't send: ", fn.__qualname__, "->", type(e).__name__)

# no_guard.py: DON'T do this
from concurrent.futures import ProcessPoolExecutor

def square(n):
    return n * n

with ProcessPoolExecutor(max_workers=2) as pool:   # no __main__ guard!
    print(list(pool.map(square, [1, 2, 3])))''',
                "output": '''can send:    top_level
can't send:  <lambda> -> PicklingError
can't send:  make_scorer.<locals>.inner -> PicklingError

RuntimeError:
        An attempt has been made to start a new process before the
        current process has finished its bootstrapping phase.
        ...
            if __name__ == '__main__':
                freeze_support()''',
            },
        ],
        "challenge": {
            "needs_demo": True,
            "task": "Using the demo's `MiniExecutor`, `as_completed` and `fetch_cover`, write `fetch_all(isbns, takes)`. Make a `MiniExecutor(max_workers=2)`, submit `fetch_cover` for every ISBN (with its time from `takes`), keep a dict from each future to its ISBN, then loop over `as_completed`. Return `(done, failed)`: `done` is the list of ISBNs that worked **in finishing order**, `failed` is a dict from ISBN to the error message (`str(e)`). One failure must not stop the others.",
            "hints": [
                "Copy the shape of the demo: `futures = {pool.submit(fetch_cover, i, t): i for i, t in zip(isbns, takes)}`, then `for future in as_completed(futures):`.",
                "Inside the loop: `isbn = futures[future]`, then `try: future.result()` and `done.append(isbn)`, `except Exception as e: failed[isbn] = str(e)`.",
            ],
            "starter": '''def fetch_all(isbns, takes):
    done = []
    failed = {}
    return done, failed

print(fetch_all(["A1", "A2", "978-BAD", "A4"], [400, 100, 150, 100]))
''',
            "solution": '''def fetch_all(isbns, takes):
    pool = MiniExecutor(max_workers=2)
    futures = {pool.submit(fetch_cover, i, t): i for i, t in zip(isbns, takes)}
    done = []
    failed = {}
    for future in as_completed(futures):
        isbn = futures[future]
        try:
            future.result()
            done.append(isbn)
        except Exception as e:
            failed[isbn] = str(e)
    return done, failed

print(fetch_all(["A1", "A2", "978-BAD", "A4"], [400, 100, 150, 100]))
''',
            "tests": '''_done, _failed = fetch_all(["A1", "A2", "978-BAD", "A4"], [400, 100, 150, 100])
assert set(_done) == {"A1", "A2", "A4"}, f"every good ISBN should end up in done, got {_done}"
assert _done == ["A2", "A4", "A1"], f"done should be in finishing order with 2 workers (A2 at 100 ms, A4 at 350 ms, A1 at 400 ms), got {_done}"
assert _failed == {"978-BAD": "cover server refused"}, f"failed should map the bad ISBN to its error message, got {_failed}"
_d2, _f2 = fetch_all(["978-BAD", "B1"], [10, 20])
assert _d2 == ["B1"] and "978-BAD" in _f2, "a failure early in the batch must not stop the later jobs"
assert "as_completed" in __source__, "loop over as_completed(...) to get finishing order"''',
        },
        "practice": [
            {
                "task": "Model a pool without the demo. `jobs` is a list of `(name, ms)`. Write `simulate(jobs, max_workers)` that gives each job, in order, to the worker that is free soonest, and returns a dict with `\"map_order\"` (the names in input order, as `pool.map` returns them), `\"completed_order\"` (the names in finishing order; ties keep input order) and `\"total_ms\"` (when the last job finishes; 0 for no jobs).",
                "hints": [
                    "Keep `free_at = [0] * max_workers`. For each job: `w = free_at.index(min(free_at))`, then `free_at[w] += ms` and remember `(free_at[w], position, name)`.",
                    "Sort the remembered tuples: they sort by finish time, then position. `completed_order` is the names from that sorted list, and `total_ms` is `max(free_at)`.",
                ],
                "starter": '''def simulate(jobs, max_workers):
    names = [name for name, ms in jobs]
    return {"map_order": names, "completed_order": names, "total_ms": sum(ms for _, ms in jobs)}

print(simulate([("a", 300), ("b", 100), ("c", 200)], max_workers=2))
''',
                "solution": '''def simulate(jobs, max_workers):
    free_at = [0] * max_workers
    finished = []
    for position, (name, ms) in enumerate(jobs):
        w = free_at.index(min(free_at))
        free_at[w] += ms
        finished.append((free_at[w], position, name))
    finished.sort()
    return {
        "map_order": [name for name, _ in jobs],
        "completed_order": [name for _, _, name in finished],
        "total_ms": max(free_at),
    }

print(simulate([("a", 300), ("b", 100), ("c", 200)], max_workers=2))
''',
                "tests": '''_r = simulate([("a", 300), ("b", 100), ("c", 200)], max_workers=2)
assert _r["map_order"] == ["a", "b", "c"], "map_order should keep the input order"
assert _r["completed_order"] == ["b", "a", "c"], f"with 2 workers b ends at 100, a at 300 and c at 300 (ties keep input order), got {_r['completed_order']}"
assert _r["total_ms"] == 300, f"the batch ends when the last job does: 300 ms, got {_r['total_ms']}"
_covers = [(f"c{n}", 200) for n in range(20)]
assert simulate(_covers, 5)["total_ms"] == 800, "20 covers of 200 ms on 5 workers should take 800 ms (Q11)"
assert simulate(_covers, 1)["total_ms"] == 4000, "one worker runs the 20 covers one after another: 4000 ms"
assert simulate([], 3)["total_ms"] == 0, "no jobs take 0 ms"''',
            },
            {
                "task": "Files imported by a pool come back in finishing order, which changes between runs. `results` is a list of `(path, outcome)`: `outcome` is a list of records for a good file, or an exception for a file that crashed. Write `merge(results)` that returns a dict with `\"records\"` (every record from the good files, files taken in **path order**), `\"errors\"` (a dict path → `str(error)` for the bad files) and `\"paths\"` (all paths, sorted). The same results in any order must give the same answer.",
                "hints": [
                    "Sort first: `for path, outcome in sorted(results, key=lambda r: r[0]):`. Then use `isinstance(outcome, Exception)` to tell a crash from a list of records.",
                    "Crashed: `errors[path] = str(outcome)`. Good: `records.extend(outcome)`. Return `{\"records\": records, \"errors\": errors, \"paths\": sorted(p for p, _ in results)}`.",
                ],
                "starter": '''def merge(results):
    records = []
    for path, outcome in results:
        if isinstance(outcome, list):
            records.extend(outcome)
    return {"records": records, "errors": {}, "paths": [p for p, _ in results]}

arrived = [("b.jsonl", ["B1"]), ("c.jsonl", ValueError("line 2: bad JSON")), ("a.jsonl", ["A1", "A2"])]
print(merge(arrived))
''',
                "solution": '''def merge(results):
    records = []
    errors = {}
    for path, outcome in sorted(results, key=lambda r: r[0]):
        if isinstance(outcome, Exception):
            errors[path] = str(outcome)
        else:
            records.extend(outcome)
    return {"records": records, "errors": errors, "paths": sorted(p for p, _ in results)}

arrived = [("b.jsonl", ["B1"]), ("c.jsonl", ValueError("line 2: bad JSON")), ("a.jsonl", ["A1", "A2"])]
print(merge(arrived))
''',
                "tests": '''_err = ValueError("line 2: bad JSON")
_one = [("b.jsonl", ["B1"]), ("c.jsonl", _err), ("a.jsonl", ["A1", "A2"])]
_two = [("a.jsonl", ["A1", "A2"]), ("c.jsonl", _err), ("b.jsonl", ["B1"])]
_m = merge(_one)
assert _m["records"] == ["A1", "A2", "B1"], f"records should follow path order (a, then b), got {_m['records']}"
assert _m["errors"] == {"c.jsonl": "line 2: bad JSON"}, f"the crashed file should be in errors with its message, got {_m['errors']}"
assert _m["paths"] == ["a.jsonl", "b.jsonl", "c.jsonl"], "paths should be sorted"
assert merge(_two) == _m, "the same files arriving in a different order must give the same report"
assert merge([("x.jsonl", KeyError("id"))])["records"] == [], "a batch where every file failed has no records"''',
            },
            {
                "task": "Get a script ready for a process pool. Write `can_send_to_process(fn)`, which returns `False` for functions that can't be pickled (a lambda, whose `__name__` is `\"<lambda>\"`, or a function defined inside another function, whose `__qualname__` contains `\"<locals>\"`) and `True` otherwise. (This name check is only a quick test, not the full rule: open files, locks and network connections can't be pickled either.) Then move the last line, `scores = main()`, under the `if __name__ == \"__main__\":` guard.",
                "hints": [
                    "`fn.__name__` and `fn.__qualname__` are plain strings, so `==` and `in` work on them.",
                    "`return not (fn.__name__ == \"<lambda>\" or \"<locals>\" in fn.__qualname__)`, and at the bottom `if __name__ == \"__main__\":` followed by an indented `scores = main()`.",
                ],
                "starter": '''def can_send_to_process(fn):
    return True

def difficulty_score(book):
    total = 0
    for i in range(book["pages"] * 100):
        total += (i * i) % 97
    return total

def main():
    scores = [difficulty_score(b) for b in [{"pages": 3}, {"pages": 5}]]
    print(scores, can_send_to_process(difficulty_score))
    return scores

scores = main()
''',
                "solution": '''def can_send_to_process(fn):
    return not (fn.__name__ == "<lambda>" or "<locals>" in fn.__qualname__)

def difficulty_score(book):
    total = 0
    for i in range(book["pages"] * 100):
        total += (i * i) % 97
    return total

def main():
    scores = [difficulty_score(b) for b in [{"pages": 3}, {"pages": 5}]]
    print(scores, can_send_to_process(difficulty_score))
    return scores

if __name__ == "__main__":
    scores = main()
''',
                "tests": '''def _outer():
    def _inner(x):
        return x
    return _inner
_nested = _outer()
_nested.__qualname__ = "_outer.<locals>._inner"   # what CPython reports (the browser's Python shortens it)
assert can_send_to_process(difficulty_score) is True, "a top-level function can be pickled"
assert can_send_to_process(lambda b: b) is False, "a lambda can't be pickled"
assert can_send_to_process(_nested) is False, "a function defined inside another function can't be pickled"
assert can_send_to_process(len) is True, "built-in functions like len can be pickled"
assert 'if __name__ == "__main__":' in __source__ or "if __name__ == '__main__':" in __source__, "put main() under the if __name__ == \\"__main__\\": guard"
assert "\\nscores = main()" not in __source__, "call main() only inside the guard: indent `scores = main()` under the if line"
assert len(scores) == 2, "main() should still run when you run the file"''',
            },
        ],
    },
    # ------------------------------------------------------------------ event loop
    {
        "id": "event-loop",
        "title": "The event loop: async and await",
        "slides": "38-40, 46",
        "idea": "A thread reserves about 1 to 8 MB of stack and the operating system has to juggle it; a **coroutine** (an `async` task) costs about 2 KB and lives inside your program. That is why one Python process can keep thousands of API calls or websocket connections waiting at once with `asyncio`.\n\nThe **event loop** is one thread with a list of tasks. It runs a task until the task says `await something_slow()`. There the task **pauses**, and the loop runs another task that is ready. When the slow thing is done, the loop resumes the paused task. Tasks only switch at `await`: this is **cooperative scheduling**. So a task that blocks without `await` (like `time.sleep(2)` or a long calculation) **freezes every task** until it finishes.\n\nIn real code: `async def fetch():` defines a coroutine function, `await` pauses inside it, and `asyncio.run(main())` starts the loop once at the top. This browser can't run `async` code, so the demo builds a **model** of the loop from generators: `yield 500` plays the part of `await asyncio.sleep(0.5)`. New: a generator can `return` a value; when it ends, `next` raises `StopIteration`, and that value travels inside it as `.value`.\n\n| In the model | In real asyncio |\n|---|---|\n| a generator function (`def` with `yield`) | `async def` |\n| `yield 500` | `await asyncio.sleep(0.5)` |\n| `Loop().run([a, b])` | `await asyncio.gather(a(), b())` inside `asyncio.run(main())` |\n| `finished.value` | the value `await` hands back |\n| a generator object never given to the loop | a coroutine never awaited |\n\n- One thread, many tasks, switching only at `await`\n- A blocking call inside async code freezes the whole loop\n- Calling an `async def` function without `await` only makes a coroutine object: nothing runs (the **forgotten await**)\n- Skip async for CPU-heavy work, for code whose libraries are all sync, for one-off scripts, and from inside ordinary (non-async) functions, which can't `await`",
        "predict": {
            "q": "Three tasks start on one event loop and each begins `await asyncio.sleep(1)`. Right after them, a fourth task calls `time.sleep(2)` (no await). About when do the three sleeping tasks finish?",
            "options": ["After about 1 second", "After about 2 seconds", "After about 3 seconds", "After about 5 seconds"],
            "answer": 1,
            "why": "Their 1-second timers started at 0 and run out while `time.sleep(2)` blocks, but nothing can run until the block ends. At about 2 seconds the loop is free again and all three finish at once: the block made them a second late. (A task that only *starts* after the block, like B in the demo, finishes even later.)",
        },
        "code": '''class Loop:
    """A model of asyncio's event loop: one thread, a list of tasks, a pretend clock."""
    def __init__(self):
        self.now = 0
        self.log = []

    def say(self, text):
        self.log.append(f"{self.now:>5} ms  {text}")

    def run(self, tasks):
        waiting = [(0, n, task) for n, task in enumerate(tasks)]   # (wake-up time, order, task)
        results = [None] * len(tasks)
        while waiting:
            waiting.sort(key=lambda w: (w[0], w[1]))
            wake, n, task = waiting.pop(0)         # the task that is ready first
            self.now = max(self.now, wake)
            try:
                wait_ms = next(task)               # run it until its next "await"
                waiting.append((self.now + wait_ms, n, task))
            except StopIteration as finished:
                results[n] = finished.value        # the task's return value
        return results

def fetch(loop, name, ms):
    loop.say(f"{name} start")
    yield ms                       # like: await asyncio.sleep(ms / 1000)
    loop.say(f"{name} done")
    return f"data from {name}"

def blocking_report(loop, ms):
    loop.say("report start (blocking!)")
    loop.now += ms                 # like time.sleep(): no yield, so no switch
    loop.say("report done")
    yield 0

loop = Loop()
print(loop.run([fetch(loop, "A", 1000), fetch(loop, "B", 1000), fetch(loop, "C", 1000)]))
print("three 1-second fetches took", loop.now, "ms")

loop = Loop()
loop.run([fetch(loop, "A", 1000), blocking_report(loop, 2000), fetch(loop, "B", 1000)])
for line in loop.log:
    print(line)

forgotten = fetch(loop, "X", 500)
print(forgotten, "| log still has", len(loop.log), "lines")
''',
        "walkthrough": [
            ["class Loop:", "A model, not the real `asyncio`: a pretend clock (`now`, in milliseconds), a log, and a `run` method that plays the event loop."],
            ["        waiting = [(0, n, task) for n, task in enumerate(tasks)]   # (wake-up time, order, task)", "Every task starts ready at time 0. `n` remembers the order, for ties and for the results list."],
            ["            wake, n, task = waiting.pop(0)         # the task that is ready first", "After sorting, the first entry is the task that wakes up soonest. One thread: only this task runs now."],
            ["                wait_ms = next(task)               # run it until its next \"await\"", "`next` runs the task until it yields. The number it yields is how long it wants to wait."],
            ["                waiting.append((self.now + wait_ms, n, task))", "The paused task goes back in the list with its wake-up time. Meanwhile the loop runs the others."],
            ["            except StopIteration as finished:", "A generator that reaches its end raises `StopIteration`. Its `return` value is in `finished.value`."],
            ["    yield ms                       # like: await asyncio.sleep(ms / 1000)", "The `await`: the task pauses here and hands control back to the loop."],
            ['    return f"data from {name}"', "A generator's `return` ends it. The loop's `next(task)` then raises `StopIteration`, and `finished.value` is `\"data from A\"`: the value a real `await fetch(...)` would hand back."],
            ["    loop.now += ms                 # like time.sleep(): no yield, so no switch", "A blocking call: time passes but the task never yields, so the loop can't run anyone else."],
            ['print("three 1-second fetches took", loop.now, "ms")', "All three waited at the same time: 1000 ms in total, not 3000."],
            ["for line in loop.log:", "Read the log: B can't even start until the report finishes at 2000 ms, and A's 1-second wait ends late, at 2000 ms. One blocking call froze everything."],
            ['forgotten = fetch(loop, "X", 500)', "Calling the function only creates a paused task object; nothing runs until a loop drives it. Same as calling an `async def` function without `await`."],
        ],
        "mistakes": [
            "Calling `time.sleep()` or a slow sync library inside `async def`: the whole loop freezes. Use `await asyncio.sleep()` or `asyncio.to_thread`.",
            "Writing `result = fetch(\"x\")` without `await`: you get a coroutine object, not the data, and Python warns *coroutine was never awaited*.",
            "Awaiting tasks one by one and expecting them to overlap: `await a()` then `await b()` runs them one after another (the next lesson shows `gather`).",
            "Calling `asyncio.run()` from inside async code: a loop is already running there, so it fails. Inside async code, use `await` instead.",
            "Using async for CPU-heavy work: it still runs on one core. Use processes.",
        ],
        "local": [
            {
                "title": "async, await and asyncio.run",
                "note": "Save as `async_basics.py` and run it. Two awaits in a row run one after another (2 seconds). Calling `fetch` without `await` only makes a coroutine object.",
                "code": '''import asyncio
import time

async def fetch(name: str, seconds: float) -> str:   # async def: a coroutine function
    print(f"start {name}")
    await asyncio.sleep(seconds)                     # pause here; the loop runs others
    print(f"done  {name}")
    return f"data from {name}"

async def main():
    t0 = time.perf_counter()
    a = await fetch("A", 1)                          # one after another
    b = await fetch("B", 1)
    print(a, "|", b, f"| {time.perf_counter() - t0:.1f}s")

    forgotten = fetch("C", 1)                        # no await: nothing runs
    print(type(forgotten).__name__)
    forgotten.close()                                # tidy up the unused coroutine

asyncio.run(main())                                  # start the event loop once''',
                "output": '''start A
done  A
start B
done  B
data from A | data from B | 2.0s
coroutine''',
            },
            {
                "title": "One blocking call freezes the loop",
                "note": "Save as `async_blocking.py` and run it. With `time.sleep` the heartbeat stops for 1.5 seconds; with `await asyncio.sleep` it keeps ticking every 0.5 seconds.",
                "code": '''import asyncio
import time

async def heartbeat():
    for i in range(4):
        print(f"  tick {i + 1} at {time.perf_counter() - T0:.1f}s")
        await asyncio.sleep(0.5)

async def blocking_report():
    time.sleep(1.5)                       # WRONG: blocks the whole loop
    print(f"  blocking report done at {time.perf_counter() - T0:.1f}s")

async def polite_report():
    await asyncio.sleep(1.5)              # RIGHT: lets other tasks run
    print(f"  polite report done at {time.perf_counter() - T0:.1f}s")

async def main(report):
    await asyncio.gather(heartbeat(), report())

T0 = time.perf_counter()
print("with time.sleep:")
asyncio.run(main(blocking_report))
T0 = time.perf_counter()
print("with await asyncio.sleep:")
asyncio.run(main(polite_report))''',
                "output": '''with time.sleep:
  tick 1 at 0.0s
  blocking report done at 1.5s
  tick 2 at 1.5s
  tick 3 at 2.0s
  tick 4 at 2.5s
with await asyncio.sleep:
  tick 1 at 0.0s
  tick 2 at 0.5s
  tick 3 at 1.0s
  polite report done at 1.5s
  tick 4 at 1.5s''',
            },
        ],
        "challenge": {
            "needs_demo": True,
            "task": "Using the demo's `Loop`, write a task `fetch_cover(loop, isbn, ms)` (a generator): it says `start <isbn>`, waits `ms` with `yield ms`, says `done <isbn>`, and returns `\"https://covers.example/<isbn>.jpg\"`. Then make `together = Loop()` and store `together.run([...])` for ISBNs `\"B1\"`, `\"B2\"`, `\"B3\"` taking 300, 800 and 500 ms in `results`. Finally make `one_by_one = Loop()` and run the same three tasks **one at a time** (a separate `one_by_one.run([task])` for each, like three awaits in a row).",
            "hints": [
                "`fetch_cover` looks just like the demo's `fetch`: `loop.say(...)`, `yield ms`, `loop.say(...)`, `return f\"https://covers.example/{isbn}.jpg\"`. Each task needs the loop it runs on: `fetch_cover(together, \"B1\", 300)`.",
                "`results = together.run([fetch_cover(together, \"B1\", 300), fetch_cover(together, \"B2\", 800), fetch_cover(together, \"B3\", 500)])`, then `for isbn, ms in [(\"B1\", 300), (\"B2\", 800), (\"B3\", 500)]: one_by_one.run([fetch_cover(one_by_one, isbn, ms)])`.",
            ],
            "starter": '''def fetch_cover(loop, isbn, ms):
    return f"https://covers.example/{isbn}.jpg"

together = Loop()
results = []
one_by_one = Loop()

print(results)
print("together:", together.now, "ms   one by one:", one_by_one.now, "ms")
''',
            "solution": '''def fetch_cover(loop, isbn, ms):
    loop.say(f"start {isbn}")
    yield ms
    loop.say(f"done {isbn}")
    return f"https://covers.example/{isbn}.jpg"

together = Loop()
results = together.run([fetch_cover(together, "B1", 300), fetch_cover(together, "B2", 800), fetch_cover(together, "B3", 500)])

one_by_one = Loop()
for isbn, ms in [("B1", 300), ("B2", 800), ("B3", 500)]:
    one_by_one.run([fetch_cover(one_by_one, isbn, ms)])

print(results)
print("together:", together.now, "ms   one by one:", one_by_one.now, "ms")
''',
            "tests": '''import types
assert isinstance(fetch_cover(Loop(), "X", 1), types.GeneratorType), "fetch_cover must be a generator: wait with yield ms"
assert results == ["https://covers.example/B1.jpg", "https://covers.example/B2.jpg", "https://covers.example/B3.jpg"], f"results should hold the three cover URLs in task order, got {results}"
assert together.now == 800, f"run together, the three waits overlap: 800 ms (the slowest), got {together.now}"
assert one_by_one.now == 1600, f"one at a time, the waits add up: 300 + 800 + 500 = 1600 ms, got {one_by_one.now}"
_l = Loop()
assert _l.run([fetch_cover(_l, "Z9", 50)]) == ["https://covers.example/Z9.jpg"], "fetch_cover should return the URL for any ISBN"
assert any("start Z9" in _x for _x in _l.log) and any("done Z9" in _x for _x in _l.log), "fetch_cover should say start <isbn> and done <isbn>"''',
        },
        "practice": [
            {
                "needs_demo": True,
                "task": "`load_catalog` blocks the loop: `loop.now += 300` is like calling `time.sleep(0.3)` inside async code, so the heartbeat stops ticking. Rewrite `load_catalog` so it **waits** with `yield 300` instead (like awaiting an async database driver), still says both messages and still returns 1200. The ticks should then come at 0, 100, 200 and 300 ms.",
                "hints": [
                    "Replace the blocking line with a `yield`, and drop the extra `yield 0` at the end.",
                    "`loop.say(\"loading catalog\")`, `yield 300`, `loop.say(\"catalog loaded\")`, `return 1200`.",
                ],
                "starter": '''def heartbeat(loop, beats):
    for _ in range(beats):
        loop.say("tick")
        yield 100

def load_catalog(loop):
    loop.say("loading catalog")
    loop.now += 300                # blocking!
    loop.say("catalog loaded")
    yield 0
    return 1200

loop = Loop()
results = loop.run([heartbeat(loop, 4), load_catalog(loop)])
tick_times = [int(line.split()[0]) for line in loop.log if line.endswith("tick")]
print(tick_times, results)
''',
                "solution": '''def heartbeat(loop, beats):
    for _ in range(beats):
        loop.say("tick")
        yield 100

def load_catalog(loop):
    loop.say("loading catalog")
    yield 300
    loop.say("catalog loaded")
    return 1200

loop = Loop()
results = loop.run([heartbeat(loop, 4), load_catalog(loop)])
tick_times = [int(line.split()[0]) for line in loop.log if line.endswith("tick")]
print(tick_times, results)
''',
                "tests": '''assert tick_times == [0, 100, 200, 300], f"the heartbeat should tick every 100 ms, got {tick_times}"
assert results[1] == 1200, "load_catalog should still return 1200"
assert any("catalog loaded" in _x for _x in loop.log), "load_catalog should still say catalog loaded"
assert "loop.now +=" not in __source__, "don't move the clock by hand: that is a blocking call. Wait with yield"''',
            },
            {
                "needs_demo": True,
                "task": "A forgotten await: task `b` is created but never handed to the loop, so it never runs (just like calling an `async def` function without `await`). In real asyncio the fix is `await asyncio.gather(fetch(\"A\"), fetch(\"B\"))`. Fix the code so the loop runs **both** tasks together: `results` should hold both answers and the whole run should take 600 ms.",
                "hints": [
                    "Creating `b` isn't enough; only tasks passed to `loop.run([...])` are run.",
                    "`results = loop.run([a, b])`",
                ],
                "starter": '''loop = Loop()
a = fetch(loop, "A", 400)
b = fetch(loop, "B", 600)
results = loop.run([a])
print(results, loop.now)
''',
                "solution": '''loop = Loop()
a = fetch(loop, "A", 400)
b = fetch(loop, "B", 600)
results = loop.run([a, b])
print(results, loop.now)
''',
                "tests": '''assert results == ["data from A", "data from B"], f"both tasks should run and return their data, got {results}"
assert loop.now == 600, f"running together, A and B overlap: 600 ms, got {loop.now}"''',
            },
            {
                "task": "Async is a tool, not a religion. Write `worth_async(project)` that returns `True` only when async really pays off: `project[\"kind\"]` is `\"io\"`, `project[\"calls\"]` is 50 or more, `project[\"async_libraries\"]` is `True` (the whole call chain can await), and `project[\"one_off\"]` is `False`. Any other case returns `False`.",
                "hints": [
                    "All four conditions must hold, so join them with `and`.",
                    "`return project[\"kind\"] == \"io\" and project[\"calls\"] >= 50 and project[\"async_libraries\"] and not project[\"one_off\"]`",
                ],
                "starter": '''def worth_async(project):
    return True

print(worth_async({"kind": "io", "calls": 500, "async_libraries": True, "one_off": False}))
''',
                "solution": '''def worth_async(project):
    return (
        project["kind"] == "io"
        and project["calls"] >= 50
        and project["async_libraries"]
        and not project["one_off"]
    )

print(worth_async({"kind": "io", "calls": 500, "async_libraries": True, "one_off": False}))
''',
                "tests": '''_good = {"kind": "io", "calls": 500, "async_libraries": True, "one_off": False}
assert worth_async(_good) is True, "500 API calls with async libraries in a long-running service: async pays off"
assert worth_async(dict(_good, kind="cpu")) is False, "CPU-bound work: async still uses one core, use processes"
assert worth_async(dict(_good, calls=3)) is False, "3 calls: plain code or a few threads is simpler"
assert worth_async(dict(_good, async_libraries=False)) is False, "if your libraries are all sync, async only adds complexity"
assert worth_async(dict(_good, one_off=True)) is False, "a one-off script doesn't need an event loop"
assert worth_async(dict(_good, calls=50)) is True, "50 calls counts as many"''',
            },
        ],
    },
    # ------------------------------------------------------------------ async patterns
    {
        "id": "async-patterns",
        "title": "gather, TaskGroup, Semaphore and timeouts",
        "slides": "41-45, 47-48",
        "idea": "`await a()` then `await b()` runs one after the other. **`asyncio.gather(a(), b(), c())`** starts them all at once and waits for all of them: three 1-second calls take about 1 second, and the results come back **in the order you passed them**. With `return_exceptions=True`, a failed task's **error comes back as a value** in the results list instead of blowing up the whole batch, so you can split successes from failures.\n\n**`asyncio.TaskGroup`** (Python 3.11+) is the modern, stricter version: if one task fails, the group **cancels** its siblings and raises an **`ExceptionGroup`**, one error holding all the task errors in `.exceptions`, built like `ExceptionGroup(\"cover fetch failed\", [error1, error2])`. An **`asyncio.Semaphore(n)`** lets at most `n` tasks inside `async with sem:` at once, so 100 requests don't hit a server together. A **timeout** (`async with asyncio.timeout(2):`) gives every call a deadline; a task that runs past it is cancelled and raises `TimeoutError`, which you can turn into a partial result. **`asyncio.to_thread(fn, arg)`** runs a blocking sync function on a thread, so the loop stays free.\n\nThis browser can't run `asyncio`, so the demo's `gather` is a **model** built from generators (as in the last lesson): it supports `return_exceptions`, a concurrency `limit` like a Semaphore, and a per-task `timeout`. The `local` cards show the real thing.\n\n- `gather`: results in input order; `return_exceptions=True` for partial failures\n- `TaskGroup`: one failure cancels the rest and raises `ExceptionGroup`\n- `Semaphore(n)` caps how many run **at once**; it does not set requests per second\n- Every external call needs a timeout; layer them (per request, plus one for the whole batch)\n- Blocking sync code inside async: wrap it in `asyncio.to_thread`",
        "code": '''def gather(tasks, limit=None, timeout=None):
    """Model of asyncio.gather(..., return_exceptions=True) with a Semaphore(limit) and timeouts."""
    clock = 0
    results = [None] * len(tasks)
    queue = list(enumerate(tasks))               # tasks waiting for a free slot
    running = []                                 # (wake time, index, task, deadline, timed out?)
    while queue or running:
        while queue and (limit is None or len(running) < limit):
            i, task = queue.pop(0)               # like: async with sem:
            deadline = None if timeout is None else clock + timeout
            running.append((clock, i, task, deadline, False))
        running.sort(key=lambda r: (r[0], r[1]))
        wake, i, task, deadline, timed_out = running.pop(0)
        clock = max(clock, wake)
        if timed_out:
            task.close()                         # cancel the task
            results[i] = TimeoutError(f"no answer within {timeout} ms")
            continue
        try:
            wait = next(task)
        except StopIteration as finished:
            results[i] = finished.value
            continue
        except Exception as error:
            results[i] = error                   # return_exceptions=True
            continue
        if deadline is not None and clock + wait > deadline:
            running.append((deadline, i, task, deadline, True))
        else:
            running.append((clock + wait, i, task, deadline, False))
    return results, clock

def fetch_cover(isbn, ms):
    yield ms                                     # await the network
    if isbn.startswith("BAD"):
        raise ConnectionError(f"HTTP 503 for {isbn}")
    return f"https://covers.example/{isbn}.jpg"

jobs = [("B1", 300), ("BAD2", 200), ("B3", 900), ("B4", 400)]

results, ms = gather([fetch_cover(i, t) for i, t in jobs])
print("gather:", ms, "ms")
for (isbn, _), r in zip(jobs, results):
    print("  ", isbn, "failed:" if isinstance(r, Exception) else "ok:", r)

results, ms = gather([fetch_cover(i, t) for i, t in jobs], limit=2)
print("at most 2 at once:", ms, "ms")

results, ms = gather([fetch_cover(i, t) for i, t in jobs], timeout=500)
print("500 ms deadline:", [type(r).__name__ for r in results], ms, "ms")
''',
        "walkthrough": [
            ["def gather(tasks, limit=None, timeout=None):", "One function that models three real tools: `asyncio.gather` (run all, wait for all), `asyncio.Semaphore(limit)` and `asyncio.timeout(...)`. Times are pretend milliseconds."],
            ["        while queue and (limit is None or len(running) < limit):", "Start tasks while there is a free slot. With `limit=2`, a third task waits in the queue until one finishes, exactly what `async with sem:` does."],
            ["            deadline = None if timeout is None else clock + timeout", "Each task's deadline is counted from the moment it starts."],
            ["            task.close()                         # cancel the task", "`close()` stops a paused generator for good. Real asyncio cancels a task by raising `CancelledError` inside it."],
            ["            results[i] = TimeoutError(f\"no answer within {timeout} ms\")", "A timed-out task gets a `TimeoutError` as its result: the batch carries on with a partial result."],
            ["            results[i] = error                   # return_exceptions=True", "A task that raises doesn't stop the others; its error object becomes its result."],
            ["        if deadline is not None and clock + wait > deadline:", "If the task would still be waiting at its deadline, schedule its cancellation for the deadline instead."],
            ["    return results, clock", "`results` keeps the order of `tasks`, like real `gather`; `clock` is how long the whole batch took."],
            ['results, ms = gather([fetch_cover(i, t) for i, t in jobs])', "All four run together: the batch takes 900 ms (the slowest), and BAD2's error is just one entry in the results."],
            ['    print("  ", isbn, "failed:" if isinstance(r, Exception) else "ok:", r)', "`isinstance(r, Exception)` splits failures from successes, the usual pattern after `return_exceptions=True`."],
            ['results, ms = gather([fetch_cover(i, t) for i, t in jobs], limit=2)', "Only two at a time: B3 can't start until BAD2 fails at 200 ms, so the batch now takes 1100 ms. Slower, but the server is never hit by more than two requests at once."],
            ['results, ms = gather([fetch_cover(i, t) for i, t in jobs], timeout=500)', "B3 needs 900 ms but gets 500: it is cancelled and its result is a `TimeoutError`. The batch is done at 500 ms."],
        ],
        "mistakes": [
            "Using `gather` without `return_exceptions=True` and expecting the other results when one task fails: the first error is raised and the results are lost, while the other tasks keep running (they are not cancelled).",
            "Thinking `Semaphore(5)` means 5 requests per second: it means at most 5 in progress at the same moment. Rate limits per second need their own pacing.",
            "Making calls without a timeout: one stuck server then hangs your whole batch forever.",
            "Catching `CancelledError` and not re-raising it: the task then can't be cancelled properly.",
            "Calling a blocking function (a sync database driver, `time.sleep`) directly in async code instead of through `asyncio.to_thread`.",
            "Using `except*` and expecting it to behave like `except`: it handles every matching error inside an `ExceptionGroup`, and it only works on a real Python (not in this browser).",
        ],
        "local": [
            {
                "title": "gather with return_exceptions",
                "note": "Save as `gather_demo.py` and run it. Three 1-second calls finish in about 1 second, and the failure comes back as a value.",
                "code": '''import asyncio
import time

async def fetch_cover(isbn: str) -> str:
    await asyncio.sleep(1)
    if isbn == "978-BAD":
        raise ConnectionError(f"HTTP 503 for {isbn}")
    return f"https://covers.example/{isbn}.jpg"

async def main():
    isbns = ["978-001", "978-BAD", "978-003"]
    t0 = time.perf_counter()
    results = await asyncio.gather(
        *(fetch_cover(i) for i in isbns),
        return_exceptions=True,          # errors come back as values
    )
    print(f"{time.perf_counter() - t0:.1f}s")
    for isbn, r in zip(isbns, results):
        if isinstance(r, Exception):
            print("fail", isbn, type(r).__name__, r)
        else:
            print("ok  ", isbn, r)

asyncio.run(main())''',
                "output": '''1.0s
ok   978-001 https://covers.example/978-001.jpg
fail 978-BAD ConnectionError HTTP 503 for 978-BAD
ok   978-003 https://covers.example/978-003.jpg''',
            },
            {
                "title": "TaskGroup, cancellation and except*",
                "note": "Save as `taskgroup_demo.py` and run it. When BAD1 and BAD2 fail, the group cancels the slow B003 and raises an `ExceptionGroup`. `except* ValueError` handles every `ValueError` inside the group. (`except*` needs a real Python 3.11+.)",
                "code": '''import asyncio

async def fetch_cover(isbn: str, delay: float) -> str:
    try:
        await asyncio.sleep(delay)
        if isbn.startswith("BAD"):
            raise ValueError(f"no cover for {isbn}")
        return f"cover/{isbn}.jpg"
    except asyncio.CancelledError:
        print(f"{isbn}: cancelled")
        raise                              # always re-raise CancelledError

async def main():
    async with asyncio.TaskGroup() as tg:
        t1 = tg.create_task(fetch_cover("B001", 0.5))
        t2 = tg.create_task(fetch_cover("B002", 0.2))
    print("all fine:", t1.result(), t2.result())

    try:
        async with asyncio.TaskGroup() as tg:
            tg.create_task(fetch_cover("B003", 2.0))   # slow sibling
            tg.create_task(fetch_cover("BAD1", 0.5))
            tg.create_task(fetch_cover("BAD2", 0.5))
    except* ValueError as group:
        for e in group.exceptions:
            print("failed:", e)

asyncio.run(main())''',
                "output": '''all fine: cover/B001.jpg cover/B002.jpg
B003: cancelled
failed: no cover for BAD1
failed: no cover for BAD2''',
            },
            {
                "title": "Semaphore and asyncio.timeout",
                "note": "Save as `limits_demo.py` and run it. Only two requests are in progress at once; the slow one hits its 1-second deadline and becomes a partial result.",
                "code": '''import asyncio
import time

T0 = time.perf_counter()

async def fetch(url: str, delay: float, sem: asyncio.Semaphore) -> str:
    async with sem:                                  # at most 2 inside at once
        print(f"{time.perf_counter() - T0:.1f}s start {url}")
        try:
            async with asyncio.timeout(1.0):         # per-request deadline
                await asyncio.sleep(delay)
                return f"data from {url}"
        except TimeoutError:
            return f"timeout for {url}"

async def main():
    sem = asyncio.Semaphore(2)
    jobs = [("book/1", 0.5), ("book/2", 0.5), ("book/slow", 3.0), ("book/3", 0.5)]
    async with asyncio.timeout(5):                   # deadline for the whole batch
        results = await asyncio.gather(*(fetch(u, d, sem) for u, d in jobs))
    print(results)
    print(f"total {time.perf_counter() - T0:.1f}s")

asyncio.run(main())''',
                "output": '''0.0s start book/1
0.0s start book/2
0.5s start book/slow
0.5s start book/3
['data from book/1', 'data from book/2', 'timeout for book/slow', 'data from book/3']
total 1.5s''',
            },
            {
                "title": "asyncio.to_thread for blocking code",
                "note": "Save as `to_thread_demo.py` and run it. Three blocking 1-second queries run on threads, so together they take about 1 second and the loop stays free.",
                "code": '''import asyncio
import time

def blocking_query(name: str) -> str:      # a sync library we can't change
    time.sleep(1)
    return f"rows for {name}"

async def main():
    t0 = time.perf_counter()
    results = await asyncio.gather(*(asyncio.to_thread(blocking_query, q) for q in ["loans", "members", "fines"]))
    print(results, f"{time.perf_counter() - t0:.1f}s")

asyncio.run(main())''',
                "output": "['rows for loans', 'rows for members', 'rows for fines'] 1.0s",
            },
            {
                "title": "The BookVault cover fetcher, tested with MockTransport (Q16, Q17)",
                "note": "Install with `pip install httpx pytest pytest-asyncio`, save the two files side by side and run `pytest -q`. `httpx.MockTransport` answers requests in memory, so the tests never touch the network. Every failure becomes a `CoverResult` with the error's name, including invalid JSON (which raises `JSONDecodeError`, a `ValueError`). The client also gets a timeout of its own.",
                "code": '''# covers.py
import asyncio
from dataclasses import dataclass

import httpx

@dataclass(frozen=True)
class CoverResult:
    isbn: str
    url: str | None
    error: str | None = None

class CoverFetcher:
    def __init__(self, *, base_url: str, concurrency: int = 5, timeout: float = 2.0, transport=None):
        self.base_url = base_url
        self._sem = asyncio.Semaphore(concurrency)
        self._timeout = timeout
        self._transport = transport               # tests pass an httpx.MockTransport

    async def fetch_one(self, client: httpx.AsyncClient, isbn: str) -> CoverResult:
        async with self._sem:
            try:
                async with asyncio.timeout(self._timeout):
                    r = await client.get(f"/covers/{isbn}")
                r.raise_for_status()
                return CoverResult(isbn, r.json()["url"])
            except (httpx.HTTPError, TimeoutError, KeyError, ValueError) as e:
                return CoverResult(isbn, None, type(e).__name__)

    async def fetch_all(self, isbns: list[str]) -> dict[str, CoverResult]:
        async with httpx.AsyncClient(base_url=self.base_url, timeout=self._timeout,
                                     transport=self._transport) as client:
            async with asyncio.TaskGroup() as tg:
                tasks = [tg.create_task(self.fetch_one(client, i)) for i in isbns]
        return {t.result().isbn: t.result() for t in tasks}

# test_covers.py
import asyncio
import httpx
import pytest
from covers import CoverFetcher

def handler(request: httpx.Request) -> httpx.Response:
    isbn = request.url.path.rsplit("/", 1)[-1]
    if isbn == "B404":
        return httpx.Response(404)
    if isbn == "B503":
        return httpx.Response(503)
    if isbn == "NOURL":
        return httpx.Response(200, json={"size": 3})
    if isbn == "BADJSON":
        return httpx.Response(200, text="not json")
    return httpx.Response(200, json={"url": f"https://img.example/{isbn}.jpg"})

@pytest.mark.asyncio
async def test_every_isbn_gets_a_result():
    fetcher = CoverFetcher(base_url="https://api.test", transport=httpx.MockTransport(handler))
    isbns = ["B001", "B404", "B503", "NOURL", "BADJSON"]
    results = await fetcher.fetch_all(isbns)
    assert set(results) == set(isbns)
    assert results["B001"].url == "https://img.example/B001.jpg"
    assert results["B404"].error == "HTTPStatusError"
    assert results["B503"].error == "HTTPStatusError"
    assert results["NOURL"].error == "KeyError"
    assert results["BADJSON"].error == "JSONDecodeError"

@pytest.mark.asyncio
async def test_slow_server_times_out():
    async def slow(request):
        await asyncio.sleep(1)
        return httpx.Response(200, json={"url": "late"})
    fetcher = CoverFetcher(base_url="https://api.test", timeout=0.1,
                           transport=httpx.MockTransport(slow))
    results = await fetcher.fetch_all(["B001"])
    assert results["B001"].error == "TimeoutError"''',
                "output": '''..                                                                       [100%]
2 passed in 0.40s''',
            },
        ],
        "challenge": {
            "needs_demo": True,
            "task": "Using the demo's `gather` and `fetch_cover`, write `cover_report(jobs)`, where `jobs` is a list of `(isbn, ms)`. Run all the fetches together with `gather`, then return `(covers, errors)`: `covers` maps **every** ISBN to its URL, or to `None` if it failed; `errors` maps each failed ISBN to the error's class name (`type(r).__name__`).",
            "hints": [
                "`results, _ = gather([fetch_cover(i, t) for i, t in jobs])`, then walk `zip(jobs, results)` to pair each ISBN with its result.",
                "For each pair: `if isinstance(r, Exception): covers[isbn] = None` and `errors[isbn] = type(r).__name__`, `else: covers[isbn] = r`.",
            ],
            "starter": '''def cover_report(jobs):
    covers = {}
    errors = {}
    return covers, errors

print(cover_report([("B1", 300), ("BAD2", 200), ("B3", 100)]))
''',
            "solution": '''def cover_report(jobs):
    results, _ = gather([fetch_cover(i, t) for i, t in jobs])
    covers = {}
    errors = {}
    for (isbn, _), r in zip(jobs, results):
        if isinstance(r, Exception):
            covers[isbn] = None
            errors[isbn] = type(r).__name__
        else:
            covers[isbn] = r
    return covers, errors

print(cover_report([("B1", 300), ("BAD2", 200), ("B3", 100)]))
''',
            "tests": '''_c, _e = cover_report([("B1", 300), ("BAD2", 200), ("B3", 100), ("BAD4", 50)])
assert set(_c) == {"B1", "BAD2", "B3", "BAD4"}, "covers should have an entry for every ISBN, including the failed ones"
assert _c["B1"] == "https://covers.example/B1.jpg" and _c["B3"] == "https://covers.example/B3.jpg", "a good ISBN should map to its URL"
assert _c["BAD2"] is None and _c["BAD4"] is None, "a failed ISBN should map to None"
assert _e == {"BAD2": "ConnectionError", "BAD4": "ConnectionError"}, f"errors should map each failed ISBN to the error's class name, got {_e}"
assert cover_report([]) == ({}, {}), "no jobs give two empty dicts"
assert "gather(" in __source__, "run the fetches together with gather(...)"''',
        },
        "practice": [
            {
                "needs_demo": True,
                "task": "The cover API allows at most **3 requests at once**, and each must answer within **1000 ms**. Write `fetch_batch(jobs)` (a list of `(isbn, ms)`) that runs `fetch_cover` for every job with the demo's `gather`, using `limit=3` and `timeout=1000`. Return `(answers, total_ms)`: `answers` maps each ISBN to its URL, `\"timeout\"` for a `TimeoutError`, or `\"error\"` for any other failure.",
                "hints": [
                    "`results, total_ms = gather([fetch_cover(i, t) for i, t in jobs], limit=3, timeout=1000)`.",
                    "Check `isinstance(r, TimeoutError)` first (answer `\"timeout\"`), then `isinstance(r, Exception)` (answer `\"error\"`), otherwise the URL.",
                ],
                "starter": '''def fetch_batch(jobs):
    results, total_ms = gather([fetch_cover(i, t) for i, t in jobs])
    answers = {}
    for (isbn, _), r in zip(jobs, results):
        answers[isbn] = r
    return answers, total_ms

print(fetch_batch([("B1", 400), ("B2", 1500), ("BAD3", 100), ("B4", 300)]))
''',
                "solution": '''def fetch_batch(jobs):
    results, total_ms = gather([fetch_cover(i, t) for i, t in jobs], limit=3, timeout=1000)
    answers = {}
    for (isbn, _), r in zip(jobs, results):
        if isinstance(r, TimeoutError):
            answers[isbn] = "timeout"
        elif isinstance(r, Exception):
            answers[isbn] = "error"
        else:
            answers[isbn] = r
    return answers, total_ms

print(fetch_batch([("B1", 400), ("B2", 1500), ("BAD3", 100), ("B4", 300)]))
''',
                "tests": '''_a, _t = fetch_batch([("B1", 400), ("B2", 1500), ("BAD3", 100), ("B4", 300)])
assert _a["B2"] == "timeout", "B2 needs 1500 ms but the deadline is 1000 ms: its answer should be \\"timeout\\""
assert _a["BAD3"] == "error", "BAD3 fails with an error that isn't a timeout: its answer should be \\"error\\""
assert _a["B1"] == "https://covers.example/B1.jpg" and _a["B4"] == "https://covers.example/B4.jpg", "good ISBNs should map to their URLs"
assert _t == 1000, f"the batch should end when B2 hits its deadline at 1000 ms, got {_t}"
_real = fetch_cover
_open = {"now": 0, "peak": 0}
def fetch_cover(isbn, ms):
    _open["now"] += 1
    _open["peak"] = max(_open["peak"], _open["now"])
    try:
        yield ms
    finally:
        _open["now"] -= 1
    return isbn
fetch_batch([(f"X{_n}", 100 * (_n % 4 + 1)) for _n in range(10)])
fetch_cover = _real
assert _open["peak"] == 3, f"never more than 3 requests at once: use limit=3 (saw {_open['peak']} at once)"''',
            },
            {
                "needs_demo": True,
                "task": "Make a strict, TaskGroup-style runner. Write `run_group(tasks)`: run the tasks with the demo's `gather`, and if **any** result is an exception, raise `ExceptionGroup(\"cover fetch failed\", errors)` with the list of all the errors. Otherwise return the results. Then catch it: put the failing batch below in `try` / `except ExceptionGroup as group:` and store the error messages (`str(e)` for each `e` in `group.exceptions`) in `messages`. (A real TaskGroup also cancels the tasks still running at the first failure; this model lets them finish.)",
                "hints": [
                    "`errors = [r for r in results if isinstance(r, Exception)]`, then `if errors: raise ExceptionGroup(\"cover fetch failed\", errors)`.",
                    "`try: run_group(...)` then `except ExceptionGroup as group: messages = [str(e) for e in group.exceptions]`.",
                ],
                "starter": '''def run_group(tasks):
    results, _ = gather(tasks)
    return results

messages = []
run_group([fetch_cover("B1", 100), fetch_cover("BAD2", 200), fetch_cover("BAD3", 50)])
print(messages)
''',
                "solution": '''def run_group(tasks):
    results, _ = gather(tasks)
    errors = [r for r in results if isinstance(r, Exception)]
    if errors:
        raise ExceptionGroup("cover fetch failed", errors)
    return results

messages = []
try:
    run_group([fetch_cover("B1", 100), fetch_cover("BAD2", 200), fetch_cover("BAD3", 50)])
except ExceptionGroup as group:
    messages = [str(e) for e in group.exceptions]
print(messages)
''',
                "tests": '''assert messages == ["HTTP 503 for BAD2", "HTTP 503 for BAD3"], f"messages should hold both failures, in task order, got {messages}"
assert run_group([fetch_cover("B1", 10), fetch_cover("B2", 20)]) == ["https://covers.example/B1.jpg", "https://covers.example/B2.jpg"], "when every task works, run_group should return the results"
try:
    run_group([fetch_cover("BAD9", 10)])
    raise AssertionError("run_group should raise ExceptionGroup when a task fails")
except ExceptionGroup as _g:
    assert len(_g.exceptions) == 1 and isinstance(_g.exceptions[0], ConnectionError), "the ExceptionGroup should hold the task's own error"
assert "except ExceptionGroup" in __source__, "catch the group with except ExceptionGroup as group:"''',
            },
            {
                "needs_demo": True,
                "task": "Model `asyncio.to_thread`. Write a task `to_thread(fn, arg, takes_ms)` (a generator): it waits `takes_ms` with `yield` (a thread does the slow work, so the loop stays free) and then returns `fn(arg)`. Then run three `slow_query` calls through it with the demo's `gather`, each taking 1000 ms, storing the results in `rows` and the time in `total_ms`.",
                "hints": [
                    "The task is two lines: `yield takes_ms`, then `return fn(arg)`.",
                    "`rows, total_ms = gather([to_thread(slow_query, q, 1000) for q in [\"loans\", \"members\", \"fines\"]])`",
                ],
                "starter": '''def slow_query(name):
    return f"rows for {name}"

def to_thread(fn, arg, takes_ms):
    return fn(arg)

rows, total_ms = [], 0
print(rows, total_ms)
''',
                "solution": '''def slow_query(name):
    return f"rows for {name}"

def to_thread(fn, arg, takes_ms):
    yield takes_ms
    return fn(arg)

rows, total_ms = gather([to_thread(slow_query, q, 1000) for q in ["loans", "members", "fines"]])
print(rows, total_ms)
''',
                "tests": '''import types
assert isinstance(to_thread(len, "abc", 5), types.GeneratorType), "to_thread must be a generator task: wait with yield takes_ms"
assert rows == ["rows for loans", "rows for members", "rows for fines"], f"rows should hold the three query results in order, got {rows}"
assert total_ms == 1000, f"the three 1000 ms queries run on threads at the same time: 1000 ms in total, got {total_ms}"
assert gather([to_thread(str.upper, "abc", 70)]) == (["ABC"], 70), "to_thread should wait takes_ms and then return fn(arg)"''',
            },
        ],
    },
    # ------------------------------------------------------------------ retry with backoff
    {
        "id": "retry-backoff",
        "title": "Retry with exponential backoff",
        "slides": "Q18",
        "idea": "Networks fail. Some failures are **transient**: try again in a moment and it may work (HTTP 429 *too many requests*, 500, 502, 503, 504, or a timeout). Others are **permanent**: trying again gives the same answer (400 *bad request*, 401, 403, 404 *not found*). A good **retry** tries again only after transient errors, and gives up after a maximum number of **attempts**, re-raising the last error.\n\nDon't retry at once, and don't wait the same time each round. **Exponential backoff** doubles the wait each time: 0.1 s, 0.2 s, 0.4 s, 0.8 s... with a **cap** (say 2 s) so it never grows silly. If a thousand clients all retry on the same schedule, they hit the server together again, so add **jitter**: a random part of the wait, such as a random number between 0 and the delay (*full jitter*).\n\nTwo things make this testable. Pass `sleep` in as a parameter (**inject** it): the real program passes `time.sleep` (or `asyncio.sleep`), and tests pass a fake that only **records** the delays, so tests run in milliseconds and can check the exact backoff. Do the same with jitter: pass a function, and in tests use a seeded `random.Random(seed)`, which gives the same \"random\" numbers every run. (This browser can't call `time.sleep` at all, which is one more reason to inject it.)\n\n- Retry 429, 500, 502, 503, 504 and timeouts; never 400, 401, 403, 404\n- Delay for attempt `n` (from 0): `min(cap, base * 2 ** n)`\n- Stop after `attempts` tries and re-raise the last error\n- Jitter spreads clients out; `random.Random(seed)` makes it repeatable in tests\n- Inject `sleep`: tests record delays instead of waiting",
        "code": '''import random

class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

TRANSIENT = {429, 500, 502, 503, 504}          # worth another try

def is_transient(error):
    if isinstance(error, TimeoutError):
        return True
    return isinstance(error, HTTPError) and error.status in TRANSIENT

def backoff(attempt, base=0.1, cap=2.0):
    return min(cap, base * 2 ** attempt)        # 0.1, 0.2, 0.4 ... at most 2.0

def retry(call, *, attempts=4, sleep, jitter=None):
    for attempt in range(attempts):
        try:
            return call()
        except Exception as error:
            if not is_transient(error) or attempt == attempts - 1:
                raise                           # permanent, or out of attempts
            delay = backoff(attempt)
            if jitter is not None:
                delay = jitter(delay)
            sleep(delay)

def fake_server(*replies):
    replies = list(replies)
    def call():
        reply = replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return reply
    return call

waits = []
print(retry(fake_server(HTTPError(503), TimeoutError(), "cover.jpg"), sleep=waits.append))
print("slept:", waits)

waits = []
try:
    retry(fake_server(HTTPError(404), "never reached"), sleep=waits.append)
except HTTPError as e:
    print("gave up at once on", e, "- slept:", waits)

print("backoff:", [backoff(n) for n in range(7)])
rng = random.Random(42)
print("with jitter:", [round(rng.uniform(0, backoff(n)), 3) for n in range(4)])
''',
        "walkthrough": [
            ["class HTTPError(Exception):", "A small error that carries the HTTP status code, so the retry logic can look at it."],
            ["TRANSIENT = {429, 500, 502, 503, 504}          # worth another try", "A set of the codes that might work on a second try: rate limited, or the server had a bad moment."],
            ["    if isinstance(error, TimeoutError):", "A timeout is transient too: the next try may be quicker."],
            ["    return min(cap, base * 2 ** attempt)        # 0.1, 0.2, 0.4 ... at most 2.0", "`2 ** attempt` doubles each round: 1, 2, 4, 8 ... times the base. `min` applies the cap."],
            ["def retry(call, *, attempts=4, sleep, jitter=None):", "`sleep` is a parameter with no default: the caller must say how to wait. The `*` makes everything after it keyword-only, so calls read clearly: `sleep=time.sleep`."],
            ["            if not is_transient(error) or attempt == attempts - 1:", "Give up on a permanent error straight away, or when this was the last attempt."],
            ["                raise                           # permanent, or out of attempts", "A bare `raise` inside `except` re-raises the same error, so the caller sees what really went wrong."],
            ["            sleep(delay)", "Wait before the next try, through whatever `sleep` was injected."],
            ["def fake_server(*replies):", "A fake API: each call gives the next reply, raising it if it is an error. Tests script exactly what the 'server' does."],
            ['print(retry(fake_server(HTTPError(503), TimeoutError(), "cover.jpg"), sleep=waits.append))', "The fake `sleep` is just `waits.append`: it records each delay instead of waiting. Two transient failures, then success."],
            ['print("slept:", waits)', "The recorded delays are exactly the backoff: `[0.1, 0.2]`, and the program didn't wait at all."],
            ['    retry(fake_server(HTTPError(404), "never reached"), sleep=waits.append)', "404 is permanent: no retry, no sleep, the error goes straight back to the caller."],
            ["rng = random.Random(42)", "A random number generator with its own seed. The same seed gives the same numbers every run, so tests stay repeatable."],
            ['print("with jitter:", [round(rng.uniform(0, backoff(n)), 3) for n in range(4)])', "Full jitter: a random wait between 0 and the backoff delay, so many clients don't all retry at the same moment."],
        ],
        "mistakes": [
            "Retrying every error: a 404 or a 401 will never succeed, and retrying just wastes time and quota.",
            "Retrying forever: always have a maximum number of attempts, then re-raise the last error.",
            "Ignoring the `Retry-After` header on a 429: when the server says how long to wait, wait at least that long instead of your own backoff.",
            "Waiting the same short time between tries: backoff gives a struggling server room to recover.",
            "Forgetting the cap: without it the 10th retry would wait 0.1 x 2^10, more than 100 seconds.",
            "Calling `time.sleep` directly inside the retry: tests become slow and can't check the delays. Inject `sleep`.",
            "Testing jitter with exact numbers from the global `random`: use a seeded `random.Random(seed)`, or check the delays are within the allowed range.",
        ],
        "local": [{
            "title": "Async retry tested with a fake async sleep (Q18)",
            "note": "Install with `pip install httpx pytest pytest-asyncio`, save both files side by side and run `pytest -q`. The real code passes `asyncio.sleep`; the tests pass `FakeSleep`, whose `__call__` is `async`, so it can be awaited like `asyncio.sleep` but only records the delay.",
            "code": '''# retry.py
import asyncio

import httpx

TRANSIENT = {429, 500, 502, 503, 504}

def is_transient(error: Exception) -> bool:
    if isinstance(error, (TimeoutError, httpx.TimeoutException)):
        return True
    return isinstance(error, httpx.HTTPStatusError) and error.response.status_code in TRANSIENT

async def retry(call, *, attempts=4, base=0.1, cap=2.0, sleep=asyncio.sleep, jitter=None):
    for attempt in range(attempts):
        try:
            return await call()
        except Exception as error:
            if not is_transient(error) or attempt == attempts - 1:
                raise
            delay = min(cap, base * 2 ** attempt)
            await sleep(jitter(delay) if jitter else delay)

# test_retry.py
import httpx
import pytest
from retry import retry

def status_error(code):
    request = httpx.Request("GET", "https://api.test/covers/B1")
    return httpx.HTTPStatusError(f"HTTP {code}", request=request,
                                 response=httpx.Response(code, request=request))

class FakeSleep:
    def __init__(self):
        self.calls = []
    async def __call__(self, seconds):
        self.calls.append(seconds)

def server(*replies):
    replies = list(replies)
    async def call():
        reply = replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return reply
    return call

@pytest.mark.asyncio
async def test_succeeds_after_two_transient_failures():
    sleep = FakeSleep()
    assert await retry(server(status_error(503), TimeoutError(), "ok"), sleep=sleep) == "ok"
    assert sleep.calls == [0.1, 0.2]

@pytest.mark.asyncio
async def test_stops_after_max_attempts():
    sleep = FakeSleep()
    with pytest.raises(httpx.HTTPStatusError):
        await retry(server(*[status_error(503)] * 4), attempts=4, sleep=sleep)
    assert sleep.calls == [0.1, 0.2, 0.4]

@pytest.mark.asyncio
async def test_does_not_retry_404():
    sleep = FakeSleep()
    with pytest.raises(httpx.HTTPStatusError):
        await retry(server(status_error(404), "never"), sleep=sleep)
    assert sleep.calls == []''',
            "output": '''...                                                                      [100%]
3 passed in 0.05s''',
        }],
        "challenge": {
            "task": "Write `retry(call, *, attempts=4, sleep)` using the `is_transient` and `backoff` functions given. Call `call()` and return its result. If it raises a transient error and attempts are left, `sleep(backoff(attempt))` and try again (attempts count from 0). If the error is permanent, or this was the last attempt, re-raise it.",
            "hints": [
                "Loop `for attempt in range(attempts):` with `try: return call()` inside. In `except Exception as error:` decide whether to give up.",
                "`if not is_transient(error) or attempt == attempts - 1: raise`, otherwise `sleep(backoff(attempt))`.",
            ],
            "starter": '''class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

def is_transient(error):
    if isinstance(error, TimeoutError):
        return True
    return isinstance(error, HTTPError) and error.status in {429, 500, 502, 503, 504}

def backoff(attempt, base=0.1, cap=2.0):
    return min(cap, base * 2 ** attempt)

def retry(call, *, attempts=4, sleep):
    return call()

def fake_server(*replies):
    replies = list(replies)
    def call():
        reply = replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return reply
    return call

waits = []
try:
    print(retry(fake_server(HTTPError(502), HTTPError(429), "cover.jpg"), sleep=waits.append), waits)
except HTTPError as e:
    print("gave up:", e, waits)
''',
            "solution": '''class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

def is_transient(error):
    if isinstance(error, TimeoutError):
        return True
    return isinstance(error, HTTPError) and error.status in {429, 500, 502, 503, 504}

def backoff(attempt, base=0.1, cap=2.0):
    return min(cap, base * 2 ** attempt)

def retry(call, *, attempts=4, sleep):
    for attempt in range(attempts):
        try:
            return call()
        except Exception as error:
            if not is_transient(error) or attempt == attempts - 1:
                raise
            sleep(backoff(attempt))

def fake_server(*replies):
    replies = list(replies)
    def call():
        reply = replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return reply
    return call

waits = []
try:
    print(retry(fake_server(HTTPError(502), HTTPError(429), "cover.jpg"), sleep=waits.append), waits)
except HTTPError as e:
    print("gave up:", e, waits)
''',
            "tests": '''def _close(a, b):
    return len(a) == len(b) and all(abs(x - y) < 1e-9 for x, y in zip(a, b))
_w = []
try:
    _r = retry(fake_server(HTTPError(503), TimeoutError(), "ok"), sleep=_w.append)
except (HTTPError, TimeoutError):
    raise AssertionError("retry gave up on a transient error (HTTP 503): it should sleep and try again")
assert _r == "ok", "after two transient failures the third try should succeed"
assert _close(_w, [0.1, 0.2]), f"the fake sleep should receive the backoff delays [0.1, 0.2], got {_w}"
_w = []
try:
    retry(fake_server(*[HTTPError(503)] * 4), attempts=4, sleep=_w.append)
    raise AssertionError("after 4 failed attempts retry should re-raise the last error")
except HTTPError as _e:
    assert _e.status == 503, "re-raise the server's own error"
assert _close(_w, [0.1, 0.2, 0.4]), f"4 attempts means 3 waits: [0.1, 0.2, 0.4], got {_w}"
_w = []
_calls = []
def _not_found():
    _calls.append(1)
    raise HTTPError(404)
try:
    retry(_not_found, sleep=_w.append)
    raise AssertionError("a 404 should be re-raised")
except HTTPError:
    pass
assert len(_calls) == 1 and _w == [], "404 is permanent: call once, never sleep"
_w = []
try:
    retry(fake_server(*[HTTPError(500)] * 7), attempts=7, sleep=_w.append)
except HTTPError:
    pass
assert _close(_w, [0.1, 0.2, 0.4, 0.8, 1.6, 2.0]), f"delays should double and stop at the 2.0 cap, got {_w}"''',
        },
        "practice": [
            {
                "task": "Write the two building blocks. `is_transient(error)` returns `True` for a `TimeoutError` and for an `HTTPError` whose `status` is 429, 500, 502, 503 or 504, and `False` for anything else. `backoff(attempt, base=0.1, cap=2.0)` returns `base * 2 ** attempt`, but never more than `cap`.",
                "hints": [
                    "Check the timeout first with `isinstance(error, TimeoutError)`. For HTTP errors, test both the type and `error.status in {429, 500, 502, 503, 504}`.",
                    "`backoff` is one line: `return min(cap, base * 2 ** attempt)`.",
                ],
                "starter": '''class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

def is_transient(error):
    return True

def backoff(attempt, base=0.1, cap=2.0):
    return base

print(is_transient(HTTPError(404)), [backoff(n) for n in range(6)])
''',
                "solution": '''class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

def is_transient(error):
    if isinstance(error, TimeoutError):
        return True
    return isinstance(error, HTTPError) and error.status in {429, 500, 502, 503, 504}

def backoff(attempt, base=0.1, cap=2.0):
    return min(cap, base * 2 ** attempt)

print(is_transient(HTTPError(404)), [backoff(n) for n in range(6)])
''',
                "tests": '''for _s in (429, 500, 502, 503, 504):
    assert is_transient(HTTPError(_s)) is True, f"HTTP {_s} is transient: retry it"
for _s in (400, 401, 403, 404):
    assert is_transient(HTTPError(_s)) is False, f"HTTP {_s} is permanent: don't retry it"
assert is_transient(TimeoutError()) is True, "a timeout is transient"
assert is_transient(ValueError("bad data")) is False, "an error that isn't HTTP or a timeout is not transient"
assert [round(backoff(n), 6) for n in range(4)] == [0.1, 0.2, 0.4, 0.8], "the delay should double each attempt: 0.1, 0.2, 0.4, 0.8"
assert backoff(5) == 2.0 and backoff(20) == 2.0, "the delay should never go above the cap of 2.0"
assert round(backoff(2, base=1, cap=30), 6) == 4 and backoff(10, base=1, cap=30) == 30, "use the base and cap parameters"''',
            },
            {
                "task": "Add jitter. Give `retry` a `jitter=None` parameter: when it isn't `None`, pass the backoff delay through `jitter(delay)` before sleeping. Then write `make_jitter(seed)`, which creates `rng = random.Random(seed)` and returns a function that, given a delay, returns `rng.uniform(0, delay)` (full jitter).",
                "hints": [
                    "In `retry`: `delay = backoff(attempt)`, then `if jitter is not None: delay = jitter(delay)`, then `sleep(delay)`. Add `jitter=None` to the keyword-only parameters.",
                    "`make_jitter` defines an inner function: `rng = random.Random(seed)`, `def jitter(delay): return rng.uniform(0, delay)`, `return jitter`.",
                ],
                "starter": '''import random

class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

def is_transient(error):
    return isinstance(error, TimeoutError) or (isinstance(error, HTTPError) and error.status in {429, 500, 502, 503, 504})

def backoff(attempt, base=0.1, cap=2.0):
    return min(cap, base * 2 ** attempt)

def retry(call, *, attempts=4, sleep):
    for attempt in range(attempts):
        try:
            return call()
        except Exception as error:
            if not is_transient(error) or attempt == attempts - 1:
                raise
            sleep(backoff(attempt))

def make_jitter(seed):
    ...

def flaky(failures):
    count = {"n": 0}
    def call():
        count["n"] += 1
        if count["n"] <= failures:
            raise HTTPError(503)
        return "ok"
    return call

waits = []
print(retry(flaky(3), sleep=waits.append), waits)
''',
                "solution": '''import random

class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

def is_transient(error):
    return isinstance(error, TimeoutError) or (isinstance(error, HTTPError) and error.status in {429, 500, 502, 503, 504})

def backoff(attempt, base=0.1, cap=2.0):
    return min(cap, base * 2 ** attempt)

def retry(call, *, attempts=4, sleep, jitter=None):
    for attempt in range(attempts):
        try:
            return call()
        except Exception as error:
            if not is_transient(error) or attempt == attempts - 1:
                raise
            delay = backoff(attempt)
            if jitter is not None:
                delay = jitter(delay)
            sleep(delay)

def make_jitter(seed):
    rng = random.Random(seed)
    def jitter(delay):
        return rng.uniform(0, delay)
    return jitter

def flaky(failures):
    count = {"n": 0}
    def call():
        count["n"] += 1
        if count["n"] <= failures:
            raise HTTPError(503)
        return "ok"
    return call

waits = []
print(retry(flaky(3), sleep=waits.append, jitter=make_jitter(7)), waits)
''',
                "tests": '''_w = []
try:
    retry(flaky(2), sleep=_w.append, jitter=lambda d: d / 2)
except TypeError:
    raise AssertionError("give retry a keyword parameter jitter=None")
assert [round(_x, 6) for _x in _w] == [0.05, 0.1], f"retry should sleep jitter(delay): halving gives [0.05, 0.1], got {_w}"
_w = []
retry(flaky(2), sleep=_w.append)
assert [round(_x, 6) for _x in _w] == [0.1, 0.2], "without jitter, retry should sleep the plain backoff delays"
_a = make_jitter(11)
_b = make_jitter(11)
_xs = [_a(1.0) for _ in range(5)]
assert _xs == [_b(1.0) for _ in range(5)], "the same seed must give the same delays every time"
assert all(0 <= _x <= 1.0 for _x in _xs), "full jitter picks a delay between 0 and the backoff delay"
assert len(set(_xs)) > 1, "each call should give a new random delay"
_w = []
retry(flaky(3), sleep=_w.append, jitter=make_jitter(3))
assert len(_w) == 3 and all(0 <= _x <= _d for _x, _d in zip(_w, [0.1, 0.2, 0.4])), f"each jittered wait should be between 0 and its backoff delay, got {_w}"''',
            },
            {
                "task": "Write the tests yourself, with an injected fake sleep. First write a class `FakeSleep` whose instances can be called like a function: `__init__` sets `self.calls = []`, and `__call__(self, seconds)` appends `seconds`. Then write two test functions that use `FakeSleep` and `fake_server`: `test_retries_then_succeeds()` (two 503s then `\"ok\"`: assert the result is `\"ok\"` and the delays are `[0.1, 0.2]`) and `test_404_is_not_retried()` (a 404: assert `retry` raises `HTTPError` and that it never slept). Your tests will be run against broken versions of `retry` too, and must catch them.",
                "hints": [
                    "`__call__` is what Python runs when you write `sleep(0.1)` on an instance, so `retry(..., sleep=FakeSleep())` works. For the 404 test, use `try: retry(...)` then `raise AssertionError(...)`, and `except HTTPError: pass`.",
                    "`sleep = FakeSleep()`, `assert retry(fake_server(HTTPError(503), HTTPError(503), \"ok\"), sleep=sleep) == \"ok\"`, `assert sleep.calls == [0.1, 0.2]`. In the 404 test, finish with `assert sleep.calls == []`.",
                ],
                "starter": '''class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

def retry(call, *, attempts=4, sleep):
    for attempt in range(attempts):
        try:
            return call()
        except Exception as error:
            transient = isinstance(error, TimeoutError) or (isinstance(error, HTTPError) and error.status in {429, 500, 502, 503, 504})
            if not transient or attempt == attempts - 1:
                raise
            sleep(min(2.0, 0.1 * 2 ** attempt))

def fake_server(*replies):
    replies = list(replies)
    def call():
        reply = replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return reply
    return call

class FakeSleep:
    pass

def test_retries_then_succeeds():
    pass

def test_404_is_not_retried():
    pass

test_retries_then_succeeds()
test_404_is_not_retried()
print("both tests passed")
''',
                "solution": '''class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

def retry(call, *, attempts=4, sleep):
    for attempt in range(attempts):
        try:
            return call()
        except Exception as error:
            transient = isinstance(error, TimeoutError) or (isinstance(error, HTTPError) and error.status in {429, 500, 502, 503, 504})
            if not transient or attempt == attempts - 1:
                raise
            sleep(min(2.0, 0.1 * 2 ** attempt))

def fake_server(*replies):
    replies = list(replies)
    def call():
        reply = replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return reply
    return call

class FakeSleep:
    def __init__(self):
        self.calls = []

    def __call__(self, seconds):
        self.calls.append(seconds)

def test_retries_then_succeeds():
    sleep = FakeSleep()
    assert retry(fake_server(HTTPError(503), HTTPError(503), "ok"), sleep=sleep) == "ok"
    assert sleep.calls == [0.1, 0.2]

def test_404_is_not_retried():
    sleep = FakeSleep()
    try:
        retry(fake_server(HTTPError(404), "ok"), sleep=sleep)
        raise AssertionError("a 404 should be raised, not retried")
    except HTTPError:
        pass
    assert sleep.calls == []

test_retries_then_succeeds()
test_404_is_not_retried()
print("both tests passed")
''',
                "tests": '''try:
    _fs = FakeSleep()
    _fs(0.1)
    _fs(0.4)
    _fs.calls
except (TypeError, AttributeError):
    raise AssertionError("FakeSleep needs __init__ (setting self.calls = []) and __call__(self, seconds), so an instance can be called like sleep")
assert _fs.calls == [0.1, 0.4], "calling a FakeSleep instance should record each delay in .calls"
test_retries_then_succeeds()
test_404_is_not_retried()
_good = retry
def _catches(test, broken):
    global retry
    retry = broken
    try:
        test()
        return False
    except Exception:
        return True
    finally:
        retry = _good
def _retries_everything(call, *, attempts=4, sleep):
    for attempt in range(attempts):
        try:
            return call()
        except Exception:
            if attempt == attempts - 1:
                raise
            sleep(min(2.0, 0.1 * 2 ** attempt))
def _fixed_delay(call, *, attempts=4, sleep):
    for attempt in range(attempts):
        try:
            return call()
        except HTTPError as error:
            if error.status == 404 or attempt == attempts - 1:
                raise
            sleep(0.5)
def _never_sleeps(call, *, attempts=4, sleep):
    for attempt in range(attempts):
        try:
            return call()
        except HTTPError as error:
            if error.status == 404 or attempt == attempts - 1:
                raise
assert _catches(test_404_is_not_retried, _retries_everything), "test_404_is_not_retried didn't notice a retry that retries 404s: check that HTTPError is raised and that sleep was never called"
assert _catches(test_retries_then_succeeds, _fixed_delay), "test_retries_then_succeeds didn't notice wrong delays: assert sleep.calls == [0.1, 0.2]"
assert _catches(test_retries_then_succeeds, _never_sleeps), "test_retries_then_succeeds didn't notice a retry that never waits: check the recorded delays"''',
            },
        ],
    },
    # ------------------------------------------------------------------ provider injection
    {
        "id": "provider-injection",
        "title": "Provider interfaces and dependency injection",
        "slides": "Q19",
        "idea": "From Day 3 on, BookVault will ask an LLM questions. If `BookClassifier` creates its own OpenAI client inside, every test calls a real, slow, paid API, and switching to Anthropic or a local Ollama model means rewriting the classifier. Instead, describe what any provider must do with an **interface**: an abstract base class (`ABC`, from Day 1) such as `LLMProvider` with one abstract method, `complete_json(prompt) -> dict`.\n\nThen use **dependency injection**: the classifier doesn't create its provider, it **receives** one: `BookClassifier(provider)`. In production you pass a real provider; in tests you pass a **fake provider** that returns a canned answer and records the prompts it was given. Switching to another LLM means writing one new provider class; the classifier and its tests don't change.\n\nNever trust what a model sends back. It may not be valid JSON, may miss a key, may invent a category, or may say `\"confidence\": 7`. **Validate** every reply and turn anything malformed into one clear domain error (`ProviderError`): the provider turns the model's text into a dict; the classifier checks the dict. And give every call a deadline: a provider that doesn't answer in time raises `TimeoutError`, which you handle like any other failure, for example with a safe fallback answer. (Providers are usually called async in a server; the demo is sync because this browser can't run async, and the `local` card shows the async version.)\n\n- An ABC says *what* a provider does; each provider class says *how*\n- Inject the provider through `__init__`; never build it inside the class that uses it\n- Fakes make tests fast, free and repeatable, and record what they were asked\n- Validate replies: valid JSON, a dict, known category, confidence a number from 0 to 1\n- Wrap provider calls: timeouts and bad replies become `ProviderError` or a fallback",
        "code": '''import json
from abc import ABC, abstractmethod

class ProviderError(Exception):
    """The provider failed or gave an answer we can't use."""

class LLMProvider(ABC):
    @abstractmethod
    def complete_json(self, prompt: str) -> dict:
        """Send the prompt; return the model's answer as a dict."""

class FakeLLMProvider(LLMProvider):
    def __init__(self, reply_text):
        self.reply_text = reply_text          # what the "model" will say
        self.prompts = []                     # what it was asked

    def complete_json(self, prompt):
        self.prompts.append(prompt)
        return json.loads(self.reply_text)    # a real model replies with text too

CATEGORIES = {"programming", "fiction", "science"}

def validate(data):
    if not isinstance(data, dict) or data.get("category") not in CATEGORIES:
        raise ProviderError(f"unusable reply: {data}")
    confidence = data.get("confidence")
    if isinstance(confidence, bool) or not isinstance(confidence, (int, float)) or not 0 <= confidence <= 1:
        raise ProviderError(f"bad confidence: {confidence}")
    return {"category": data["category"], "confidence": float(confidence)}

class BookClassifier:
    def __init__(self, provider: LLMProvider):
        self.provider = provider              # injected: never built in here

    def classify(self, title):
        try:
            data = self.provider.complete_json(f"Classify this book: {title}. Reply as JSON.")
        except json.JSONDecodeError as e:
            raise ProviderError("reply is not valid JSON") from e
        return validate(data)

fake = FakeLLMProvider('{"category": "programming", "confidence": 0.95}')
print(BookClassifier(fake).classify("Fluent Python"))
print("asked:", fake.prompts)

for reply in ['{"category": "cooking", "confidence": 0.9}', 'Sure! Here is your JSON: {', '{"category": "fiction", "confidence": 7}']:
    try:
        BookClassifier(FakeLLMProvider(reply)).classify("Dune")
    except ProviderError as e:
        print("rejected:", e)

try:
    LLMProvider()
except TypeError:
    print("LLMProvider is only an interface: it can't be created")
''',
        "walkthrough": [
            ["class ProviderError(Exception):", "One domain error for every way a provider can let us down, so callers need only one `except`."],
            ["class LLMProvider(ABC):", "The interface. Any provider (fake, OpenAI, Anthropic, Ollama) must be a subclass and fill in `complete_json`."],
            ["    @abstractmethod", "Marks the method as required: Python refuses to create a subclass object that doesn't define it."],
            ["class FakeLLMProvider(LLMProvider):", "A fake for tests: no network, no cost, the same answer every time."],
            ["        self.prompts.append(prompt)", "The fake records what it was asked, so a test can check the prompt included the book title."],
            ["        return json.loads(self.reply_text)    # a real model replies with text too", "Models answer with text that should be JSON. Parsing it here means a bad reply raises `JSONDecodeError`, just as it would with a real model."],
            ["    if not isinstance(data, dict) or data.get(\"category\") not in CATEGORIES:", "Validation: the reply must be a dict and the category one we know. `.get` returns `None` for a missing key instead of crashing."],
            ["    if isinstance(confidence, bool) or not isinstance(confidence, (int, float)) or not 0 <= confidence <= 1:", "`True` counts as an int in Python, so reject a `bool` first. `isinstance` with a tuple accepts either type, and the confidence must be a number from 0 to 1."],
            ["        self.provider = provider              # injected: never built in here", "Dependency injection: whoever creates the classifier decides which provider it talks to."],
            ["            raise ProviderError(\"reply is not valid JSON\") from e", "Turn the low-level JSON error into our domain error. `from e` keeps the original error attached, for the traceback."],
            ["print(BookClassifier(fake).classify(\"Fluent Python\"))", "The same classifier code that will later run against a real LLM, tested here with the fake."],
            ["for reply in ['{\"category\": \"cooking\", \"confidence\": 0.9}', 'Sure! Here is your JSON: {', '{\"category\": \"fiction\", \"confidence\": 7}']:", "Three malformed replies a real model might send: an invented category, chatty text that isn't JSON, and an impossible confidence. All three are rejected with a clear message."],
            ["    LLMProvider()", "An ABC with an abstract method can't be created itself: it only describes the contract."],
        ],
        "mistakes": [
            "Creating the real client inside the class (`self.client = OpenAI()` in `__init__`): tests then hit the real API. Pass the provider in.",
            "Trusting the model's reply: always check it is valid JSON, a dict, with the keys and value ranges you expect.",
            "Letting `json.JSONDecodeError` or `KeyError` escape from deep inside: wrap them in one domain error such as `ProviderError`.",
            "Calling a provider without a timeout: one hung request then hangs the whole request handler.",
            "Making the fake too clever: it should return exactly what the test sets up, and record what it was asked.",
        ],
        "local": [
            {
                "title": "The async version with a timeout (Q19)",
                "note": "Save as `classifier.py` and run it, then save the test file next to it and run `pytest -q` (`pip install pytest pytest-asyncio`). Providers are usually called async in a server, so `complete_json` is `async def` and the classifier gives every call a deadline with `asyncio.timeout`.",
                "code": '''# classifier.py
import asyncio
import json
from abc import ABC, abstractmethod

class ProviderError(Exception):
    """The provider failed or gave an answer we can't use."""

class LLMProvider(ABC):
    @abstractmethod
    async def complete_json(self, prompt: str) -> dict: ...

class FakeLLMProvider(LLMProvider):
    def __init__(self, reply: str = '{"category": "programming", "confidence": 0.95}', delay: float = 0.0):
        self.reply = reply
        self.delay = delay
        self.prompts = []

    async def complete_json(self, prompt: str) -> dict:
        self.prompts.append(prompt)
        await asyncio.sleep(self.delay)
        return json.loads(self.reply)

CATEGORIES = {"programming", "fiction", "science"}

class BookClassifier:
    def __init__(self, provider: LLMProvider, timeout: float = 5.0):
        self.provider = provider                 # injected
        self.timeout = timeout

    async def classify(self, title: str) -> dict:
        try:
            async with asyncio.timeout(self.timeout):
                data = await self.provider.complete_json(f"Classify this book: {title}. Reply as JSON.")
        except TimeoutError as e:
            raise ProviderError(f"no answer within {self.timeout}s") from e
        except json.JSONDecodeError as e:
            raise ProviderError("reply is not valid JSON") from e
        if not isinstance(data, dict) or data.get("category") not in CATEGORIES:
            raise ProviderError(f"unusable reply: {data}")
        confidence = data.get("confidence")
        if isinstance(confidence, bool) or not isinstance(confidence, (int, float)) or not 0 <= confidence <= 1:
            raise ProviderError(f"bad confidence: {confidence}")
        return {"category": data["category"], "confidence": float(confidence)}

async def main():
    classifier = BookClassifier(FakeLLMProvider())
    print(await classifier.classify("Fluent Python"))
    slow = BookClassifier(FakeLLMProvider(delay=1), timeout=0.1)
    try:
        await slow.classify("Dune")
    except ProviderError as e:
        print("ProviderError:", e)

if __name__ == "__main__":
    asyncio.run(main())

# test_classifier.py
import pytest
from classifier import BookClassifier, FakeLLMProvider, ProviderError

@pytest.mark.asyncio
async def test_classifies_with_the_fake():
    fake = FakeLLMProvider()
    result = await BookClassifier(fake).classify("Fluent Python")
    assert result == {"category": "programming", "confidence": 0.95}
    assert "Fluent Python" in fake.prompts[0]

@pytest.mark.asyncio
@pytest.mark.parametrize("reply", ["not json",
                                   '{"category": "cooking", "confidence": 0.9}',
                                   '{"category": "fiction", "confidence": 7}'])
async def test_rejects_malformed_replies(reply):
    with pytest.raises(ProviderError):
        await BookClassifier(FakeLLMProvider(reply)).classify("Dune")

@pytest.mark.asyncio
async def test_times_out():
    with pytest.raises(ProviderError, match="no answer"):
        await BookClassifier(FakeLLMProvider(delay=1), timeout=0.05).classify("Dune")''',
                "output": '''$ python classifier.py
{'category': 'programming', 'confidence': 0.95}
ProviderError: no answer within 0.1s

$ pytest -q test_classifier.py
.....                                                                    [100%]
5 passed in 0.20s''',
            },
            {
                "title": "Switching providers: a local Ollama adapter",
                "note": "Moving from the fake to OpenAI, Anthropic or a local Ollama model means adding **one** class like this; `BookClassifier` and its tests stay the same. Each vendor differs in how you call it (an SDK or plain HTTP), how you ask for JSON, its rate limits and its errors, and all of that stays inside the adapter. This one needs `pip install httpx` and Ollama running with the model pulled (`ollama pull llama3.2`); the model's answer will vary.",
                "code": '''# ollama_provider.py  (uses LLMProvider and BookClassifier from classifier.py)
import asyncio
import json

import httpx

from classifier import BookClassifier, LLMProvider

class OllamaProvider(LLMProvider):
    def __init__(self, model: str = "llama3.2", base_url: str = "http://localhost:11434"):
        self.model = model
        self.base_url = base_url

    async def complete_json(self, prompt: str) -> dict:
        async with httpx.AsyncClient(base_url=self.base_url, timeout=30.0) as client:
            r = await client.post("/api/generate", json={
                "model": self.model, "prompt": prompt, "format": "json", "stream": False,
            })
            r.raise_for_status()
            return json.loads(r.json()["response"])   # the model's text, parsed

async def main():
    classifier = BookClassifier(OllamaProvider(), timeout=60)
    print(await classifier.classify("Fluent Python"))

asyncio.run(main())''',
                "output": "{'category': 'programming', 'confidence': 0.9}",
            },
        ],
        "challenge": {
            "task": "Write `BookClassifier` with dependency injection. `__init__(self, provider)` stores the provider it is given in `self.provider` (it must not create one). `classify(self, title)` calls `self.provider.complete_json(...)` with a prompt that contains the title, and returns the reply's `\"category\"`.",
            "hints": [
                "`__init__` is one line: `self.provider = provider`. Don't write `FakeLLMProvider(...)` inside the class.",
                "`data = self.provider.complete_json(f\"Classify this book: {title}\")`, then `return data[\"category\"]`.",
            ],
            "starter": '''from abc import ABC, abstractmethod

class LLMProvider(ABC):
    @abstractmethod
    def complete_json(self, prompt: str) -> dict:
        """Send the prompt; return the model's answer as a dict."""

class FakeLLMProvider(LLMProvider):
    def __init__(self, reply):
        self.reply = reply
        self.prompts = []

    def complete_json(self, prompt):
        self.prompts.append(prompt)
        return self.reply

class BookClassifier:
    def __init__(self, provider):
        self.provider = FakeLLMProvider({"category": "fiction", "confidence": 0.5})

    def classify(self, title):
        return "fiction"

fake = FakeLLMProvider({"category": "programming", "confidence": 0.95})
print(BookClassifier(fake).classify("Fluent Python"), fake.prompts)
''',
            "solution": '''from abc import ABC, abstractmethod

class LLMProvider(ABC):
    @abstractmethod
    def complete_json(self, prompt: str) -> dict:
        """Send the prompt; return the model's answer as a dict."""

class FakeLLMProvider(LLMProvider):
    def __init__(self, reply):
        self.reply = reply
        self.prompts = []

    def complete_json(self, prompt):
        self.prompts.append(prompt)
        return self.reply

class BookClassifier:
    def __init__(self, provider):
        self.provider = provider

    def classify(self, title):
        data = self.provider.complete_json(f"Classify this book: {title}")
        return data["category"]

fake = FakeLLMProvider({"category": "programming", "confidence": 0.95})
print(BookClassifier(fake).classify("Fluent Python"), fake.prompts)
''',
            "tests": '''_sci = FakeLLMProvider({"category": "science", "confidence": 0.8})
_c = BookClassifier(_sci)
assert _c.provider is _sci, "store the provider you are given in self.provider (don't create a new one)"
assert _c.classify("A Brief History of Time") == "science", "classify should return the category from the injected provider's reply"
assert len(_sci.prompts) == 1 and "A Brief History of Time" in _sci.prompts[0], "the prompt sent to the provider should contain the book title"
_prog = FakeLLMProvider({"category": "programming", "confidence": 0.9})
assert BookClassifier(_prog).classify("Fluent Python") == "programming", "a different provider should give a different answer, with no change to BookClassifier"''',
        },
        "practice": [
            {
                "task": "Write the interface and a second provider. `LLMProvider` is an `ABC` with an abstract method `complete_json(self, prompt)`. `KeywordProvider(LLMProvider)` is a tiny rule-based provider: its `complete_json` returns `{\"category\": \"programming\", \"confidence\": 0.6}` if `\"python\"` appears in the prompt (any case), otherwise `{\"category\": \"fiction\", \"confidence\": 0.6}`. The `BookClassifier` below must work with it unchanged.",
                "hints": [
                    "`from abc import ABC, abstractmethod`, then `class LLMProvider(ABC):` with `@abstractmethod` above `def complete_json(self, prompt):` and a docstring or `...` as the body.",
                    "In `KeywordProvider.complete_json`: `if \"python\" in prompt.lower(): return {\"category\": \"programming\", \"confidence\": 0.6}`, otherwise return the fiction dict.",
                ],
                "starter": '''class LLMProvider:
    def complete_json(self, prompt):
        return {"category": "unknown"}

class KeywordProvider(LLMProvider):
    pass

class BookClassifier:
    def __init__(self, provider):
        self.provider = provider

    def classify(self, title):
        return self.provider.complete_json(f"Classify this book: {title}")["category"]

print(BookClassifier(KeywordProvider()).classify("Fluent Python"))
''',
                "solution": '''from abc import ABC, abstractmethod

class LLMProvider(ABC):
    @abstractmethod
    def complete_json(self, prompt):
        """Send the prompt; return the model's answer as a dict."""

class KeywordProvider(LLMProvider):
    def complete_json(self, prompt):
        if "python" in prompt.lower():
            return {"category": "programming", "confidence": 0.6}
        return {"category": "fiction", "confidence": 0.6}

class BookClassifier:
    def __init__(self, provider):
        self.provider = provider

    def classify(self, title):
        return self.provider.complete_json(f"Classify this book: {title}")["category"]

print(BookClassifier(KeywordProvider()).classify("Fluent Python"))
''',
                "tests": '''try:
    LLMProvider()
    raise AssertionError("LLMProvider should be an ABC with an abstract method, so it can't be created")
except TypeError:
    pass
class _Lazy(LLMProvider):
    pass
try:
    _Lazy()
    raise AssertionError("a provider that doesn't define complete_json should be impossible to create: mark it @abstractmethod")
except TypeError:
    pass
assert issubclass(KeywordProvider, LLMProvider), "KeywordProvider should inherit from LLMProvider"
assert KeywordProvider().complete_json("Learning PYTHON") == {"category": "programming", "confidence": 0.6}, "\\"python\\" in any case should give programming"
assert KeywordProvider().complete_json("Pride and Prejudice") == {"category": "fiction", "confidence": 0.6}, "anything else should give fiction"
assert BookClassifier(KeywordProvider()).classify("Dune") == "fiction", "BookClassifier should work with KeywordProvider unchanged"''',
            },
            {
                "task": "Validate model replies. Write `parse_reply(text)`: parse `text` with `json.loads` and return a clean dict `{\"category\": ..., \"confidence\": ...}` (confidence as a float). Raise `ProviderError` when the text isn't valid JSON, isn't a JSON object (dict), has a category not in `CATEGORIES`, or has a confidence that is missing, not a number (a `bool` doesn't count), or outside 0 to 1.",
                "hints": [
                    "Wrap `json.loads(text)` in `try` / `except json.JSONDecodeError` and raise `ProviderError` there. Then check `isinstance(data, dict)` and `data.get(\"category\") in CATEGORIES`.",
                    "For the confidence: `c = data.get(\"confidence\")`, then `if isinstance(c, bool) or not isinstance(c, (int, float)) or not 0 <= c <= 1: raise ProviderError(...)`.",
                ],
                "starter": '''import json

class ProviderError(Exception):
    pass

CATEGORIES = {"programming", "fiction", "science"}

def parse_reply(text):
    return json.loads(text)

print(parse_reply('{"category": "science", "confidence": 1}'))
''',
                "solution": '''import json

class ProviderError(Exception):
    pass

CATEGORIES = {"programming", "fiction", "science"}

def parse_reply(text):
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ProviderError("reply is not valid JSON") from e
    if not isinstance(data, dict):
        raise ProviderError("reply is not a JSON object")
    if data.get("category") not in CATEGORIES:
        raise ProviderError(f"unknown category: {data.get('category')}")
    c = data.get("confidence")
    if isinstance(c, bool) or not isinstance(c, (int, float)) or not 0 <= c <= 1:
        raise ProviderError(f"bad confidence: {c}")
    return {"category": data["category"], "confidence": float(c)}

print(parse_reply('{"category": "science", "confidence": 1}'))
''',
                "tests": '''_ok = parse_reply('{"category": "science", "confidence": 1, "extra": "ignored"}')
assert _ok == {"category": "science", "confidence": 1.0} and isinstance(_ok["confidence"], float), "a good reply should give a clean dict with only category and a float confidence"
_bad = {
    "Sure! {": "text that isn't JSON",
    '["programming", 0.9]': "a JSON list instead of an object",
    '{"confidence": 0.9}': "a missing category",
    '{"category": "cooking", "confidence": 0.9}': "an unknown category",
    '{"category": "fiction"}': "a missing confidence",
    '{"category": "fiction", "confidence": "high"}': "a confidence that is text",
    '{"category": "fiction", "confidence": true}': "a confidence that is true/false",
    '{"category": "fiction", "confidence": 1.5}': "a confidence above 1",
    '{"category": "fiction", "confidence": -0.1}': "a confidence below 0",
}
for _text, _why in _bad.items():
    try:
        parse_reply(_text)
        raise AssertionError(f"parse_reply should raise ProviderError for {_why}: {_text}")
    except ProviderError:
        pass''',
            },
            {
                "task": "Never let a slow or broken provider crash the caller. Write `classify_or_unknown(provider, title)`: call `provider.complete_json(...)` (with the title in the prompt) and return `validate(...)` of the reply. If the call raises `TimeoutError`, or validation raises `ProviderError`, return the fallback `{\"category\": \"unknown\", \"confidence\": 0.0, \"error\": <the error's class name>}` instead.",
                "hints": [
                    "Put both the call and `validate(...)` inside one `try`, and catch the two errors together: `except (TimeoutError, ProviderError) as e:`.",
                    "In the `except`: `return {\"category\": \"unknown\", \"confidence\": 0.0, \"error\": type(e).__name__}`.",
                ],
                "starter": '''class ProviderError(Exception):
    pass

CATEGORIES = {"programming", "fiction", "science"}

def validate(data):
    if not isinstance(data, dict) or data.get("category") not in CATEGORIES:
        raise ProviderError(f"unusable reply: {data}")
    return {"category": data["category"], "confidence": float(data.get("confidence", 0))}

class FakeLLMProvider:
    def __init__(self, reply):
        self.reply = reply
        self.prompts = []

    def complete_json(self, prompt):
        self.prompts.append(prompt)
        return self.reply

class SlowProvider:
    """Like a real provider whose request hit its deadline."""
    def complete_json(self, prompt):
        raise TimeoutError("no answer within 5 s")

def classify_or_unknown(provider, title):
    return validate(provider.complete_json(f"Classify this book: {title}"))

print(classify_or_unknown(FakeLLMProvider({"category": "fiction", "confidence": 0.7}), "Emma"))
''',
                "solution": '''class ProviderError(Exception):
    pass

CATEGORIES = {"programming", "fiction", "science"}

def validate(data):
    if not isinstance(data, dict) or data.get("category") not in CATEGORIES:
        raise ProviderError(f"unusable reply: {data}")
    return {"category": data["category"], "confidence": float(data.get("confidence", 0))}

class FakeLLMProvider:
    def __init__(self, reply):
        self.reply = reply
        self.prompts = []

    def complete_json(self, prompt):
        self.prompts.append(prompt)
        return self.reply

class SlowProvider:
    """Like a real provider whose request hit its deadline."""
    def complete_json(self, prompt):
        raise TimeoutError("no answer within 5 s")

def classify_or_unknown(provider, title):
    try:
        return validate(provider.complete_json(f"Classify this book: {title}"))
    except (TimeoutError, ProviderError) as e:
        return {"category": "unknown", "confidence": 0.0, "error": type(e).__name__}

print(classify_or_unknown(FakeLLMProvider({"category": "fiction", "confidence": 0.7}), "Emma"))
''',
                "tests": '''_f = FakeLLMProvider({"category": "science", "confidence": 0.8})
assert classify_or_unknown(_f, "Cosmos") == {"category": "science", "confidence": 0.8}, "a good reply should be returned validated"
assert "Cosmos" in _f.prompts[0], "the prompt should contain the title"
try:
    _slow = classify_or_unknown(SlowProvider(), "Cosmos")
    _odd = classify_or_unknown(FakeLLMProvider({"category": "cooking"}), "Cosmos")
except (TimeoutError, ProviderError) as _e:
    raise AssertionError(f"a {type(_e).__name__} escaped from classify_or_unknown: catch it and return the unknown fallback")
assert _slow == {"category": "unknown", "confidence": 0.0, "error": "TimeoutError"}, "a timeout should give the unknown fallback with error TimeoutError"
assert _odd == {"category": "unknown", "confidence": 0.0, "error": "ProviderError"}, "a malformed reply should give the unknown fallback with error ProviderError"
class _Broken:
    def complete_json(self, prompt):
        raise ZeroDivisionError("a real bug")
try:
    classify_or_unknown(_Broken(), "Cosmos")
    raise AssertionError("only catch TimeoutError and ProviderError: a real bug should still crash loudly")
except ZeroDivisionError:
    pass''',
            },
        ],
    },
]

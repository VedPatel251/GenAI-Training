"""Day 2 · Forensic Examiner: Academy lessons (first-tests ... import-report).

Same lesson format as lessons.py describes. `part` is set by lessons.py, so leave it out here.
Check with:  python engine/build_game.py --day day2 --no-write

pytest can't run in the browser, so these lessons build a tiny in-page test runner and extend it
lesson by lesson (raises, fixtures, parametrize). Each demo and task is self-contained, so the
runner code is repeated where a task needs it. Real pytest code and output sit on the `local` cards.
Code strings are raw (r'''...''') so "\\n" and "\\t" inside them stay escape sequences.
"""

# ---------------------------------------------------------------- shared snippets for tasks

_MINI = "# ---- mini pytest (a stand-in; real pytest does this for you) ----\n\n"
_START = "# ---- the tests start here ----\n\n"

# The BookVault Book used in the first-tests tasks (Q3 rules: pages positive, title not empty).
_BOOK = r'''from dataclasses import dataclass

class BookVaultError(Exception):
    pass

class ItemUnavailableError(BookVaultError, ValueError):
    pass

@dataclass
class Book:
    title: str
    item_id: str
    author: str
    pages: int
    available: bool = True

    def __post_init__(self):
        if not self.title.strip():
            raise ValueError("title cannot be empty")
        if self.pages <= 0:
            raise ValueError("pages must be positive")

    def borrow(self):
        if not self.available:
            raise ItemUnavailableError(f"{self.item_id} is unavailable")
        self.available = False

    def return_item(self):
        self.available = True

'''

_RAISES = r'''from contextlib import contextmanager

@contextmanager
def raises(error, match=""):
    try:
        yield
    except error as e:
        assert match in str(e), f"{match!r} is not in the message {str(e)!r}"
        return
    raise AssertionError(f"DID NOT RAISE {error.__name__}")

'''

_RUNNER = r'''def run_tests(namespace):
    passed = 0
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"{name} PASSED")
                passed += 1
            except Exception as e:
                print(f"{name} FAILED: {type(e).__name__}: {e}")
                failed += 1
    print(f"===== {passed} passed, {failed} failed =====")

'''

# Test helper: run one of the trainee's test functions with a global name swapped for a buggy
# version. Returns True when the test caught the bug (it raised), False when it still passed.
_CATCHES = r'''def _catches(_test, _name, _fake):
    _real = globals()[_name]
    globals()[_name] = _fake
    try:
        _test()
        return False
    except Exception:
        return True
    finally:
        globals()[_name] = _real

def _passes(_test_name):
    _fn = globals().get(_test_name)
    assert callable(_fn), f"write a test function called {_test_name}"
    try:
        _fn()
    except Exception as _e:
        raise AssertionError(f"{_test_name} should pass on the correct code, but it failed: {type(_e).__name__}: {_e}")

'''

# The mini runner with fixtures (fixtures lesson): inject by parameter name, fresh per test,
# fixtures may ask for other fixtures, and a fixture that yields gets its teardown run afterwards.
_FIX_RUNNER = r'''import inspect

FIXTURES = {}

def fixture(fn):
    FIXTURES[fn.__name__] = fn
    return fn

def call_with_fixtures(fn, made, teardowns):
    kwargs = {}
    for name in inspect.signature(fn).parameters:
        if name not in made:
            value = call_with_fixtures(FIXTURES[name], made, teardowns)
            if inspect.isgenerator(value):
                teardowns.append(value)
                value = next(value)
            made[name] = value
        kwargs[name] = made[name]
    return fn(**kwargs)

def run_tests(namespace):
    passed = 0
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            teardowns = []
            try:
                call_with_fixtures(fn, {}, teardowns)
                result = "PASSED"
                passed += 1
            except Exception as e:
                result = f"FAILED: {type(e).__name__}: {e}"
                failed += 1
            for gen in reversed(teardowns):
                next(gen, None)
            print(name, result)
    print(f"===== {passed} passed, {failed} failed =====")

'''

_LIBRARY = r'''from dataclasses import dataclass

@dataclass
class Book:
    title: str
    item_id: str
    author: str
    pages: int
    available: bool = True

@dataclass
class Member:
    member_id: str
    name: str
    email: str

class Library:
    def __init__(self, name):
        self.name = name
        self.items = {}
        self.members = {}

    def add_item(self, item):
        self.items[item.item_id] = item

    def add_member(self, member):
        self.members[member.member_id] = member

    def borrow(self, item_id, member_id):
        self.items[item_id].available = False

    def __len__(self):
        return len(self.items)

'''

# A correct clean_isbn (the course example strips every non-digit, so "978abc0132350884" passes).
_ISBN = r'''def clean_isbn(raw):
    if not isinstance(raw, str):
        raise ValueError("ISBN must be text")
    cleaned = ""
    for ch in raw:
        if ch not in " -\t\n":
            cleaned += ch
    cleaned = cleaned.upper()
    if len(cleaned) == 13 and cleaned.isdigit():
        return cleaned
    if len(cleaned) == 10 and cleaned[:9].isdigit() and cleaned[9] in "0123456789X":
        return cleaned
    raise ValueError(f"not a valid ISBN: {raw!r}")

'''

_PARAM = r'''def parametrize(argnames, rows):
    def mark(fn):
        if "," in argnames:
            fn.rows = list(rows)
        else:
            fn.rows = [(row,) for row in rows]
        return fn
    return mark

'''

_PARAM_RUNNER = r'''def run_tests(namespace):
    passed = 0
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            for row in getattr(fn, "rows", [()]):
                label = f"{name}{list(row)}" if row else name
                try:
                    fn(*row)
                    print(label, "PASSED")
                    passed += 1
                except Exception as e:
                    print(label, "FAILED:", type(e).__name__, e)
                    failed += 1
    print(f"===== {passed} passed, {failed} failed =====")

'''

_ISBN_TABLES = r'''@parametrize("raw, expected", [
    ("978-0-13-235088-4", "9780132350884"),
    ("0132350882", "0132350882"),
    ("978\t0132350884", "9780132350884"),
    ("0-8044-2957-X", "080442957X"),
])
def test_clean_isbn_valid(raw, expected):
    assert clean_isbn(raw) == expected

@parametrize("bad", ["abc", "12345", "", None, "978abc0132350884"])
def test_clean_isbn_invalid(bad):
    with raises(ValueError):
        clean_isbn(bad)

'''

# Hand-marked coverage for the coverage tasks: each branch of late_fee calls hit(name).
_PROBES = r'''# ---- mini coverage (a stand-in; pytest-cov does this for you) ----

PROBES = ["start", "not-late", "member", "guest", "cap"]
hits = set()

def hit(name):
    hits.add(name)

'''

_FEE_BODY = r'''    hit("start")
    if days <= 0:
        hit("not-late")
        return 0.0
    if member:
        hit("member")
        fee = days * 0.5
    else:
        hit("guest")
        fee = days * 1.0
'''

_LATE_FEE = r'''def late_fee(days, member):
''' + _FEE_BODY + r'''    if fee > 20:
        hit("cap")
        fee = 20.0
    return fee

'''

_SUITE = r'''def run_suite(namespace):
    hits.clear()
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(name, "PASSED")
            except Exception as e:
                print(name, "FAILED:", type(e).__name__, e)
    missing = [p for p in PROBES if p not in hits]
    print("Missing:", ", ".join(missing) or "none")

'''

# Test helper: the trainee's test functions, and a check that one of them catches a buggy late_fee.
_FEE_MUTANTS = r'''_tests = [_f for _n, _f in list(globals().items()) if _n.startswith("test_") and callable(_f)]
def _bad_free(days, member):
    return 1.0 if days <= 0 else _good_fee(days, member)
def _bad_member(days, member):
    return min(days * 1.0, 20.0) if days > 0 else 0.0
def _bad_guest(days, member):
    return _good_fee(days, member) if member else min(days * 0.8, 20.0) if days > 0 else 0.0
def _bad_cap(days, member):
    if days <= 0:
        return 0.0
    return min(days * (0.5 if member else 1.0), 25.0)
def _good_fee(days, member):
    if days <= 0:
        return 0.0
    return min(days * (0.5 if member else 1.0), 20.0)
def _caught(_bad):
    return any(_catches(_t, "late_fee", _bad) for _t in _tests)
'''

# The import pipeline pieces: import-report (assignment Q8) and validate-and-stream (Q14).
_IMPORTS = r'''import io
import json
from dataclasses import dataclass, field

'''

# import-report's small parse_record: JSON plus a type check (full validation comes in validate-and-stream).
_TINY_PARSE = r'''def parse_record(raw):
    data = json.loads(raw)
    if not isinstance(data, dict) or data.get("type") not in ("book", "magazine"):
        raise ValueError("not a book or magazine record")
    return data

'''

_REPORT = r'''class ImportRecordError(Exception):
    def __init__(self, line_no, reason):
        super().__init__(f"line {line_no}: {reason}")
        self.line_no = line_no

@dataclass
class ImportReport:
    items: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    total_lines: int = 0
    skipped: int = 0

    @property
    def loaded_count(self):
        return len(self.items)

    @property
    def error_count(self):
        return len(self.errors)

'''

_IMPORT = r'''def import_catalog(f, strict=False):
    report = ImportReport()
    for line_no, raw in enumerate(f, start=1):
        raw = raw.strip()
        report.total_lines += 1
        if not raw:
            report.skipped += 1
            continue
        try:
            report.items.append(parse_record(raw))
        except ValueError as e:
            if strict:
                raise ImportRecordError(line_no, str(e))
            report.errors.append({"line": line_no, "raw": raw, "error": str(e)})
    return report

'''

_CATALOG_TEXT = r'''TEXT = (
    '{"type": "book", "title": "Clean Code", "item_id": "B001", "author": "Robert Martin", "pages": 464}\n'
    '{"type": "magazine", "title": "National Geographic", "item_id": "MG001", "issue": 247}\n'
    'BAD JSON HERE\n'
    '\n'
    '{"type": "dvd", "title": "Heat", "item_id": "D001"}\n'
    '{"type": "book", "title": "Dune", "item_id": "B002", "author": "Frank Herbert", "pages": 412}\n'
)

'''

_ITEMS = r'''import io
import json
from dataclasses import dataclass

@dataclass
class Book:
    title: str
    item_id: str
    author: str
    pages: int

@dataclass
class Magazine:
    title: str
    item_id: str
    issue: int

KINDS = {"book": Book, "magazine": Magazine}
REQUIRED = {
    "book": ["title", "item_id", "author", "pages"],
    "magazine": ["title", "item_id", "issue"],
}

'''

_PARSE = r'''def parse_record(raw):
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("not a JSON object")
    kind = data.get("type")
    if kind not in KINDS:
        raise ValueError(f"unknown type {kind!r}")
    missing = [name for name in REQUIRED[kind] if name not in data]
    if missing:
        raise ValueError(f"missing {', '.join(missing)}")
    return KINDS[kind](**{name: data[name] for name in REQUIRED[kind]})

'''

_NUMBERED = r'''def numbered_lines(f):
    for line_no, raw in enumerate(f, start=1):
        yield line_no, raw.strip()

'''


LESSONS = [
    # ------------------------------------------------------------------ first tests
    {
        "id": "first-tests",
        "title": "Your first tests",
        "slides": "19-22",
        "idea": "A **test** is a small function that runs your code and checks the result with `assert`. When every test still passes after you change something, you know you didn't break it. That is how teams **refactor without fear**: change `library.py`, run the tests, get a green result in two seconds instead of praying and getting paged at 3 AM. It matters even more for GenAI code: an LLM can answer differently every time, so you can't just eyeball it.\n\n**pytest** is the tool almost every Python project uses. It has two rules: test files are named `test_*.py`, and test functions are named `test_*`. pytest finds (**collects**) those functions, runs each one, prints `PASSED` or `FAILED` for it, then a summary such as `2 passed`. A test **fails** when an `assert` is false or any error escapes from it.\n\npytest can't run in this page, so here you use a tiny **test runner** (about fifteen lines) that does the same job, and a `raises` helper that copies `pytest.raises`. The cards at the bottom show the real pytest code and output.\n\n- name every test `test_something`, and test one behaviour per test\n- plain `assert b.pages == 464`; add `, \"message\"` to explain a failure\n- `with raises(ValueError, match=\"unavailable\"):` passes only if the block raises that error **and** its message contains the text\n- floats: never `==`; use `math.isclose(a, b)` (in pytest: `a == pytest.approx(b)`)",
        "predict": {
            "q": "A file `test_library.py` holds `def test_borrow():`, `def check_return():` and `def test_search():`. How many tests does pytest run?",
            "options": ["1", "2", "3"],
            "answer": 1,
            "why": "Only functions whose names start with `test_` are collected, so `check_return` is ignored. A test you forgot to name `test_...` silently never runs.",
        },
        "code": r'''import math
from contextlib import contextmanager

# ---- the code under test ----

class Book:
    def __init__(self, title, pages):
        self.title = title
        self.pages = pages
        self.available = True

    def borrow(self):
        if not self.available:
            raise ValueError(f"{self.title} is unavailable")
        self.available = False

# ---- mini pytest (a stand-in; real pytest does this for you) ----

@contextmanager
def raises(error, match=""):
    try:
        yield
    except error as e:
        assert match in str(e), f"{match!r} is not in the message {str(e)!r}"
        return
    raise AssertionError(f"DID NOT RAISE {error.__name__}")

def run_tests(namespace):
    passed = 0
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"{name} PASSED")
                passed += 1
            except Exception as e:
                print(f"{name} FAILED: {type(e).__name__}: {e}")
                failed += 1
    print(f"===== {passed} passed, {failed} failed =====")

# ---- the tests start here ----

def test_book_creation():
    b = Book("Clean Code", 464)
    assert b.title == "Clean Code"
    assert b.available is True

def test_double_borrow_raises():
    b = Book("Clean Code", 464)
    b.borrow()
    with raises(ValueError, match="unavailable"):
        b.borrow()

def test_fee_with_floats():
    fee = 3 * 0.1
    assert math.isclose(fee, 0.3), f"fee was {fee}"

def test_page_count():
    b = Book("Refactoring", 448)
    assert b.pages == 500, f"expected 500 pages, got {b.pages}"

run_tests(globals())
''',
        "walkthrough": [
            ["class Book:", "A tiny Book to test. In the real project you would `from bookvault.items import Book`."],
            ["@contextmanager\ndef raises(error, match=\"\"):", "Our copy of `pytest.raises`, built with `@contextmanager` from Day 1. The `with` block runs where the `yield` is."],
            ["    except error as e:", "The block raised the error we expected: good. Now check its message."],
            ["        assert match in str(e), ...", "`match` must appear in the message, so a ValueError for some *other* reason doesn't count. (Real pytest treats `match` as a regular expression searched in the message.)"],
            ["        return", "Returning from the `except` swallows the expected error, so the test carries on and passes."],
            ["    raise AssertionError(f\"DID NOT RAISE {error.__name__}\")", "We only get here if the block raised nothing: that is a failure. pytest prints the same words."],
            ["def run_tests(namespace):", "The runner. `namespace` is a dictionary of every name in the program: we pass `globals()`."],
            ["    for name, fn in list(namespace.items()):", "Go through every name in the program and its value. `list(...)` takes a copy first, so the loop stays safe even if a test creates a new global variable while it runs."],
            ["        if name.startswith(\"test_\") and callable(fn):", "This is pytest's collection rule: only functions whose name starts with `test_`. `callable` skips values like `test_data = 5`."],
            ["                fn()", "Run the test. If it finishes without an error, it passed."],
            ["            except Exception as e:", "Any error means FAILED: a false `assert` raises AssertionError, and a crash raises something else. The runner records it and keeps going to the next test."],
            ["    assert b.available is True", "Plain `assert`: no special methods to remember. Use `is True` / `is None` for those exact values."],
            ["    with raises(ValueError, match=\"unavailable\"):\n        b.borrow()", "The second borrow must raise a ValueError whose message says `unavailable`. If it doesn't, the test fails."],
            ["    assert math.isclose(fee, 0.3), f\"fee was {fee}\"", "`3 * 0.1` is `0.30000000000000004`, so `== 0.3` would fail. `math.isclose` allows a tiny rounding difference (pytest: `fee == pytest.approx(0.3)`)."],
            ["    assert b.pages == 500, f\"expected 500 pages, got {b.pages}\"", "This test is wrong on purpose, to show a FAILED line. The text after the comma becomes the failure message."],
            ["run_tests(globals())", "Collect and run every test in this program. The summary says 3 passed, 1 failed."],
        ],
        "mistakes": [
            "Naming a test `check_borrow` or `borrow_test`: it doesn't start with `test_`, so it never runs and you think it passed.",
            "Putting both borrows inside `with raises(...)`: the first borrow is then not checked, and a bug in it could hide.",
            "Leaving out `match=`: the test passes for any ValueError, even one raised for the wrong reason.",
            "Comparing floats with `==`: use `math.isclose` (or `pytest.approx` in real pytest).",
            "Testing several behaviours in one test: when it fails, the name no longer tells you what broke.",
        ],
        "local": [
            {
                "title": "Run it with real pytest",
                "note": "Install once with `pip install pytest pytest-cov` (or `uv pip install ...`) in your project's virtual environment. Use the flat layout: a `bookvault/` package folder and a `tests/` folder side by side. So that `import bookvault` works with plain `pytest`, add `pythonpath = [\".\"]` under `[tool.pytest.ini_options]` in `pyproject.toml` (or run `python -m pytest`, which adds the project folder for you). Put the test in `tests/test_book.py` and run `pytest -v` from the project folder. `-v` lists every test by name. (Header lines trimmed.)",
                "code": r'''# tests/test_book.py
import pytest
from bookvault.items import Book


def test_book_creation():
    b = Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    assert b.title == "Clean Code"
    assert b.available is True


def test_double_borrow_raises():
    b = Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    b.borrow()
    with pytest.raises(ValueError, match="unavailable"):
        b.borrow()


def test_fee_with_floats():
    assert 3 * 0.1 == pytest.approx(0.3)
''',
                "output": r'''$ pytest -v
============================= test session starts =============================
collected 3 items

tests/test_book.py::test_book_creation PASSED                            [ 33%]
tests/test_book.py::test_double_borrow_raises PASSED                     [ 66%]
tests/test_book.py::test_fee_with_floats PASSED                          [100%]

============================== 3 passed in 0.02s ==============================''',
            },
            {
                "title": "What a failing assert looks like",
                "note": "pytest rewrites plain `assert` so a failure shows the values on both sides. You never need `assertEqual`-style methods. (Header lines trimmed.)",
                "code": r'''# tests/test_book.py
from bookvault.items import Book


def test_page_count():
    b = Book(title="Refactoring", item_id="B002", author="Martin Fowler", pages=448)
    assert b.pages == 500
''',
                "output": r'''$ pytest tests/test_book.py::test_page_count
collected 1 item

tests/test_book.py F                                                     [100%]

================================== FAILURES ===================================
_______________________________ test_page_count _______________________________

    def test_page_count():
        b = Book(title="Refactoring", item_id="B002", author="Martin Fowler", pages=448)
>       assert b.pages == 500
E       AssertionError: assert 448 == 500
E        +  where 448 = Book(title='Refactoring', item_id='B002', author='Martin Fowler', pages=448, available=True).pages

tests/test_book.py:6: AssertionError
=========================== short test summary info ===========================
FAILED tests/test_book.py::test_page_count - AssertionError: assert 448 == 500
============================== 1 failed in 0.05s ==============================''',
            },
        ],
        "challenge": {
            "task": "The editor holds the BookVault `Book`, the `raises` helper and the runner. Write two tests:\n- `test_book_creation`: make `Book(title=\"Clean Code\", item_id=\"B001\", author=\"Robert Martin\", pages=464)` and assert its title is `\"Clean Code\"` and it is available.\n- `test_double_borrow_raises`: borrow the book once, then use `with raises(ValueError, match=\"unavailable\"):` around the second borrow.\n\nThe last line `run_tests(globals())` should print `2 passed, 0 failed`. The checker also runs your tests against broken Books, so they must catch real bugs.",
            "hints": [
                "A test is a plain function with no parameters: `def test_book_creation():`, then make the book and write two `assert` lines.",
                "`b.borrow()` on its own line, then `with raises(ValueError, match=\"unavailable\"):` and, indented under it, `b.borrow()` again.",
            ],
            "starter": _BOOK + _MINI + _RAISES + _RUNNER + _START + r'''# write test_book_creation and test_double_borrow_raises here


run_tests(globals())
''',
            "solution": _BOOK + _MINI + _RAISES + _RUNNER + _START + r'''def test_book_creation():
    b = Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    assert b.title == "Clean Code"
    assert b.available is True

def test_double_borrow_raises():
    b = Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    b.borrow()
    with raises(ValueError, match="unavailable"):
        b.borrow()


run_tests(globals())
''',
            "tests": _CATCHES + r'''_passes("test_book_creation")
_passes("test_double_borrow_raises")
_Good = Book
class _Shouting(_Good):
    def __post_init__(self):
        _Good.__post_init__(self)
        self.title = self.title.upper()
class _OnLoan(_Good):
    def __post_init__(self):
        _Good.__post_init__(self)
        self.available = False
class _BorrowTwice(_Good):
    def borrow(self):
        self.available = False
class _WrongWords(_Good):
    def borrow(self):
        if not self.available:
            raise ValueError("already out")
        self.available = False
assert _catches(test_book_creation, "Book", _Shouting), "test_book_creation should check the title: assert b.title == \"Clean Code\""
assert _catches(test_book_creation, "Book", _OnLoan), "test_book_creation should check that a new book is available: assert b.available is True"
assert _catches(test_double_borrow_raises, "Book", _BorrowTwice), "test_double_borrow_raises should fail when the second borrow raises nothing: wrap it in with raises(ValueError, ...)"
assert _catches(test_double_borrow_raises, "Book", _WrongWords), "test_double_borrow_raises should also check the message: add match=\"unavailable\""
assert "2 passed, 0 failed" in __output__, "keep run_tests(globals()) at the end; it should print 2 passed, 0 failed"''',
        },
        "practice": [
            {
                "task": "Assignment Q3 says a Book's pages must be positive and its title can't be empty. Write:\n- `test_pages_must_be_positive`: making a book with `pages=0` must raise `ValueError` whose message contains `\"positive\"`.\n- `test_title_cannot_be_empty`: making a book with `title=\"\"` must raise `ValueError` whose message contains `\"empty\"`.\n\nUse `with raises(..., match=...)` in both. `run_tests(globals())` should print `2 passed, 0 failed`.",
                "hints": [
                    "This time the line that should raise is the one that *creates* the book, so `Book(...)` goes inside the `with` block.",
                    "`with raises(ValueError, match=\"positive\"):` then, indented, `Book(title=\"Clean Code\", item_id=\"B001\", author=\"Robert Martin\", pages=0)`. Same shape with `title=\"\"` and `match=\"empty\"`.",
                ],
                "starter": _BOOK + _MINI + _RAISES + _RUNNER + _START + r'''# write test_pages_must_be_positive and test_title_cannot_be_empty here


run_tests(globals())
''',
                "solution": _BOOK + _MINI + _RAISES + _RUNNER + _START + r'''def test_pages_must_be_positive():
    with raises(ValueError, match="positive"):
        Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=0)

def test_title_cannot_be_empty():
    with raises(ValueError, match="empty"):
        Book(title="", item_id="B001", author="Robert Martin", pages=464)


run_tests(globals())
''',
                "tests": _CATCHES + r'''_passes("test_pages_must_be_positive")
_passes("test_title_cannot_be_empty")
_Good = Book
class _NoPageCheck(_Good):
    def __post_init__(self):
        if not self.title.strip():
            raise ValueError("title cannot be empty")
class _NoTitleCheck(_Good):
    def __post_init__(self):
        if self.pages <= 0:
            raise ValueError("pages must be positive")
class _Swapped(_Good):
    def __post_init__(self):
        if not self.title.strip():
            raise ValueError("pages must be positive")
        if self.pages <= 0:
            raise ValueError("title cannot be empty")
assert _catches(test_pages_must_be_positive, "Book", _NoPageCheck), "test_pages_must_be_positive should fail when a Book accepts pages=0"
assert _catches(test_title_cannot_be_empty, "Book", _NoTitleCheck), "test_title_cannot_be_empty should fail when a Book accepts an empty title"
assert _catches(test_pages_must_be_positive, "Book", _Swapped) and _catches(test_title_cannot_be_empty, "Book", _Swapped), "check the messages too: match=\"positive\" in one test and match=\"empty\" in the other"
assert "2 passed, 0 failed" in __output__, "keep run_tests(globals()) at the end; it should print 2 passed, 0 failed"''',
            },
            {
                "task": "Build the runner yourself. Finish `run_tests(namespace)`:\n- go through `namespace.items()` and run every value whose name starts with `test_` **and** is callable\n- print `NAME PASSED` when it finishes, or `NAME FAILED: ...` when it raises **any** exception, and keep going\n- at the end print `N passed, M failed` and return the tuple `(passed, failed)`\n\nThe three sample tests should give 2 passed, 1 failed (`helper` and `test_data` are not tests).",
                "hints": [
                    "Loop with `for name, fn in list(namespace.items()):` and skip anything where `not (name.startswith(\"test_\") and callable(fn))`.",
                    "Inside the loop: `try: fn()` then `print(f\"{name} PASSED\")` and `passed += 1`; `except Exception as e: print(f\"{name} FAILED: {e}\")` and `failed += 1`.",
                ],
                "starter": r'''def run_tests(namespace):
    passed = 0
    failed = 0
    # loop over the namespace and run each test function here

    print(f"===== {passed} passed, {failed} failed =====")
    return passed, failed

def test_adds():
    assert 2 + 2 == 4

def test_title_case():
    assert "clean code".title() == "Clean Code"

def test_broken():
    assert 2 + 2 == 5, "maths is broken"

def helper():
    return "not a test"

test_data = [1, 2, 3]

run_tests(globals())
''',
                "solution": r'''def run_tests(namespace):
    passed = 0
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"{name} PASSED")
                passed += 1
            except Exception as e:
                print(f"{name} FAILED: {e}")
                failed += 1
    print(f"===== {passed} passed, {failed} failed =====")
    return passed, failed

def test_adds():
    assert 2 + 2 == 4

def test_title_case():
    assert "clean code".title() == "Clean Code"

def test_broken():
    assert 2 + 2 == 5, "maths is broken"

def helper():
    return "not a test"

test_data = [1, 2, 3]

run_tests(globals())
''',
                "tests": r'''import contextlib, io
def _ok():
    assert True
def _bad():
    assert False, "nope"
def _boom():
    raise KeyError("B999")
_ns = {"test_ok": _ok, "helper": _ok, "test_bad": _bad, "test_data": 5, "test_boom": _boom, "test_ok_again": _ok}
_buf = io.StringIO()
with contextlib.redirect_stdout(_buf):
    _r = run_tests(_ns)
_out = _buf.getvalue()
assert "helper" not in _out, "only run names that start with test_ (helper ran)"
assert _r is not None and tuple(_r) == (2, 2), f"for 2 passing and 2 failing tests run_tests should return (2, 2), got {_r}. Are you skipping values that aren't callable, like test_data = 5?"
assert "test_ok PASSED" in _out and "test_ok_again PASSED" in _out, "print NAME PASSED for each passing test"
assert "test_bad FAILED" in _out, "print NAME FAILED for a test whose assert is false"
assert "test_boom FAILED" in _out, "a test that raises any error (here a KeyError) is FAILED too, and the runner keeps going"
assert "2 passed, 2 failed" in _out, "finish with a summary line like 2 passed, 2 failed"''',
            },
            {
                "task": "Three more Q3 tests. Write:\n- `test_return_makes_available`: borrow a book, call `return_item()`, assert it is available again.\n- `test_repr_shows_class_and_id`: assert that `\"Book\"` and `\"B001\"` both appear in `repr(book)`.\n- `test_late_fee`: `late_fee(3)` should be 0.3. Try `==` first and watch it fail, then use `math.isclose`.\n\n`run_tests(globals())` should print `3 passed, 0 failed`.",
                "hints": [
                    "`repr(b)` of a dataclass looks like `Book(title='Clean Code', item_id='B001', ...)`, so `assert \"B001\" in repr(b)` works.",
                    "`assert math.isclose(late_fee(3), 0.3)`: the real value is `0.30000000000000004`, so `==` fails.",
                ],
                "starter": "import math\n" + _BOOK + _MINI + _RUNNER + _START + r'''def late_fee(days_late):
    return days_late * 0.1

# write the three tests here


run_tests(globals())
''',
                "solution": "import math\n" + _BOOK + _MINI + _RUNNER + _START + r'''def late_fee(days_late):
    return days_late * 0.1

def test_return_makes_available():
    b = Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    b.borrow()
    b.return_item()
    assert b.available is True

def test_repr_shows_class_and_id():
    b = Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    assert "Book" in repr(b)
    assert "B001" in repr(b)

def test_late_fee():
    assert math.isclose(late_fee(3), 0.3)


run_tests(globals())
''',
                "tests": _CATCHES + r'''_passes("test_return_makes_available")
_passes("test_repr_shows_class_and_id")
_passes("test_late_fee")
_Good = Book
class _NoReturn(_Good):
    def return_item(self):
        pass
class _Vague(_Good):
    def __repr__(self):
        return f"<{self.title}>"
class _NoId(_Good):
    def __repr__(self):
        return f"Book({self.title!r})"
def _double_fee(days_late):
    return days_late * 0.2
assert _catches(test_return_makes_available, "Book", _NoReturn), "test_return_makes_available should fail when return_item does nothing: borrow, return, then assert available"
assert _catches(test_repr_shows_class_and_id, "Book", _Vague), "test_repr_shows_class_and_id should check that \"Book\" is in repr(b)"
assert _catches(test_repr_shows_class_and_id, "Book", _NoId), "test_repr_shows_class_and_id should check that \"B001\" is in repr(b)"
assert _catches(test_late_fee, "late_fee", _double_fee), "test_late_fee should fail when late_fee charges 0.2 a day"
assert "isclose" in __source__, "compare the float fee with math.isclose"
assert "3 passed, 0 failed" in __output__, "keep run_tests(globals()) at the end; it should print 3 passed, 0 failed"''',
            },
        ],
    },
    # ------------------------------------------------------------------ fixtures
    {
        "id": "fixtures",
        "title": "Fixtures: setup you write once",
        "slides": "23-24",
        "idea": "A **fixture** is a function that builds what a test needs, such as an empty library, a stocked library or a member, so you write that setup once instead of copying it into every test. In pytest you mark it with `@pytest.fixture`, and a test asks for it just by naming it as a **parameter**: `def test_len(empty_library):`. pytest sees the name, calls the fixture, and passes in what it returned. This is called **injection**.\n\nEvery test gets a **fresh** result: the fixture runs again for each test, so one test's borrowing can't leak into the next. A fixture can ask for other fixtures the same way: `def stocked_library(empty_library):`. If a fixture uses `yield` instead of `return`, the code after `yield` is the **teardown**: it runs after the test, even when the test failed (close the connection, delete the temporary file).\n\nThe mini runner below does all of this with `inspect.signature(fn).parameters`, which lists a function's parameter names. Real pytest adds three things you'll use (see the cards): **`conftest.py`**, a file whose fixtures every test in the folder can use without importing them; a fixture's **scope**: `\"function\"` (the default: every test), `\"class\"`, `\"module\"` (once per file) or `\"session\"` (once per whole run); and built-in fixtures such as **`tmp_path`** (a new empty folder for each test) and **`capsys`** (captures what the code printed).\n\n- the parameter name must match the fixture name exactly\n- `return` for plain setup; `yield` when something must be cleaned up afterwards\n- keep the default function scope for anything a test changes; share (`module`, `session`) only slow, read-only things",
        "predict": {
            "q": "`tests/test_library.py` has `def test_len(stocked_library):` but never imports `stocked_library`. Where does pytest find it?",
            "options": ["It can't: the test fails with a NameError", "In `tests/conftest.py`, which pytest loads by itself", "In any file of the project that defines a function with that name"],
            "answer": 1,
            "why": "pytest automatically loads every `conftest.py` in the test folder (and the folders above it), and its fixtures are available to all those tests without any import. Fixtures elsewhere must be in the test file itself.",
        },
        "code": _MINI + _FIX_RUNNER + r'''# ---- the code under test ----

class Library:
    def __init__(self, name):
        self.name = name
        self.items = []

    def add_item(self, title):
        self.items.append(title)

# ---- the tests start here ----

@fixture
def empty_library():
    return Library("Test Vault")

@fixture
def stocked_library(empty_library):
    empty_library.add_item("Clean Code")
    return empty_library

@fixture
def connection():
    print("  [setup] open connection")
    yield {"open": True}
    print("  [teardown] close connection")

def test_empty(empty_library):
    assert len(empty_library.items) == 0

def test_add_one_more(stocked_library):
    stocked_library.add_item("Refactoring")
    assert len(stocked_library.items) == 2

def test_still_fresh(stocked_library):
    assert len(stocked_library.items) == 1

def test_connection(connection):
    assert connection["open"] is True

run_tests(globals())
''',
        "walkthrough": [
            ["FIXTURES = {}", "The runner's list of fixtures, by name. pytest keeps the same kind of list."],
            ["def fixture(fn):\n    FIXTURES[fn.__name__] = fn\n    return fn", "Our `@fixture` decorator (like `@pytest.fixture`): it records the function under its own name and gives it back unchanged."],
            ["    for name in inspect.signature(fn).parameters:", "`inspect.signature(fn).parameters` gives the names of a function's parameters, e.g. `['stocked_library']`. This is how a test \"asks\" for a fixture."],
            ["            value = call_with_fixtures(FIXTURES[name], made, teardowns)", "Call the fixture with that name. It may have parameters of its own, so the same function fills those first (`stocked_library` needs `empty_library`)."],
            ["            if inspect.isgenerator(value):", "A fixture that uses `yield` gives back a generator instead of a value."],
            ["                teardowns.append(value)\n                value = next(value)", "`next` runs the fixture up to its `yield` (the setup) and hands over the yielded value. The paused generator is kept so the rest can run later."],
            ["            made[name] = value", "`made` remembers fixtures already built for **this** test, so if two things ask for `empty_library` they get the same one."],
            ["    return fn(**kwargs)", "Call the test (or fixture) with every fixture passed in by name, like `test_still_fresh(stocked_library=...)`."],
            ["                call_with_fixtures(fn, {}, teardowns)", "Each test starts with an empty `made`: nothing carries over, so every test gets fresh fixtures."],
            ["            for gen in reversed(teardowns):\n                next(gen, None)", "After the test, pass or fail, resume each yield fixture so the code after `yield` (the teardown) runs. `next(gen, None)` returns `None` instead of raising when the generator ends. Last set up, first torn down."],
            ["def stocked_library(empty_library):", "A fixture that uses another fixture, just by naming it."],
            ["    yield {\"open\": True}", "Setup above the `yield`, teardown below it. The test receives the yielded dictionary."],
            ["def test_still_fresh(stocked_library):\n    assert len(stocked_library.items) == 1", "The test before added \"Refactoring\", but this one still sees one item: its library was built from scratch."],
        ],
        "mistakes": [
            "Misspelling the parameter (`empty_libary`): pytest reports the test as an ERROR (`fixture 'empty_libary' not found`); our runner shows it as FAILED with a KeyError.",
            "Calling the fixture yourself inside a test (`empty_library()`): just name it as a parameter and let the runner pass it in.",
            "Keeping test data in a global variable that every test changes: tests then pass or fail depending on their order. Build it inside a fixture.",
            "Using `return` in a fixture that must clean up: nothing runs after `return`. Use `yield` and put the cleanup after it.",
            "Giving a fixture that tests change a `session` or `module` scope: the changes leak into later tests.",
        ],
        "local": [
            {
                "title": "Fixtures in conftest.py (assignment Q5)",
                "note": "pytest finds `tests/conftest.py` by itself; every test file in `tests/` can use its fixtures without an import. This assumes your `Library` keeps its items in a dict called `items`, like the one in the lesson. Run `pytest -v tests/test_library.py`.",
                "code": r'''# tests/conftest.py
import pytest
from bookvault.items import Book
from bookvault.library import Library
from bookvault.members import Member


@pytest.fixture
def empty_library():
    return Library("Test Vault")


@pytest.fixture
def clean_code():
    return Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)


@pytest.fixture
def member():
    return Member(member_id="M001", name="Asha", email="asha@example.com")


@pytest.fixture
def stocked_library(empty_library, clean_code, member):
    empty_library.add_item(clean_code)
    empty_library.add_member(member)
    return empty_library


# tests/test_library.py
def test_empty_library_len(empty_library):
    assert len(empty_library) == 0


def test_stocked_library_len(stocked_library):
    assert len(stocked_library) == 1


def test_borrow_does_not_leak(stocked_library):
    stocked_library.borrow("B001", "M001")
    assert stocked_library.items["B001"].available is False


def test_next_test_is_fresh(stocked_library):
    assert stocked_library.items["B001"].available is True
''',
                "output": r'''$ pytest -v tests/test_library.py
collected 4 items

tests/test_library.py::test_empty_library_len PASSED                     [ 25%]
tests/test_library.py::test_stocked_library_len PASSED                   [ 50%]
tests/test_library.py::test_borrow_does_not_leak PASSED                  [ 75%]
tests/test_library.py::test_next_test_is_fresh PASSED                    [100%]

============================== 4 passed in 0.03s ==============================''',
            },
            {
                "title": "Scopes and yield teardown",
                "note": "`-s` shows print output. The session fixture opens once for the whole run; the function-scoped one runs for every test.",
                "code": r'''# tests/test_scopes.py
import pytest


@pytest.fixture(scope="session")
def catalog_db():
    print("\n[open db]")
    db = {"B001": "Clean Code"}
    yield db
    print("\n[close db]")


@pytest.fixture             # scope="function" is the default
def cart():
    return []


def test_one(catalog_db, cart):
    cart.append("B001")
    assert catalog_db["B001"] == "Clean Code"


def test_two(catalog_db, cart):
    assert cart == []       # a fresh cart: test_one's append is gone
''',
                "output": r'''$ pytest -s -v tests/test_scopes.py
collected 2 items

tests/test_scopes.py::test_one
[open db]
PASSED                                                                   [ 50%]
tests/test_scopes.py::test_two PASSED                                    [100%]
[close db]


============================== 2 passed in 0.01s ==============================''',
            },
            {
                "title": "Built-in fixtures: tmp_path and capsys",
                "note": "`tmp_path` is a `pathlib.Path` to a new empty folder for each test, so tests never depend on files on your machine. `capsys.readouterr().out` returns everything printed so far. Both are used in assignment Q8 and Q9.",
                "code": r'''# tests/test_cli.py
import json
from bookvault.cli import main


def test_list_prints_titles(tmp_path, capsys):
    data = tmp_path / "books.jsonl"
    record = {"type": "book", "title": "Clean Code", "item_id": "B001",
              "author": "Robert Martin", "pages": 464}
    data.write_text(json.dumps(record) + "\n", encoding="utf-8")

    main(["--data", str(data), "list"])          # call the CLI function directly

    out = capsys.readouterr().out
    assert "Clean Code" in out
''',
                "output": r'''$ pytest -v tests/test_cli.py
collected 1 item

tests/test_cli.py::test_list_prints_titles PASSED                        [100%]

============================== 1 passed in 0.02s ==============================''',
            },
        ],
        "challenge": {
            "task": "Assignment Q5 in the mini runner. Below the classes, write four fixtures, each with `@fixture` above it:\n- `empty_library`: returns `Library(\"Test Vault\")`\n- `clean_code`: returns `Book(title=\"Clean Code\", item_id=\"B001\", author=\"Robert Martin\", pages=464)`\n- `member`: returns `Member(member_id=\"M001\", name=\"Asha\", email=\"asha@example.com\")`\n- `stocked_library(empty_library, clean_code, member)`: adds the book and the member to the library and returns it\n\nThe three tests are already written. `run_tests(globals())` should print `3 passed, 0 failed`.",
            "hints": [
                "Each fixture is a normal function with `@fixture` on the line above. `stocked_library` lists the other three as its parameters.",
                "Inside `stocked_library`: `empty_library.add_item(clean_code)`, `empty_library.add_member(member)`, then `return empty_library`.",
            ],
            "starter": _LIBRARY + _MINI + _FIX_RUNNER + _START + r'''# write the four fixtures here


def test_empty_library_len(empty_library):
    assert len(empty_library) == 0

def test_stocked_library_len(stocked_library):
    assert len(stocked_library) == 1

def test_stocked_has_member(stocked_library, member):
    assert member.member_id in stocked_library.members

run_tests(globals())
''',
            "solution": _LIBRARY + _MINI + _FIX_RUNNER + _START + r'''@fixture
def empty_library():
    return Library("Test Vault")

@fixture
def clean_code():
    return Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)

@fixture
def member():
    return Member(member_id="M001", name="Asha", email="asha@example.com")

@fixture
def stocked_library(empty_library, clean_code, member):
    empty_library.add_item(clean_code)
    empty_library.add_member(member)
    return empty_library


def test_empty_library_len(empty_library):
    assert len(empty_library) == 0

def test_stocked_library_len(stocked_library):
    assert len(stocked_library) == 1

def test_stocked_has_member(stocked_library, member):
    assert member.member_id in stocked_library.members

run_tests(globals())
''',
            "tests": r'''for _n in ("empty_library", "clean_code", "member", "stocked_library"):
    assert _n in FIXTURES, f"add a fixture called {_n}, with @fixture on the line above it"
_e = FIXTURES["empty_library"]()
assert isinstance(_e, Library) and len(_e) == 0 and _e.name == "Test Vault", 'empty_library should return Library("Test Vault")'
_b = FIXTURES["clean_code"]()
assert isinstance(_b, Book) and _b.item_id == "B001" and _b.title == "Clean Code" and _b.pages == 464, "clean_code should return the Clean Code book (B001, 464 pages)"
_m = FIXTURES["member"]()
assert isinstance(_m, Member) and _m.member_id == "M001" and _m.name == "Asha", "member should return Member M001, Asha"
_p = sorted(inspect.signature(FIXTURES["stocked_library"]).parameters)
assert _p == ["clean_code", "empty_library", "member"], f"stocked_library should ask for empty_library, clean_code and member as parameters, not {_p}"
_lib = call_with_fixtures(FIXTURES["stocked_library"], {}, [])
assert isinstance(_lib, Library) and len(_lib) == 1 and "B001" in _lib.items, "stocked_library should add the book and return the library"
assert "M001" in _lib.members, "stocked_library should add the member too"
assert "3 passed, 0 failed" in __output__, "keep run_tests(globals()) at the end; it should print 3 passed, 0 failed"''',
        },
        "practice": [
            {
                "task": "Two tests pass on their own but fail together: the `stocked_library` fixture hands every test the **same** global `SHARED` library, so the first test's borrow leaks into the second. Rewrite `stocked_library` so it builds a new `Library(\"Test Vault\")` and a new Clean Code book every time it runs, and delete `SHARED`. `run_tests(globals())` should print `2 passed, 0 failed`.",
                "hints": [
                    "Move the two `SHARED` lines inside the fixture, using a local variable such as `lib` instead of `SHARED`.",
                    "`lib = Library(\"Test Vault\")`, `lib.add_item(Book(title=\"Clean Code\", item_id=\"B001\", author=\"Robert Martin\", pages=464))`, `return lib`.",
                ],
                "starter": _LIBRARY + _MINI + _FIX_RUNNER + _START + r'''SHARED = Library("Test Vault")
SHARED.add_item(Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464))

@fixture
def stocked_library():
    return SHARED


def test_borrow_marks_book_out(stocked_library):
    stocked_library.borrow("B001", "M001")
    assert stocked_library.items["B001"].available is False

def test_book_starts_available(stocked_library):
    assert stocked_library.items["B001"].available is True

run_tests(globals())
''',
                "solution": _LIBRARY + _MINI + _FIX_RUNNER + _START + r'''@fixture
def stocked_library():
    lib = Library("Test Vault")
    lib.add_item(Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464))
    return lib


def test_borrow_marks_book_out(stocked_library):
    stocked_library.borrow("B001", "M001")
    assert stocked_library.items["B001"].available is False

def test_book_starts_available(stocked_library):
    assert stocked_library.items["B001"].available is True

run_tests(globals())
''',
                "tests": r'''_a = FIXTURES["stocked_library"]()
_b = FIXTURES["stocked_library"]()
assert _a is not _b, "stocked_library still returns the same library every time: build a new Library inside the fixture"
assert len(_a) == 1 and "B001" in _a.items, "the library should hold the Clean Code book (B001)"
_a.borrow("B001", "M001")
assert _b.items["B001"].available is True, "both libraries share one Book object: create the Book inside the fixture too"
assert "2 passed, 0 failed" in __output__, "both tests should pass: run_tests(globals()) should print 2 passed, 0 failed"''',
            },
            {
                "task": "Build your own version of pytest's `capsys`. Write a fixture called `output` that:\n- makes `buf = io.StringIO()`\n- inside `with contextlib.redirect_stdout(buf):` does `yield buf`\n\nWhile the test runs, everything printed goes into `buf`; leaving the `with` after the yield is the teardown that puts printing back to normal. `test_welcome` is written for you. `run_tests(globals())` should print `1 passed, 0 failed`.",
                "hints": [
                    "It's a generator fixture: `@fixture`, then `def output():`, then the two lines from the task. Use `yield`, not `return`.",
                    "`buf = io.StringIO()` then `with contextlib.redirect_stdout(buf):` and, indented under it, `yield buf`.",
                ],
                "starter": "import contextlib\nimport io\n\n" + _MINI + _FIX_RUNNER + _START + r'''def welcome(name):
    print(f"Welcome, {name}!")

# write the output fixture here


def test_welcome(output):
    welcome("Asha")
    assert output.getvalue() == "Welcome, Asha!\n"

run_tests(globals())
''',
                "solution": "import contextlib\nimport io\n\n" + _MINI + _FIX_RUNNER + _START + r'''def welcome(name):
    print(f"Welcome, {name}!")

@fixture
def output():
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        yield buf


def test_welcome(output):
    welcome("Asha")
    assert output.getvalue() == "Welcome, Asha!\n"

run_tests(globals())
''',
                "tests": r'''import sys
assert "output" in FIXTURES, "add a fixture called output, with @fixture on the line above it"
_g = FIXTURES["output"]()
assert inspect.isgenerator(_g), "output should use yield (not return), so it can clean up after the test"
_buf = next(_g)
print("hello")
_during = _buf.getvalue()
next(_g, None)
assert _during == "hello\n", "while the test runs, print should write into the StringIO you yield (use contextlib.redirect_stdout(buf))"
assert sys.stdout is not _buf, "after the test, printing should go back to normal: yield inside the with block"
assert "1 passed, 0 failed" in __output__, "run_tests(globals()) should print 1 passed, 0 failed"''',
            },
            {
                "task": "Scopes. This runner supports `scope=\"session\"`: a fixture whose name is in the set `SESSION` runs once and is then shared by every test. Right now `SESSION` holds the wrong fixture: `cart` (tests change it) is shared, so the cart tests fail, and `catalog` (slow to load, never changed) loads three times.\n\nChange the `SESSION = ...` line so the catalog loads **once** and all three tests pass.",
                "hints": [
                    "Share only what no test changes. `cart` gets `append` calls, so it must stay fresh per test (function scope).",
                    "`SESSION = {\"catalog\"}`",
                ],
                "starter": _MINI + r'''import inspect

FIXTURES = {}
SESSION = {"cart"}       # names of fixtures with scope="session"
session_cache = {}

def fixture(fn):
    FIXTURES[fn.__name__] = fn
    return fn

def call_with_fixtures(fn, made):
    kwargs = {}
    for name in inspect.signature(fn).parameters:
        if name in SESSION and name in session_cache:
            made[name] = session_cache[name]
        if name not in made:
            made[name] = call_with_fixtures(FIXTURES[name], made)
            if name in SESSION:
                session_cache[name] = made[name]
        kwargs[name] = made[name]
    return fn(**kwargs)

def run_tests(namespace):
    passed = 0
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            try:
                call_with_fixtures(fn, {})
                print(name, "PASSED")
                passed += 1
            except Exception as e:
                print(name, "FAILED:", type(e).__name__, e)
                failed += 1
    print(f"===== {passed} passed, {failed} failed =====")

''' + _START + r'''@fixture
def catalog():
    print("loading catalog (slow)")
    return {"B001": "Clean Code", "B002": "Refactoring"}

@fixture
def cart():
    return []

def test_add_to_cart(catalog, cart):
    cart.append("B001")
    assert cart == ["B001"]

def test_cart_starts_empty(catalog, cart):
    assert cart == []

def test_catalog_has_titles(catalog):
    assert catalog["B002"] == "Refactoring"

run_tests(globals())
''',
                "solution": _MINI + r'''import inspect

FIXTURES = {}
SESSION = {"catalog"}      # names of fixtures with scope="session"
session_cache = {}

def fixture(fn):
    FIXTURES[fn.__name__] = fn
    return fn

def call_with_fixtures(fn, made):
    kwargs = {}
    for name in inspect.signature(fn).parameters:
        if name in SESSION and name in session_cache:
            made[name] = session_cache[name]
        if name not in made:
            made[name] = call_with_fixtures(FIXTURES[name], made)
            if name in SESSION:
                session_cache[name] = made[name]
        kwargs[name] = made[name]
    return fn(**kwargs)

def run_tests(namespace):
    passed = 0
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            try:
                call_with_fixtures(fn, {})
                print(name, "PASSED")
                passed += 1
            except Exception as e:
                print(name, "FAILED:", type(e).__name__, e)
                failed += 1
    print(f"===== {passed} passed, {failed} failed =====")

''' + _START + r'''@fixture
def catalog():
    print("loading catalog (slow)")
    return {"B001": "Clean Code", "B002": "Refactoring"}

@fixture
def cart():
    return []

def test_add_to_cart(catalog, cart):
    cart.append("B001")
    assert cart == ["B001"]

def test_cart_starts_empty(catalog, cart):
    assert cart == []

def test_catalog_has_titles(catalog):
    assert catalog["B002"] == "Refactoring"

run_tests(globals())
''',
                "tests": r'''assert SESSION == {"catalog"}, f"SESSION should hold only the read-only, slow fixture, catalog; it holds {SESSION}"
assert __output__.count("loading catalog") == 1, "with catalog shared for the whole session it should load once"
assert "3 passed, 0 failed" in __output__, "all three tests should pass: the cart must be fresh for every test"''',
            },
        ],
    },
    # ------------------------------------------------------------------ parametrize
    {
        "id": "parametrize",
        "title": "Parametrize: one test, many cases",
        "slides": "25",
        "idea": "Often you want to run the **same check** on many inputs: ten ISBNs that must clean correctly, five that must be rejected. Instead of ten copies of one test, write the test once and give it a **table** of inputs. That is **table-driven testing**. In pytest it is `@pytest.mark.parametrize(...)`; in this page our copy is `@parametrize(...)`.\n\nThe decorator takes the parameter names as one string and a list of rows: `@parametrize(\"raw, expected\", [(\"978-0132350884\", \"9780132350884\"), ...])`. The runner calls the test once **per row**, filling `raw` and `expected` from that row, and reports each row as its own test, so you see exactly which input failed. Found a new edge case? Add one line to the table. With a single name, such as `\"bad\"`, each row is just the value: `[\"abc\", \"12345\", None]`.\n\nA good table has two halves: **valid** inputs with the expected result, and **invalid** inputs that must raise. The invalid half is where forgeries are caught: the course's example `clean_isbn` deletes every character that isn't a digit, so `\"978abc0132350884\"` comes out as a valid-looking ISBN. One row in the invalid table exposes it.\n\n- names in one string, separated by commas: `\"raw, expected\"`\n- each row is a tuple with one value per name; with one name, list the values directly\n- every row is reported separately: one bad row doesn't hide the others\n- test valid **and** invalid inputs; edge cases (empty text, `None`, tabs, letters) are where bugs live",
        "predict": {
            "q": "With our copy, what does `parametrize(\"x\", [1])` return, before any `@` is applied?",
            "options": ["A test result", "The function `mark`, which is then used as the decorator", "The list `[(1,)]`"],
            "answer": 1,
            "why": "`parametrize(...)` only builds and returns `mark`. Python then applies `mark` to the function below the `@` line, and `mark` stores the rows on it.",
        },
        "code": _ISBN + _MINI + _RAISES + _PARAM + _PARAM_RUNNER + _START + _ISBN_TABLES + r'''run_tests(globals())
''',
        "walkthrough": [
            ["        if ch not in \" -\\t\\n\":", "A correct `clean_isbn` removes only spaces, hyphens, tabs (`\\t`) and newlines (`\\n`). Anything else stays, so letters make the ISBN invalid instead of disappearing."],
            ["    if len(cleaned) == 10 and cleaned[:9].isdigit() and cleaned[9] in \"0123456789X\":", "An ISBN-10 may end in `X` (it stands for 10). The course example dropped the `X`; this one keeps it."],
            ["def parametrize(argnames, rows):", "Our copy of `@pytest.mark.parametrize`. `@parametrize(\"a, b\", rows)` first *calls* `parametrize`, which returns `mark`; `mark` is the real decorator Python applies to the test. So the brackets are right here, unlike `@timed` on Day 1, where `@timed()` was a mistake."],
            ["    def mark(fn):", "The real decorator: it receives the test function. It can still use `argnames` and `rows`, because it was made inside `parametrize`."],
            ["            fn.rows = list(rows)", "Functions are objects, so you can attach your own attribute to one. The runner looks for `rows` later."],
            ["            fn.rows = [(row,) for row in rows]", "With only one name, each row is a plain value; wrapping it in a one-item tuple `(row,)` lets the runner treat every table the same way."],
            ["        return fn\n    return mark", "`mark` hands back the same test function, now carrying its table. `parametrize` returns `mark`, which is what the `@` line then applies."],
            ["            for row in getattr(fn, \"rows\", [()]):", "`getattr` with a default: a test without a table gets one empty row, so it runs once with no arguments."],
            ["                label = f\"{name}{list(row)}\" if row else name", "Each row gets its own label with its values, so you know which input failed. Ours shows the values as a list; pytest joins them with `-`: `test_clean_isbn_valid[0132350882-0132350882]`."],
            ["                    fn(*row)", "`*row` spreads the tuple into arguments: `(\"0132350882\", \"0132350882\")` becomes `fn(\"0132350882\", \"0132350882\")`."],
            ["@parametrize(\"raw, expected\", [", "Two names, so each row is a pair: the messy input and the clean result."],
            ["    (\"978\\t0132350884\", \"9780132350884\"),", "The row that proves a tab is cleaned (assignment Q4 asks for one)."],
            ["@parametrize(\"bad\", [\"abc\", \"12345\", \"\", None, \"978abc0132350884\"])", "One name, so the values are listed directly. Each must make `clean_isbn` raise ValueError."],
        ],
        "mistakes": [
            "A typo in the names string: each name must match a test parameter exactly.",
            "Giving a two-name table rows with one value, or the other way round: every row needs exactly one value per name.",
            "Only testing valid inputs: the invalid half (empty, `None`, letters, wrong length) is what catches forged checks.",
            "Copying the same test five times instead of adding rows: the next edge case then needs a sixth copy.",
            "Putting a loop with several asserts inside one test: the first failure stops the loop and hides the other rows. Parametrize reports each row.",
        ],
        "local": [
            {
                "title": "The same tables with real pytest (assignment Q4)",
                "note": "Put `clean_isbn` in `bookvault/utils.py` and the tests in `tests/test_utils.py`. pytest builds each row's id from its values. (Percent column trimmed.)",
                "code": r'''# tests/test_utils.py
import pytest
from bookvault.utils import clean_isbn


@pytest.mark.parametrize("raw, expected", [
    ("978-0-13-235088-4", "9780132350884"),
    ("0132350882", "0132350882"),
    ("  978 0132350884  ", "9780132350884"),
    ("978\t0132350884", "9780132350884"),
])
def test_clean_isbn_valid(raw, expected):
    assert clean_isbn(raw) == expected


@pytest.mark.parametrize("bad", ["abc", "12345", "", None, "978abc0132350884"])
def test_clean_isbn_invalid(bad):
    with pytest.raises(ValueError):
        clean_isbn(bad)
''',
                "output": r'''$ pytest -v tests/test_utils.py
collected 9 items

tests/test_utils.py::test_clean_isbn_valid[978-0-13-235088-4-9780132350884] PASSED
tests/test_utils.py::test_clean_isbn_valid[0132350882-0132350882] PASSED
tests/test_utils.py::test_clean_isbn_valid[  978 0132350884  -9780132350884] PASSED
tests/test_utils.py::test_clean_isbn_valid[978\t0132350884-9780132350884] PASSED
tests/test_utils.py::test_clean_isbn_invalid[abc] PASSED
tests/test_utils.py::test_clean_isbn_invalid[12345] PASSED
tests/test_utils.py::test_clean_isbn_invalid[] PASSED
tests/test_utils.py::test_clean_isbn_invalid[None] PASSED
tests/test_utils.py::test_clean_isbn_invalid[978abc0132350884] PASSED

============================== 9 passed in 0.04s ==============================''',
            },
            {
                "title": "From this page to a real pytest file",
                "note": "Everything in the mini pytest has a real pytest twin. To turn a page exercise into a real test file: add `import pytest`, swap each stand-in for its real name, move shared fixtures into `tests/conftest.py`, delete the mini pytest code and the `run_tests(globals())` line, and run `pytest -v`.",
                "code": r'''# In this page                         ->  In a real test file
# (mini pytest code at the top)        ->  import pytest   (delete the mini pytest code)
# with raises(ValueError, match="x"):  ->  with pytest.raises(ValueError, match="x"):
# math.isclose(a, b)                   ->  a == pytest.approx(b)
# @fixture                             ->  @pytest.fixture   (shared ones in tests/conftest.py)
# @parametrize("raw, expected", rows)  ->  @pytest.mark.parametrize("raw, expected", rows)
# run_tests(globals())                 ->  delete it; run  pytest -v  in the terminal

# tests/test_utils.py
import pytest
from bookvault.utils import clean_isbn


@pytest.mark.parametrize("bad", ["abc", "", None])
def test_clean_isbn_invalid(bad):
    with pytest.raises(ValueError):
        clean_isbn(bad)
''',
                "output": r'''$ pytest -v tests/test_utils.py
collected 3 items

tests/test_utils.py::test_clean_isbn_invalid[abc] PASSED                 [ 33%]
tests/test_utils.py::test_clean_isbn_invalid[] PASSED                    [ 66%]
tests/test_utils.py::test_clean_isbn_invalid[None] PASSED                [100%]

============================== 3 passed in 0.02s ==============================''',
            },
        ],
        "challenge": {
            "task": "Write the **valid** table for `clean_isbn`. Put `@parametrize(\"raw, expected\", [...])` above `test_clean_isbn_valid(raw, expected)`, whose body is `assert clean_isbn(raw) == expected`. Use the four valid cases from assignment Q4:\n- `\"978-0-13-235088-4\"` gives `\"9780132350884\"`\n- `\"0132350882\"` gives `\"0132350882\"`\n- `\"  978 0132350884  \"` gives `\"9780132350884\"`\n- `\"978\\t0132350884\"` (with a tab) gives `\"9780132350884\"`\n\nThe runner should print 4 PASSED lines and `4 passed, 0 failed`.",
            "hints": [
                "The table is a list of `(raw, expected)` tuples, one per line, inside `@parametrize(\"raw, expected\", [ ... ])`.",
                "Write the tab row as `(\"978\\t0132350884\", \"9780132350884\")`: `\\t` inside a string is a tab.",
            ],
            "starter": _ISBN + _MINI + _PARAM + _PARAM_RUNNER + _START + r'''# write the table and test_clean_isbn_valid here


run_tests(globals())
''',
            "solution": _ISBN + _MINI + _PARAM + _PARAM_RUNNER + _START + r'''@parametrize("raw, expected", [
    ("978-0-13-235088-4", "9780132350884"),
    ("0132350882", "0132350882"),
    ("  978 0132350884  ", "9780132350884"),
    ("978\t0132350884", "9780132350884"),
])
def test_clean_isbn_valid(raw, expected):
    assert clean_isbn(raw) == expected


run_tests(globals())
''',
            "tests": _CATCHES + r'''assert callable(globals().get("test_clean_isbn_valid")), "write a test function called test_clean_isbn_valid"
_rows = getattr(test_clean_isbn_valid, "rows", None)
assert _rows, 'put @parametrize("raw, expected", [...]) on the line above test_clean_isbn_valid'
assert all(len(_r) == 2 for _r in _rows), "each row should be a (raw, expected) pair"
assert len({_r[0] for _r in _rows}) >= 4, "the table needs the 4 different valid ISBNs from the task"
assert any(isinstance(_r[0], str) and ("\t" in _r[0] or "\n" in _r[0]) for _r in _rows), "include the row with a tab: \"978\\t0132350884\""
for _r in _rows:
    try:
        test_clean_isbn_valid(*_r)
    except Exception as _e:
        raise AssertionError(f"the row {_r!r} fails on the correct clean_isbn: check its expected value")
def _no_tabs(raw):
    cleaned = raw.replace(" ", "").replace("-", "")
    if len(cleaned) in (10, 13) and cleaned.isdigit():
        return cleaned
    raise ValueError("not an ISBN")
assert any(_catches(lambda _row=_r: test_clean_isbn_valid(*_row), "clean_isbn", _no_tabs) for _r in _rows), "your table should catch a clean_isbn that forgets to remove tabs"
assert "PASSED" in __output__ and " 0 failed" in __output__, "keep run_tests(globals()) at the end; every row should pass"''',
        },
        "practice": [
            {
                "task": "Now the **invalid** table. With one name, write `@parametrize(\"bad\", [...])` above `test_clean_isbn_invalid(bad)`, listing the five bad inputs from Q4: `\"abc\"`, `\"12345\"`, `\"\"`, `None` and `\"978abc0132350884\"`. The test body checks that `clean_isbn(bad)` raises `ValueError` (use `with raises(ValueError):`). The checker also runs your table against the course's forged `clean_isbn`, which wrongly accepts `\"978abc0132350884\"`.",
                "hints": [
                    "One name means plain values, not tuples: `@parametrize(\"bad\", [\"abc\", \"12345\", \"\", None, \"978abc0132350884\"])`.",
                    "Body: `with raises(ValueError):` and, indented, `clean_isbn(bad)`.",
                ],
                "starter": _ISBN + _MINI + _RAISES + _PARAM + _PARAM_RUNNER + _START + r'''# write the table and test_clean_isbn_invalid here


run_tests(globals())
''',
                "solution": _ISBN + _MINI + _RAISES + _PARAM + _PARAM_RUNNER + _START + r'''@parametrize("bad", ["abc", "12345", "", None, "978abc0132350884"])
def test_clean_isbn_invalid(bad):
    with raises(ValueError):
        clean_isbn(bad)


run_tests(globals())
''',
                "tests": _CATCHES + r'''import re
assert callable(globals().get("test_clean_isbn_invalid")), "write a test function called test_clean_isbn_invalid"
_rows = getattr(test_clean_isbn_invalid, "rows", None)
assert _rows, 'put @parametrize("bad", [...]) on the line above test_clean_isbn_invalid'
assert all(len(_r) == 1 for _r in _rows), 'with one name, "bad", list the values directly (and test_clean_isbn_invalid takes one parameter)'
_vals = [_r[0] for _r in _rows]
for _need in ("abc", "12345", "", None, "978abc0132350884"):
    assert _need in _vals, f"the table is missing the bad input {_need!r}"
for _r in _rows:
    try:
        test_clean_isbn_invalid(*_r)
    except Exception as _e:
        raise AssertionError(f"the row {_r!r} fails on the correct clean_isbn: {_e}")
def _accepts_all(raw):
    return "0000000000"
def _forged(isbn):
    if isbn is None:
        raise ValueError("ISBN cannot be None")
    cleaned = re.sub(r"[^\d]", "", isbn)
    if not cleaned or len(cleaned) < 10 or len(cleaned) > 13:
        raise ValueError(f"Invalid ISBN length: {isbn}")
    return cleaned
assert _catches(lambda: test_clean_isbn_invalid("abc"), "clean_isbn", _accepts_all), "test_clean_isbn_invalid should fail when clean_isbn raises nothing: use with raises(ValueError):"
assert any(_catches(lambda _v=_v: test_clean_isbn_invalid(_v), "clean_isbn", _forged) for _v in _vals), "your table should expose the forged clean_isbn (the 978abc row)"
assert "5 passed, 0 failed" in __output__, "keep run_tests(globals()) at the end; it should print 5 passed, 0 failed"''',
            },
            {
                "task": "Build the decorator yourself. Finish `parametrize(argnames, rows)` so that `mark(fn)` stores the table on the function as `fn.rows`, always as a list of tuples, then returns `fn`:\n- if `argnames` contains a comma, keep the rows as they are: `list(rows)`\n- otherwise wrap each value in a one-item tuple: `[(row,) for row in rows]`\n\nThe runner already uses `fn.rows`. It should print `5 passed, 0 failed`.",
                "hints": [
                    "Inside `mark`, before `return fn`: `if \",\" in argnames:` then `fn.rows = list(rows)`.",
                    "`else:` then `fn.rows = [(row,) for row in rows]`. Keep `return fn` at the end and `return mark` outside.",
                ],
                "starter": _MINI + r'''def parametrize(argnames, rows):
    def mark(fn):
        # store the table on fn as fn.rows (a list of tuples)
        return fn
    return mark

''' + _PARAM_RUNNER + _START + r'''@parametrize("days, fee", [(0, 0.0), (2, 1.0), (10, 5.0)])
def test_late_fee(days, fee):
    assert days * 0.5 == fee

@parametrize("title", ["Clean Code", "Dune"])
def test_title_not_blank(title):
    assert title.strip() != ""

run_tests(globals())
''',
                "solution": _MINI + _PARAM + _PARAM_RUNNER + _START + r'''@parametrize("days, fee", [(0, 0.0), (2, 1.0), (10, 5.0)])
def test_late_fee(days, fee):
    assert days * 0.5 == fee

@parametrize("title", ["Clean Code", "Dune"])
def test_title_not_blank(title):
    assert title.strip() != ""

run_tests(globals())
''',
                "tests": r'''@parametrize("a, b", [(1, 2), (3, 4)])
def _two(a, b):
    pass
assert callable(_two), "mark should return the function itself (return fn)"
assert getattr(_two, "rows", None) == [(1, 2), (3, 4)], "with two names, fn.rows should be the rows as given: list(rows)"
@parametrize("x", [5, (6, 7), None])
def _one(x):
    pass
assert getattr(_one, "rows", None) == [(5,), ((6, 7),), (None,)], "with one name, wrap every value in a one-item tuple: [(row,) for row in rows]"
assert "5 passed, 0 failed" in __output__, "run_tests(globals()) should print 5 passed, 0 failed"''',
            },
            {
                "task": "Fix the forgery. This `clean_isbn` is the course's version rewritten without regular expressions: it keeps only digits and silently drops everything else, so `\"978abc0132350884\"` passes and an ISBN-10 loses its `X`. Rewrite it so that:\n- anything that isn't a string raises `ValueError`\n- only spaces, hyphens, tabs (`\\t`) and newlines (`\\n`) are removed; a lowercase `x` becomes `X`\n- 13 characters, all digits, is valid; 10 characters, the first 9 digits and the last a digit or `X`, is valid\n- anything else raises `ValueError`\n\nBoth tables are ready; all 9 rows should pass.",
                "hints": [
                    "Build `cleaned` with a loop that skips characters `in \" -\\t\\n\"`, then `cleaned = cleaned.upper()`.",
                    "`if len(cleaned) == 13 and cleaned.isdigit(): return cleaned`, then `if len(cleaned) == 10 and cleaned[:9].isdigit() and cleaned[9] in \"0123456789X\": return cleaned`, then `raise ValueError(...)`.",
                ],
                "starter": r'''def clean_isbn(raw):
    if raw is None:
        raise ValueError("ISBN cannot be None")
    cleaned = ""
    for ch in raw:
        if ch.isdigit():
            cleaned += ch        # keeps digits, silently drops everything else
    if len(cleaned) < 10 or len(cleaned) > 13:
        raise ValueError(f"not a valid ISBN: {raw!r}")
    return cleaned

''' + _MINI + _RAISES + _PARAM + _PARAM_RUNNER + _START + _ISBN_TABLES + r'''run_tests(globals())
''',
                "solution": _ISBN + _MINI + _RAISES + _PARAM + _PARAM_RUNNER + _START + _ISBN_TABLES + r'''run_tests(globals())
''',
                "tests": r'''for _raw, _exp in [("978-0-13-235088-4", "9780132350884"), ("0132350882", "0132350882"),
                   ("  978 0132350884  ", "9780132350884"), ("978\t0132350884", "9780132350884"),
                   ("978\n0132350884", "9780132350884"), ("0-8044-2957-X", "080442957X"), ("080442957x", "080442957X")]:
    try:
        _got = clean_isbn(_raw)
    except Exception as _e:
        raise AssertionError(f"clean_isbn({_raw!r}) should return {_exp!r}, but it raised {type(_e).__name__}")
    assert _got == _exp, f"clean_isbn({_raw!r}) should return {_exp!r}, got {_got!r}"
for _bad in ["abc", "12345", "", None, 9780132350884, "978abc0132350884", "978013235088X", "X132350882",
             "12345678901", "0132350882!", "978_0132350884"]:
    try:
        clean_isbn(_bad)
    except ValueError:
        continue
    except Exception as _e:
        raise AssertionError(f"clean_isbn({_bad!r}) should raise ValueError, not {type(_e).__name__}")
    raise AssertionError(f"clean_isbn({_bad!r}) should raise ValueError, but it returned a value")
assert "9 passed, 0 failed" in __output__, "keep run_tests(globals()) at the end; all 9 rows should pass"''',
            },
        ],
    },
    # ------------------------------------------------------------------ test doubles
    {
        "id": "test-doubles",
        "title": "Fakes and mocks",
        "slides": "26",
        "idea": "A test must give the same result every time, on every machine, with no internet. Real code doesn't: it reads **environment variables**, asks the clock for today's date, and calls web APIs. Each of those makes a test **flaky** (passes today, fails tomorrow), slow, or expensive (a real LLM call costs money). The fix is a **test double**: a stand-in you control.\n\nThe simplest double is a **fake** passed in as an argument. Write `days_late(due, clock=date.today)`: real code gets the real clock, and a test passes `clock=lambda: date(2026, 5, 18)`. The same works for settings (`data_path(env=os.environ)`; a test passes a plain dict) and for APIs (`cover_url(isbn, fetch)`; a test passes a fake `fetch`). Handing a function what it needs, instead of letting it grab it, is called **dependency injection**. It also keeps tests fast: no real waiting, no real network.\n\nWhen you also want to check *how* the double was used, use a **mock**. `MagicMock` from `unittest.mock` accepts any call and records it. Set its answer with `return_value`, then check it with `assert_called_once()`, `assert_called_once_with(...)` and `call_args` (the arguments of the last call). To swap a method you can't pass in, `patch.object(SomeClass, \"method\")` replaces it for the length of a `with` block and puts the real one back afterwards. On Day 3 you'll do exactly this to an LLM client.\n\n- inject the clock, settings and API calls as arguments, with the real thing as the default\n- `MagicMock(return_value=...)`: a fake that records its calls\n- `fake.assert_called_once()` and `args, kwargs = fake.call_args`\n- `with patch.object(Class, \"method\") as fake:`; pytest's `monkeypatch` and `patch(\"module.name\")` do the same by name (see the cards)",
        "predict": {
            "q": "`bookvault/covers.py` starts with `from requests import get` and calls `get(url)`. Which patch stops the real network call in a test?",
            "options": ["`patch(\"requests.get\")`", "`patch(\"bookvault.covers.get\")`", "Either one: they replace the same function"],
            "answer": 1,
            "why": "`from requests import get` copies the name `get` into `bookvault.covers`. Patching `requests.get` changes the name in the requests module, but covers.py still holds the original. Always patch the name where it is used.",
        },
        "code": r'''import os
from datetime import date
from unittest.mock import MagicMock, patch

def data_path(env=os.environ):
    return env.get("BOOKVAULT_DATA_PATH", "data/books.jsonl")

def days_late(due, clock=date.today):
    return max(0, (clock() - due).days)

def cover_url(isbn, fetch):
    return fetch(f"https://covers.example/{isbn}")["url"]

print(data_path({"BOOKVAULT_DATA_PATH": "/tmp/test.jsonl"}))
print(data_path({}))
print(days_late(date(2026, 5, 1), clock=lambda: date(2026, 5, 18)))

fake_fetch = MagicMock(return_value={"url": "https://img.example/B001.jpg"})
print(cover_url("9780132350884", fake_fetch))
fake_fetch.assert_called_once()
args, kwargs = fake_fetch.call_args
print("called with", args[0])

class Mailer:
    def send(self, to, text):
        raise RuntimeError("a real email was sent during a test!")

def remind(mailer, member_email):
    mailer.send(member_email, "Your book is due")

with patch.object(Mailer, "send") as fake_send:
    remind(Mailer(), "asha@example.com")
fake_send.assert_called_once_with("asha@example.com", "Your book is due")
print("send was called with", fake_send.call_args)
print("real send is back:", not isinstance(Mailer.send, MagicMock))
''',
        "walkthrough": [
            ["def data_path(env=os.environ):", "The real program reads the real environment variables (`os.environ` acts like a dict). A test passes its own small dict instead, so it never depends on your machine's settings."],
            ["def days_late(due, clock=date.today):", "Note: `date.today` **without** brackets: the function itself is the default, and it is called inside. A test passes a different function that always returns the same date."],
            ["def cover_url(isbn, fetch):", "The function that talks to the network is passed in, so a test can hand over a fake one."],
            ["print(days_late(date(2026, 5, 1), clock=lambda: date(2026, 5, 18)))", "A fake clock: a `lambda` that always says 18 May 2026. The answer is 17 today, tomorrow and next year."],
            ["fake_fetch = MagicMock(return_value={\"url\": \"https://img.example/B001.jpg\"})", "A mock you can call like a function. Whatever it's called with, it returns `return_value`, and it remembers the call."],
            ["fake_fetch.assert_called_once()", "Raises AssertionError unless the mock was called exactly once. It catches code that calls the API twice (twice the cost)."],
            ["args, kwargs = fake_fetch.call_args", "The arguments of the last call: `args` is a tuple of positional arguments, `kwargs` a dict of keyword arguments. Check that the right URL was asked for."],
            ["with patch.object(Mailer, \"send\") as fake_send:", "For the length of the `with` block, `Mailer.send` is replaced by a MagicMock, so no email can go out. `as fake_send` gives you the mock to inspect."],
            ["fake_send.assert_called_once_with(\"asha@example.com\", \"Your book is due\")", "Checks the call and its exact arguments in one line. (The mock replaced the method on the class, so `self` is not among the recorded arguments.)"],
            ["print(\"real send is back:\", not isinstance(Mailer.send, MagicMock))", "After the block, `patch.object` restored the real method, so the next test sees the normal class."],
        ],
        "mistakes": [
            "Calling `date.today()` or reading `os.environ` deep inside a function: a test can't control it. Pass the clock or settings in.",
            "Writing `clock=date.today()` with brackets: the date is fixed once, when the function is defined. Pass the function, `date.today`.",
            "Changing the real `os.environ` in a test and not undoing it: later tests see your value. Pass a dict, or use pytest's `monkeypatch`, which undoes it for you.",
            "Only checking the result and not the calls: a bug that calls the API twice, or for the wrong ISBN, slips through. Use `assert_called_once` and `call_args`.",
            "Patching the wrong name with `patch(\"requests.get\")` when the code did `from requests import get`: patch the name where it is **used**, such as `patch(\"bookvault.covers.get\")`.",
        ],
        "local": [
            {
                "title": "monkeypatch: environment, clock and API (assignment Q10)",
                "note": "`monkeypatch` is a built-in pytest fixture. Everything it changes (`setenv`, `delenv`, `setattr`) is undone automatically after the test. Assumes `bookvault/loader.py` has `data_path()` reading `os.environ`, and `bookvault/covers.py` has `cover_url(isbn)` calling its own `fetch_json(url)`.",
                "code": r'''# tests/test_doubles.py
from datetime import date

import bookvault.covers as covers
import bookvault.loader as loader
from bookvault.library import days_late


def test_data_path_from_env(monkeypatch):
    monkeypatch.setenv("BOOKVAULT_DATA_PATH", "/tmp/test.jsonl")
    assert loader.data_path() == "/tmp/test.jsonl"


def test_default_path(monkeypatch):
    monkeypatch.delenv("BOOKVAULT_DATA_PATH", raising=False)
    assert loader.data_path() == "data/books.jsonl"


def test_days_late_with_fixed_clock():
    assert days_late(date(2026, 5, 1), clock=lambda: date(2026, 5, 18)) == 17


def test_cover_without_network(monkeypatch):
    def fake_fetch(url):
        return {"url": "https://img.example/B001.jpg"}
    monkeypatch.setattr(covers, "fetch_json", fake_fetch)
    assert covers.cover_url("9780132350884") == "https://img.example/B001.jpg"
''',
                "output": r'''$ pytest -v tests/test_doubles.py
collected 4 items

tests/test_doubles.py::test_data_path_from_env PASSED                    [ 25%]
tests/test_doubles.py::test_default_path PASSED                          [ 50%]
tests/test_doubles.py::test_days_late_with_fixed_clock PASSED            [ 75%]
tests/test_doubles.py::test_cover_without_network PASSED                 [100%]

============================== 4 passed in 0.02s ==============================''',
            },
            {
                "title": "patch(\"module.name\") for a library call",
                "note": "`patch` takes the dotted path of the name **where your code looks it up**. `covers.py` does `from requests import get`, which copies `get` into the `bookvault.covers` module, so the target is `bookvault.covers.get`. This form doesn't work in the browser page (it has no real modules), which is why the lesson uses `patch.object`.",
                "code": r'''# bookvault/covers.py
from requests import get

def fetch_cover(isbn):
    response = get(f"https://covers.example.com/{isbn}", timeout=5)
    return response.json()["url"]


# tests/test_covers.py
from unittest.mock import patch
from bookvault.covers import fetch_cover


def test_fetch_cover_mocked():
    # patch("requests.get") would NOT work here: covers.py already holds its own name `get`
    with patch("bookvault.covers.get") as mock_get:
        mock_get.return_value.json.return_value = {"url": "fake-url.jpg"}
        assert fetch_cover("9780132350884") == "fake-url.jpg"

    mock_get.assert_called_once()
    args, kwargs = mock_get.call_args
    assert "978" in args[0]
    assert kwargs == {"timeout": 5}
''',
                "output": r'''$ pytest -v tests/test_covers.py
collected 1 item

tests/test_covers.py::test_fetch_cover_mocked PASSED                     [100%]

============================== 1 passed in 0.03s ==============================''',
            },
        ],
        "challenge": {
            "task": "Assignment Q10 without monkeypatch: inject the fakes. Write three tests:\n- `test_path_from_env`: `data_path({\"BOOKVAULT_DATA_PATH\": \"/tmp/test.jsonl\"})` returns `\"/tmp/test.jsonl\"`\n- `test_default_path`: `data_path({})` returns `\"data/books.jsonl\"`\n- `test_days_late`: with a fake clock that always returns `date(2026, 5, 18)`, a book due `date(2026, 5, 1)` is 17 days late, and a book due `date(2026, 6, 1)` is 0 days late\n\nDon't call `date.today()` and don't change `os.environ`. The runner should print `3 passed, 0 failed`.",
            "hints": [
                "Pass the fake straight in: `assert data_path({}) == \"data/books.jsonl\"`.",
                "`fake_clock = lambda: date(2026, 5, 18)`, then `assert days_late(date(2026, 5, 1), clock=fake_clock) == 17` and the same with `date(2026, 6, 1)` and `0`.",
            ],
            "starter": r'''import os
from datetime import date

def data_path(env=os.environ):
    return env.get("BOOKVAULT_DATA_PATH", "data/books.jsonl")

def days_late(due, clock=date.today):
    return max(0, (clock() - due).days)

''' + _MINI + _RUNNER + _START + r'''# write test_path_from_env, test_default_path and test_days_late here


run_tests(globals())
''',
            "solution": r'''import os
from datetime import date

def data_path(env=os.environ):
    return env.get("BOOKVAULT_DATA_PATH", "data/books.jsonl")

def days_late(due, clock=date.today):
    return max(0, (clock() - due).days)

''' + _MINI + _RUNNER + _START + r'''def test_path_from_env():
    assert data_path({"BOOKVAULT_DATA_PATH": "/tmp/test.jsonl"}) == "/tmp/test.jsonl"

def test_default_path():
    assert data_path({}) == "data/books.jsonl"

def test_days_late():
    fake_clock = lambda: date(2026, 5, 18)
    assert days_late(date(2026, 5, 1), clock=fake_clock) == 17
    assert days_late(date(2026, 6, 1), clock=fake_clock) == 0


run_tests(globals())
''',
            "tests": _CATCHES + r'''import os
from datetime import date as _date
for _n in ("test_path_from_env", "test_default_path", "test_days_late"):
    _passes(_n)
def _ignores_env(env=None):
    return "data/books.jsonl"
def _wrong_default(env=os.environ):
    return env.get("BOOKVAULT_DATA_PATH", "books.json")
def _ignores_clock(due, clock=None):
    return max(0, (_date(2026, 1, 1) - due).days)
def _negative(due, clock=_date.today):
    return (clock() - due).days
assert _catches(test_path_from_env, "data_path", _ignores_env), "test_path_from_env should pass a dict holding BOOKVAULT_DATA_PATH and check that path comes back"
assert _catches(test_default_path, "data_path", _wrong_default), "test_default_path should pass an empty dict and check for \"data/books.jsonl\""
assert _catches(test_days_late, "days_late", _ignores_clock), "test_days_late should pass a fake clock (clock=...) and check the answer 17"
assert _catches(test_days_late, "days_late", _negative), "test_days_late should also check that a book due after the fake today is 0 days late"
assert "date.today()" not in __source__, "don't call date.today() in a test: the answer would change every day"
assert "os.environ[" not in __source__ and "setenv" not in __source__ and "putenv" not in __source__, "don't change os.environ: pass a plain dict instead"
assert "3 passed, 0 failed" in __output__, "keep run_tests(globals()) at the end; it should print 3 passed, 0 failed"''',
        },
        "practice": [
            {
                "task": "`cover_url(isbn, fetch)` asks the cover API for a URL. Write `test_cover_url` that:\n- makes `fake = MagicMock(return_value={\"url\": \"https://img.example/B001.jpg\"})`\n- asserts `cover_url(\"9780132350884\", fake)` returns that URL\n- calls `fake.assert_called_once()`\n- takes `args, kwargs = fake.call_args` and asserts `\"9780132350884\"` is in `args[0]` (the URL that was requested)\n\nThe runner should print `1 passed, 0 failed`.",
                "hints": [
                    "Build the mock first, pass it as the second argument of `cover_url`, and only then check how it was called.",
                    "`fake.assert_called_once()` then `args, kwargs = fake.call_args` then `assert \"9780132350884\" in args[0]`.",
                ],
                "starter": r'''from unittest.mock import MagicMock

def cover_url(isbn, fetch):
    data = fetch(f"https://covers.example/{isbn}")
    return data["url"]

''' + _MINI + _RUNNER + _START + r'''# write test_cover_url here


run_tests(globals())
''',
                "solution": r'''from unittest.mock import MagicMock

def cover_url(isbn, fetch):
    data = fetch(f"https://covers.example/{isbn}")
    return data["url"]

''' + _MINI + _RUNNER + _START + r'''def test_cover_url():
    fake = MagicMock(return_value={"url": "https://img.example/B001.jpg"})
    assert cover_url("9780132350884", fake) == "https://img.example/B001.jpg"
    fake.assert_called_once()
    args, kwargs = fake.call_args
    assert "9780132350884" in args[0]


run_tests(globals())
''',
                "tests": _CATCHES + r'''_passes("test_cover_url")
def _twice(isbn, fetch):
    fetch(f"https://covers.example/{isbn}")
    return fetch(f"https://covers.example/{isbn}")["url"]
def _wrong_isbn(isbn, fetch):
    return fetch("https://covers.example/" + isbn[:3])["url"]
def _ignores_reply(isbn, fetch):
    fetch(f"https://covers.example/{isbn}")
    return "https://img.example/default.jpg"
assert "MagicMock(" in __source__.split("def test_cover_url", 1)[-1], "make the fake inside test_cover_url with MagicMock(return_value=...)"
assert _catches(test_cover_url, "cover_url", _ignores_reply), "test_cover_url should check that cover_url returns the URL from the fake's reply"
assert _catches(test_cover_url, "cover_url", _twice), "test_cover_url should catch a cover_url that calls the API twice: fake.assert_called_once()"
assert _catches(test_cover_url, "cover_url", _wrong_isbn), "test_cover_url should check the requested URL: args, kwargs = fake.call_args, then look for the ISBN in args[0]"
assert "1 passed, 0 failed" in __output__, "keep run_tests(globals()) at the end; it should print 1 passed, 0 failed"''',
            },
            {
                "task": "`Library.borrow` sends a notice through `self.notify`, which would send a real email (here it raises). Write `test_borrow_sends_notice`:\n- inside `with patch.object(Library, \"notify\") as fake_notify:` make `lib = Library()` and call `lib.borrow(\"B001\", \"M001\")`\n- after the block: `fake_notify.assert_called_once_with(\"M001\", \"You borrowed B001\")`, which checks the call and its exact arguments in one line\n- also assert the loan was recorded: `(\"B001\", \"M001\") in lib.loans`\n\nThe runner should print `1 passed, 0 failed`.",
                "hints": [
                    "Everything that calls `notify` must happen inside the `with` block; the checks can come after it.",
                    "`with patch.object(Library, \"notify\") as fake_notify:` / `lib = Library()` / `lib.borrow(\"B001\", \"M001\")`, then, outside: `fake_notify.assert_called_once_with(\"M001\", \"You borrowed B001\")` and the `lib.loans` check.",
                ],
                "starter": r'''from unittest.mock import patch

class Library:
    def __init__(self):
        self.loans = []

    def notify(self, member_id, text):
        raise RuntimeError("tried to send a real email during a test!")

    def borrow(self, item_id, member_id):
        self.loans.append((item_id, member_id))
        self.notify(member_id, f"You borrowed {item_id}")

''' + _MINI + _RUNNER + _START + r'''# write test_borrow_sends_notice here


run_tests(globals())
''',
                "solution": r'''from unittest.mock import patch

class Library:
    def __init__(self):
        self.loans = []

    def notify(self, member_id, text):
        raise RuntimeError("tried to send a real email during a test!")

    def borrow(self, item_id, member_id):
        self.loans.append((item_id, member_id))
        self.notify(member_id, f"You borrowed {item_id}")

''' + _MINI + _RUNNER + _START + r'''def test_borrow_sends_notice():
    with patch.object(Library, "notify") as fake_notify:
        lib = Library()
        lib.borrow("B001", "M001")
    fake_notify.assert_called_once_with("M001", "You borrowed B001")
    assert ("B001", "M001") in lib.loans


run_tests(globals())
''',
                "tests": _CATCHES + r'''_passes("test_borrow_sends_notice")
assert "patch.object(" in __source__, "replace notify with patch.object(Library, \"notify\")"
_Real = Library
class _Silent(_Real):
    def borrow(self, item_id, member_id):
        self.loans.append((item_id, member_id))
class _WrongPerson(_Real):
    def borrow(self, item_id, member_id):
        self.loans.append((item_id, member_id))
        self.notify(item_id, f"You borrowed {item_id}")
class _NoLoan(_Real):
    def borrow(self, item_id, member_id):
        self.notify(member_id, f"You borrowed {item_id}")
assert _catches(test_borrow_sends_notice, "Library", _Silent), "test_borrow_sends_notice should fail when borrow sends no notice: fake_notify.assert_called_once_with(...)"
assert _catches(test_borrow_sends_notice, "Library", _WrongPerson), "test_borrow_sends_notice should check who was notified: fake_notify.assert_called_once_with(\"M001\", \"You borrowed B001\")"
assert _catches(test_borrow_sends_notice, "Library", _NoLoan), "test_borrow_sends_notice should also check the loan was recorded in lib.loans"
from unittest.mock import MagicMock as _MM
assert not isinstance(Library.notify, _MM), "notify should be the real method again after the test: use patch.object in a with block"
assert "1 passed, 0 failed" in __output__, "keep run_tests(globals()) at the end; it should print 1 passed, 0 failed"''',
            },
        ],
    },
    # ------------------------------------------------------------------ coverage
    {
        "id": "coverage",
        "title": "Coverage: which lines never ran",
        "slides": "27",
        "idea": "**Coverage** measures which lines of your code actually ran while the tests ran. The `pytest-cov` plugin prints a table per file: **Stmts** (statements), **Miss** (how many never ran), **Cover** (the percent that ran) and **Missing** (the line numbers that never ran). The Missing column is your to-do list: each number is a line no test reached, usually an error branch or an edge case.\n\nTwo warnings from the deck. Aim for about **80%+ on business logic** (fees, loans, imports), not on trivial getters, `__repr__` or generated code. And **100% is vanity**: coverage only says a line *ran*, not that its result was *checked*. A test with no `assert` can reach 100% and catch nothing.\n\nReal coverage watches the interpreter run every line (through `sys.settrace`), which this page can't do reliably. So the demo marks the code by hand: each branch calls `hit(\"name\")`, a set remembers which names ran, and a report lists the ones that never did. Same idea, with named branches instead of line numbers. The card shows real pytest-cov and the `pyproject.toml` settings that run it every time, including `fail_under`, which fails the whole run when coverage drops below a target (85% in the assignment).\n\n- Missing = code no test reached: write tests for those lines next\n- aim for 80%+ on business logic; don't chase 100%\n- coverage counts what ran, not what was checked: every test still needs real asserts\n- `fail_under` (or `--cov-fail-under=85`) turns low coverage into a failed run",
        "predict": {
            "q": "Your test suite reaches 100% coverage. What do you know for sure?",
            "options": ["The code has no bugs", "Every line ran at least once during the tests", "Every result was checked by an assert"],
            "answer": 1,
            "why": "Coverage records which lines ran, nothing more. A test that calls a function and never asserts anything still counts. That is why 100% is called vanity.",
        },
        "code": _PROBES + _LATE_FEE + r'''def report():
    missing = [p for p in PROBES if p not in hits]
    cover = round(100 * (len(PROBES) - len(missing)) / len(PROBES))
    print(f"Branches {len(PROBES)}  Miss {len(missing)}  Cover {cover}%  Missing: {', '.join(missing) or 'none'}")

# ---- the tests start here ----

assert late_fee(4, member=True) == 2.0
report()

assert late_fee(0, member=True) == 0.0
assert late_fee(30, member=False) == 20.0
report()

hits.clear()
late_fee(0, True)
late_fee(3, True)
late_fee(50, False)
report()
print("100% again, yet nothing was checked: there is no assert")
''',
        "walkthrough": [
            ["PROBES = [\"start\", \"not-late\", \"member\", \"guest\", \"cap\"]", "The names of every branch in `late_fee`. Real coverage uses line numbers instead, and finds them by itself."],
            ["hits = set()", "A set of the branch names that ran. A set ignores repeats, so a branch that runs 50 times is still recorded once."],
            ["    hit(\"not-late\")", "Each branch announces itself. This is what coverage.py does for every line automatically."],
            ["    missing = [p for p in PROBES if p not in hits]", "The Missing column: every branch that never ran, in the order it appears in the code."],
            ["    cover = round(100 * (len(PROBES) - len(missing)) / len(PROBES))", "Cover = the share of branches that ran, as a whole percent."],
            ["assert late_fee(4, member=True) == 2.0\nreport()", "One test reaches only `start` and `member`: 40%, and Missing lists `not-late, guest, cap`. That list tells you which tests to write next."],
            ["assert late_fee(30, member=False) == 20.0", "A guest 30 days late reaches both the `guest` branch and the `cap` branch. Two more tests bring coverage to 100%."],
            ["hits.clear()\nlate_fee(0, True)", "Start again with calls that check nothing. Every branch still runs, so the report says 100%: proof that coverage can't tell a real test from a fake one."],
        ],
        "mistakes": [
            "Reading 100% coverage as \"no bugs\": it only means every line ran.",
            "Writing tests with no `assert` just to make lines go green: they raise the number and catch nothing.",
            "Chasing 100% on trivial code (`__repr__`, getters) while the tricky business rules have untested branches.",
            "Ignoring the Missing column: it tells you exactly which branch (often an error path) has no test.",
        ],
        "local": [
            {
                "title": "pytest-cov and the pyproject.toml settings",
                "note": "Install with `pip install pytest-cov`. With these settings, a plain `pytest` measures coverage every time and fails when the total is below 85% (assignment Q20). `branch = true` also checks that both sides of every `if` ran. `exclude_also` skips lines that never need a test. In the Missing column, `18-19` are lines that never ran and `12->15` is a branch that was never taken (the `if` on line 12 never jumped to line 15). Note the end of the run: all 24 tests passed, yet the run **fails** (non-zero exit code, so CI goes red) because coverage is below 85%. Your numbers will differ.",
                "code": r'''# pyproject.toml
[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["."]
addopts = "--cov=bookvault --cov-report=term-missing"

[tool.coverage.run]
source = ["bookvault"]
branch = true

[tool.coverage.report]
fail_under = 85
show_missing = true
exclude_also = [
    "if __name__ == .__main__.:",
    "raise NotImplementedError",
]

# Or without the settings, on the command line:
#   pytest --cov=bookvault --cov-report=term-missing --cov-fail-under=85
''',
                "output": r'''$ pytest
collected 24 items

tests/test_fees.py ........                                              [ 33%]
tests/test_loader.py ................                                    [100%]

================================ tests coverage ================================
_______________ coverage: platform win32, python 3.12.4-final-0 ________________

Name                    Stmts   Miss Branch BrPart  Cover   Missing
-------------------------------------------------------------------
bookvault/__init__.py       2      0      0      0   100%
bookvault/fees.py          14      2      6      1    85%   12->15, 18-19
bookvault/loader.py        35      9     12      3    70%   22->24, 30->33, 41-50, 55->exit
-------------------------------------------------------------------
TOTAL                      51     11     18      4    75%
FAIL Required test coverage of 85% not reached. Total coverage: 75.36%
============================== 24 passed in 0.31s ==============================''',
            },
        ],
        "challenge": {
            "task": "`late_fee` has five marked branches, and the one test reaches only two. Add tests (functions named `test_...`) until `run_suite` prints `Missing: none`. Each test must **assert** the right fee, because the checker also runs your tests against broken versions of `late_fee`. The rules: 0 or fewer days late costs `0.0`; members pay `0.5` a day, guests `1.0` a day; the fee never goes above `20.0`.",
            "hints": [
                "Look at the Missing line first. You need one test for a book that isn't late, one for a guest, and one where the fee hits the cap.",
                "For example: `assert late_fee(0, member=True) == 0.0`, `assert late_fee(3, member=False) == 3.0`, `assert late_fee(60, member=True) == 20.0`, each in its own `def test_...():`.",
            ],
            "starter": _PROBES + _LATE_FEE + _MINI + _SUITE + _START + r'''def test_member_fee():
    assert late_fee(4, member=True) == 2.0

# add tests here until Missing is empty


run_suite(globals())
''',
            "solution": _PROBES + _LATE_FEE + _MINI + _SUITE + _START + r'''def test_member_fee():
    assert late_fee(4, member=True) == 2.0

def test_not_late_is_free():
    assert late_fee(0, member=True) == 0.0

def test_guest_fee():
    assert late_fee(3, member=False) == 3.0

def test_fee_is_capped():
    assert late_fee(60, member=True) == 20.0


run_suite(globals())
''',
            "tests": _CATCHES + _FEE_MUTANTS + r'''hits.clear()
for _t in _tests:
    _t()
_miss = [_p for _p in PROBES if _p not in hits]
assert not _miss, f"these branches never ran in your tests: {', '.join(_miss)}"
assert _caught(_bad_free), "no test catches a late_fee that charges for a book that isn't late: assert late_fee(0, ...) == 0.0"
assert _caught(_bad_guest), "no test catches a wrong guest rate: assert the fee for member=False"
assert _caught(_bad_cap), "no test catches a cap of 25 instead of 20: assert a big fee equals 20.0"
assert "Missing: none" in __output__, "keep run_suite(globals()) at the end; it should print Missing: none"''',
        },
        "practice": [
            {
                "task": "Write the report yourself. `coverage_report(probes, hits, fail_under=80)` should:\n- build `missing`: the names in `probes` that are not in `hits`, in the order of `probes`\n- compute `cover = round(100 * (len(probes) - len(missing)) / len(probes))`\n- print `Cover {cover}%  Missing: ...` (the missing names joined with `\", \"`)\n- raise `CoverageTooLow(f\"coverage {cover}% is below {fail_under}%\")` if `cover` is below `fail_under`\n- otherwise return the tuple `(cover, missing)`",
                "hints": [
                    "`missing = [p for p in probes if p not in hits]`; names in `hits` that aren't probes are simply ignored this way.",
                    "After printing: `if cover < fail_under: raise CoverageTooLow(...)`, then `return cover, missing`.",
                ],
                "starter": r'''class CoverageTooLow(Exception):
    pass

def coverage_report(probes, hits, fail_under=80):
    ...

print(coverage_report(["start", "member", "guest", "cap"], {"start", "member", "guest"}, fail_under=70))
try:
    coverage_report(["start", "member", "guest", "cap"], {"start"}, fail_under=85)
except CoverageTooLow as e:
    print("run failed:", e)
''',
                "solution": r'''class CoverageTooLow(Exception):
    pass

def coverage_report(probes, hits, fail_under=80):
    missing = [p for p in probes if p not in hits]
    cover = round(100 * (len(probes) - len(missing)) / len(probes))
    print(f"Cover {cover}%  Missing: {', '.join(missing)}")
    if cover < fail_under:
        raise CoverageTooLow(f"coverage {cover}% is below {fail_under}%")
    return cover, missing

print(coverage_report(["start", "member", "guest", "cap"], {"start", "member", "guest"}, fail_under=70))
try:
    coverage_report(["start", "member", "guest", "cap"], {"start"}, fail_under=85)
except CoverageTooLow as e:
    print("run failed:", e)
''',
                "tests": r'''import contextlib, io
def _call(*a, **k):
    with contextlib.redirect_stdout(io.StringIO()) as _b:
        _r = coverage_report(*a, **k)
    return _r, _b.getvalue()
_r, _o = _call(["a", "b", "c", "d", "e"], {"a", "b", "c", "d", "e"})
assert _r is not None and tuple(_r) == (100, []), f"when everything ran, return (100, []), got {_r}"
_r, _o = _call(["a", "b", "c", "d"], {"d", "a"}, fail_under=0)
assert tuple(_r) == (50, ["b", "c"]), f"for 4 probes with a and d hit, return (50, ['b', 'c']) with missing in probe order, got {_r}"
assert "50%" in _o and "b, c" in _o, "print the cover percent and the missing names joined with \", \""
_r, _o = _call(["x", "y", "z"], {"z", "x", "other"}, fail_under=50)
assert tuple(_r) == (67, ["y"]), f"ignore hit names that aren't probes and round the percent: expected (67, ['y']), got {_r}"
_r, _o = _call(["a", "b", "c", "d", "e"], {"a", "b", "c", "d"})
assert tuple(_r) == (80, ["e"]), "exactly 80% with the default fail_under=80 should pass, not raise"
try:
    _call(["a", "b", "c", "d"], {"a"}, fail_under=85)
    raise AssertionError("25% coverage with fail_under=85 should raise CoverageTooLow")
except CoverageTooLow as _e:
    assert "25%" in str(_e) and "85%" in str(_e), "the CoverageTooLow message should give the coverage and the target, e.g. coverage 25% is below 85%"''',
            },
            {
                "task": "100% is vanity. This suite reaches every branch (`Missing: none`), but none of its tests asserts anything, so it never noticed the bug in `late_fee`: the cap is 25 instead of 20.\n1. Add an `assert` with the correct fee to each test: `late_fee(0, True)` is `0.0`, `late_fee(3, True)` is `1.5`, `late_fee(50, False)` is `20.0`. Run it: the cap test now FAILS and exposes the bug.\n2. Fix `late_fee` so the fee never goes above `20.0`. All three tests should pass with `Missing: none`.",
                "hints": [
                    "Turn each bare call into a check: `assert late_fee(50, False) == 20.0`.",
                    "In `late_fee`, change both 25s to 20: `if fee > 20:` and `fee = 20.0`.",
                ],
                "starter": _PROBES + r'''def late_fee(days, member):
''' + _FEE_BODY + r'''    if fee > 25:
        hit("cap")
        fee = 25.0
    return fee

''' + _MINI + _SUITE + _START + r'''def test_not_late():
    late_fee(0, True)

def test_member():
    late_fee(3, True)

def test_cap():
    late_fee(50, False)

run_suite(globals())
''',
                "solution": _PROBES + _LATE_FEE + _MINI + _SUITE + _START + r'''def test_not_late():
    assert late_fee(0, True) == 0.0

def test_member():
    assert late_fee(3, True) == 1.5

def test_cap():
    assert late_fee(50, False) == 20.0

run_suite(globals())
''',
                "tests": _CATCHES + _FEE_MUTANTS + r'''for _d, _m in ((0, True), (3, True), (30, True), (41, True), (12, False), (50, False)):
    _want = _good_fee(_d, _m)
    _got = late_fee(_d, _m)
    assert _got == _want, f"late_fee({_d}, {_m}) should be {_want}, got {_got}: fix the cap in late_fee"
hits.clear()
for _t in _tests:
    _t()
assert not [_p for _p in PROBES if _p not in hits], "your tests should still reach every branch (Missing: none)"
assert _caught(_bad_cap), "test_cap should assert the capped fee: assert late_fee(50, False) == 20.0"
assert _caught(_bad_free), "test_not_late should assert the fee is 0.0"
assert _caught(_bad_member), "test_member should assert the member fee: 1.5"
assert "FAILED" not in __output__ and "Missing: none" in __output__, "all three tests should pass and run_suite should print Missing: none"''',
            },
        ],
    },
    # ------------------------------------------------------------------ import report
    {
        "id": "import-report",
        "title": "An import that keeps going",
        "slides": "assignment Q8",
        "idea": "Real data is messy. A catalogue file with 10,000 lines will have a few broken ones: bad JSON, a record of the wrong kind. A loader that crashes on line 7,012 loses everything; a loader that silently skips the line hides the problem. A production import **keeps going** and **reports**: every good record is imported, and every bad line is recorded with its **line number**, its **raw text** and the reason, so someone can fix the file.\n\nThe file is **JSON Lines** (Day 1): one JSON object per line. `for line_no, raw in enumerate(f, start=1):` numbers the lines from 1, the way an editor does, and blank lines are skipped but still counted so the numbers stay right. Each line goes through a small `parse_record`, which raises `ValueError` for anything it can't accept (`json.JSONDecodeError` is a kind of ValueError). The loop catches that error for **one line**, records it, and moves on.\n\nThe result is an **ImportReport** dataclass: the items, the errors, how many lines were read, and counts as properties. Sometimes you want the opposite behaviour: **strict mode** (`strict=True`) stops at the first bad line by raising an error that names the line, for a job that must never load half a file. This page can't open files, so the lesson reads text through `io.StringIO`, a pretend file; the card shows the real file version with `tmp_path`.\n\n- number lines from 1 with `enumerate(f, start=1)`; skip blank lines but still count them\n- put the `try` inside the loop: a bad line is recorded (line number, raw text, reason), not fatal\n- `loaded_count` and `error_count` are properties, so they always match the lists\n- `strict=True` raises on the first bad line; the default keeps going\n- in tests, never compare JSON error messages: their wording differs between Python versions",
        "code": _IMPORTS + _TINY_PARSE + _REPORT + _IMPORT + _CATALOG_TEXT + r'''report = import_catalog(io.StringIO(TEXT))
print(report.loaded_count, "imported,", report.error_count, "errors,", report.skipped, "blank, from", report.total_lines, "lines")
for err in report.errors:
    print(f"  line {err['line']}: {err['raw'][:30]}")

try:
    import_catalog(io.StringIO(TEXT), strict=True)
except ImportRecordError as e:
    print("strict mode stopped at line", e.line_no)
''',
        "walkthrough": [
            ["    data = json.loads(raw)", "Bad JSON raises `json.JSONDecodeError`, which is a kind of `ValueError`."],
            ["    if not isinstance(data, dict) or data.get(\"type\") not in (\"book\", \"magazine\"):", "A small check for now: the line must be a JSON object of a type we know. (The next lesson checks every field.)"],
            ["class ImportRecordError(Exception):", "The strict-mode error. It keeps `line_no`, so the caller knows exactly where the file is broken."],
            ["    def loaded_count(self):\n        return len(self.items)", "A property, so the count can never disagree with the list. Assignment Q8 asks for `loaded_count` and `error_count`."],
            ["    for line_no, raw in enumerate(f, start=1):", "Looping over a file (or a pretend file) gives one line at a time. `enumerate(..., start=1)` numbers them from 1."],
            ["        if not raw:\n            report.skipped += 1\n            continue", "Blank lines are skipped, but still counted, so the line numbers after them stay right."],
            ["        except ValueError as e:", "One bad line lands here. The loop then carries on with the next line."],
            ["            if strict:\n                raise ImportRecordError(line_no, str(e))", "In strict mode the first bad line ends the import, naming the line."],
            ["            report.errors.append({\"line\": line_no, \"raw\": raw, \"error\": str(e)})", "Otherwise record the line number, the original text and the reason, and keep going."],
            ["report = import_catalog(io.StringIO(TEXT))", "`io.StringIO` turns a string into a pretend file you can loop over line by line, exactly like an open file."],
        ],
        "mistakes": [
            "Wrapping the whole loop in one `try`: the first bad line then ends the import. Put the `try` inside the loop, around one line.",
            "Counting lines yourself and forgetting blank lines: every reported line number after a blank line is then off by one. Use `enumerate(f, start=1)`.",
            "Catching `Exception` instead of `ValueError`: a real bug in your own code gets recorded as \"bad data\" and hidden.",
            "Recording only the reason and not the raw line or its number: nobody can find and fix the bad record.",
            "Testing the exact JSON error message: it differs between Python versions (and in this page). Test the line number and that an error was recorded.",
        ],
        "local": [
            {
                "title": "Real files, tested with tmp_path",
                "note": "In `bookvault/loader.py` only the start changes: open the path with `with`, which closes the file when the loop ends. The tests write their own files into `tmp_path`, so they never depend on files on your machine.",
                "code": r'''# bookvault/loader.py  (the part that changes for real files)
def import_catalog(path, strict=False):
    report = ImportReport()
    with open(path, encoding="utf-8") as f:
        for line_no, raw in enumerate(f, start=1):
            ...   # the same loop body as in the lesson
    return report


# tests/test_loader.py
import pytest
from bookvault.loader import ImportRecordError, import_catalog

GOOD = '{"type": "book", "title": "Clean Code", "item_id": "B001", "author": "Robert Martin", "pages": 464}\n'
BAD_TYPE = '{"type": "dvd", "title": "Heat", "item_id": "D001"}\n'


@pytest.fixture
def messy_file(tmp_path):
    path = tmp_path / "books.jsonl"
    path.write_text(GOOD + "BAD JSON HERE\n" + "\n" + BAD_TYPE, encoding="utf-8")
    return path


def test_keeps_going(messy_file):
    report = import_catalog(messy_file)
    assert report.loaded_count == 1
    assert [e["line"] for e in report.errors] == [2, 4]
    assert report.errors[0]["raw"] == "BAD JSON HERE"


def test_strict_mode_raises(messy_file):
    with pytest.raises(ImportRecordError) as info:
        import_catalog(messy_file, strict=True)
    assert info.value.line_no == 2
''',
                "output": r'''$ pytest -v tests/test_loader.py
collected 2 items

tests/test_loader.py::test_keeps_going PASSED                            [ 50%]
tests/test_loader.py::test_strict_mode_raises PASSED                     [100%]

============================== 2 passed in 0.03s ==============================''',
            },
        ],
        "challenge": {
            "task": "Assignment Q8. Finish the `ImportReport` dataclass and `load_items(f)`:\n- add two properties: `loaded_count` (how many items) and `error_count` (how many errors)\n- in `load_items`, loop over `enumerate(f, start=1)`, strip each line and add 1 to `total_lines` for **every** line\n- skip blank lines\n- `json.loads` each other line and append the result to `items`; if it raises `json.JSONDecodeError`, append `{\"line\": line_no, \"raw\": raw, \"error\": str(e)}` to `errors` and keep going\n\nThe sample should give 3 loaded, 1 error, 5 lines.",
            "hints": [
                "A property looks like `@property` then `def loaded_count(self): return len(self.items)`.",
                "Inside the loop: `raw = raw.strip()`, `report.total_lines += 1`, `if not raw: continue`, then `try: report.items.append(json.loads(raw))` and `except json.JSONDecodeError as e: report.errors.append({...})`.",
            ],
            "starter": r'''import io
import json
from dataclasses import dataclass, field

@dataclass
class ImportReport:
    items: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    total_lines: int = 0
    # add the loaded_count and error_count properties here

def load_items(f):
    report = ImportReport()
    # loop over the lines here
    return report

TEXT = (
    '{"type": "book", "title": "Clean Code", "item_id": "B001", "author": "Robert Martin", "pages": 464}\n'
    '{"type": "magazine", "title": "National Geographic", "item_id": "MG001", "issue": 247}\n'
    'BAD JSON HERE\n'
    '\n'
    '{"type": "book", "title": "Dune", "item_id": "B002", "author": "Frank Herbert", "pages": 412}\n'
)
report = load_items(io.StringIO(TEXT))
print(len(report.items), "loaded,", len(report.errors), "error(s),", report.total_lines, "lines")
''',
            "solution": r'''import io
import json
from dataclasses import dataclass, field

@dataclass
class ImportReport:
    items: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    total_lines: int = 0

    @property
    def loaded_count(self):
        return len(self.items)

    @property
    def error_count(self):
        return len(self.errors)

def load_items(f):
    report = ImportReport()
    for line_no, raw in enumerate(f, start=1):
        raw = raw.strip()
        report.total_lines += 1
        if not raw:
            continue
        try:
            report.items.append(json.loads(raw))
        except json.JSONDecodeError as e:
            report.errors.append({"line": line_no, "raw": raw, "error": str(e)})
    return report

TEXT = (
    '{"type": "book", "title": "Clean Code", "item_id": "B001", "author": "Robert Martin", "pages": 464}\n'
    '{"type": "magazine", "title": "National Geographic", "item_id": "MG001", "issue": 247}\n'
    'BAD JSON HERE\n'
    '\n'
    '{"type": "book", "title": "Dune", "item_id": "B002", "author": "Frank Herbert", "pages": 412}\n'
)
report = load_items(io.StringIO(TEXT))
print(len(report.items), "loaded,", len(report.errors), "error(s),", report.total_lines, "lines")
''',
            "tests": r'''import io as _io
_r = load_items(_io.StringIO('{"a": 1}\n\nnot json\n{"b": 2}\n   \n{oops\n'))
assert isinstance(_r, ImportReport), "load_items should return an ImportReport"
assert _r.items == [{"a": 1}, {"b": 2}], f"items should hold the two good records, got {_r.items}"
assert _r.total_lines == 6, f"total_lines should count every line, blank ones too: expected 6, got {_r.total_lines}"
assert len(_r.errors) == 2, f"there are 2 bad lines (3 and 6), but errors has {len(_r.errors)} entries. Are blank lines skipped?"
assert [_e.get("line") for _e in _r.errors] == [3, 6], f"the error line numbers should be [3, 6] (counting from 1, blank lines included), got {[_e.get('line') for _e in _r.errors]}"
assert _r.errors[0].get("raw") == "not json", "each error should keep the raw line (stripped) under \"raw\""
assert _r.errors[0].get("error"), "each error should say what went wrong under \"error\""
assert isinstance(getattr(ImportReport, "loaded_count", None), property) and isinstance(getattr(ImportReport, "error_count", None), property), "add loaded_count and error_count as @property methods"
assert _r.loaded_count == 2 and _r.error_count == 2, "loaded_count and error_count should be the lengths of items and errors"
_r2 = load_items(_io.StringIO(""))
assert _r2.total_lines == 0 and _r2.loaded_count == 0, "an empty file gives an empty report"''',
        },
        "practice": [
            {
                "task": "Write the small `parse_record(raw)` the import uses:\n- `data = json.loads(raw)` (bad JSON already raises a ValueError)\n- if `data` is not a dict, or `data.get(\"type\")` is not `\"book\"` or `\"magazine\"`, raise `ValueError` with a short reason\n- otherwise return `data`",
                "hints": [
                    "`isinstance(data, dict)` checks for a JSON object; a list such as `[1, 2]` is valid JSON but not a record.",
                    "`if not isinstance(data, dict) or data.get(\"type\") not in (\"book\", \"magazine\"): raise ValueError(\"not a book or magazine record\")`, then `return data`.",
                ],
                "starter": r'''import json

def parse_record(raw):
    ...

for raw in ['{"type": "magazine", "title": "Wired", "item_id": "MG002", "issue": 12}', 'BAD JSON', '{"type": "dvd", "title": "Heat"}', '[1, 2]']:
    try:
        print("accepted:", parse_record(raw))
    except ValueError:
        print("rejected:", raw)
''',
                "solution": r'''import json

def parse_record(raw):
    data = json.loads(raw)
    if not isinstance(data, dict) or data.get("type") not in ("book", "magazine"):
        raise ValueError("not a book or magazine record")
    return data

for raw in ['{"type": "magazine", "title": "Wired", "item_id": "MG002", "issue": 12}', 'BAD JSON', '{"type": "dvd", "title": "Heat"}', '[1, 2]']:
    try:
        print("accepted:", parse_record(raw))
    except ValueError:
        print("rejected:", raw)
''',
                "tests": r'''_b = parse_record('{"type": "book", "title": "Clean Code", "item_id": "B001"}')
assert _b == {"type": "book", "title": "Clean Code", "item_id": "B001"}, "a book record should come back as its dict"
assert parse_record('{"type": "magazine", "item_id": "MG001"}')["item_id"] == "MG001", "a magazine record should be accepted"
for _bad, _why in [("BAD JSON HERE", "bad JSON"), ('{"type": "dvd", "title": "Heat"}', "an unknown type"),
                   ('{"title": "No Type"}', "a record with no type"), ("[1, 2, 3]", "JSON that isn't an object"), ('"book"', "a plain JSON string")]:
    try:
        parse_record(_bad)
    except ValueError:
        continue
    except Exception as _e:
        raise AssertionError(f"{_why} should raise ValueError, not {type(_e).__name__}")
    raise AssertionError(f"{_why} should raise ValueError, but parse_record returned a value")''',
            },
            {
                "task": "Strict mode (assignment Q14 asks for it). `parse_record`, `ImportReport` and `ImportRecordError` are ready. Write `import_catalog(f, strict=False)`:\n- loop over `enumerate(f, start=1)`, strip each line, add 1 to `total_lines`; if the line is empty add 1 to `skipped` and move on\n- try `parse_record(raw)` and append the result to `items`\n- on `ValueError`: if `strict`, raise `ImportRecordError(line_no, str(e))`; otherwise append `{\"line\": line_no, \"raw\": raw, \"error\": str(e)}` to `errors` and keep going\n- return the report",
                "hints": [
                    "Start with `report = ImportReport()` and `for line_no, raw in enumerate(f, start=1):`; the `try` goes inside the loop.",
                    "`except ValueError as e:` then `if strict: raise ImportRecordError(line_no, str(e))` and, after that `if`, `report.errors.append({...})`.",
                ],
                "starter": _IMPORTS + _TINY_PARSE + _REPORT + r'''def import_catalog(f, strict=False):
    report = ImportReport()
    # loop over the lines here
    return report

''' + _CATALOG_TEXT + r'''report = import_catalog(io.StringIO(TEXT))
print(report.loaded_count, "imported,", report.error_count, "errors,", report.skipped, "blank")
try:
    import_catalog(io.StringIO(TEXT), strict=True)
    print("strict mode did not stop")
except ImportRecordError as e:
    print("strict mode stopped at line", e.line_no)
''',
                "solution": _IMPORTS + _TINY_PARSE + _REPORT + _IMPORT + _CATALOG_TEXT + r'''report = import_catalog(io.StringIO(TEXT))
print(report.loaded_count, "imported,", report.error_count, "errors,", report.skipped, "blank")
try:
    import_catalog(io.StringIO(TEXT), strict=True)
    print("strict mode did not stop")
except ImportRecordError as e:
    print("strict mode stopped at line", e.line_no)
''',
                "tests": r'''import io as _io
_good = '{"type": "book", "title": "Clean Code", "item_id": "B001"}\n'
_mag = '{"type": "magazine", "title": "Wired", "item_id": "MG002"}\n'
_txt = _good + "\n" + '{"type": "dvd", "title": "Heat"}\n' + _mag + "{broken\n" + "\n"
_r = import_catalog(_io.StringIO(_txt))
assert isinstance(_r, ImportReport), "import_catalog should return an ImportReport"
assert [_i.get("type") for _i in _r.items] == ["book", "magazine"], f"the two good lines should be imported, got {_r.items}"
assert _r.total_lines == 6 and _r.skipped == 2, f"expected 6 lines with 2 blank ones, got total_lines={_r.total_lines}, skipped={_r.skipped}"
assert [_e.get("line") for _e in _r.errors] == [3, 5], f"errors should be on lines [3, 5], got {[_e.get('line') for _e in _r.errors]}"
assert _r.errors[0].get("raw", "").startswith('{"type": "dvd"') and _r.errors[0].get("error"), "each error needs the raw line and a reason"
try:
    import_catalog(_io.StringIO(_txt), strict=True)
    raise AssertionError("strict=True should raise ImportRecordError at the first bad line")
except ImportRecordError as _e:
    assert _e.line_no == 3, f"strict mode should stop at the first bad line, 3, not {_e.line_no}"
_clean = import_catalog(_io.StringIO(_good + _mag), strict=True)
assert _clean.loaded_count == 2 and _clean.error_count == 0, "strict mode on a clean file should import everything"''',
            },
        ],
    },
    # ------------------------------------------------------------------ validate and stream
    {
        "id": "validate-and-stream",
        "title": "Validate records, stream the file",
        "slides": "assignment Q14",
        "idea": "The last lesson only checked that a line was JSON of a known type. A production import (assignment Q14) **validates** each record before it turns it into an object: is the `type` one we know, and does the record have every **required field** for that type? A `book` needs a title, an id, an author and pages; a `magazine` needs a title, an id and an issue number. Two dictionaries describe that: `KINDS` maps each type to its class, and `REQUIRED` lists each type's fields. Anything wrong raises `ValueError` with a clear reason, such as `missing author, pages`.\n\nOnly then is the object built: `Book(**fields)`. The `**` turns the dict into keyword arguments, so `Book(**{\"title\": \"Dune\", \"pages\": 412, ...})` means the same as `Book(title=\"Dune\", pages=412, ...)`. Building from the required fields only means an extra field in the file (an `isbn`, say) can't crash the constructor.\n\nThe file itself is **streamed**: a generator such as `numbered_lines(f)` reads one line, hands it over with `yield`, and waits until the next one is asked for. The whole file is never in memory at once, which matters for a catalogue of millions of lines, and a search can stop at the first match without reading the rest.\n\n- `KINDS` (type to class) and `REQUIRED` (type to field names) drive the checks\n- check the type, then the required fields, then build the object\n- `**some_dict` passes a dict's items as keyword arguments\n- a generator with `yield` reads one line at a time; don't call `read()` or `readlines()` first",
        "code": _ITEMS + _PARSE + _NUMBERED + r'''fields = {"title": "Dune", "item_id": "B002", "author": "Frank Herbert", "pages": 412}
print(Book(**fields))

TEXT = (
    '{"type": "book", "title": "Clean Code", "item_id": "B001", "author": "Robert Martin", "pages": 464, "isbn": "9780132350884"}\n'
    '{"type": "magazine", "title": "National Geographic", "item_id": "MG001", "issue": 247}\n'
    '\n'
    '{"type": "dvd", "title": "Heat", "item_id": "D001"}\n'
    '{"type": "book", "title": "Dune", "item_id": "B002"}\n'
    '[1, 2]\n'
)
lines = numbered_lines(io.StringIO(TEXT))
line_no, raw = next(lines)
print("only line", line_no, "has been read so far:", parse_record(raw))
for line_no, raw in lines:
    if not raw:
        continue
    try:
        item = parse_record(raw)
        print(line_no, "ok:", type(item).__name__, item.item_id)
    except ValueError as e:
        print(line_no, "rejected:", e)
''',
        "walkthrough": [
            ["KINDS = {\"book\": Book, \"magazine\": Magazine}", "Maps the `type` written in the file to the class to build. Magazine ids start with `MG`, so they never clash with member ids like `M001`."],
            ["REQUIRED = {", "The fields each type must have. Checking them first gives a clear reason (`missing pages`) instead of a confusing crash."],
            ["    if not isinstance(data, dict):", "`[1, 2]` is valid JSON but not a record, so it is rejected."],
            ["    if kind not in KINDS:\n        raise ValueError(f\"unknown type {kind!r}\")", "A `dvd`, or a line with no `type` at all, is rejected with a reason."],
            ["    missing = [name for name in REQUIRED[kind] if name not in data]", "Every required field that isn't in the record, in a list. An empty list means nothing is missing."],
            ["    return KINDS[kind](**{name: data[name] for name in REQUIRED[kind]})", "Build a dict of just the required fields, then `**` turns that dict into keyword arguments for the class. Extra fields such as `isbn` are left out, so they can't crash it."],
            ["print(Book(**fields))", "The same `**` on its own: `Book(**fields)` is `Book(title=\"Dune\", item_id=\"B002\", author=\"Frank Herbert\", pages=412)`."],
            ["def numbered_lines(f):\n    for line_no, raw in enumerate(f, start=1):\n        yield line_no, raw.strip()", "A generator: each `yield` hands over one numbered line and pauses. Looping over a file reads line by line, so the whole file is never loaded."],
            ["line_no, raw = next(lines)", "`next` asks the generator for one line. At this point only the first line of the file has been read. Its extra `isbn` field is simply left out of the Book."],
            ["for line_no, raw in lines:", "The `for` loop carries on from where `next` stopped, pulling the remaining lines one at a time."],
        ],
        "mistakes": [
            "Building the object straight from the whole dict (`Book(**data)`): the `type` key, or any extra field, raises a TypeError. Pass only the required fields.",
            "Checking fields with `data[\"pages\"]` before checking it exists: a missing field raises KeyError instead of a clear ValueError.",
            "Forgetting that `[1, 2]` or `\"book\"` are valid JSON: check `isinstance(data, dict)` before calling `.get`.",
            "Reading the whole file with `f.read()` or `readlines()` before parsing: fine for a small file, too much memory for a large one. Loop over the file inside a generator.",
            "Returning a list from `numbered_lines` instead of using `yield`: everything is read up front, and a search can't stop early.",
        ],
        "local": [
            {
                "title": "Streaming a real file, and table tests for parse_record",
                "note": "The generator opens the path with `with`, so the file is closed when the loop ends (or the generator is dropped). The invalid records make a good `parametrize` table.",
                "code": r'''# bookvault/loader.py
def numbered_lines(path):
    with open(path, encoding="utf-8") as f:
        for line_no, raw in enumerate(f, start=1):
            yield line_no, raw.strip()


# tests/test_parse.py
import pytest
from bookvault.loader import numbered_lines, parse_record


@pytest.mark.parametrize("raw", [
    "BAD JSON",
    '{"type": "dvd", "title": "Heat", "item_id": "D001"}',
    '{"type": "book", "title": "Dune", "item_id": "B002"}',
    "[1, 2]",
])
def test_parse_record_rejects(raw):
    with pytest.raises(ValueError):
        parse_record(raw)


def test_reads_one_line_at_a_time(tmp_path):
    path = tmp_path / "books.jsonl"
    path.write_text('{"a": 1}\n{"b": 2}\n', encoding="utf-8")
    lines = numbered_lines(path)
    assert next(lines) == (1, '{"a": 1}')
''',
                "output": r'''$ pytest -v tests/test_parse.py
collected 5 items

tests/test_parse.py::test_parse_record_rejects[BAD JSON] PASSED          [ 20%]
tests/test_parse.py::test_parse_record_rejects[{"type": "dvd", "title": "Heat", "item_id": "D001"}] PASSED [ 40%]
tests/test_parse.py::test_parse_record_rejects[{"type": "book", "title": "Dune", "item_id": "B002"}] PASSED [ 60%]
tests/test_parse.py::test_parse_record_rejects[[1, 2]] PASSED            [ 80%]
tests/test_parse.py::test_reads_one_line_at_a_time PASSED                [100%]

============================== 5 passed in 0.03s ==============================''',
            },
        ],
        "challenge": {
            "task": "Write `parse_record(raw)` that returns a `Book` or `Magazine` and raises `ValueError` for anything wrong:\n- `data = json.loads(raw)` (bad JSON already raises a ValueError); if `data` isn't a dict, raise `ValueError`\n- if `data.get(\"type\")` isn't a key of `KINDS`, raise `ValueError` (unknown type)\n- if any name in `REQUIRED[kind]` is missing from `data`, raise `ValueError` naming them\n- otherwise build `KINDS[kind]` from the required fields only, using `**`, so extra fields are ignored",
            "hints": [
                "`kind = data.get(\"type\")`, then `missing = [name for name in REQUIRED[kind] if name not in data]` and `if missing: raise ValueError(...)`.",
                "Build it with `return KINDS[kind](**{name: data[name] for name in REQUIRED[kind]})`.",
            ],
            "starter": _ITEMS + r'''def parse_record(raw):
    ...

print(parse_record('{"type": "magazine", "title": "National Geographic", "item_id": "MG001", "issue": 247}'))
for bad in ['BAD JSON', '{"type": "dvd", "title": "Heat", "item_id": "D001"}', '{"type": "book", "title": "Dune", "item_id": "B002"}']:
    try:
        parse_record(bad)
        print("accepted (wrong!):", bad)
    except ValueError as e:
        print("rejected:", bad[:30])
''',
            "solution": _ITEMS + _PARSE + r'''print(parse_record('{"type": "magazine", "title": "National Geographic", "item_id": "MG001", "issue": 247}'))
for bad in ['BAD JSON', '{"type": "dvd", "title": "Heat", "item_id": "D001"}', '{"type": "book", "title": "Dune", "item_id": "B002"}']:
    try:
        parse_record(bad)
        print("accepted (wrong!):", bad)
    except ValueError as e:
        print("rejected:", bad[:30])
''',
            "tests": r'''_b = parse_record('{"type": "book", "title": "Clean Code", "item_id": "B001", "author": "Robert Martin", "pages": 464}')
assert isinstance(_b, Book) and _b.item_id == "B001" and _b.pages == 464, "a book line should become a Book"
_m = parse_record('{"type": "magazine", "title": "National Geographic", "item_id": "MG001", "issue": 247}')
assert isinstance(_m, Magazine) and _m.issue == 247, "a magazine line should become a Magazine"
try:
    _x = parse_record('{"type": "book", "title": "Dune", "item_id": "B002", "author": "Frank Herbert", "pages": 412, "isbn": "9780441013593"}')
except Exception as _e:
    raise AssertionError(f"an extra field such as isbn should be ignored, but parse_record raised {type(_e).__name__}")
assert isinstance(_x, Book) and _x.title == "Dune", "an extra field such as isbn should be ignored"
for _bad, _why in [("BAD JSON HERE", "bad JSON"), ('{"type": "dvd", "title": "Heat", "item_id": "D001"}', "an unknown type"),
                   ('{"title": "No Type", "item_id": "B009"}', "a missing type"), ('{"type": "book", "title": "Dune", "item_id": "B002"}', "missing author and pages"),
                   ('{"type": "magazine", "title": "Wired", "item_id": "MG002"}', "a magazine with no issue"), ("[1, 2, 3]", "JSON that isn't an object")]:
    try:
        parse_record(_bad)
    except ValueError:
        continue
    except Exception as _e:
        raise AssertionError(f"{_why} should raise ValueError, not {type(_e).__name__}")
    raise AssertionError(f"{_why} should raise ValueError, but parse_record returned a value")''',
        },
        "practice": [
            {
                "task": "Streaming. Right now `numbered_lines` reads the **whole** file with `readlines()` before giving back anything. Rewrite it as a generator: `for line_no, raw in enumerate(f, start=1):` and `yield line_no, raw.strip()`, so it reads one line at a time.\n\nThen finish `first_bad_line(f)`: using `numbered_lines`, return the number of the first non-blank line that isn't valid JSON (catch `json.JSONDecodeError`), or `None` if there is none. Because the generator is lazy, the lines after the bad one are never even read.",
                "hints": [
                    "A generator function has `yield` inside its loop and no `return` of a list: delete the `readlines()` line.",
                    "In `first_bad_line`: `if not raw: continue`, then `try: json.loads(raw)` and `except json.JSONDecodeError: return line_no`.",
                ],
                "starter": r'''import io
import json

def numbered_lines(f):
    lines = f.readlines()        # reads the WHOLE file into memory first
    return [(n, line.strip()) for n, line in enumerate(lines, start=1)]

def first_bad_line(f):
    for line_no, raw in numbered_lines(f):
        pass                     # find the first line that isn't valid JSON
    return None

TEXT = '{"id": "B001"}\n\n{"id": "MG001"}\nBAD JSON HERE\n{"id": "B002"}\n'
print(first_bad_line(io.StringIO(TEXT)))
''',
                "solution": r'''import io
import json

def numbered_lines(f):
    for line_no, raw in enumerate(f, start=1):
        yield line_no, raw.strip()

def first_bad_line(f):
    for line_no, raw in numbered_lines(f):
        if not raw:
            continue
        try:
            json.loads(raw)
        except json.JSONDecodeError:
            return line_no
    return None

TEXT = '{"id": "B001"}\n\n{"id": "MG001"}\nBAD JSON HERE\n{"id": "B002"}\n'
print(first_bad_line(io.StringIO(TEXT)))
''',
                "tests": r'''class _Spy:
    def __init__(self, lines):
        self.lines = lines
        self.pulled = 0
    def __iter__(self):
        return self
    def __next__(self):
        if self.pulled >= len(self.lines):
            raise StopIteration
        self.pulled += 1
        return self.lines[self.pulled - 1]
    def readlines(self):
        return list(self)
_s = _Spy(['{"id": 1}\n', "\n", "  x  \n"])
_g = numbered_lines(_s)
assert _s.pulled == 0, "numbered_lines should be a generator (use yield): nothing should be read until the first line is asked for"
assert next(_g) == (1, '{"id": 1}'), "the first item should be (1, the stripped first line)"
assert _s.pulled == 1, "read one line at a time: after the first item only one line should have been read (loop over f, don't call readlines())"
assert list(_g) == [(2, ""), (3, "x")], "yield every line, numbered from 1 and stripped, blank ones included"
_s2 = _Spy(['{"a": 1}\n', "\n", "oops\n", '{"b": 2}\n', "more junk\n"])
assert first_bad_line(_s2) == 3, "first_bad_line should return 3 for a file whose third line is bad"
assert _s2.pulled == 3, f"first_bad_line should stop reading at the bad line, but it read {_s2.pulled} lines"
assert first_bad_line(_Spy(['{"a": 1}\n', "\n", "[2]\n"])) is None, "a file with no bad JSON should give None (blank lines are not errors)"''',
            },
        ],
    },
]

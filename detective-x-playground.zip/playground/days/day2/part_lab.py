"""Day 2 · Lab Technician: Academy lessons (lab-briefing ... structured-logging).

Same lesson format as lessons.py describes. `part` is set by lessons.py, so leave it out here.
Check with:  python engine/build_game.py --day day2 --no-write

Browser notes: the VS Code debugger can't run in the page, so the debugger lessons rebuild each panel
with tiny helpers (`pause`, a call-stack decorator, a recorded list of steps) and show the real thing
on `local` cards. Logging runs in the page: every demo and test uses its own named logger with
`propagate = False`, clears old handlers first and writes to an `io.StringIO`, because the logging
module (and the root logger) keeps its state between runs.
"""

# A test-only handler that keeps every log record, so tests can look at levels, messages and extra fields.
_KEEP = '''import logging as _lg
class _Keep(_lg.Handler):
    def __init__(self):
        super().__init__()
        self.records = []
    def emit(self, record):
        self.records.append(record)

def _fresh(name, level=_lg.DEBUG):
    _logger = _lg.getLogger(name)
    _logger.handlers.clear()
    _logger.propagate = False
    _logger.setLevel(level)
    _keep = _Keep()
    _logger.addHandler(_keep)
    return _logger, _keep
'''

LESSONS = [
    # ------------------------------------------------------------------ lab-briefing
    {
        "id": "lab-briefing",
        "title": "Welcome to the Forensics Lab",
        "slides": "1-3, 49-52",
        "idea": "Day 2 turns Python that *works* into Python you can **prove** works: **production Python**. On Day 1 you built BookVault; today you learn the tools that show what really happened inside it.\n\nEvery Day 1 pain gets a tool. You debug with `print()`, so you learn the **debugger**. You can't see what happened on a server, so you learn **logging**. You're scared to change code, so you learn **tests** (pytest). Importing 1,000 book covers is slow, so you learn **concurrency** (threads, processes, async). Network calls fail now and then, so you learn **retries**.\n\nThe Lab has three chapters: **Lab Technician** (VS Code, the debugger, logging), **Forensic Examiner** (tests, fakes, coverage) and **Task Force** (concurrency, async, retries). Each one is exactly what GenAI engineers use from Day 3 on: you'll step through LangChain chains in the debugger, test LLM code with fake models, and send many LLM calls at once.\n\n- Production Python means code other people can run, change and debug.\n- Each Day 2 tool fixes a pain you hit on Day 1.\n- The debugger is for while the code runs on your machine; logs are what you have after it ships.\n- \"The best engineers write code others can debug at 3 AM.\"",
        "predict": {
            "q": "BookVault crashed on the server at 3 AM. Nobody was watching. What can you still look at the next morning?",
            "options": [
                "The debugger's Variables panel",
                "The `print()` calls you deleted before shipping",
                "The log lines the program wrote",
                "Nothing: the crash is lost",
            ],
            "answer": 2,
            "why": "The debugger only helps while you are watching the program run on your own machine. Logs are written down as the program runs, so they are still there after it crashed. That's why this chapter teaches both.",
        },
        "code": '''# Day 1 left these pains. Day 2 gives each one a tool.
pains = {
    "I debug with print()": "the VS Code debugger",
    "I can't see what happened on the server": "structured logging",
    "I'm scared to change working code": "pytest tests",
    "Importing 1000 covers takes forever": "concurrency",
    "Flaky network calls crash my import": "retries with backoff",
}
for pain, tool in pains.items():
    print(f"{pain:<42} -> {tool}")

print()
chapters = [
    ("Lab Technician", "VS Code, debugger, logging"),
    ("Forensic Examiner", "pytest, fixtures, fakes, coverage"),
    ("Task Force", "threads, processes, async, retries"),
]
for number, (name, topics) in enumerate(chapters, start=4):
    print(f"Chapter {number}: {name} - {topics}")
''',
        "walkthrough": [
            ["pains = {", "A dictionary from each Day 1 pain to the Day 2 tool that fixes it."],
            ["for pain, tool in pains.items():", "`.items()` gives each key and value together."],
            ['    print(f"{pain:<42} -> {tool}")', "`:<42` pads the pain to 42 characters, so the arrows line up in a column."],
            ["chapters = [", "A list of (name, topics) tuples: the three chapters of the Lab, in order."],
            ["for number, (name, topics) in enumerate(chapters, start=4):", "`enumerate(..., start=4)` counts 4, 5, 6 (Day 1 had chapters 1 to 3). The brackets unpack each tuple into `name` and `topics`."],
        ],
        "mistakes": [
            "Thinking the debugger replaces logging. The debugger is for your own machine; logs are for code that already shipped.",
            "Skipping the setup lessons. A wrongly set up editor causes confusing bugs all day.",
        ],
        "challenge": {
            "task": "Write `tool_for(problem)`. It looks through the `KEYWORDS` dictionary and returns the tool for the **first** keyword that appears in `problem` (ignore upper/lower case). If no keyword appears, return `\"ask your trainer\"`.",
            "hints": [
                "Loop with `for keyword, tool in KEYWORDS.items():` and test `keyword in problem.lower()`.",
                "Inside the loop: `if keyword in problem.lower(): return tool`. After the loop: `return \"ask your trainer\"`.",
            ],
            "starter": '''KEYWORDS = {
    "print": "the debugger",
    "server": "logging",
    "refactor": "tests",
    "slow": "concurrency",
    "flaky": "retries",
}

def tool_for(problem):
    return "ask your trainer"

print(tool_for("My import is SLOW"))
print(tool_for("I want to refactor the loader"))
print(tool_for("My cat ate the keyboard"))
''',
            "solution": '''KEYWORDS = {
    "print": "the debugger",
    "server": "logging",
    "refactor": "tests",
    "slow": "concurrency",
    "flaky": "retries",
}

def tool_for(problem):
    for keyword, tool in KEYWORDS.items():
        if keyword in problem.lower():
            return tool
    return "ask your trainer"

print(tool_for("My import is SLOW"))
print(tool_for("I want to refactor the loader"))
print(tool_for("My cat ate the keyboard"))
''',
            "tests": '''assert tool_for("My import is SLOW") == "concurrency", "tool_for('My import is SLOW') should be 'concurrency': compare in lower case"
assert tool_for("I keep adding print calls") == "the debugger", "a problem with 'print' in it should give 'the debugger'"
assert tool_for("The API is flaky") == "retries", "a problem with 'flaky' in it should give 'retries'"
assert tool_for("What happened on the SERVER?") == "logging", "a problem with 'server' in it should give 'logging'"
assert tool_for("The server is slow") == "logging", "'server' comes before 'slow' in KEYWORDS: return the tool for the first keyword in KEYWORDS order"
assert tool_for("Flaky and slow") == "concurrency", "'slow' comes before 'flaky' in KEYWORDS: return the tool for the first keyword in KEYWORDS order"
assert tool_for("My cat ate the keyboard") == "ask your trainer", "when no keyword matches, return 'ask your trainer'"''',
        },
        "practice": [
            {
                "task": "The Day 2 timetable lists each section and its minutes. Write `total_hours(schedule)` that returns the total time in hours (minutes / 60), and `longest(schedule)` that returns the **name** of the longest section.",
                "hints": [
                    "Add up the minutes with a loop or `sum(minutes for name, minutes in schedule)`. For the longest, `max` takes a `key=`.",
                    "`return sum(m for n, m in schedule) / 60` and `return max(schedule, key=lambda s: s[1])[0]`.",
                ],
                "starter": '''schedule = [("VS Code", 45), ("Debugging", 45), ("Pytest", 90), ("Concurrency", 150)]

def total_hours(schedule):
    return 0

def longest(schedule):
    return ""

print(total_hours(schedule), longest(schedule))
''',
                "solution": '''schedule = [("VS Code", 45), ("Debugging", 45), ("Pytest", 90), ("Concurrency", 150)]

def total_hours(schedule):
    return sum(minutes for name, minutes in schedule) / 60

def longest(schedule):
    return max(schedule, key=lambda section: section[1])[0]

print(total_hours(schedule), longest(schedule))
''',
                "tests": '''assert total_hours(schedule) == 5.5, f"the Day 2 sections add up to 330 minutes = 5.5 hours, got {total_hours(schedule)!r}"
assert total_hours([("A", 30), ("B", 30)]) == 1, "total_hours([('A', 30), ('B', 30)]) should be 1"
assert longest(schedule) == "Concurrency", f"the longest section is Concurrency, got {longest(schedule)!r}"
assert longest([("A", 10), ("B", 99), ("C", 5)]) == "B", "longest should return the NAME of the section with the most minutes"''',
            },
            {
                "task": "Every Day 2 tool has a GenAI use from Day 3 on (`BRIDGE`). Write `genai_uses(learned)`: for each tool name in the list `learned`, in order, add its GenAI use to a new list. Skip names that aren't in `BRIDGE`. Return the list.",
                "hints": [
                    "Loop over `learned` and check `if tool in BRIDGE:` before you look it up.",
                    "`return [BRIDGE[tool] for tool in learned if tool in BRIDGE]`",
                ],
                "starter": '''BRIDGE = {
    "debugger": "step through a LangChain chain",
    "mocks": "test LLM code with a fake model",
    "parametrize": "check 50 prompts in one test run",
    "threads": "embed 10,000 documents at once",
    "semaphore": "stay under an API's concurrency limit",
}

def genai_uses(learned):
    return []

print(genai_uses(["debugger", "mocks", "knitting"]))
''',
                "solution": '''BRIDGE = {
    "debugger": "step through a LangChain chain",
    "mocks": "test LLM code with a fake model",
    "parametrize": "check 50 prompts in one test run",
    "threads": "embed 10,000 documents at once",
    "semaphore": "stay under an API's concurrency limit",
}

def genai_uses(learned):
    return [BRIDGE[tool] for tool in learned if tool in BRIDGE]

print(genai_uses(["debugger", "mocks", "knitting"]))
''',
                "tests": '''assert genai_uses(["debugger", "mocks", "knitting"]) == [BRIDGE["debugger"], BRIDGE["mocks"]], "genai_uses should return the uses in order and skip unknown tools"
assert genai_uses(["semaphore", "threads"]) == [BRIDGE["semaphore"], BRIDGE["threads"]], "keep the order of the list you were given"
assert genai_uses([]) == [], "an empty list should give an empty list"''',
            },
        ],
    },
    # ------------------------------------------------------------------ vscode-setup
    {
        "id": "vscode-setup",
        "title": "VS Code as your lab bench",
        "slides": "4-8",
        "idea": "VS Code becomes a full **IDE** (an editor with a debugger, test runner and checker built in) once you add five **extensions**: **Python** (`ms-python.python`: run, debug, test, pick the interpreter), **Pylance** (`ms-python.vscode-pylance`: smart completion and type errors as you type), **Ruff** (`charliermarsh.ruff`: finds mistakes and formats your code on save), **Even Better TOML** (`tamasfe.even-better-toml`: colours `pyproject.toml`) and **GitLens** (`eamodio.gitlens`: who changed this line, and when).\n\nProject settings live in **`.vscode/settings.json`**, a JSON file you commit with the project so the whole team gets the same setup. The most important line is `python.defaultInterpreterPath`: the **interpreter** is the `python` program that runs your code. It must be the one inside the project's `.venv` (Day 1): `.venv\\Scripts\\python.exe` on Windows, `.venv/bin/python` on macOS and Linux.\n\nWhy it matters: if VS Code uses a *different* Python, you `pip install` a package into `.venv` but the code runs elsewhere and says `ModuleNotFoundError`, or tests pass in the terminal and fail in the editor. Always check which Python is running: `import sys; print(sys.executable)` prints its path.\n\n- Five extensions: Python, Pylance, Ruff, Even Better TOML, GitLens.\n- `.vscode/settings.json`: interpreter path, `typeCheckingMode: basic`, `formatOnSave: true`, `pytestEnabled: true`.\n- Interpreter: `.venv\\Scripts\\python.exe` (Windows) or `.venv/bin/python` (macOS/Linux). `sys.executable` tells you which one runs.\n- Keys: Ctrl+Shift+P command palette, Ctrl+P open file, F12 go to definition, F2 rename, F5 debug, F9 breakpoint (Cmd on a Mac).",
        "predict": {
            "q": "You ran `pip install requests` in your project's `.venv`. VS Code still says `ModuleNotFoundError: No module named 'requests'`. What is the most likely cause?",
            "options": [
                "`requests` is not a real package",
                "VS Code is running a different Python interpreter, not the one in `.venv`",
                "You need to restart your computer",
                "Python can't import packages in VS Code",
            ],
            "answer": 1,
            "why": "Each interpreter has its own packages. The package went into `.venv`, but VS Code runs another Python that never got it. Pick the `.venv` interpreter (Ctrl+Shift+P, then *Python: Select Interpreter*) or set `python.defaultInterpreterPath`.",
        },
        "code": r'''import json

def in_venv(path):
    folders = path.replace("\\", "/").split("/")
    return ".venv" in folders

# What sys.executable printed on each detective's machine
reports = {
    "Asha (Windows)": r"C:\work\bookvault\.venv\Scripts\python.exe",
    "Ravi (Windows)": r"C:\Users\ravi\AppData\Local\Programs\Python\Python312\python.exe",
    "Meera (macOS)": "/Users/meera/bookvault/.venv/bin/python",
    "Dev (Linux)": "/usr/bin/python3",
}
for who, path in reports.items():
    verdict = "project venv" if in_venv(path) else "WRONG interpreter"
    print(f"{who:<15} {verdict}")

settings = json.loads("""{
    "python.defaultInterpreterPath": ".venv/bin/python",
    "python.analysis.typeCheckingMode": "basic",
    "editor.formatOnSave": true,
    "python.testing.pytestEnabled": true
}""")
print(settings["editor.formatOnSave"], settings["python.analysis.typeCheckingMode"])
''',
        "walkthrough": [
            ['    folders = path.replace("\\\\", "/").split("/")', "Windows paths use backslashes, macOS and Linux use forward slashes. Turning every `\\` into `/` lets one `split` break any path into its folder names."],
            ['    return ".venv" in folders', "The interpreter is the project's only if one of the folders on its path is exactly `.venv`."],
            ['    "Asha (Windows)": r"C:\\work\\bookvault\\.venv\\Scripts\\python.exe",', "The `r` in front makes a **raw string**: backslashes stay as typed. On Windows the venv's Python is in `.venv\\Scripts\\python.exe`."],
            ['    "Ravi (Windows)": r"C:\\Users\\ravi\\AppData\\Local\\Programs\\Python\\Python312\\python.exe",', "This is the Python installed for the whole computer. Packages installed into the project's `.venv` are invisible to it."],
            ['settings = json.loads("""{', "`settings.json` is plain JSON, so `json.loads` (Day 1) reads it. JSON writes `true`, Python shows `True`."],
            ['print(settings["editor.formatOnSave"], settings["python.analysis.typeCheckingMode"])', "Keys in settings.json contain dots, but they are ordinary dictionary keys: the whole text is one key."],
        ],
        "mistakes": [
            "Leaving VS Code on the computer's global Python. Check the interpreter in the bottom-right corner of the window, or print `sys.executable`.",
            "Copying the macOS path `.venv/bin/python` onto Windows. Windows venvs keep Python in `.venv\\Scripts\\python.exe` (inside JSON, write each backslash twice: `.venv\\\\Scripts\\\\python.exe`).",
            "Putting settings in your *user* settings only. Project settings go in `.vscode/settings.json` and are committed, so the team shares them.",
            "Adding comments or a trailing comma when you read settings.json with `json.loads`: plain JSON allows neither.",
        ],
        "local": [
            {
                "title": ".vscode/settings.json (Windows version)",
                "note": "Create the folder `.vscode` in your project and put this file in it. On macOS/Linux use `\".venv/bin/python\"` for the first line. Then press Ctrl+Shift+P, run *Python: Select Interpreter* and pick the `.venv` one.",
                "code": '''{
  "python.defaultInterpreterPath": ".venv\\\\Scripts\\\\python.exe",
  "python.analysis.typeCheckingMode": "basic",
  "python.analysis.autoImportCompletions": true,
  "editor.formatOnSave": true,
  "editor.codeActionsOnSave": {
    "source.fixAll": "explicit",
    "source.organizeImports": "explicit"
  },
  "[python]": {
    "editor.defaultFormatter": "charliermarsh.ruff",
    "editor.tabSize": 4,
    "editor.rulers": [88, 100]
  },
  "python.testing.pytestEnabled": true,
  "python.testing.pytestArgs": ["tests"],
  "python.testing.unittestEnabled": false,
  "files.exclude": {
    "**/__pycache__": true,
    "**/.pytest_cache": true,
    "**/*.egg-info": true
  }
}''',
            },
            {
                "title": "Which Python am I running?",
                "note": "Run this in VS Code's terminal (Ctrl+`) with the venv active. The path must end in `.venv\\Scripts\\python.exe` (Windows) or `.venv/bin/python` (macOS/Linux).",
                "code": '''python -c "import sys; print(sys.executable)"''',
                "output": '''C:\\work\\bookvault\\.venv\\Scripts\\python.exe''',
            },
            {
                "title": "Install the five extensions from the terminal",
                "note": "The `code` command comes with VS Code. Or open the Extensions view (Ctrl+Shift+X) and search for each name.",
                "code": '''code --install-extension ms-python.python
code --install-extension ms-python.vscode-pylance
code --install-extension charliermarsh.ruff
code --install-extension tamasfe.even-better-toml
code --install-extension eamodio.gitlens''',
            },
        ],
        "challenge": {
            "task": "Find the detectives whose VS Code runs the wrong Python. Write `find_wrong(reports)`: `reports` maps a name to the path `sys.executable` printed. Use the demo's `in_venv(path)` and return a **sorted** list of the names whose path is **not** inside a `.venv` folder.",
            "needs_demo": True,
            "hints": [
                "Loop over `reports.items()` and keep the names where `not in_venv(path)`.",
                "`return sorted(name for name, path in reports.items() if not in_venv(path))`",
            ],
            "starter": r'''def find_wrong(reports):
    return []

team = {
    "Kiran": r"C:\Python311\python.exe",
    "Asha": r"D:\code\bookvault\.venv\Scripts\python.exe",
    "Bea": "/opt/homebrew/bin/python3",
}
print(find_wrong(team))
''',
            "solution": r'''def find_wrong(reports):
    return sorted(name for name, path in reports.items() if not in_venv(path))

team = {
    "Kiran": r"C:\Python311\python.exe",
    "Asha": r"D:\code\bookvault\.venv\Scripts\python.exe",
    "Bea": "/opt/homebrew/bin/python3",
}
print(find_wrong(team))
''',
            "tests": r'''assert find_wrong(team) == ["Bea", "Kiran"], f"Bea and Kiran use the wrong Python (sorted), got {find_wrong(team)!r}"
assert find_wrong({"Zed": "/home/zed/app/.venv/bin/python"}) == [], "a path inside .venv is the right interpreter"
assert find_wrong({"Lu": "C:\\Tools\\python.exe", "Al": "/usr/bin/python3"}) == ["Al", "Lu"], "return the names sorted alphabetically"''',
        },
        "practice": [
            {
                "task": "Write `venv_python(os_name)`. Python's `os.name` is `\"nt\"` on Windows and `\"posix\"` on macOS and Linux. Return the project interpreter path for that system: `.venv\\Scripts\\python.exe` for `\"nt\"`, otherwise `.venv/bin/python`.",
                "hints": [
                    "Use a raw string for the Windows path, `r\".venv\\Scripts\\python.exe\"`, so the backslashes stay as typed.",
                    "`if os_name == \"nt\": return r\".venv\\Scripts\\python.exe\"` and otherwise `return \".venv/bin/python\"`.",
                ],
                "starter": '''import os

def venv_python(os_name):
    return ".venv/bin/python"

print("On this computer:", venv_python(os.name))
''',
                "solution": r'''import os

def venv_python(os_name):
    if os_name == "nt":
        return r".venv\Scripts\python.exe"
    return ".venv/bin/python"

print("On this computer:", venv_python(os.name))
''',
                "tests": r'''assert venv_python("nt") == ".venv\\Scripts\\python.exe", f"on Windows ('nt') the path is .venv\\Scripts\\python.exe, got {venv_python('nt')!r}"
assert venv_python("posix") == ".venv/bin/python", "on macOS and Linux ('posix') the path is .venv/bin/python"''',
            },
            {
                "task": "Check a teammate's `settings.json`. Write `check_settings(text)`: read the JSON text with `json.loads`, then return a list of every key in `REQUIRED` whose value in the settings is missing or different from the required value (in `REQUIRED`'s order). Return `[]` when all is well.",
                "hints": [
                    "After `settings = json.loads(text)`, use `settings.get(key)`: it gives `None` for a missing key, which never equals the required value.",
                    "`return [key for key, value in REQUIRED.items() if settings.get(key) != value]`",
                ],
                "starter": '''import json

REQUIRED = {
    "python.analysis.typeCheckingMode": "basic",
    "editor.formatOnSave": True,
    "python.testing.pytestEnabled": True,
}

def check_settings(text):
    return []

teammate = """{
    "python.defaultInterpreterPath": ".venv/bin/python",
    "python.analysis.typeCheckingMode": "strict",
    "python.testing.pytestEnabled": true
}"""
print(check_settings(teammate))
''',
                "solution": '''import json

REQUIRED = {
    "python.analysis.typeCheckingMode": "basic",
    "editor.formatOnSave": True,
    "python.testing.pytestEnabled": True,
}

def check_settings(text):
    settings = json.loads(text)
    return [key for key, value in REQUIRED.items() if settings.get(key) != value]

teammate = """{
    "python.defaultInterpreterPath": ".venv/bin/python",
    "python.analysis.typeCheckingMode": "strict",
    "python.testing.pytestEnabled": true
}"""
print(check_settings(teammate))
''',
                "tests": '''assert check_settings(teammate) == ["python.analysis.typeCheckingMode", "editor.formatOnSave"], f"typeCheckingMode is wrong and formatOnSave is missing, got {check_settings(teammate)!r}"
_good = '{"python.analysis.typeCheckingMode": "basic", "editor.formatOnSave": true, "python.testing.pytestEnabled": true}'
assert check_settings(_good) == [], "settings with all three values right should give []"
assert check_settings("{}") == list(REQUIRED), "empty settings are missing every required key"
assert check_settings('{"editor.formatOnSave": false, "python.analysis.typeCheckingMode": "basic", "python.testing.pytestEnabled": true}') == ["editor.formatOnSave"], "formatOnSave set to false is wrong too"''',
            },
            {
                "task": "Fill in your lab kit. `EXTENSIONS` maps each job to the extension id that does it, and `KEYS` maps each action to its Windows shortcut. Replace every `\"?\"` with the right value from the lesson (write keys like `Ctrl+Shift+P`).",
                "hints": [
                    "Look at the five extensions and six keys in the lesson's idea; extension ids look like `publisher.name`, for example `ms-python.python`.",
                    "Keys: command palette `Ctrl+Shift+P`, open a file by name `Ctrl+P`, go to definition `F12`, rename `F2`, start debugging `F5`, toggle breakpoint `F9`.",
                ],
                "starter": '''EXTENSIONS = {
    "run, debug and test Python": "?",
    "smart completion and type errors": "?",
    "lint and format on save": "?",
    "pyproject.toml colours": "?",
    "who changed this line": "?",
}
KEYS = {
    "command palette": "?",
    "open a file by name": "?",
    "go to definition": "?",
    "rename everywhere": "?",
    "start debugging": "?",
    "toggle breakpoint": "?",
}
print(EXTENSIONS)
print(KEYS)
''',
                "solution": '''EXTENSIONS = {
    "run, debug and test Python": "ms-python.python",
    "smart completion and type errors": "ms-python.vscode-pylance",
    "lint and format on save": "charliermarsh.ruff",
    "pyproject.toml colours": "tamasfe.even-better-toml",
    "who changed this line": "eamodio.gitlens",
}
KEYS = {
    "command palette": "Ctrl+Shift+P",
    "open a file by name": "Ctrl+P",
    "go to definition": "F12",
    "rename everywhere": "F2",
    "start debugging": "F5",
    "toggle breakpoint": "F9",
}
print(EXTENSIONS)
print(KEYS)
''',
                "tests": '''_ext = {"run, debug and test Python": "ms-python.python", "smart completion and type errors": "ms-python.vscode-pylance", "lint and format on save": "charliermarsh.ruff", "pyproject.toml colours": "tamasfe.even-better-toml", "who changed this line": "eamodio.gitlens"}
for _job, _id in _ext.items():
    assert EXTENSIONS.get(_job, "").strip().lower() == _id, f"the extension for '{_job}' is not right yet"
_keys = {"command palette": "ctrl+shift+p", "open a file by name": "ctrl+p", "go to definition": "f12", "rename everywhere": "f2", "start debugging": "f5", "toggle breakpoint": "f9"}
for _action, _key in _keys.items():
    assert KEYS.get(_action, "").replace(" ", "").lower() == _key, f"the shortcut for '{_action}' is not right yet"''',
            },
        ],
    },
    # ------------------------------------------------------------------ debugger-basics
    {
        "id": "debugger-basics",
        "title": "The debugger: pause and look",
        "slides": "9-12, 14",
        "idea": "A **debugger** pauses your program in the middle of running, so you can look at every variable and then go on one line at a time. You mark the line to stop at with a **breakpoint**: click left of the line number (a red dot appears) or press **F9**. Press **F5** to start, and the program runs until it reaches the red dot, *before* that line runs.\n\nWhy not `print()`? Prints have to be typed, re-run and deleted, show only what you guessed to print, and the one you forget ships to production. A paused debugger shows everything, with zero code changes.\n\nWhile paused, the Run and Debug side bar has four panels, plus a console:\n- **Variables**: every local (and global) variable and its value right now.\n- **Watch**: expressions you pin, such as `book.available` or `len(loans)`; they are worked out again at every pause.\n- **Call Stack**: how you got here, newest call on top (`late_fee` called by `checkout` called by the main program). Click a line to see that function's variables.\n- **Breakpoints**: every red dot; switch one off without deleting it.\n- **Debug Console**: type any expression to evaluate it, or even change a variable to test a theory.\n\nThe four step keys: **F5** continue (run to the next breakpoint), **F10** step over (run this line; if it calls a function, run the whole call without stopping inside), **F11** step into (go inside the function this line calls), **Shift+F11** step out (finish this function and stop back in the caller).\n\nThe debugger can't run inside this page, so the demo rebuilds the Variables and Call Stack panels with small helpers (the practice builds Watch and the step keys). The card at the bottom shows the real thing.",
        "predict": {
            "q": "The debugger is paused on `fee = late_fee(days)` inside `checkout`. You press **F10** (step over). Where does it pause next?",
            "options": [
                "On the first line inside `late_fee`",
                "On the next line of `checkout`, with `fee` already set",
                "At the end of the program",
                "Back at the first line of `checkout`",
            ],
            "answer": 1,
            "why": "Step over runs the whole line, including the call to `late_fee`, and stops on the next line of the same function. F11 (step into) would have stopped inside `late_fee`.",
        },
        "code": '''STACK = []                                     # the Call Stack panel

def on_stack(func):
    def wrapper(*args):
        STACK.append(func.__name__)            # entering the function
        result = func(*args)
        STACK.pop()                            # leaving it again
        return result
    return wrapper

def pause(where, **variables):                 # a breakpoint: look, change nothing
    print(f"PAUSED at {where}")
    print("  Call Stack:", " > ".join(STACK))
    for name, value in variables.items():
        print(f"  Variables: {name} = {value!r}")

@on_stack
def late_fee(days):
    rate = 2.5
    pause("late_fee", days=days, rate=rate)
    return days * rate

@on_stack
def checkout(member_id, days):
    fee = late_fee(days)
    return f"{member_id} owes {fee}"

print(checkout("M001", 4))
''',
        "walkthrough": [
            ["STACK = []                                     # the Call Stack panel", "A list that holds the names of the functions running right now, oldest first."],
            ["def on_stack(func):", "A decorator (Day 1) that wraps a function so the stack knows when it starts and ends."],
            ["        STACK.append(func.__name__)            # entering the function", "Push the function's name when it starts..."],
            ["        STACK.pop()                            # leaving it again", "...and pop it when it returns. That is exactly what the Call Stack panel tracks."],
            ["def pause(where, **variables):                 # a breakpoint: look, change nothing", "Our stand-in for a breakpoint. `**variables` collects keyword arguments into a dictionary, like the Variables panel."],
            ['    print("  Call Stack:", " > ".join(STACK))', "Shows how we got here: `checkout > late_fee` means `checkout` called `late_fee`."],
            ['        print(f"  Variables: {name} = {value!r}")', "`!r` shows the value the way Python would type it (text gets quotes), like the debugger does."],
            ['    pause("late_fee", days=days, rate=rate)', "The program \"pauses\" here: we see the panels, then it carries on unchanged."],
        ],
        "mistakes": [
            "Expecting the breakpoint line to have run already. The debugger stops *before* the marked line, so a variable set on that line doesn't exist yet: press F10 once.",
            "Pressing F11 on every line. You end up deep inside library code; use F10 for calls you trust and Shift+F11 to climb back out.",
            "Pressing F5 to step. F5 runs on to the next breakpoint (or to the end), so you can fly past the bug.",
            "Forgetting the Call Stack. When a value is wrong, click the caller's line in the Call Stack to see where it came from.",
        ],
        "local": [
            {
                "title": "Pause the real program in VS Code",
                "note": "Save this as `fees.py`. Click left of line 3 (`return days * rate`) to add a red dot, press F5 and choose *Python Debugger: Debug Python File*. In the Watch panel click **+** and type `days * rate`. The side bar then shows the panels below (your panel may look slightly different). In the Debug Console type `days * rate` and press Enter, then press F10 a few times and watch the yellow line move.",
                "code": '''def late_fee(days):
    rate = 2.5
    return days * rate

def checkout(member_id, days):
    fee = late_fee(days)
    return f"{member_id} owes {fee}"

print(checkout("M001", 4))''',
                "output": '''VARIABLES
  Locals
    days: 4
    rate: 2.5
WATCH
  days * rate: 10.0
CALL STACK
  late_fee     fees.py  3
  checkout     fees.py  6
  <module>     fees.py  9
DEBUG CONSOLE
  > days * rate
  10.0''',
            },
        ],
        "challenge": {
            "task": "Write the Variables panel. `pause(where, **variables)` must print `PAUSED at <where>`, then one line per variable: two spaces, the name, ` = `, and the value shown with `repr` (so text keeps its quotes). For example `pause(\"late_fee\", days=4, title=\"Dune\")` prints:\n\n```\nPAUSED at late_fee\n  days = 4\n  title = 'Dune'\n```",
            "hints": [
                "`variables` is a dictionary: loop over `variables.items()`.",
                "`print(f\"PAUSED at {where}\")`, then in the loop `print(f\"  {name} = {value!r}\")`.",
            ],
            "starter": '''def pause(where, **variables):
    print("paused")

pause("late_fee", days=4, title="Dune")
''',
            "solution": '''def pause(where, **variables):
    print(f"PAUSED at {where}")
    for name, value in variables.items():
        print(f"  {name} = {value!r}")

pause("late_fee", days=4, title="Dune")
''',
            "tests": '''import contextlib as _cl, io as _io
_buf = _io.StringIO()
with _cl.redirect_stdout(_buf):
    pause("late_fee", days=4, title="Dune")
assert _buf.getvalue() == "PAUSED at late_fee\\n  days = 4\\n  title = 'Dune'\\n", f"pause printed {_buf.getvalue()!r}"
_buf = _io.StringIO()
with _cl.redirect_stdout(_buf):
    pause("borrow", member_id="M001", available=False, loans=[1, 2])
assert _buf.getvalue() == "PAUSED at borrow\\n  member_id = 'M001'\\n  available = False\\n  loans = [1, 2]\\n", f"with other variables pause printed {_buf.getvalue()!r}"''',
        },
        "practice": [
            {
                "task": "Build the Call Stack panel. Finish the decorator `on_stack(func)`: its wrapper must add `func.__name__` to the end of `STACK` before calling `func`, remove it again after the call, and return the function's result.",
                "hints": [
                    "Inside `wrapper(*args)`: `STACK.append(func.__name__)`, then `result = func(*args)`, then `STACK.pop()`.",
                    "Don't forget `return result` at the end of `wrapper`, and `return wrapper` at the end of `on_stack`.",
                ],
                "starter": '''STACK = []

def on_stack(func):
    return func

@on_stack
def late_fee(days):
    print("Call Stack:", " > ".join(STACK))
    return days * 2.5

@on_stack
def checkout(days):
    return late_fee(days)

print(checkout(4))
''',
                "solution": '''STACK = []

def on_stack(func):
    def wrapper(*args):
        STACK.append(func.__name__)
        result = func(*args)
        STACK.pop()
        return result
    return wrapper

@on_stack
def late_fee(days):
    print("Call Stack:", " > ".join(STACK))
    return days * 2.5

@on_stack
def checkout(days):
    return late_fee(days)

print(checkout(4))
''',
                "tests": '''_seen = []
@on_stack
def _inner(x):
    _seen.append(list(STACK))
    return x * 2
@on_stack
def _outer(x):
    return _inner(x) + 1
STACK.clear()
assert _outer(5) == 11, "the wrapper must return the function's result"
assert _seen == [["_outer", "_inner"]], f"inside _inner the stack should be ['_outer', '_inner'], got {_seen!r}"
assert STACK == [], "after the calls finish, STACK should be empty again: pop the name when the function returns"''',
            },
            {
                "task": "Build the Watch panel. Write `watch_values(watch, variables)`: `watch` maps a label to a function that takes the variables dictionary. Return a new dictionary from each label to its computed value. Like VS Code, a broken watch must not crash: if computing raises an error, store `\"<ErrorName>\"` instead (for example `\"<KeyError>\"`).",
                "hints": [
                    "Loop over `watch.items()`; inside, use `try: result[label] = compute(variables)` and `except Exception as e:`.",
                    "In the `except`, store `f\"<{type(e).__name__}>\"`.",
                ],
                "starter": '''def watch_values(watch, variables):
    return {}

watch = {
    "days > 3": lambda v: v["days"] > 3,
    "fee": lambda v: v["days"] * v["rate"],
    "member": lambda v: v["member_id"],
}
print(watch_values(watch, {"days": 4, "rate": 2.5}))
''',
                "solution": '''def watch_values(watch, variables):
    result = {}
    for label, compute in watch.items():
        try:
            result[label] = compute(variables)
        except Exception as e:
            result[label] = f"<{type(e).__name__}>"
    return result

watch = {
    "days > 3": lambda v: v["days"] > 3,
    "fee": lambda v: v["days"] * v["rate"],
    "member": lambda v: v["member_id"],
}
print(watch_values(watch, {"days": 4, "rate": 2.5}))
''',
                "tests": '''_w = {"days > 3": lambda v: v["days"] > 3, "fee": lambda v: v["days"] * v["rate"]}
assert watch_values(_w, {"days": 4, "rate": 2.5}) == {"days > 3": True, "fee": 10.0}, "watch_values should compute every label from the variables"
assert watch_values(_w, {"days": 1, "rate": 2.0}) == {"days > 3": False, "fee": 2.0}, "the watches must be worked out again with the new variables"
assert watch_values(_w, {"days": 1}) == {"days > 3": False, "fee": "<KeyError>"}, "a watch that raises should show '<KeyError>' and not crash the others"
assert watch_values({"x": lambda v: 1 / 0}, {}) == {"x": "<ZeroDivisionError>"}, "use the error's class name: '<ZeroDivisionError>'"''',
            },
            {
                "task": "Learn the step keys. `steps` is a recording of every line the debugger could pause on, in order, as `(depth, function, line)`; depth 1 means \"inside a function that depth 0 called\". `step_into` (F11) is done: it goes to the very next index. Write `step_over(steps, i)` (F10): the next index whose depth is **the same or smaller** than the depth at `i`. Write `step_out(steps, i)` (Shift+F11): the next index whose depth is **smaller**. Write `continue_to(steps, i, breakpoints)` (F5): `breakpoints` maps a line's text to `True` (enabled) or `False` (switched off), like the Breakpoints panel; return the next index after `i` whose line has an **enabled** breakpoint, or `len(steps)` when there is none (the program runs to the end). Then fill `KEYS` to map `\"F5\"`, `\"F10\"`, `\"F11\"` and `\"Shift+F11\"` to the four functions.",
                "hints": [
                    "Remember `depth = steps[i][0]`, move on with `i += 1`, and keep moving while the depth at `i` is too deep.",
                    "step_over: `while steps[i][0] > depth: i += 1`. step_out: `while steps[i][0] >= depth: i += 1`. continue_to: `i += 1`, then `while i < len(steps) and not breakpoints.get(steps[i][2], False): i += 1`. `KEYS = {\"F5\": continue_to, \"F10\": step_over, \"F11\": step_into, \"Shift+F11\": step_out}`.",
                ],
                "starter": '''steps = [
    (0, "checkout", "days = 5"),
    (0, "checkout", "fee = late_fee(days)"),
    (1, "late_fee", "rate = 2.5"),
    (1, "late_fee", "return days * rate"),
    (0, "checkout", "print(fee)"),
    (0, "checkout", "return fee"),
]

def step_into(steps, i):          # F11: simply the next line, even inside a call
    return i + 1

def step_over(steps, i):          # F10
    return i + 1

def step_out(steps, i):           # Shift+F11
    return i + 1

def continue_to(steps, i, breakpoints):   # F5
    return i + 1

KEYS = {}

print("F10 from line 1 ->", steps[step_over(steps, 1)])
print("F11 from line 1 ->", steps[step_into(steps, 1)])
''',
                "solution": '''steps = [
    (0, "checkout", "days = 5"),
    (0, "checkout", "fee = late_fee(days)"),
    (1, "late_fee", "rate = 2.5"),
    (1, "late_fee", "return days * rate"),
    (0, "checkout", "print(fee)"),
    (0, "checkout", "return fee"),
]

def step_into(steps, i):          # F11: simply the next line, even inside a call
    return i + 1

def step_over(steps, i):          # F10
    depth = steps[i][0]
    i += 1
    while steps[i][0] > depth:
        i += 1
    return i

def step_out(steps, i):           # Shift+F11
    depth = steps[i][0]
    i += 1
    while steps[i][0] >= depth:
        i += 1
    return i

def continue_to(steps, i, breakpoints):   # F5
    i += 1
    while i < len(steps) and not breakpoints.get(steps[i][2], False):
        i += 1
    return i

KEYS = {"F5": continue_to, "F10": step_over, "F11": step_into, "Shift+F11": step_out}

print("F10 from line 1 ->", steps[step_over(steps, 1)])
print("F11 from line 1 ->", steps[step_into(steps, 1)])
''',
                "tests": '''assert step_over(steps, 1) == 4, "F10 on 'fee = late_fee(days)' should run the whole call and stop at index 4 ('print(fee)')"
assert step_into(steps, 1) == 2, "F11 on the call should stop inside late_fee (index 2)"
assert step_over(steps, 2) == 3, "F10 inside late_fee stops on the next line of late_fee (index 3)"
assert step_out(steps, 2) == 4, "Shift+F11 inside late_fee should finish it and stop back in checkout (index 4)"
_s = [(0, "a", "x = 1"), (0, "a", "b()"), (1, "b", "c()"), (2, "c", "y = 2"), (1, "b", "z = 3"), (0, "a", "end")]
assert step_over(_s, 1) == 5 and step_over(_s, 2) == 4, "step_over must skip every deeper line, however deep the calls go"
assert step_out(_s, 3) == 4 and step_out(_s, 2) == 5, "step_out must stop at the first line that is less deep"
_bp = {"rate = 2.5": False, "print(fee)": True}
assert continue_to(steps, 0, _bp) == 4, "F5 should skip the switched-off breakpoint on 'rate = 2.5' and stop at 'print(fee)' (index 4)"
assert continue_to(steps, 0, {"rate = 2.5": True}) == 2, "F5 should stop at the next line with an enabled breakpoint"
assert continue_to(steps, 4, _bp) == len(steps), "with no enabled breakpoint ahead, F5 runs to the end: return len(steps)"
assert continue_to(steps, 0, {}) == len(steps), "with no breakpoints at all, F5 runs to the end"
assert KEYS.get("F5") is continue_to and KEYS.get("F10") is step_over and KEYS.get("F11") is step_into and KEYS.get("Shift+F11") is step_out, "KEYS should map 'F5', 'F10', 'F11' and 'Shift+F11' to continue_to, step_over, step_into and step_out"''',
            },
        ],
    },
    # ------------------------------------------------------------------ conditional-breakpoints
    {
        "id": "conditional-breakpoints",
        "title": "Conditional breakpoints and logpoints",
        "slides": "13-14, 18",
        "idea": "A plain breakpoint in a loop over 5,000 loans pauses 5,000 times. A **conditional breakpoint** pauses only when an expression is true, such as `loan.returned_on is not None` or `isbn == \"B042\"`. Add one by right-clicking a red dot, choosing *Edit Breakpoint* and typing the condition. It's the biggest debugging upgrade you'll learn.\n\nA **logpoint** is a breakpoint that never pauses: it prints a message to the Debug Console, with values put in from curly braces, like `Checking {loan.item_id}`. You get the information of a `print()` without changing the code, so nothing leaks into git. (Python fills `{name}` slots the same way with `\"text {name}\".format(name=value)`.)\n\nThe debugger can't run in this page, so the demo fakes the breakpoint and the logpoint with plain Python: an `if` around a `pause()` call, and a `print`. The second card at the bottom shows the real thing in VS Code.\n\nTo debug the same way every time, save **debug configurations** in `.vscode/launch.json`. Each one has a `name`; `\"request\": \"launch\"` starts a program and `\"attach\"` joins one already running. Use `\"module\": \"bookvault.cli\"` to run it like `python -m bookvault.cli` or `\"program\": \"app.py\"` for a plain script, `\"args\"` for the command-line arguments, and `\"justMyCode\": false` when you want to step into library code too.\n\n**The overdue bug.** BookVault fines patrons for books they already returned. Put a conditional breakpoint on the overdue check with the condition `loan.returned_on is not None`; it pauses on exactly the loans that should never count, and the Variables panel shows `returned_on` is set. The check forgot to ask whether the loan is still out.\n\n- Conditional breakpoint: pause only when the condition is true.\n- Logpoint: print a message with `{values}`, never pause, no code change.\n- launch.json: `name`, `request`, `module` or `program`, `args`, `justMyCode`.\n- Pause and check why a value is wrong before you change code; fix the cause, not the symptom.",
        "predict": {
            "q": "A loop runs `overdue_loans` over 2,000 loans, and only one returned loan is wrongly counted. Which breakpoint gets you to it fastest?",
            "options": [
                "A plain breakpoint inside the loop, then F5 until you find it",
                "A conditional breakpoint inside the loop with `loan.returned_on is not None`",
                "A breakpoint on the first line of the program",
                "A logpoint on the `return` line",
            ],
            "answer": 1,
            "why": "The condition skips every loan that isn't returned, so the debugger pauses only on the suspicious ones. A plain breakpoint would need about 2,000 presses of F5.",
        },
        "code": '''from dataclasses import dataclass
from datetime import date

@dataclass
class Loan:
    item_id: str
    due_on: date
    returned_on: date | None = None

def pause(where, **variables):                # a breakpoint that fired
    print(f"PAUSED at {where}:", variables)

def overdue_loans(loans, *, today):
    overdue = []
    for loan in loans:
        print("LOG:", "checking {item_id}".format(item_id=loan.item_id))   # a logpoint
        if loan.returned_on is not None:      # the breakpoint's condition
            pause("overdue check", returned_on=loan.returned_on, due_on=loan.due_on)
        if loan.due_on < today:               # the bug: returned loans pass too
            overdue.append(loan.item_id)
    return overdue

loans = [
    Loan("B001", date(2026, 1, 10), returned_on=date(2026, 1, 5)),
    Loan("B002", date(2026, 3, 1)),
]
print("Overdue:", overdue_loans(loans, today=date(2026, 5, 18)))
''',
        "walkthrough": [
            ["    returned_on: date | None = None", "A loan that is still out has no return date: `None`. Returned loans get a `date`."],
            ["def pause(where, **variables):                # a breakpoint that fired", "Our stand-in for the debugger pausing: it prints the variables we would see in the Variables panel."],
            ["def overdue_loans(loans, *, today):", "The `*` makes `today` keyword-only: callers must write `today=...`, so nobody swaps the dates by accident."],
            ['        print("LOG:", "checking {item_id}".format(item_id=loan.item_id))   # a logpoint', "Our stand-in for a logpoint: one line of output per loan, and the program never pauses. `.format(item_id=\"B001\")` fills the `{item_id}` slot, the way a VS Code logpoint fills `{...}`."],
            ["        if loan.returned_on is not None:      # the breakpoint's condition", "In VS Code you type this condition into the breakpoint itself; here an `if` plays that role, so we only pause on returned loans."],
            ["        if loan.due_on < today:               # the bug: returned loans pass too", "B001 was due on 10 January, so it is \"before today\" even though it came back on 5 January. The check never asks whether the loan is still out."],
        ],
        "mistakes": [
            "Typing a condition with one `=`: `isbn = \"B042\"` is an assignment. A condition compares with `==`.",
            "Writing a condition that uses a variable that doesn't exist yet on that line. The breakpoint stops before the line runs.",
            "Fixing the symptom (deleting B001 from the list) instead of the cause (the missing `returned_on is None` check).",
            "Changing code before you know why a value is wrong. Pause and check first; then fix the cause, not the symptom.",
            "Using `\"program\"` with a dotted name like `bookvault.cli`. Dotted names go in `\"module\"`; file paths go in `\"program\"`.",
        ],
        "local": [
            {
                "title": ".vscode/launch.json",
                "note": "Create it from the Run and Debug view (*create a launch.json file*) or by hand. Pick a configuration from the drop-down at the top of the view and press F5.",
                "code": '''{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Run CLI: list books",
      "type": "debugpy",
      "request": "launch",
      "module": "bookvault.cli",
      "args": ["list"],
      "console": "integratedTerminal",
      "justMyCode": false
    },
    {
      "name": "Run pytest (all tests)",
      "type": "debugpy",
      "request": "launch",
      "module": "pytest",
      "args": ["tests/", "-v"]
    },
    {
      "name": "Attach to running process",
      "type": "debugpy",
      "request": "attach",
      "connect": { "host": "localhost", "port": 5678 }
    }
  ]
}''',
            },
            {
                "title": "Catch the overdue bug with a conditional breakpoint",
                "note": "Save this as `overdue.py`. Click left of `if loan.due_on < today:` to add a red dot, right-click it, choose *Edit Breakpoint...*, pick *Expression* and type `loan.returned_on is not None`, then press Enter. Next, right-click left of the `overdue = []` line, choose *Add Logpoint...* and type `today is {today}`. Press F5. It pauses only once, on B001; press F5 again to finish. Your panels may look slightly different.",
                "code": '''from dataclasses import dataclass
from datetime import date

@dataclass
class Loan:
    item_id: str
    due_on: date
    returned_on: date | None = None

def overdue_loans(loans, *, today):
    overdue = []
    for loan in loans:
        if loan.due_on < today:
            overdue.append(loan.item_id)
    return overdue

loans = [
    Loan("B001", date(2026, 1, 10), returned_on=date(2026, 1, 5)),
    Loan("B002", date(2026, 3, 1)),
]
print("Overdue:", overdue_loans(loans, today=date(2026, 5, 18)))''',
                "output": '''DEBUG CONSOLE
  today is 2026-05-18
Paused on breakpoint (only once, for B001)
VARIABLES
  loan: Loan(item_id='B001', due_on=datetime.date(2026, 1, 10), returned_on=datetime.date(2026, 1, 5))
  today: datetime.date(2026, 5, 18)
After F5 again, in the terminal
  Overdue: ['B001', 'B002']''',
            },
        ],
        "challenge": {
            "task": "Fix BookVault's overdue bug (assignment Q2). `overdue_loans(*, today)` must return only loans that are **still out** (`returned_on is None`) **and** were due before `today`. Keep `today` keyword-only.",
            "hints": [
                "The list comprehension needs two conditions joined with `and`.",
                "`return [loan for loan in self.loans if loan.returned_on is None and loan.due_on < today]`",
            ],
            "starter": '''from dataclasses import dataclass
from datetime import date

@dataclass
class Loan:
    item_id: str
    member_id: str
    due_on: date
    returned_on: date | None = None

class Library:
    def __init__(self):
        self.loans = []

    def borrow(self, item_id, member_id, *, due_on):
        loan = Loan(item_id, member_id, due_on)
        self.loans.append(loan)
        return loan

    def return_item(self, item_id, *, returned_on):
        for loan in self.loans:
            if loan.item_id == item_id and loan.returned_on is None:
                loan.returned_on = returned_on
                return loan
        raise ValueError(f"No active loan for {item_id}")

    def overdue_loans(self, *, today):
        return [loan for loan in self.loans if loan.due_on < today]

lib = Library()
lib.borrow("B001", "M001", due_on=date(2026, 1, 1))
lib.return_item("B001", returned_on=date(2026, 1, 5))
print(lib.overdue_loans(today=date(2026, 5, 18)))
''',
            "solution": '''from dataclasses import dataclass
from datetime import date

@dataclass
class Loan:
    item_id: str
    member_id: str
    due_on: date
    returned_on: date | None = None

class Library:
    def __init__(self):
        self.loans = []

    def borrow(self, item_id, member_id, *, due_on):
        loan = Loan(item_id, member_id, due_on)
        self.loans.append(loan)
        return loan

    def return_item(self, item_id, *, returned_on):
        for loan in self.loans:
            if loan.item_id == item_id and loan.returned_on is None:
                loan.returned_on = returned_on
                return loan
        raise ValueError(f"No active loan for {item_id}")

    def overdue_loans(self, *, today):
        return [loan for loan in self.loans
                if loan.returned_on is None and loan.due_on < today]

lib = Library()
lib.borrow("B001", "M001", due_on=date(2026, 1, 1))
lib.return_item("B001", returned_on=date(2026, 1, 5))
print(lib.overdue_loans(today=date(2026, 5, 18)))
''',
            "tests": '''from datetime import date as _date
_lib = Library()
_lib.borrow("B001", "M001", due_on=_date(2026, 1, 1))
_lib.return_item("B001", returned_on=_date(2026, 1, 5))
assert _lib.overdue_loans(today=_date(2026, 5, 18)) == [], "a returned loan must never be overdue (B001 came back on 5 January)"
_lib.borrow("B002", "M002", due_on=_date(2026, 3, 1))
_lib.borrow("B003", "M003", due_on=_date(2026, 6, 1))
_ids = [_l.item_id for _l in _lib.overdue_loans(today=_date(2026, 5, 18))]
assert _ids == ["B002"], f"only B002 is still out and past its due date, got {_ids!r}"
_lib.return_item("B002", returned_on=_date(2026, 5, 20))
assert _lib.overdue_loans(today=_date(2026, 5, 25)) == [], "a loan returned late is still returned: it is no longer overdue"
_lib2 = Library()
_lib2.borrow("B004", "M004", due_on=_date(2026, 5, 18))
assert _lib2.overdue_loans(today=_date(2026, 5, 18)) == [], "a loan due today is not overdue yet"
try:
    _lib2.overdue_loans(_date(2026, 5, 18))
    _kw = False
except TypeError:
    _kw = True
assert _kw, "keep the * so today must be passed by keyword: overdue_loans(today=...)"''',
        },
        "practice": [
            {
                "task": "Write a conditional breakpoint. `run_with_breakpoint(loans, condition)` loops over the loans; when `condition(loan)` is `True` it prints `PAUSED on <item_id>` and remembers the `item_id`. Return the list of item ids it paused on. Then store `hits = run_with_breakpoint(loans, ...)` using a `lambda` that pauses only on returned loans.",
                "hints": [
                    "In the loop: `if condition(loan):`, then print and `paused.append(loan.item_id)`.",
                    "The condition is `lambda loan: loan.returned_on is not None`.",
                ],
                "starter": '''from dataclasses import dataclass
from datetime import date

@dataclass
class Loan:
    item_id: str
    due_on: date
    returned_on: date | None = None

loans = [
    Loan("B001", date(2026, 1, 10), returned_on=date(2026, 1, 5)),
    Loan("B042", date(2026, 3, 1)),
    Loan("B077", date(2026, 2, 1), returned_on=date(2026, 2, 3)),
]

def run_with_breakpoint(loans, condition):
    return []

hits = []
print(hits)
''',
                "solution": '''from dataclasses import dataclass
from datetime import date

@dataclass
class Loan:
    item_id: str
    due_on: date
    returned_on: date | None = None

loans = [
    Loan("B001", date(2026, 1, 10), returned_on=date(2026, 1, 5)),
    Loan("B042", date(2026, 3, 1)),
    Loan("B077", date(2026, 2, 1), returned_on=date(2026, 2, 3)),
]

def run_with_breakpoint(loans, condition):
    paused = []
    for loan in loans:
        if condition(loan):
            print(f"PAUSED on {loan.item_id}")
            paused.append(loan.item_id)
    return paused

hits = run_with_breakpoint(loans, lambda loan: loan.returned_on is not None)
print(hits)
''',
                "tests": '''assert hits == ["B001", "B077"], f"hits should be the two returned loans ['B001', 'B077'], got {hits!r}"
assert "PAUSED on B001" in __output__, "print 'PAUSED on <item_id>' each time the condition is true"
import contextlib as _cl, io as _io
with _cl.redirect_stdout(_io.StringIO()):
    _only = run_with_breakpoint(loans, lambda loan: loan.item_id == "B042")
    _none = run_with_breakpoint(loans, lambda loan: False)
assert _only == ["B042"], "with the condition item_id == 'B042' it should pause only on B042"
assert _none == [], "a condition that is never true never pauses"''',
            },
            {
                "task": "Write a logpoint. `logpoint(message, **variables)` fills the `{...}` slots in `message` from `variables` with `.format(**variables)`, prints `LOG: ` followed by the result, and returns the filled text (without `LOG: `).",
                "hints": [
                    "`text = message.format(**variables)` turns `\"Borrowed {isbn}\"` with `isbn=\"B042\"` into `\"Borrowed B042\"`.",
                    "Then `print(\"LOG:\", text)` and `return text`.",
                ],
                "starter": '''def logpoint(message, **variables):
    print(message)

logpoint("Borrowed {isbn} by {member_id}", isbn="B042", member_id="M001")
''',
                "solution": '''def logpoint(message, **variables):
    text = message.format(**variables)
    print("LOG:", text)
    return text

logpoint("Borrowed {isbn} by {member_id}", isbn="B042", member_id="M001")
''',
                "tests": '''assert __output__.strip() == "LOG: Borrowed B042 by M001", f"the demo call should print 'LOG: Borrowed B042 by M001', got {__output__.strip()!r}"
import contextlib as _cl, io as _io
_buf = _io.StringIO()
with _cl.redirect_stdout(_buf):
    _t = logpoint("today is {today}, {n} loans", today="2026-05-18", n=3)
assert _t == "today is 2026-05-18, 3 loans", f"logpoint should return the filled text, got {_t!r}"
assert _buf.getvalue() == "LOG: today is 2026-05-18, 3 loans\\n", "logpoint should print 'LOG: ' and the filled text"''',
            },
            {
                "task": "Read a launch.json configuration. Write `command_for(config)` that returns the terminal command the configuration runs: `python -m <module>` when it has a `\"module\"`, otherwise `python <program>`, followed by each item of `\"args\"` (if there are any), all separated by spaces.",
                "hints": [
                    "Start a list: `[\"python\", \"-m\", config[\"module\"]]` or `[\"python\", config[\"program\"]]`, then add `config.get(\"args\", [])`.",
                    "`return \" \".join(parts + config.get(\"args\", []))`",
                ],
                "starter": '''def command_for(config):
    return "python"

cli = {"name": "Run CLI: list books", "request": "launch", "module": "bookvault.cli", "args": ["list"]}
print(command_for(cli))
''',
                "solution": '''def command_for(config):
    if "module" in config:
        parts = ["python", "-m", config["module"]]
    else:
        parts = ["python", config["program"]]
    return " ".join(parts + config.get("args", []))

cli = {"name": "Run CLI: list books", "request": "launch", "module": "bookvault.cli", "args": ["list"]}
print(command_for(cli))
''',
                "tests": '''assert command_for(cli) == "python -m bookvault.cli list", f"got {command_for(cli)!r}"
assert command_for({"module": "pytest", "args": ["tests/", "-v"]}) == "python -m pytest tests/ -v", "the pytest configuration runs 'python -m pytest tests/ -v'"
assert command_for({"program": "app.py"}) == "python app.py", "a 'program' configuration with no args runs 'python app.py'"
assert command_for({"program": "scripts/load.py", "args": ["books.json"]}) == "python scripts/load.py books.json", "add the args after the program"''',
            },
            {
                "task": "Which configurations step into library code? Write `library_steppers(text)`: read the launch.json text with `json.loads` and return the `name` of every configuration whose `justMyCode` is `False`. A configuration without `justMyCode` uses the default, `True`.",
                "hints": [
                    "The list is under `data[\"configurations\"]`; read the setting with `config.get(\"justMyCode\", True)`.",
                    "`return [c[\"name\"] for c in json.loads(text)[\"configurations\"] if c.get(\"justMyCode\", True) is False]`",
                ],
                "starter": '''import json

launch = """{
  "version": "0.2.0",
  "configurations": [
    {"name": "Run CLI: list books", "request": "launch", "module": "bookvault.cli", "justMyCode": false},
    {"name": "Run pytest (all tests)", "request": "launch", "module": "pytest"},
    {"name": "Attach to running process", "request": "attach", "justMyCode": true}
  ]
}"""

def library_steppers(text):
    return []

print(library_steppers(launch))
''',
                "solution": '''import json

launch = """{
  "version": "0.2.0",
  "configurations": [
    {"name": "Run CLI: list books", "request": "launch", "module": "bookvault.cli", "justMyCode": false},
    {"name": "Run pytest (all tests)", "request": "launch", "module": "pytest"},
    {"name": "Attach to running process", "request": "attach", "justMyCode": true}
  ]
}"""

def library_steppers(text):
    data = json.loads(text)
    return [c["name"] for c in data["configurations"] if c.get("justMyCode", True) is False]

print(library_steppers(launch))
''',
                "tests": '''assert library_steppers(launch) == ["Run CLI: list books"], f"only 'Run CLI: list books' sets justMyCode to false, got {library_steppers(launch)!r}"
_t = '{"configurations": [{"name": "A", "justMyCode": false}, {"name": "B"}, {"name": "C", "justMyCode": false}]}'
assert library_steppers(_t) == ["A", "C"], "return every matching name, in order"
assert library_steppers('{"configurations": []}') == [], "no configurations gives []"''',
            },
        ],
    },
    # ------------------------------------------------------------------ logging-levels
    {
        "id": "logging-levels",
        "title": "Logging levels and handlers",
        "slides": "15-16",
        "idea": "`print()` always prints, to one place, with no label. Python's **logging** module gives every message a **level** (how serious it is) and lets you choose, without editing the code, which levels are shown and where they go. Rule of thumb: `print()` is for experiments, logging is for software.\n\nThe levels, from least to most serious: **DEBUG** (10, details for developers: variables, cache decisions), **INFO** (20, normal business events: a book was borrowed), **WARNING** (30, unexpected but recoverable: retrying), **ERROR** (40, an action failed), **CRITICAL** (50, the whole program is in trouble).\n\nThree pieces work together:\n- A **logger** is what your code calls: `logger = logging.getLogger(\"bookvault.library\")` (in a module, `logging.getLogger(__name__)` names it after the module). `logger.setLevel(logging.INFO)` sets its **threshold**: anything below it is dropped.\n- A **handler** decides where lines go: `StreamHandler` writes to the screen or any text stream, `FileHandler` to a file. A handler can have its own level too, so the screen shows only warnings while the file keeps everything. A message must pass the logger's level, then each handler's level.\n- A **formatter** decides what a line looks like: `\"%(asctime)s [%(levelname)s] %(name)s: %(message)s\"`.\n\nDotted names form a family: a record from `bookvault.library` is passed up (**propagates**) to the handlers of `bookvault` and finally the **root** logger. Most apps set everything up once at startup with `logging.basicConfig(level=..., format=...)`, which configures the root logger; only the *first* call counts.",
        "predict": {
            "q": "At startup an app calls `logging.basicConfig(level=logging.WARNING)`. Later, a module calls `logging.basicConfig(level=logging.DEBUG)`. Which level does the root logger use?",
            "options": [
                "DEBUG: the last call wins",
                "WARNING: the second call does nothing, because logging is already set up",
                "Both: it logs everything twice",
                "Python raises an error for calling basicConfig twice",
            ],
            "answer": 1,
            "why": "`basicConfig` only acts when the root logger has no handlers yet. After the first call it silently does nothing (unless you pass `force=True`). So configure logging once, at startup.",
        },
        "code": '''import io
import logging

buffer = io.StringIO()                        # an in-memory "file" for the log lines
handler = logging.StreamHandler(buffer)
handler.setFormatter(logging.Formatter("[%(levelname)s] %(name)s: %(message)s"))

logger = logging.getLogger("bookvault.library")
logger.handlers.clear()                       # running this again? start clean
logger.addHandler(handler)
logger.propagate = False                      # don't also pass records up to the root logger
logger.setLevel(logging.INFO)                 # the threshold

logger.debug("cache miss for B001")           # 10 is below 20: dropped
logger.info("book_borrowed B001")
logger.warning("member M001 has 4 loans")
logger.error("cover fetch failed for B042")
print(buffer.getvalue())

logger.setLevel(logging.DEBUG)                # turn the detail up; the log calls stay the same
logger.debug("cache miss for B002")
print(buffer.getvalue().splitlines()[-1])
print(logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL)
''',
        "walkthrough": [
            ["buffer = io.StringIO()                        # an in-memory \"file\" for the log lines", "On your machine you'd log to the screen or a file. In this page we log to a `StringIO` (Day 1), a text \"file\" in memory, so we can print the lines and the checks can read them."],
            ["handler = logging.StreamHandler(buffer)", "A **handler** sends each finished line somewhere: this one writes into `buffer`."],
            ['handler.setFormatter(logging.Formatter("[%(levelname)s] %(name)s: %(message)s"))', "The **formatter**'s pattern: `%(levelname)s` becomes `INFO`, `%(name)s` the logger's name, `%(message)s` your text. Add `%(asctime)s` for the time."],
            ['logger = logging.getLogger("bookvault.library")', "Get (or create) the logger with this name. Asking again for the same name gives the same logger."],
            ["logger.handlers.clear()                       # running this again? start clean", "Loggers live as long as the program, and in this page the logging module even remembers them between runs. Without this line, a second run would add a second handler and every line would appear twice. (`basicConfig` does the reverse: if the root logger already has handlers, it does nothing.)"],
            ["logger.propagate = False                      # don't also pass records up to the root logger", "Normally records also travel up to parent loggers. Turning that off keeps this example's lines in our buffer only."],
            ["logger.setLevel(logging.INFO)                 # the threshold", "Only INFO (20) and above get through."],
            ['logger.debug("cache miss for B001")           # 10 is below 20: dropped', "Below the threshold, so nothing is written. The call is cheap and can stay in the code."],
            ["logger.setLevel(logging.DEBUG)                # turn the detail up; the log calls stay the same", "Lower the threshold and the DEBUG lines appear. In a real app this comes from a setting, not a code edit."],
            ["print(logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL)", "The levels are just numbers: 10, 20, 30, 40, 50. Higher means more serious."],
        ],
        "mistakes": [
            "Calling `logging.basicConfig` in several modules. Only the first call counts; set logging up once at startup.",
            "Adding a handler every time a function runs. Each extra handler prints every line again: set handlers up once (or clear them first).",
            "Setting the handler to DEBUG but leaving the logger at WARNING. The logger drops DEBUG records before any handler sees them: both levels must let it through.",
            "Logging everything as INFO or everything as ERROR. Pick the level by meaning, so a threshold can filter the noise.",
            "Doing slow work just to build a DEBUG message that will be dropped anyway. Keep debug messages cheap, or check `logger.isEnabledFor(logging.DEBUG)` first.",
        ],
        "local": [
            {
                "title": "basicConfig: one line at startup",
                "note": "Run as `python log_demo.py`. Your times will differ. The second `basicConfig` is ignored because logging is already set up, so DEBUG stays hidden.",
                "code": '''import logging
import sys

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger("bookvault.library")

logger.debug("cache miss for B001")
logger.info("book_borrowed B001")
logger.warning("member M001 has 4 loans")

logging.basicConfig(level=logging.DEBUG)   # ignored: already configured
logger.debug("still hidden")''',
                "output": '''2026-11-26 10:15:02,114 [INFO] bookvault.library: book_borrowed B001
2026-11-26 10:15:02,115 [WARNING] bookvault.library: member M001 has 4 loans''',
            },
            {
                "title": "FileHandler: everything to a file, warnings to the screen",
                "note": "Assignment Q1 asks for file logging. Run it, then open `bookvault.log` in the same folder. The logger lets everything through (DEBUG); each handler then keeps what its own level allows.",
                "code": '''import logging

logger = logging.getLogger("bookvault")
logger.setLevel(logging.DEBUG)

file_handler = logging.FileHandler("bookvault.log", encoding="utf-8")
file_handler.setLevel(logging.DEBUG)
file_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))

console = logging.StreamHandler()
console.setLevel(logging.WARNING)
console.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))

logger.addHandler(file_handler)
logger.addHandler(console)

logger.debug("loading books.json")
logger.info("loaded 48 books")
logger.warning("2 books skipped")''',
                "output": '''# in the terminal
WARNING: 2 books skipped

# in bookvault.log
2026-11-26 10:20:41,503 DEBUG bookvault: loading books.json
2026-11-26 10:20:41,504 INFO bookvault: loaded 48 books
2026-11-26 10:20:41,504 WARNING bookvault: 2 books skipped''',
            },
        ],
        "challenge": {
            "task": "Write `make_logger(name, level, stream)`. It gets the logger called `name`, removes any old handlers, adds one `StreamHandler` writing to `stream` with the format `\"%(levelname)s %(name)s: %(message)s\"`, sets the logger's level to `level`, sets `propagate` to `False`, and returns the logger. Calling it twice must not make lines appear twice. (`basicConfig` does the reverse: if the root logger already has handlers, it does nothing. The last practice part builds that version.)",
            "hints": [
                "Follow the demo: `getLogger`, `handlers.clear()`, make a `StreamHandler(stream)`, `setFormatter(...)`, `addHandler`, `setLevel`, `propagate = False`.",
                "`handler = logging.StreamHandler(stream)` and `handler.setFormatter(logging.Formatter(\"%(levelname)s %(name)s: %(message)s\"))`, then `logger.addHandler(handler)`; finish with `return logger`.",
            ],
            "starter": '''import io
import logging

def make_logger(name, level, stream):
    logger = logging.getLogger(name)
    return logger

buffer = io.StringIO()
log = make_logger("bookvault.loans", logging.INFO, buffer)
log.debug("checking B001")
log.info("book_borrowed B001")
print(buffer.getvalue())
''',
            "solution": '''import io
import logging

def make_logger(name, level, stream):
    logger = logging.getLogger(name)
    logger.handlers.clear()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter("%(levelname)s %(name)s: %(message)s"))
    logger.addHandler(handler)
    logger.setLevel(level)
    logger.propagate = False
    return logger

buffer = io.StringIO()
log = make_logger("bookvault.loans", logging.INFO, buffer)
log.debug("checking B001")
log.info("book_borrowed B001")
print(buffer.getvalue())
''',
            "tests": '''import io as _io, logging as _lg
_b1 = _io.StringIO()
_log = make_logger("lab.challenge", _lg.WARNING, _b1)
_log.info("hidden")
_log.warning("shown")
assert _b1.getvalue() == "WARNING lab.challenge: shown\\n", f"at WARNING only the warning should be written as 'WARNING lab.challenge: shown', got {_b1.getvalue()!r}"
_b2 = _io.StringIO()
_log = make_logger("lab.challenge", _lg.DEBUG, _b2)
_log.debug("detail")
assert _b2.getvalue() == "DEBUG lab.challenge: detail\\n", f"at DEBUG the debug line should be written, got {_b2.getvalue()!r}"
assert _b1.getvalue() == "WARNING lab.challenge: shown\\n", "the old handler is still attached: clear the logger's handlers before adding the new one"
assert len(_log.handlers) == 1, "the logger should have exactly one handler"
assert _log.propagate is False, "set propagate to False"''',
        },
        "practice": [
            {
                "task": "Pick the right level. Write `report_loan(logger, item_id, days_late)`. It always logs a DEBUG message first (e.g. `checking B001`). Then it logs **one** more message: INFO when `days_late` is 0, WARNING when it is 1 to 30, ERROR when it is more than 30 (the book is probably lost). The checks look only at the levels.",
                "hints": [
                    "Use `logger.debug(...)`, then an `if / elif / else` with `logger.info`, `logger.warning` and `logger.error`.",
                    "`if days_late == 0: logger.info(...)`, `elif days_late <= 30: logger.warning(...)`, `else: logger.error(...)`.",
                ],
                "starter": '''import io
import logging

def report_loan(logger, item_id, days_late):
    logger.info(f"{item_id} checked")

buffer = io.StringIO()
logger = logging.getLogger("bookvault.fines")
logger.handlers.clear()
logger.addHandler(logging.StreamHandler(buffer))
logger.propagate = False
logger.setLevel(logging.DEBUG)

for item, late in [("B001", 0), ("B002", 5), ("B003", 45)]:
    report_loan(logger, item, late)
print(buffer.getvalue())
''',
                "solution": '''import io
import logging

def report_loan(logger, item_id, days_late):
    logger.debug(f"checking {item_id}")
    if days_late == 0:
        logger.info(f"{item_id} on_time")
    elif days_late <= 30:
        logger.warning(f"{item_id} late by {days_late} days")
    else:
        logger.error(f"{item_id} probably lost")

buffer = io.StringIO()
logger = logging.getLogger("bookvault.fines")
logger.handlers.clear()
logger.addHandler(logging.StreamHandler(buffer))
logger.propagate = False
logger.setLevel(logging.DEBUG)

for item, late in [("B001", 0), ("B002", 5), ("B003", 45)]:
    report_loan(logger, item, late)
print(buffer.getvalue())
''',
                "tests": _KEEP + '''_logger, _keep = _fresh("lab.levels")
for _late, _want in [(0, "INFO"), (1, "WARNING"), (30, "WARNING"), (31, "ERROR"), (100, "ERROR")]:
    _keep.records.clear()
    report_loan(_logger, "B9", _late)
    _got = [_r.levelname for _r in _keep.records]
    assert _got == ["DEBUG", _want], f"with days_late={_late} the levels should be ['DEBUG', '{_want}'], got {_got}"
_logger.setLevel(_lg.WARNING)
_keep.records.clear()
report_loan(_logger, "B9", 0)
assert _keep.records == [], "at a WARNING threshold an on-time loan should log nothing (DEBUG and INFO are dropped)"''',
            },
            {
                "task": "Two handlers, two levels (like a screen and a log file). Write `setup(console, logfile)` for the logger `\"lab.loans\"`: clear its handlers, set its level to DEBUG and `propagate` to `False`. Add a `StreamHandler(console)` at level WARNING and a `StreamHandler(logfile)` at level DEBUG, both with the format `\"%(levelname)s %(message)s\"`. Return the logger.",
                "hints": [
                    "A handler has its own `setLevel`: `screen = logging.StreamHandler(console)` then `screen.setLevel(logging.WARNING)`.",
                    "Make one `fmt = logging.Formatter(\"%(levelname)s %(message)s\")`, call `setFormatter(fmt)` on both handlers and `addHandler` both. The logger itself must be at DEBUG, or the file never sees debug lines.",
                ],
                "starter": '''import io
import logging

def setup(console, logfile):
    logger = logging.getLogger("lab.loans")
    return logger

console, logfile = io.StringIO(), io.StringIO()
log = setup(console, logfile)
log.debug("loading books.json")
log.warning("2 books skipped")
print("console:", console.getvalue())
print("file:", logfile.getvalue())
''',
                "solution": '''import io
import logging

def setup(console, logfile):
    logger = logging.getLogger("lab.loans")
    logger.handlers.clear()
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    fmt = logging.Formatter("%(levelname)s %(message)s")
    screen = logging.StreamHandler(console)
    screen.setLevel(logging.WARNING)
    screen.setFormatter(fmt)
    file = logging.StreamHandler(logfile)
    file.setLevel(logging.DEBUG)
    file.setFormatter(fmt)
    logger.addHandler(screen)
    logger.addHandler(file)
    return logger

console, logfile = io.StringIO(), io.StringIO()
log = setup(console, logfile)
log.debug("loading books.json")
log.warning("2 books skipped")
print("console:", console.getvalue())
print("file:", logfile.getvalue())
''',
                "tests": '''import io as _io
_c, _f = _io.StringIO(), _io.StringIO()
_log = setup(_c, _f)
_log.debug("d1")
_log.info("i1")
_log.error("e1")
assert _c.getvalue() == "ERROR e1\\n", f"the console handler (WARNING) should only get 'ERROR e1', got {_c.getvalue()!r}"
assert _f.getvalue() == "DEBUG d1\\nINFO i1\\nERROR e1\\n", f"the file handler (DEBUG) should get all three lines, got {_f.getvalue()!r}"
assert len(_log.handlers) == 2, "the logger should have exactly two handlers (clear old ones first)"
assert _log.propagate is False, "set propagate to False"''',
            },
            {
                "task": "Logger families. Write `setup_parent(stream)`: configure **only** the parent logger `\"archive\"` (clear its handlers, add one `StreamHandler(stream)` with the format `\"%(name)s %(levelname)s %(message)s\"`, level INFO, `propagate = False`) and return it. Then get the child loggers `loans_log = logging.getLogger(\"archive.loans\")` and `covers_log = logging.getLogger(\"archive.covers\")` **without** giving them any handlers: their records travel up to the parent.",
                "hints": [
                    "Children with no handlers and no level of their own use the parent's: just `logging.getLogger(\"archive.loans\")`.",
                    "In `setup_parent`: `parent = logging.getLogger(\"archive\")`, clear, add the handler with its formatter, `parent.setLevel(logging.INFO)`, `parent.propagate = False`, `return parent`.",
                ],
                "starter": '''import io
import logging

def setup_parent(stream):
    return logging.getLogger("archive")

buffer = io.StringIO()
setup_parent(buffer)
loans_log = None
covers_log = None
print(buffer.getvalue())
''',
                "solution": '''import io
import logging

def setup_parent(stream):
    parent = logging.getLogger("archive")
    parent.handlers.clear()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter("%(name)s %(levelname)s %(message)s"))
    parent.addHandler(handler)
    parent.setLevel(logging.INFO)
    parent.propagate = False
    return parent

buffer = io.StringIO()
setup_parent(buffer)
loans_log = logging.getLogger("archive.loans")
covers_log = logging.getLogger("archive.covers")
loans_log.info("book_borrowed B001")
covers_log.warning("cover missing for B042")
print(buffer.getvalue())
''',
                "tests": '''import io as _io, logging as _lg
assert loans_log is _lg.getLogger("archive.loans"), "loans_log should be logging.getLogger('archive.loans')"
assert covers_log is _lg.getLogger("archive.covers"), "covers_log should be logging.getLogger('archive.covers')"
for _child in (loans_log, covers_log):
    _child.handlers.clear()
    _child.propagate = True
    _child.setLevel(_lg.NOTSET)
_b = _io.StringIO()
_parent = setup_parent(_b)
assert _parent is _lg.getLogger("archive"), "setup_parent should return the 'archive' logger"
loans_log.debug("hidden")
loans_log.info("book_borrowed B7")
covers_log.error("cover_fetch_failed B8")
assert _b.getvalue() == "archive.loans INFO book_borrowed B7\\narchive.covers ERROR cover_fetch_failed B8\\n", f"the children's records should reach the parent's handler (and DEBUG is below the parent's INFO level), got {_b.getvalue()!r}"
assert len(_parent.handlers) == 1 and _parent.propagate is False, "the parent needs exactly one handler and propagate = False"''',
            },
            {
                "task": "Configure once, like `basicConfig`. Write `configure_once(name, level, stream)`: get the logger called `name`. If it **already has handlers**, do nothing and return it. Otherwise add a `StreamHandler(stream)` with the format `\"%(levelname)s %(message)s\"`, set the level to `level`, set `propagate = False`, and return it. Calling it a second time with a different level must change nothing: the first setup sticks.",
                "hints": [
                    "`logger.handlers` is a list; an empty list is falsy, so `if logger.handlers: return logger` skips the setup.",
                    "After that check: `handler = logging.StreamHandler(stream)`, `handler.setFormatter(logging.Formatter(\"%(levelname)s %(message)s\"))`, `logger.addHandler(handler)`, `logger.setLevel(level)`, `logger.propagate = False`, `return logger`.",
                ],
                "starter": '''import io
import logging

def configure_once(name, level, stream):
    logger = logging.getLogger(name)
    logger.handlers.clear()
    logger.addHandler(logging.StreamHandler(stream))
    logger.setLevel(level)
    logger.propagate = False
    return logger

buffer = io.StringIO()
logging.getLogger("bookvault.startup").handlers.clear()   # start fresh for this example
log = configure_once("bookvault.startup", logging.WARNING, buffer)
log = configure_once("bookvault.startup", logging.DEBUG, buffer)   # should change nothing
log.debug("hidden")
log.warning("disk almost full")
print(buffer.getvalue())
''',
                "solution": '''import io
import logging

def configure_once(name, level, stream):
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter("%(levelname)s %(message)s"))
    logger.addHandler(handler)
    logger.setLevel(level)
    logger.propagate = False
    return logger

buffer = io.StringIO()
logging.getLogger("bookvault.startup").handlers.clear()   # start fresh for this example
log = configure_once("bookvault.startup", logging.WARNING, buffer)
log = configure_once("bookvault.startup", logging.DEBUG, buffer)   # should change nothing
log.debug("hidden")
log.warning("disk almost full")
print(buffer.getvalue())
''',
                "tests": '''import io as _io, logging as _lg
_lg.getLogger("lab.once").handlers.clear()
_b1, _b2 = _io.StringIO(), _io.StringIO()
_log = configure_once("lab.once", _lg.WARNING, _b1)
_again = configure_once("lab.once", _lg.DEBUG, _b2)
assert _again is _log, "configure_once should return the logger called name both times"
_log.debug("d")
_log.info("i")
_log.error("e")
assert _b1.getvalue() == "ERROR e\\n", f"the first setup (WARNING, first stream) should stick, so only 'ERROR e' is written, got {_b1.getvalue()!r}"
assert _b2.getvalue() == "", "the second call must not add a handler for the second stream"
assert len(_log.handlers) == 1, f"the logger should have exactly one handler, got {len(_log.handlers)}"
assert _log.level == _lg.WARNING, "the second call must not change the level"
assert _log.propagate is False, "set propagate to False"''',
            },
        ],
    },
    # ------------------------------------------------------------------ structured-logging
    {
        "id": "structured-logging",
        "title": "Structured JSON logs",
        "slides": "15-17",
        "idea": "`Borrowed Clean Code for M001!` is easy to read but hard to search: every line is worded differently. **Structured logging** writes every line as an **event**: a stable name such as `book_borrowed`, plus **fields** such as `isbn`, `member_id` and `request_id`, usually as one JSON object per line. A log tool can then find every failure for `isbn=\"B042\"` in seconds, or build a dashboard.\n\nYou add fields with `extra=`: `logger.info(\"book_borrowed\", extra={\"isbn\": isbn})`. Logging copies each key onto the **log record** (the object a handler receives), so `record.isbn` exists. A **formatter** that turns the record into JSON is a small class: inherit from `logging.Formatter` and override `format(self, record)` to return `json.dumps(...)`.\n\nInside an `except` block, use `logger.exception(\"cover_fetch_failed\", extra=...)`: it logs at ERROR level and attaches the full **traceback** (the error report Python prints when it crashes) as `record.exc_info`. A **request_id** ties together all lines from one request, even when many run at once (Chapter 6), and `duration_ms` records how long it took. To measure time, pass in a `clock` function instead of calling the real one, so tests control it.\n\nThe logging checklist:\n- The event name is stable: `book_borrowed`, not `Borrowed book!`.\n- Fields are consistent: always `isbn`, `member_id`, `request_id`, `duration_ms`.\n- No secrets: never log passwords, tokens, API keys, raw prompts or patient data.\n- Errors include context: `logger.exception` plus useful ids.",
        "predict": {
            "q": "Which log call follows the structured logging checklist?",
            "options": [
                "`logger.info(f\"Borrowed {isbn} for {member_id}!\")`",
                "`logger.info(\"book_borrowed\", extra={\"isbn\": isbn, \"member_id\": member_id})`",
                "`print(\"book_borrowed\", isbn, member_id)`",
                "`logger.info(\"book_borrowed\", extra={\"isbn\": isbn, \"password\": password})`",
            ],
            "answer": 1,
            "why": "The event name never changes and the values sit in named fields, so tools can search them. The f-string version changes text every time, `print` has no level and no handler, and the last one leaks a secret.",
        },
        "code": '''import io
import json
import logging

class JsonFormatter(logging.Formatter):
    FIELDS = ("isbn", "request_id")

    def format(self, record):
        data = {"levelname": record.levelname, "name": record.name,
                "message": record.getMessage()}
        for field in self.FIELDS:
            if hasattr(record, field):
                data[field] = getattr(record, field)
        if record.exc_info:
            data["error"] = repr(record.exc_info[1])
        return json.dumps(data)

buffer = io.StringIO()
handler = logging.StreamHandler(buffer)
handler.setFormatter(JsonFormatter())
logger = logging.getLogger("bookvault.covers")
logger.handlers.clear()
logger.addHandler(handler)
logger.propagate = False
logger.setLevel(logging.INFO)

logger.info("cover_fetch_succeeded", extra={"isbn": "B042", "request_id": "req-9f3"})
try:
    raise ValueError("bad isbn 'x99'")
except ValueError:
    logger.exception("cover_fetch_failed", extra={"isbn": "x99", "request_id": "req-9f4"})
print(buffer.getvalue())
''',
        "walkthrough": [
            ["class JsonFormatter(logging.Formatter):", "Our own formatter: it inherits everything from `logging.Formatter` (Day 1 inheritance) and changes one method."],
            ["    def format(self, record):", "Logging calls `format` with each **log record** and writes whatever text it returns."],
            ["                \"message\": record.getMessage()}", "`getMessage()` gives the message text. `record.levelname` and `record.name` are the level and the logger's name."],
            ["            if hasattr(record, field):", "`hasattr(obj, \"isbn\")` asks whether the object has an attribute with that name. Fields passed with `extra=` become attributes of the record."],
            ["                data[field] = getattr(record, field)", "`getattr(obj, \"isbn\")` reads an attribute whose name is in a variable: the same as `record.isbn`."],
            ["        if record.exc_info:", "`exc_info` is only set by `logger.exception` (or `exc_info=True`): it holds the error being handled, as (type, error, traceback)."],
            ["            data[\"error\"] = repr(record.exc_info[1])", "To keep the demo short we store just the error itself. For the full traceback text, use `self.formatException(record.exc_info)` instead (the challenge does)."],
            ["        return json.dumps(data)", "One JSON object per line. Newlines inside a traceback are written as `\\n`, so each event stays on one line."],
            ["logger.info(\"cover_fetch_succeeded\", extra={\"isbn\": \"B042\", \"request_id\": \"req-9f3\"})", "A stable event name plus fields. The same name every time means you can count or search successes."],
            ["    logger.exception(\"cover_fetch_failed\", extra={\"isbn\": \"x99\", \"request_id\": \"req-9f4\"})", "Inside `except`: logs at ERROR and attaches the error, with the ids that tell you which request failed."],
        ],
        "mistakes": [
            "Putting values into the message (`f\"Borrowed {isbn}\"`). Keep the message a fixed event name and put values in `extra=`.",
            "Using a reserved name in `extra`, such as `\"name\"`, `\"message\"` or `\"args\"`: logging raises `KeyError: Attempt to overwrite 'name' in LogRecord`. Use `book_name` instead.",
            "Calling `logger.error` inside `except` and losing the traceback. `logger.exception` keeps it.",
            "Calling `logger.exception` outside an `except` block: there is no error to attach.",
            "Logging secrets (passwords, tokens, API keys, full prompts). Logs are kept for a long time and read by many people.",
            "Importing `from pythonjsonlogger import jsonlogger` in new code. In python-json-logger 3.1+ the formatter lives in `pythonjsonlogger.json`.",
        ],
        "local": [
            {
                "title": "Real JSON logs with python-json-logger 3.1+",
                "note": "Install it in your venv with `pip install \"python-json-logger>=3.1\"`, then save this as `covers.py` and run `python covers.py`. In 3.1+ the formatter lives in `pythonjsonlogger.json`; the old import path `from pythonjsonlogger import jsonlogger` (in the slides) is deprecated. Your times will differ, and the traceback shows your file name.",
                "code": '''import logging
import sys
from pythonjsonlogger.json import JsonFormatter

handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(JsonFormatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
logging.basicConfig(level=logging.INFO, handlers=[handler])

logger = logging.getLogger("bookvault.covers")
logger.info("cover_fetch_succeeded",
            extra={"isbn": "B042", "request_id": "req-9f3", "duration_ms": 318})
try:
    raise ValueError("Invalid ISBN format provided.")
except ValueError:
    logger.exception("cover_fetch_failed",
                     extra={"isbn": "invalid-isbn", "request_id": "req-9f4"})''',
                "output": '''{"asctime": "2026-11-26 10:31:07,412", "levelname": "INFO", "name": "bookvault.covers", "message": "cover_fetch_succeeded", "isbn": "B042", "request_id": "req-9f3", "duration_ms": 318}
{"asctime": "2026-11-26 10:31:07,413", "levelname": "ERROR", "name": "bookvault.covers", "message": "cover_fetch_failed", "exc_info": "Traceback (most recent call last):\\n  File \\"covers.py\\", line 13, in <module>\\n    raise ValueError(\\"Invalid ISBN format provided.\\")\\nValueError: Invalid ISBN format provided.", "isbn": "invalid-isbn", "request_id": "req-9f4"}''',
            },
        ],
        "challenge": {
            "task": "Write the JSON formatter. `JsonFormatter.format(record)` must return one line of JSON with the keys `level` (the level name), `logger` (the logger's name) and `event` (the message), then every name in `FIELDS` that the record has, and an `error` key **only** when the record has `exc_info`, holding the full traceback text from `self.formatException(record.exc_info)`.",
            "hints": [
                "Start with `data = {\"level\": record.levelname, \"logger\": record.name, \"event\": record.getMessage()}`, then loop over `self.FIELDS` with `hasattr` / `getattr`.",
                "`if record.exc_info: data[\"error\"] = self.formatException(record.exc_info)`, and finally `return json.dumps(data)`.",
            ],
            "starter": '''import io
import json
import logging

class JsonFormatter(logging.Formatter):
    FIELDS = ("isbn", "member_id", "request_id", "duration_ms")

    def format(self, record):
        return record.getMessage()        # plain text: make it one line of JSON

buffer = io.StringIO()
handler = logging.StreamHandler(buffer)
handler.setFormatter(JsonFormatter())
logger = logging.getLogger("bookvault.loans")
logger.handlers.clear()
logger.addHandler(handler)
logger.propagate = False
logger.setLevel(logging.INFO)

logger.info("book_borrowed", extra={"isbn": "B042", "member_id": "M001"})
print(buffer.getvalue())
''',
            "solution": '''import io
import json
import logging

class JsonFormatter(logging.Formatter):
    FIELDS = ("isbn", "member_id", "request_id", "duration_ms")

    def format(self, record):
        data = {"level": record.levelname, "logger": record.name, "event": record.getMessage()}
        for field in self.FIELDS:
            if hasattr(record, field):
                data[field] = getattr(record, field)
        if record.exc_info:
            data["error"] = self.formatException(record.exc_info)
        return json.dumps(data)

buffer = io.StringIO()
handler = logging.StreamHandler(buffer)
handler.setFormatter(JsonFormatter())
logger = logging.getLogger("bookvault.loans")
logger.handlers.clear()
logger.addHandler(handler)
logger.propagate = False
logger.setLevel(logging.INFO)

logger.info("book_borrowed", extra={"isbn": "B042", "member_id": "M001"})
print(buffer.getvalue())
''',
            "tests": '''import io as _io, json as _json, logging as _lg
_b = _io.StringIO()
_h = _lg.StreamHandler(_b)
_h.setFormatter(JsonFormatter())
_log = _lg.getLogger("lab.json")
_log.handlers.clear()
_log.addHandler(_h)
_log.propagate = False
_log.setLevel(_lg.INFO)
_log.info("book_borrowed", extra={"isbn": "B042", "member_id": "M001", "colour": "red"})
_log.warning("loan_limit_near")
try:
    raise ValueError("bad isbn")
except ValueError:
    _log.exception("cover_fetch_failed", extra={"request_id": "req-1"})
_lines = _b.getvalue().splitlines()
assert len(_lines) == 3, f"each record should be exactly one line of JSON, got {len(_lines)} lines"
try:
    _recs = [_json.loads(_x) for _x in _lines]
except ValueError:
    raise AssertionError("format must return valid JSON: use json.dumps(data)")
assert _recs[0] == {"level": "INFO", "logger": "lab.json", "event": "book_borrowed", "isbn": "B042", "member_id": "M001"}, f"first record is {_recs[0]} (fields not in FIELDS, like colour, are left out)"
assert _recs[1] == {"level": "WARNING", "logger": "lab.json", "event": "loan_limit_near"}, f"a record without extra fields should only have level, logger and event, got {_recs[1]}"
assert _recs[2].get("level") == "ERROR" and _recs[2].get("request_id") == "req-1", "the exception record should be ERROR with its request_id"
assert "ValueError" in _recs[2].get("error", ""), "when the record has exc_info, add the traceback text under 'error' (self.formatException(record.exc_info))"''',
        },
        "practice": [
            {
                "task": "Log an event with fields. Write `log_borrow(logger, isbn, member_id, request_id)`: log at INFO the stable event name `\"book_borrowed\"` with `extra=` holding `isbn`, `member_id` and `request_id`. The message must be exactly `book_borrowed` every time, whatever the values.",
                "hints": [
                    "The values go in `extra={...}`, not in the message text.",
                    "`logger.info(\"book_borrowed\", extra={\"isbn\": isbn, \"member_id\": member_id, \"request_id\": request_id})`",
                ],
                "starter": '''import logging

def log_borrow(logger, isbn, member_id, request_id):
    logger.info(f"Borrowed book {isbn} for {member_id}!")

log_borrow(logging.getLogger("bookvault.loans"), "B042", "M001", "req-1")
''',
                "solution": '''import logging

def log_borrow(logger, isbn, member_id, request_id):
    logger.info("book_borrowed", extra={"isbn": isbn, "member_id": member_id, "request_id": request_id})

log_borrow(logging.getLogger("bookvault.loans"), "B042", "M001", "req-1")
''',
                "tests": _KEEP + '''_logger, _keep = _fresh("lab.borrow")
log_borrow(_logger, "B042", "M001", "req-1")
log_borrow(_logger, "B077", "M002", "req-2")
assert len(_keep.records) == 2, "log_borrow should log exactly one record per call"
_r1, _r2 = _keep.records
assert _r1.getMessage() == "book_borrowed" and _r2.getMessage() == "book_borrowed", f"the message must always be the event name 'book_borrowed', got {_r1.getMessage()!r}"
assert _r1.levelname == "INFO", "log the event at INFO"
assert getattr(_r1, "isbn", None) == "B042" and getattr(_r1, "member_id", None) == "M001" and getattr(_r1, "request_id", None) == "req-1", "pass isbn, member_id and request_id with extra={...}"
assert getattr(_r2, "isbn", None) == "B077" and getattr(_r2, "request_id", None) == "req-2", "the fields must come from the arguments"''',
            },
            {
                "task": "Log errors with their traceback. Write `safe_fetch(logger, isbn, fetch)`: return `fetch(isbn)`. If it raises any `Exception`, log the event `\"cover_fetch_failed\"` with `logger.exception` and `extra={\"isbn\": isbn}`, then return `None`.",
                "hints": [
                    "Wrap `return fetch(isbn)` in `try:` and catch `except Exception:`.",
                    "In the `except`: `logger.exception(\"cover_fetch_failed\", extra={\"isbn\": isbn})` and `return None`.",
                ],
                "starter": '''import logging

def safe_fetch(logger, isbn, fetch):
    try:
        return fetch(isbn)
    except Exception as e:
        logger.error(f"failed: {e}")
        return None

def broken_fetch(isbn):
    raise ConnectionError("cover server down")

print(safe_fetch(logging.getLogger("bookvault.covers"), "B042", broken_fetch))
''',
                "solution": '''import logging

def safe_fetch(logger, isbn, fetch):
    try:
        return fetch(isbn)
    except Exception:
        logger.exception("cover_fetch_failed", extra={"isbn": isbn})
        return None

def broken_fetch(isbn):
    raise ConnectionError("cover server down")

print(safe_fetch(logging.getLogger("bookvault.covers"), "B042", broken_fetch))
''',
                "tests": _KEEP + '''_logger, _keep = _fresh("lab.safe")
assert safe_fetch(_logger, "B1", lambda isbn: f"url/{isbn}") == "url/B1", "when fetch works, return its result"
assert _keep.records == [], "when fetch works, log nothing"
def _boom(isbn):
    raise KeyError(isbn)
assert safe_fetch(_logger, "B2", _boom) is None, "when fetch raises, return None"
assert len(_keep.records) == 1, "log exactly one record when fetch fails"
_r = _keep.records[0]
assert _r.getMessage() == "cover_fetch_failed", f"the event name should be 'cover_fetch_failed', got {_r.getMessage()!r}"
assert _r.levelname == "ERROR", "logger.exception logs at ERROR level"
assert _r.exc_info and _r.exc_info[0] is KeyError, "use logger.exception so the traceback is attached to the record"
assert getattr(_r, "isbn", None) == "B2", "add extra={'isbn': isbn}"''',
            },
            {
                "task": "Time a request. Write `timed_fetch(logger, isbn, request_id, fetch, clock)`: read `started = clock()`, call `fetch(isbn)`, then work out `duration_ms = round((clock() - started) * 1000)`. Log `\"cover_fetch_succeeded\"` at INFO with `extra` holding `isbn`, `request_id` and `duration_ms`, and return the fetch result. `clock` is passed in, so the checks can use a fake one.",
                "hints": [
                    "Call `clock()` once before `fetch` and once after it.",
                    "`logger.info(\"cover_fetch_succeeded\", extra={\"isbn\": isbn, \"request_id\": request_id, \"duration_ms\": duration_ms})`, then `return url`.",
                ],
                "starter": '''import logging

def timed_fetch(logger, isbn, request_id, fetch, clock):
    return fetch(isbn)

ticks = iter([5.0, 5.25])
url = timed_fetch(logging.getLogger("bookvault.covers"), "B042", "req-7",
                  fetch=lambda isbn: f"https://covers.example.com/{isbn}.jpg",
                  clock=lambda: next(ticks))
print(url)
''',
                "solution": '''import logging

def timed_fetch(logger, isbn, request_id, fetch, clock):
    started = clock()
    url = fetch(isbn)
    duration_ms = round((clock() - started) * 1000)
    logger.info("cover_fetch_succeeded",
                extra={"isbn": isbn, "request_id": request_id, "duration_ms": duration_ms})
    return url

ticks = iter([5.0, 5.25])
url = timed_fetch(logging.getLogger("bookvault.covers"), "B042", "req-7",
                  fetch=lambda isbn: f"https://covers.example.com/{isbn}.jpg",
                  clock=lambda: next(ticks))
print(url)
''',
                "tests": _KEEP + '''_logger, _keep = _fresh("lab.timed")
_t = iter([2.0, 2.318])
_u = timed_fetch(_logger, "B9", "req-42", fetch=lambda isbn: "u-" + isbn, clock=lambda: next(_t))
assert _u == "u-B9", "return what fetch returned"
assert len(_keep.records) == 1, "log exactly one record"
_r = _keep.records[0]
assert _r.getMessage() == "cover_fetch_succeeded" and _r.levelname == "INFO", "log 'cover_fetch_succeeded' at INFO"
assert getattr(_r, "duration_ms", None) == 318, f"from 2.0 s to 2.318 s is 318 ms, got {getattr(_r, 'duration_ms', None)!r}"
assert getattr(_r, "request_id", None) == "req-42" and getattr(_r, "isbn", None) == "B9", "include request_id and isbn in extra"''',
            },
            {
                "task": "No secrets in logs. Write `redact(fields)`: return a **new** dictionary with the same keys, where the value of every key in `SECRET_KEYS` is replaced by `\"***\"`. Leave the original dictionary unchanged. Then log the event `\"member_login\"` with `extra=redact(login)`.",
                "hints": [
                    "A dictionary comprehension builds the new dictionary: `{key: ... for key, value in fields.items()}`.",
                    "`return {key: \"***\" if key in SECRET_KEYS else value for key, value in fields.items()}`, then `logger.info(\"member_login\", extra=redact(login))`.",
                ],
                "starter": '''import logging

SECRET_KEYS = {"password", "token", "api_key"}

def redact(fields):
    return fields

logger = logging.getLogger("bookvault.auth")
login = {"member_id": "M001", "password": "hunter2", "request_id": "req-5"}
logger.info("member_login", extra=login)
print(redact(login))
''',
                "solution": '''import logging

SECRET_KEYS = {"password", "token", "api_key"}

def redact(fields):
    return {key: "***" if key in SECRET_KEYS else value for key, value in fields.items()}

logger = logging.getLogger("bookvault.auth")
login = {"member_id": "M001", "password": "hunter2", "request_id": "req-5"}
logger.info("member_login", extra=redact(login))
print(redact(login))
''',
                "tests": '''_src = {"member_id": "M1", "password": "pw", "token": "t0k", "api_key": "k", "isbn": "B1"}
_out = redact(_src)
assert _out == {"member_id": "M1", "password": "***", "token": "***", "api_key": "***", "isbn": "B1"}, f"secrets should become '***' and the rest stay, got {_out}"
assert _src["password"] == "pw", "redact must not change the original dictionary: build a new one"
assert redact({"isbn": "B2"}) == {"isbn": "B2"}, "a dictionary without secrets comes back the same"
assert "extra=redact(" in __source__.replace(" ", ""), "log the login with extra=redact(login)"
assert "extra=login)" not in __source__.replace(" ", ""), "don't log the raw login dictionary: it holds the password"''',
            },
        ],
    },
]

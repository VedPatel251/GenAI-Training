"""Detective X Day 2: medium cases (2-4 skills, 2-3 steps; most are reskinned assignments).

Case format (see .claude/skills/write-cases/SKILL.md for the full rules):
  id, tier ("small" | "medium" | "big"), title, teaser, skills, story, suspects,
  variants  2-3 evidence scripts; the trainee's code runs on each, answers must differ
  steps     [{question, starter, solution, tests, tips: [2 tips], reveal}]
  closing   text shown when the case is closed; optional "fragment" (an X clue, big cases)
Check with:  python engine/build_game.py --check cases_medium --day day2
"""

# ---------------------------------------------------------------- shared evidence pieces

# overdue-mixup (Q2): the notice machine's Library, still with the assignment's bug.
_OVERDUE_CORE = r'''from dataclasses import dataclass
from datetime import date

@dataclass
class Loan:
    item_id: str
    member_id: str
    due_on: date
    returned_on: date | None = None

class Library:
    def __init__(self):
        self.loans = []

    def borrow(self, item_id, member_id, *, due_on):
        loan = Loan(item_id, member_id, due_on)
        self.loans.append(loan)
        return loan

    def return_item(self, item_id, *, returned_on):
        for loan in self.loans:
            if loan.item_id == item_id and loan.returned_on is None:
                loan.returned_on = returned_on
                return loan
        raise ValueError(f"No active loan for {item_id}")

    def overdue_loans(self, *, today):        # the notice machine's check
        return [loan for loan in self.loans if loan.due_on < today]

_pause_log = []

def pause(where, **variables):               # the lab's stand-in for a breakpoint
    print(f"PAUSED at {where}:", variables)
    _pause_log.append(variables)

_pause = pause

def stock(lib):
    """Replay the desk ledger into a library and return it."""
    for item_id, member_id, due_on, returned_on in LEDGER:
        lib.borrow(item_id, member_id, due_on=due_on)
        if returned_on is not None:
            lib.return_item(item_id, returned_on=returned_on)
    return lib

'''

_FIXED_LIBRARY = r'''class FixedLibrary(Library):
    def overdue_loans(self, *, today):
        return [loan for loan in self.loans
                if loan.returned_on is None and loan.due_on < today]
'''

# json-trail (Q1 logging): the night desk replays its requests through any logger you give it.
_REPLAY = r'''import io
import json
import logging

def replay(logger, night):
    """The night desk's requests, replayed through your logger."""
    for staff_id, action, item_id, request_id in night:
        fields = {"staff_id": staff_id, "item_id": item_id, "request_id": request_id}
        if action == "lookup":
            logger.debug("catalog_lookup", extra=fields)
        elif action == "borrow":
            logger.info("book_borrowed", extra=fields)
        elif action == "return":
            logger.info("book_returned", extra=fields)
        elif action == "delete":
            logger.warning("item_deleted", extra=fields)
        elif action == "cover":
            try:
                raise ConnectionError("cover server timed out")
            except ConnectionError:
                logger.exception("cover_fetch_failed", extra=fields)

'''

_JSON_FORMATTER = r'''class JsonFormatter(logging.Formatter):
    FIELDS = ("staff_id", "item_id", "request_id")

    def format(self, record):
        data = {"level": record.levelname, "logger": record.name, "event": record.getMessage()}
        for field in self.FIELDS:
            if hasattr(record, field):
                data[field] = getattr(record, field)
        if record.exc_info:
            data["error"] = self.formatException(record.exc_info)
        return json.dumps(data)
'''

_JSON_SETUP_FN = r'''
def setup_logger(name, console, audit):
    logger = logging.getLogger(name)
    logger.handlers.clear()
    logger.propagate = False
    logger.setLevel(logging.INFO)

    screen = logging.StreamHandler(console)
    screen.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
    logger.addHandler(screen)

    audit_file = logging.StreamHandler(audit)     # stands in for logging.FileHandler("audit.jsonl")
    audit_file.setLevel(logging.WARNING)
    audit_file.setFormatter(JsonFormatter())
    logger.addHandler(audit_file)
    return logger
'''

_JSON_SETUP = _JSON_FORMATTER + _JSON_SETUP_FN

_JSON_FORMAT_STARTER = r'''class JsonFormatter(logging.Formatter):
    FIELDS = ("staff_id", "item_id", "request_id")

    def format(self, record):
        return record.getMessage()      # make this one line of JSON
'''

_JSON_RUN = r'''
console = io.StringIO()
audit = io.StringIO()
logger = setup_logger("lab.night", console, audit)
replay(logger, NIGHT)
'''

# ---------------------------------------------------------------- test-bench pieces

# The mini pytest from the first-tests lesson, plus the lab's suspect runner.
_MINI_PYTEST = r'''# ---- lab equipment: mini pytest (real pytest does this for you) ----
from contextlib import contextmanager

@contextmanager
def raises(error, match=""):
    try:
        yield
    except error as e:
        assert match in str(e), f"{match!r} is not in the message {str(e)!r}"
        return
    raise AssertionError(f"DID NOT RAISE {error.__name__}")

def run_tests(namespace):
    passed = 0
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"{name} PASSED")
                passed += 1
            except Exception as e:
                print(f"{name} FAILED: {type(e).__name__}: {e}")
                failed += 1
    print(f"===== {passed} passed, {failed} failed =====")

def lab_run(name, suspect):
    """Swap the global `name` for `suspect`, run every test_ function quietly,
    put the real one back, and return the names of the tests that failed."""
    real = globals()[name]
    globals()[name] = suspect
    failed = []
    try:
        for test_name, fn in list(globals().items()):
            if test_name.startswith("test_") and callable(fn):
                try:
                    fn()
                except Exception:
                    failed.append(test_name)
    finally:
        globals()[name] = real
    return failed

'''


def _suspect_classes(base, suffix, lineup, bodies):
    """Evidence code: one subclass of `base` per clerk, with that clerk's rewrite, plus SUSPECTS."""
    out = ["# ---- the rewrites under suspicion ----\n\n"]
    for clerk, kind in lineup:
        out.append(f"class {clerk}{suffix}({base}):\n" + bodies[kind] + "\n")
    out.append("SUSPECTS = {" + ", ".join(f'"{c}": {c}{suffix}' for c, _ in lineup) + "}\n")
    return "".join(out)


# book-inquest (Q3): the lab's Book and the clerks' rewrites.
_BOOK_CORE = r'''# ---- the lab's Book ----
from dataclasses import dataclass

class BookVaultError(Exception):
    pass

class ItemUnavailableError(BookVaultError, ValueError):
    pass

@dataclass
class Book:
    title: str
    item_id: str
    author: str
    pages: int
    available: bool = True

    def __post_init__(self):
        if not self.title.strip():
            raise ValueError("title cannot be empty")
        if self.pages <= 0:
            raise ValueError("pages must be positive")

    def borrow(self):
        if not self.available:
            raise ItemUnavailableError(f"{self.item_id} is unavailable")
        self.available = False

    def return_item(self):
        self.available = True

'''

_BOOK_REWRITES = {
    "ok_borrow": '''    def borrow(self):
        if self.available is False:
            raise ItemUnavailableError(f"{self.item_id} is unavailable right now")
        self.available = False
''',
    "ok_repr": '''    def __repr__(self):
        state = "in" if self.available else "out"
        return f"{type(self).__name__}({self.item_id!r}, {self.title!r}, {state})"
''',
    "ok_return": '''    def return_item(self):
        if not self.available:
            self.available = True
''',
    "pages": '''    def __post_init__(self):
        if not self.title.strip():
            raise ValueError("title cannot be empty")
''',
    "title": '''    def __post_init__(self):
        if self.pages <= 0:
            raise ValueError("pages must be positive")
''',
    "onloan": '''    def __post_init__(self):
        Book.__post_init__(self)
        self.available = False
''',
    "twice": '''    def borrow(self):
        self.available = False
''',
    "words": '''    def borrow(self):
        if not self.available:
            raise ValueError("already out")
        self.available = False
''',
    "return": '''    def return_item(self):
        pass
''',
    "repr": '''    def __repr__(self):
        return f"<{self.title}>"
''',
}


_SEAL_RUN = "\n# ---- the lab keeps sealed copies of its equipment ----\n_lab_run = lab_run\n_run_tests = run_tests\n_raises = raises\n"
_CHECK_RUN = '''assert lab_run is _lab_run and run_tests is _run_tests and raises is _raises, "don't redefine the lab's equipment (lab_run, run_tests, raises): the checker uses the lab's own copies"
'''


def _book_evidence(lineup):
    return _MINI_PYTEST + _BOOK_CORE + _suspect_classes("Book", "Book", lineup, _BOOK_REWRITES) + _SEAL_RUN


_BOOK_TESTS_1 = r'''def test_book_creation():
    b = Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    assert b.title == "Clean Code"
    assert b.available is True

def test_valid_book():
    b = Book(title="Dune", item_id="B002", author="Frank Herbert", pages=412)
    assert b.item_id == "B002"
    assert b.author == "Frank Herbert"
    assert b.pages == 412

def test_pages_must_be_positive():
    with raises(ValueError, match="positive"):
        Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=0)

def test_title_cannot_be_empty():
    with raises(ValueError, match="empty"):
        Book(title="", item_id="B001", author="Robert Martin", pages=464)
'''

_BOOK_TESTS_2 = r'''
def test_double_borrow_raises():
    b = Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    b.borrow()
    with raises(ValueError, match="unavailable"):
        b.borrow()

def test_return_makes_available():
    b = Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    b.borrow()
    b.return_item()
    assert b.available is True

def test_repr_shows_class_and_id():
    b = Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    assert "Book" in repr(b)
    assert "B001" in repr(b)
'''

_BOOK_VERDICT = r'''
failures = {}
for clerk, suspect in SUSPECTS.items():
    failures[clerk] = lab_run("Book", suspect)
'''

# Hidden checks: a reference battery that says which Book classes are really broken.
_BOOK_REF = r'''def _bad_creation(_cls):
    try:
        _b = _cls(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    except Exception:
        return True
    if (_b.title, _b.item_id, _b.author, _b.pages, _b.available) != ("Clean Code", "B001", "Robert Martin", 464, True):
        return True
    for _change, _word in (({"pages": 0}, "positive"), ({"title": ""}, "empty")):
        _args = {"title": "Clean Code", "item_id": "B001", "author": "Robert Martin", "pages": 464}
        _args.update(_change)
        try:
            _cls(**_args)
        except ValueError as _e:
            if _word not in str(_e):
                return True
            continue
        except Exception:
            return True
        return True
    return False

def _bad_loans(_cls):
    _b = _cls(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    if "B001" not in repr(_b) or "Book" not in repr(_b):
        return True
    _b.borrow()
    try:
        _b.borrow()
        return True
    except ValueError as _e:
        if "unavailable" not in str(_e):
            return True
    _b.return_item()
    return _b.available is not True
'''

# fresh-evidence (Q5): the fixture runner, the Library, and the clerks' fixtures.
_FIX_LAB = r'''# ---- lab equipment: mini pytest with fixtures ----
import inspect

FIXTURES = {}

def fixture(fn):
    FIXTURES[fn.__name__] = fn
    return fn

def call_with_fixtures(fn, made, teardowns):
    kwargs = {}
    for name in inspect.signature(fn).parameters:
        if name not in made:
            value = call_with_fixtures(FIXTURES[name], made, teardowns)
            if inspect.isgenerator(value):
                teardowns.append(value)
                value = next(value)
            made[name] = value
        kwargs[name] = made[name]
    return fn(**kwargs)

def run_tests(namespace):
    passed = 0
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            teardowns = []
            try:
                call_with_fixtures(fn, {}, teardowns)
                result = "PASSED"
                passed += 1
            except Exception as e:
                result = f"FAILED: {type(e).__name__}: {e}"
                failed += 1
            for gen in reversed(teardowns):
                next(gen, None)
            print(name, result)
    print(f"===== {passed} passed, {failed} failed =====")

def lab_fixtures(swaps):
    """Swap some of your fixtures for a suspect's versions (a dict name -> function),
    run every test quietly, put yours back, and return the names of the tests that failed."""
    saved = dict(FIXTURES)
    FIXTURES.update(swaps)
    failed = []
    try:
        for name, fn in list(globals().items()):
            if name.startswith("test_") and callable(fn):
                try:
                    call_with_fixtures(fn, {}, [])
                except Exception:
                    failed.append(name)
    finally:
        FIXTURES.clear()
        FIXTURES.update(saved)
    return failed

# ---- the code under test ----
from dataclasses import dataclass

@dataclass
class Book:
    title: str
    item_id: str
    author: str
    pages: int
    available: bool = True

@dataclass
class Member:
    member_id: str
    name: str
    email: str

class Library:
    def __init__(self, name):
        self.name = name
        self.items = {}
        self.members = {}

    def add_item(self, item):
        self.items[item.item_id] = item

    def add_member(self, member):
        self.members[member.member_id] = member

    def borrow(self, item_id, member_id):
        self.items[item_id].available = False

    def __len__(self):
        return len(self.items)

'''

# Each clerk's conftest: a function that builds that clerk's fixtures fresh (CLERK = name prefix).
_FIX_REWRITES = {
    "ok": '''def CLERK_conftest():
    def stocked_library():
        lib = Library("Test Vault")
        lib.add_item(Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464))
        lib.add_member(Member(member_id="M001", name="Asha", email="asha@example.com"))
        return lib
    return {"stocked_library": stocked_library}
''',
    "ok_member": '''def CLERK_conftest():
    def member():
        return Member("M001", "Asha", "asha@example.com")
    return {"member": member}
''',
    "cache": '''def CLERK_conftest():
    cache = {}
    def stocked_library(empty_library, clean_code, member):
        if "lib" not in cache:
            empty_library.add_item(clean_code)
            empty_library.add_member(member)
            cache["lib"] = empty_library
        return cache["lib"]
    return {"stocked_library": stocked_library}
''',
    "book": '''def CLERK_conftest():
    book = Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    def clean_code():
        return book
    return {"clean_code": clean_code}
''',
    "spare": '''def CLERK_conftest():
    spare = Library("Test Vault")
    def empty_library():
        return spare
    return {"empty_library": empty_library}
''',
    "nomember": '''def CLERK_conftest():
    def stocked_library(empty_library, clean_code, member):
        empty_library.add_item(clean_code)
        return empty_library
    return {"stocked_library": stocked_library}
''',
    "twobooks": '''def CLERK_conftest():
    def stocked_library(empty_library, clean_code, member):
        empty_library.add_item(clean_code)
        empty_library.add_item(Book(title="Refactoring", item_id="B002", author="Martin Fowler", pages=448))
        empty_library.add_member(member)
        return empty_library
    return {"stocked_library": stocked_library}
''',
}


def _fix_evidence(lineup):
    out = [_FIX_LAB, "# ---- the conftests under suspicion: each call builds that clerk's fixtures fresh ----\n\n"]
    for clerk, kind in lineup:
        out.append(_FIX_REWRITES[kind].replace("CLERK", clerk.lower()) + "\n")
    out.append("SUSPECTS = {" + ", ".join(f'"{c}": {c.lower()}_conftest' for c, _ in lineup) + "}\n")
    out.append(_SEAL_FIX)
    return "".join(out)


_SEAL_FIX = ("\n# ---- the lab keeps sealed copies of its equipment ----\n_lab_fixtures = lab_fixtures\n_run_tests = run_tests\n"
             "_call_with_fixtures = call_with_fixtures\n_fixture = fixture\n_FIXTURES = FIXTURES\n")
_CHECK_FIX = '''assert lab_fixtures is _lab_fixtures and run_tests is _run_tests and call_with_fixtures is _call_with_fixtures and fixture is _fixture and FIXTURES is _FIXTURES, "don't redefine the lab's equipment (lab_fixtures, run_tests, fixture, call_with_fixtures, FIXTURES): the checker uses the lab's own copies"
'''


_FIXTURES_SOLUTION = r'''@fixture
def empty_library():
    return Library("Test Vault")

@fixture
def clean_code():
    return Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)

@fixture
def member():
    return Member(member_id="M001", name="Asha", email="asha@example.com")

@fixture
def stocked_library(empty_library, clean_code, member):
    empty_library.add_item(clean_code)
    empty_library.add_member(member)
    return empty_library

'''

_FIX_GIVEN_TESTS = r'''def test_empty_library_len(empty_library):
    assert len(empty_library) == 0

def test_stocked_library_len(stocked_library):
    assert len(stocked_library) == 1

def test_stocked_has_member(stocked_library, member):
    assert member.member_id in stocked_library.members
'''

_FIX_FRESH_TESTS = r'''
def test_borrow_does_not_leak(stocked_library):
    stocked_library.borrow("B001", "M001")
    assert stocked_library.items["B001"].available is False

def test_empty_after_borrow(empty_library):
    assert len(empty_library) == 0

def test_next_test_is_fresh(stocked_library):
    assert stocked_library.items["B001"].available is True
'''

_FIX_VERDICT = r'''
failures = {}
for clerk, conftest in SUSPECTS.items():
    failures[clerk] = lab_fixtures(conftest())
'''

# Hidden checks: fresh copies of the leaky fixtures, so every check starts clean.
_FIX_MUTANTS = r'''def _leaks():
    _cache = {}
    def _cached(empty_library, clean_code, member):
        if "lib" not in _cache:
            empty_library.add_item(clean_code)
            empty_library.add_member(member)
            _cache["lib"] = empty_library
        return _cache["lib"]
    _book = Book(title="Clean Code", item_id="B001", author="Robert Martin", pages=464)
    _spare = Library("Test Vault")
    return [("a stocked_library that is built once and reused", {"stocked_library": _cached}),
            ("a clean_code fixture that hands every test the same Book", {"clean_code": lambda: _book}),
            ("an empty_library fixture that hands every test the same Library", {"empty_library": lambda: _spare})]
'''

# loan-limit (Q7): BookVault with no limit yet, and the clerks' limit rewrites.
_LOAN_CORE = r'''# ---- BookVault, before the limit ----
from dataclasses import dataclass

class BookVaultError(Exception):
    pass

class ItemUnavailableError(BookVaultError, ValueError):
    pass

@dataclass
class Book:
    item_id: str
    available: bool = True

    def borrow(self):
        if not self.available:
            raise ItemUnavailableError(f"{self.item_id} is unavailable")
        self.available = False

    def return_item(self):
        self.available = True

@dataclass
class Loan:
    item_id: str
    member_id: str
    returned: bool = False

class Library:
    def __init__(self, name, max_active_loans=3):
        self.name = name
        self.max_active_loans = max_active_loans
        self.items = {}
        self.loans = []

    def add_item(self, item):
        self.items[item.item_id] = item

    def active_loans(self, member_id):
        return [loan for loan in self.loans if loan.member_id == member_id and not loan.returned]

    def borrow(self, item_id, member_id):          # no limit yet
        self.items[item_id].borrow()
        loan = Loan(item_id, member_id)
        self.loans.append(loan)
        return loan

    def return_item(self, item_id):
        for loan in self.loans:
            if loan.item_id == item_id and not loan.returned:
                loan.returned = True
                self.items[item_id].return_item()
                return loan
        raise BookVaultError(f"No active loan for {item_id}")

'''

_LIMIT_REWRITES = {
    "ok": '''    def borrow(self, item_id, member_id):
        active = self.active_loans(member_id)
        if len(active) == self.max_active_loans:
            raise LoanLimitExceededError(f"{member_id} already has {len(active)} loans")
        return Library.borrow(self, item_id, member_id)
''',
    "ok2": '''    def borrow(self, item_id, member_id):
        if len(self.active_loans(member_id)) >= self.max_active_loans:
            raise LoanLimitExceededError("loan limit reached")
        return super().borrow(item_id, member_id)
''',
    "returned": '''    def borrow(self, item_id, member_id):
        mine = [loan for loan in self.loans if loan.member_id == member_id]
        if len(mine) >= self.max_active_loans:
            raise LoanLimitExceededError("loan limit reached")
        return super().borrow(item_id, member_id)
''',
    "offbyone": '''    def borrow(self, item_id, member_id):
        if len(self.active_loans(member_id)) > self.max_active_loans:
            raise LoanLimitExceededError("loan limit reached")
        return super().borrow(item_id, member_id)
''',
    "hardcoded": '''    def borrow(self, item_id, member_id):
        if len(self.active_loans(member_id)) >= 3:
            raise LoanLimitExceededError("loan limit reached")
        return super().borrow(item_id, member_id)
''',
    "wrongexc": '''    def borrow(self, item_id, member_id):
        if len(self.active_loans(member_id)) >= self.max_active_loans:
            raise ItemUnavailableError("loan limit reached")
        return super().borrow(item_id, member_id)
''',
}

_LIMIT_SOLUTION = r'''class LoanLimitExceededError(BookVaultError):
    pass

class LimitedLibrary(Library):
    def borrow(self, item_id, member_id):
        if len(self.active_loans(member_id)) >= self.max_active_loans:
            raise LoanLimitExceededError(f"{member_id} has reached the limit")
        return super().borrow(item_id, member_id)
'''

_LIMIT_REPLAY = r'''
desk = LimitedLibrary("Night Desk", max_active_loans=LIMIT)
for item_id in SHELF:
    desk.add_item(Book(item_id))
'''

_LIMIT_HELPER = r'''
def make_library(limit=3):
    lib = LimitedLibrary("Test Vault", max_active_loans=limit)
    for item_id in ["B001", "B002", "B003", "B004", "B005"]:
        lib.add_item(Book(item_id))
    return lib

'''

_LIMIT_TESTS = r'''def test_can_borrow_three():
    lib = make_library()
    for item_id in ["B001", "B002", "B003"]:
        lib.borrow(item_id, "M001")
    assert len(lib.active_loans("M001")) == 3

def test_fourth_borrow_raises():
    lib = make_library()
    for item_id in ["B001", "B002", "B003"]:
        lib.borrow(item_id, "M001")
    with raises(LoanLimitExceededError):
        lib.borrow("B004", "M001")

def test_return_frees_a_slot():
    lib = make_library()
    for item_id in ["B001", "B002", "B003"]:
        lib.borrow(item_id, "M001")
    lib.return_item("B002")
    lib.borrow("B004", "M001")
    assert len(lib.active_loans("M001")) == 3

def test_limit_of_one():
    lib = make_library(limit=1)
    lib.borrow("B001", "M001")
    with raises(LoanLimitExceededError):
        lib.borrow("B002", "M001")
'''


def _limit_evidence(data, lineup):
    return _MINI_PYTEST + _LOAN_CORE + _suspect_classes("Library", "Library", lineup, _LIMIT_REWRITES) + data + _SEAL_RUN


# ---------------------------------------------------------------- decoy-kit pieces

# smuggled-records (Q8): a JSON-lines manifest and the couriers' shifts.
_SMUGGLE_HEAD = r'''import io
import json
from dataclasses import dataclass, field

KNOWN_TYPES = ("book", "magazine", "audiobook")

'''


def _jsonl(lines):
    """Evidence code: a JSON-lines text built from a list of raw lines, one per source line."""
    return "MANIFEST = (\n" + "".join(f"    {line + chr(10)!r}\n" for line in lines) + ")\n"


_REPORT_SOLUTION = r'''@dataclass
class ImportReport:
    items: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    total_lines: int = 0

    @property
    def loaded_count(self):
        return len(self.items)

    @property
    def error_count(self):
        return len(self.errors)

def parse_record(raw):
    data = json.loads(raw)
    if not isinstance(data, dict) or data.get("type") not in KNOWN_TYPES:
        raise ValueError("not a known record type")
    return data

def load_items(f):
    report = ImportReport()
    for line_no, raw in enumerate(f, start=1):
        raw = raw.strip()
        report.total_lines += 1
        if not raw:
            continue
        try:
            report.items.append(parse_record(raw))
        except ValueError as e:
            report.errors.append({"line": line_no, "raw": raw, "error": str(e)})
    return report
'''

_REPORT_RUN = r'''
report = load_items(io.StringIO(MANIFEST))
print(len(report.items), "loaded,", len(report.errors), "errors,", report.total_lines, "lines")
'''

# fake-clock (Q10): the lab's three unstable functions and each clerk's rewrite of them.
_CLOCK_LAB = r'''# ---- lab equipment: mini pytest (real pytest does this for you) ----
from contextlib import contextmanager

@contextmanager
def raises(error, match=""):
    try:
        yield
    except error as e:
        assert match in str(e), f"{match!r} is not in the message {str(e)!r}"
        return
    raise AssertionError(f"DID NOT RAISE {error.__name__}")

def run_tests(namespace):
    passed = 0
    failed = 0
    for name, fn in list(namespace.items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"{name} PASSED")
                passed += 1
            except Exception as e:
                print(f"{name} FAILED: {type(e).__name__}: {e}")
                failed += 1
    print(f"===== {passed} passed, {failed} failed =====")

def lab_swap(swaps):
    """Swap several globals at once (a dict name -> suspect function), run every test_
    function quietly, put the real ones back, and return the names of the tests that failed."""
    real = {}
    for name in swaps:
        real[name] = globals()[name]
        globals()[name] = swaps[name]
    failed = []
    try:
        for test_name, fn in list(globals().items()):
            if test_name.startswith("test_") and callable(fn):
                try:
                    fn()
                except Exception:
                    failed.append(test_name)
    finally:
        for name in real:
            globals()[name] = real[name]
    return failed

# ---- the lab's code: three things a test can't trust ----
import os
from datetime import date
from unittest.mock import MagicMock

def real_fetch(url):
    raise RuntimeError("a real network call during a test!")

def data_path(env=os.environ):
    return env.get("BOOKVAULT_DATA_PATH", "data/books.jsonl")

def days_late(due, clock=date.today):
    return max(0, (clock() - due).days)

def cover_url(isbn, fetch=real_fetch):
    return fetch(f"https://covers.example/{isbn}")["url"]

# ---- the rewrites under suspicion ----

'''

_CLOCK_REWRITES = {
    "data_path": {
        "ok": '''def CLERK_data_path(env=os.environ):
    return env.get("BOOKVAULT_DATA_PATH", "data/books.jsonl")
''',
        "ok2": '''def CLERK_data_path(env=os.environ):
    if "BOOKVAULT_DATA_PATH" in env:
        return env["BOOKVAULT_DATA_PATH"]
    return "data/books.jsonl"
''',
        "env_real": '''def CLERK_data_path(env=os.environ):
    return os.environ.get("BOOKVAULT_DATA_PATH", "data/books.jsonl")
''',
        "default": '''def CLERK_data_path(env=os.environ):
    return env.get("BOOKVAULT_DATA_PATH", "books.json")
''',
    },
    "days_late": {
        "ok": '''def CLERK_days_late(due, clock=date.today):
    return max(0, (clock() - due).days)
''',
        "ok2": '''def CLERK_days_late(due, clock=date.today):
    late = (clock() - due).days
    if late < 0:
        return 0
    return late
''',
        "today": '''def CLERK_days_late(due, clock=date.today):
    return max(0, (date.today() - due).days)
''',
        "negative": '''def CLERK_days_late(due, clock=date.today):
    return (clock() - due).days
''',
    },
    "cover_url": {
        "ok": '''def CLERK_cover_url(isbn, fetch=real_fetch):
    return fetch(f"https://covers.example/{isbn}")["url"]
''',
        "ok2": '''def CLERK_cover_url(isbn, fetch=real_fetch):
    reply = fetch("https://covers.example/" + isbn)
    return reply["url"]
''',
        "twice": '''def CLERK_cover_url(isbn, fetch=real_fetch):
    if fetch(f"https://covers.example/{isbn}"):
        return fetch(f"https://covers.example/{isbn}")["url"]
''',
        "wrong_url": '''def CLERK_cover_url(isbn, fetch=real_fetch):
    return fetch(f"https://covers.example/{isbn[:3]}")["url"]
''',
        "ignores": '''def CLERK_cover_url(isbn, fetch=real_fetch):
    fetch(f"https://covers.example/{isbn}")
    return "https://img.example/default.jpg"
''',
        "network": '''def CLERK_cover_url(isbn, fetch=real_fetch):
    return real_fetch(f"https://covers.example/{isbn}")["url"]
''',
    },
}


def _clock_evidence(lineup):
    """lineup: [(clerk, data_path kind, days_late kind, cover_url kind)]."""
    out = [_CLOCK_LAB]
    entries = []
    for clerk, dp, dl, cu in lineup:
        low = clerk.lower()
        for fn, kind in (("data_path", dp), ("days_late", dl), ("cover_url", cu)):
            out.append(_CLOCK_REWRITES[fn][kind].replace("CLERK", low) + "\n")
        entries.append(f'    "{clerk}": {{"data_path": {low}_data_path, "days_late": {low}_days_late, "cover_url": {low}_cover_url}},\n')
    out.append("SUSPECTS = {\n" + "".join(entries) + "}\n")
    out.append("\n# ---- the lab keeps sealed copies of its equipment ----\n_lab_swap = lab_swap\n_run_tests = run_tests\n_raises = raises\n")
    return "".join(out)


_CHECK_SWAP = '''assert lab_swap is _lab_swap and run_tests is _run_tests and raises is _raises, "don't redefine the lab's equipment (lab_swap, run_tests, raises): the checker uses the lab's own copies"
'''


_CLOCK_TESTS_1 = r'''def test_path_from_env():
    assert data_path({"BOOKVAULT_DATA_PATH": "/tmp/test.jsonl"}) == "/tmp/test.jsonl"

def test_default_path():
    assert data_path({}) == "data/books.jsonl"

def test_days_late():
    fake_clock = lambda: date(2026, 5, 18)
    assert days_late(date(2026, 5, 1), clock=fake_clock) == 17
    assert days_late(date(2026, 6, 1), clock=fake_clock) == 0
'''

_CLOCK_TESTS_2 = r'''
def test_cover_url():
    fake = MagicMock(return_value={"url": "https://img.example/B001.jpg"})
    assert cover_url("9780132350884", fake) == "https://img.example/B001.jpg"
    fake.assert_called_once()
    args, kwargs = fake.call_args
    assert "9780132350884" in args[0]
'''

_CLOCK_VERDICT = r'''
failures = {}
for clerk, swaps in SUSPECTS.items():
    failures[clerk] = lab_swap(swaps)
'''

# paper-trail (Q14): validated, streamed import with strict mode.
_PAPER_HEAD = r'''import io
import json
from dataclasses import dataclass, field

@dataclass
class Book:
    title: str
    item_id: str
    author: str
    pages: int

@dataclass
class Magazine:
    title: str
    item_id: str
    issue: int

@dataclass
class AudioBook:
    title: str
    item_id: str
    narrator: str
    duration_min: int

KINDS = {"book": Book, "magazine": Magazine, "audiobook": AudioBook}
REQUIRED = {
    "book": ["title", "item_id", "author", "pages"],
    "magazine": ["title", "item_id", "issue"],
    "audiobook": ["title", "item_id", "narrator", "duration_min"],
}

class ImportRecordError(Exception):
    def __init__(self, line_no, reason):
        super().__init__(f"line {line_no}: {reason}")
        self.line_no = line_no

@dataclass
class ImportReport:
    items: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    total_lines: int = 0
    skipped: int = 0

    @property
    def loaded_count(self):
        return len(self.items)

    @property
    def error_count(self):
        return len(self.errors)

'''


def _catalog(lines):
    return "CATALOG = (\n" + "".join(f"    {line + chr(10)!r}\n" for line in lines) + ")\n"


_PAPER_PARSE = r'''def numbered_lines(f):
    for line_no, raw in enumerate(f, start=1):
        yield line_no, raw.strip()

def parse_record(raw):
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("not a JSON object")
    kind = data.get("type")
    if kind not in KINDS:
        raise ValueError(f"unknown type {kind!r}")
    missing = [name for name in REQUIRED[kind] if name not in data]
    if missing:
        raise ValueError(f"missing {', '.join(missing)}")
    return KINDS[kind](**{name: data[name] for name in REQUIRED[kind]})
'''

_PAPER_ACCEPT = r'''
accepted = []
for line_no, raw in numbered_lines(io.StringIO(CATALOG)):
    if not raw:
        continue
    try:
        accepted.append(parse_record(raw).item_id)
    except ValueError:
        pass
print("Accepted:", accepted)
'''

_PAPER_IMPORT = r'''def import_catalog(f, strict=False):
    report = ImportReport()
    for line_no, raw in numbered_lines(f):
        report.total_lines += 1
        if not raw:
            report.skipped += 1
            continue
        try:
            report.items.append(parse_record(raw))
        except ValueError as e:
            if strict:
                raise ImportRecordError(line_no, str(e))
            report.errors.append({"line": line_no, "raw": raw, "error": str(e)})
    return report
'''

_PAPER_RUN = r'''
report = import_catalog(io.StringIO(CATALOG))
try:
    import_catalog(io.StringIO(CATALOG), strict=True)
    stopped_at = None
except ImportRecordError as e:
    stopped_at = e.line_no
'''

# A file object that counts how many lines were pulled from it (to check streaming).
_SPY = r'''class _Spy:
    def __init__(self, lines):
        self.lines = lines
        self.pulled = 0
    def __iter__(self):
        return self
    def __next__(self):
        if self.pulled >= len(self.lines):
            raise StopIteration
        self.pulled += 1
        return self.lines[self.pulled - 1]
    def read(self):
        self.pulled = len(self.lines)
        return "".join(self.lines)
    def readlines(self):
        self.pulled = len(self.lines)
        return list(self.lines)
'''


CASES = [
    # ------------------------------------------------------------ microscope (Q2)
    {
        "id": "overdue-mixup",
        "tier": "medium",
        "title": "The Overdue Mix-up",
        "teaser": "The lab's notice machine fined patrons who had already brought their books back.",
        "skills": ["microscope", "inheritance"],
        "story": "The Forensics Lab took over the library desk's **overdue notice machine** last week. This morning the complaints poured in: patrons who returned their books on time got angry letters, and fines.\n\nForensics loaded the desk's code and data for you:\n- `Library`, with the machine's check `overdue_loans(*, today)`\n- `LEDGER`, every loan as `(item_id, member_id, due_on, returned_on)`; `returned_on` is `None` while the book is still out\n- `lib`, a `Library` already filled from the ledger by `stock(Library())`\n- `TODAY`, the date the notices were printed\n- `pause(where, **variables)`, the lab's stand-in for a breakpoint: it prints `PAUSED at ...` and the values you give it\n\n*(This is assignment Q2: debug and fix `overdue_loans`.)*",
        "suspects": [
            {"name": "the notice machine", "note": "Has printed the same kind of letter for years. Nobody has read its code since."},
            {"name": "the patrons who complained", "note": "Say they returned everything. Some of them might be lying."},
        ],
        "variants": [
            _OVERDUE_CORE + r'''TODAY = date(2026, 5, 18)
LEDGER = [
    ("B001", "M001", date(2026, 1, 10), date(2026, 1, 5)),
    ("B002", "M002", date(2026, 3, 1), None),
    ("B003", "M003", date(2026, 4, 2), date(2026, 4, 20)),
    ("B004", "M001", date(2026, 6, 1), None),
    ("B005", "M004", date(2026, 6, 3), date(2026, 5, 10)),
    ("B006", "M005", date(2026, 5, 2), None),
]
lib = stock(Library())
''',
            _OVERDUE_CORE + r'''TODAY = date(2026, 9, 30)
LEDGER = [
    ("B010", "M007", date(2026, 8, 1), None),
    ("B011", "M003", date(2026, 9, 12), date(2026, 9, 10)),
    ("B012", "M008", date(2026, 10, 5), None),
    ("B013", "M007", date(2026, 7, 20), date(2026, 9, 1)),
    ("B014", "M002", date(2026, 9, 30), None),
    ("B015", "M009", date(2026, 6, 30), date(2026, 6, 28)),
    ("B016", "M004", date(2026, 9, 29), None),
]
lib = stock(Library())
''',
            _OVERDUE_CORE + r'''TODAY = date(2027, 1, 15)
LEDGER = [
    ("B020", "M011", date(2026, 12, 20), date(2026, 12, 19)),
    ("B021", "M012", date(2027, 1, 2), None),
    ("B022", "M013", date(2027, 1, 20), date(2027, 1, 3)),
    ("B023", "M011", date(2026, 11, 30), None),
    ("B024", "M014", date(2027, 1, 14), None),
]
lib = stock(Library())
''',
        ],
        "steps": [
            {
                "notes": "**Overdue** (the library's rule): a loan is overdue when the book is **still out** (`returned_on is None`) **and** its due date is **before** today. A book due today is not overdue yet. A returned book is never overdue, even if it came back late.\n\nThe machine's check only looks at `loan.due_on < today`.",
                "question": "**Goal:** set a conditional breakpoint on returned loans and list the ones the machine wrongly flagged.\n\n**You have:**\n- `lib.loans`, a list of `Loan` objects; each has `item_id`, `member_id`, `due_on` and `returned_on` (a `date`, or `None` if still out)\n- `TODAY`, a `date`\n- `pause(where, **variables)`, which prints one `PAUSED at ...` line\n\n**Write** a loop over `lib.loans` that acts like a conditional breakpoint:\n- the condition is `loan.returned_on is not None`; only then call `pause(\"overdue check\", item_id=loan.item_id, due_on=loan.due_on, returned_on=loan.returned_on, today=TODAY)`, so you can inspect every value the check uses\n- while \"paused\", check the machine's test `loan.due_on < TODAY`: if it is true, the machine flagged a returned book, so append `loan.item_id` to `wrongly_flagged`\n\n**Then** leave the result in `wrongly_flagged`: a list of item ids in the order of `lib.loans`. There must be one `PAUSED` line per returned loan, and none for loans still out.\n\n**Example:** a loan `B9` due 1 March, returned 28 February, checked on 18 May: it pauses, and `B9` goes in `wrongly_flagged`. A loan returned on 10 May but due on 3 June pauses too, but isn't flagged.",
                "starter": "wrongly_flagged = []\nfor loan in lib.loans:\n    pass    # the conditional breakpoint goes here\n\nprint(\"Wrongly flagged:\", wrongly_flagged)\n",
                "solution": "wrongly_flagged = []\nfor loan in lib.loans:\n    if loan.returned_on is not None:\n        pause(\"overdue check\", item_id=loan.item_id, due_on=loan.due_on, returned_on=loan.returned_on, today=TODAY)\n        if loan.due_on < TODAY:\n            wrongly_flagged.append(loan.item_id)\n\nprint(\"Wrongly flagged:\", wrongly_flagged)\n",
                "tests": '''_exp = [_l.item_id for _l in lib.loans if _l.returned_on is not None and _l.due_on < TODAY]
_returned = [_l for _l in lib.loans if _l.returned_on is not None]
assert wrongly_flagged == _exp, f"wrongly_flagged should be {_exp} on this evidence (returned loans whose due date is before TODAY), got {wrongly_flagged!r}"
assert pause is _pause, "don't redefine pause: call the lab's pause(...) inside your if"
_want = [_l.item_id for _l in _returned]
_got = [_v.get("item_id") for _v in _pause_log]
assert _got == _want, f"pause should be called once per returned loan, in loan order, with item_id=loan.item_id: expected the item ids {_want}, got {_got}"
for _v in _pause_log:
    assert _v.get("today") == TODAY and "due_on" in _v and "returned_on" in _v, "pass due_on=..., returned_on=... and today=TODAY to pause, so the pause shows every value the check uses"''',
                "tips": [
                    "The breakpoint's condition is an `if` inside the loop: `if loan.returned_on is not None:`. Everything indented under it only runs for returned loans.",
                    "Under that `if`: first the `pause(...)` call, then a second `if loan.due_on < TODAY:` with `wrongly_flagged.append(loan.item_id)` inside it.",
                ],
                "reveal": "Every returned book that was due before today got a letter. The machine never asks whether the book came back.",
            },
            {
                "notes": "**Overdue** (the library's rule): still out (`returned_on is None`) **and** `due_on` before `today`. A book due today is not overdue; a returned book is never overdue.",
                "question": "**Goal:** fix the check without touching the machine's original class, and find who really gets a notice.\n\n**You have:** `Library`, `stock(...)` and `TODAY` (see the evidence).\n\n**Write** a class `FixedLibrary(Library)` that overrides one method, `overdue_loans(self, *, today)`:\n- keep the `*`, so `today` must be passed by keyword (`overdue_loans(today=...)`)\n- return the list of `Loan` objects in `self.loans` that are overdue by the field notes, in their original order\n\n**Then** build a fixed library from the same ledger with `fixed = stock(FixedLibrary())`, and store `notices`: the `member_id` of each overdue loan on `TODAY`, in loan order (a list of strings).\n\n**Example:** after `borrow(\"B001\", \"M001\", due_on=date(2026, 1, 1))` and `return_item(\"B001\", returned_on=date(2026, 1, 5))`, `overdue_loans(today=date(2026, 5, 18))` is `[]`.",
                "starter": "class FixedLibrary(Library):\n    pass    # override overdue_loans here\n\nfixed = stock(FixedLibrary())\nnotices = []\nprint(\"Notices for:\", notices)\n",
                "solution": _FIXED_LIBRARY + "\nfixed = stock(FixedLibrary())\nnotices = [loan.member_id for loan in fixed.overdue_loans(today=TODAY)]\nprint(\"Notices for:\", notices)\n",
                "tests": '''_lib = FixedLibrary()
_lib.borrow("B001", "M001", due_on=date(2026, 1, 1))
_lib.return_item("B001", returned_on=date(2026, 1, 5))
assert _lib.overdue_loans(today=date(2026, 5, 18)) == [], "the assignment's scenario: B001 came back on 5 January, so nothing is overdue on 18 May"
_lib.borrow("B002", "M002", due_on=date(2026, 3, 1))
_lib.borrow("B003", "M003", due_on=date(2026, 5, 18))
_ids = [_l.item_id for _l in _lib.overdue_loans(today=date(2026, 5, 18))]
assert _ids == ["B002"], f"only B002 is out and past due (B003 is due today, so not overdue yet); got {_ids!r}"
try:
    _lib.overdue_loans(date(2026, 5, 18))
    _kw = False
except TypeError:
    _kw = True
assert _kw, "keep the * in overdue_loans(self, *, today), so today must be passed by keyword"
assert issubclass(FixedLibrary, Library), "FixedLibrary should inherit from Library: class FixedLibrary(Library):"
_exp = [_m for _i, _m, _d, _r in LEDGER if _r is None and _d < TODAY]
assert notices == _exp, f"notices should be {_exp} on this evidence, got {notices!r}"''',
                "tips": [
                    "Inside the class, `def overdue_loans(self, *, today):` and a list comprehension over `self.loans` with two conditions joined by `and`.",
                    "`return [loan for loan in self.loans if loan.returned_on is None and loan.due_on < today]`, then `notices = [loan.member_id for loan in fixed.overdue_loans(today=TODAY)]`.",
                ],
                "reveal": "With the missing check back in, the letters go only to patrons who still hold a late book. The loudest complainers were telling the truth.",
            },
        ],
        "closing": "Case closed. One missing condition sent fines to innocent patrons. A breakpoint that only stopped on returned loans found it in minutes, and the fix lives in a subclass the lab can test.",
    },
    # ------------------------------------------------------------ logbook (Q1 structured logging)
    {
        "id": "json-trail",
        "tier": "medium",
        "title": "The JSON Trail",
        "teaser": "Books vanished from the catalogue overnight. The audit log will say who, if it is set up right.",
        "skills": ["logbook", "lab-bench"],
        "story": "Overnight, several books were **deleted** from the catalogue. The night desk's requests were recorded, but the lab's logging was never set up, so nothing was written down.\n\nForensics can replay the night through any logger you build:\n- `NIGHT`, a list of requests `(staff_id, action, item_id, request_id)`\n- `replay(logger, night)`, which logs each request as an event: `catalog_lookup` (DEBUG), `book_borrowed` and `book_returned` (INFO), `item_deleted` (WARNING), and `cover_fetch_failed` (ERROR, with a traceback)\n- `io`, `json` and `logging` are already imported\n\n*(Assignment Q1 asks for structured logging, especially file handlers, across the whole project.)*",
        "suspects": [
            {"name": "the night staff", "note": "Each one signs requests with a staff id like S07."},
            {"name": "the cover server", "note": "Failed again and again last night. Loud, but is it guilty?"},
        ],
        "variants": [
            _REPLAY + r'''NIGHT = [
    ("S07", "lookup", "B001", "req-101"),
    ("S07", "borrow", "B001", "req-102"),
    ("S03", "cover", "B042", "req-103"),
    ("S03", "cover", "B042", "req-104"),
    ("S11", "delete", "B014", "req-105"),
    ("S03", "cover", "B077", "req-106"),
    ("S07", "return", "B001", "req-107"),
    ("S11", "delete", "B019", "req-108"),
    ("S07", "delete", "B020", "req-109"),
    ("S11", "lookup", "B020", "req-110"),
]
''',
            _REPLAY + r'''NIGHT = [
    ("S02", "borrow", "B031", "req-201"),
    ("S05", "delete", "B032", "req-202"),
    ("S09", "cover", "B033", "req-203"),
    ("S05", "lookup", "B034", "req-204"),
    ("S02", "delete", "B035", "req-205"),
    ("S05", "delete", "B036", "req-206"),
    ("S09", "cover", "B033", "req-207"),
    ("S05", "delete", "B037", "req-208"),
    ("S09", "return", "B031", "req-209"),
    ("S02", "cover", "B038", "req-210"),
]
''',
            _REPLAY + r'''NIGHT = [
    ("S04", "delete", "B051", "req-301"),
    ("S08", "borrow", "B052", "req-302"),
    ("S08", "delete", "B053", "req-303"),
    ("S04", "cover", "B054", "req-304"),
    ("S04", "cover", "B055", "req-305"),
    ("S08", "delete", "B056", "req-306"),
    ("S04", "lookup", "B057", "req-307"),
    ("S12", "return", "B052", "req-308"),
]
''',
        ],
        "steps": [
            {
                "notes": "**The lab's logging policy:**\n- the logger keeps **INFO and above** (DEBUG lookups are dropped)\n- the **screen** shows every kept line as plain text: `[LEVEL] event`\n- the **audit file** keeps only **WARNING and above**, one JSON object per line, so it stays small and searchable\n\nIn production the audit handler is a `logging.FileHandler(\"audit.jsonl\")`. This page has no files, so a `StreamHandler` writing into an `io.StringIO` stands in for it: same handler rules, text kept in memory.",
                "question": "**Goal:** build the lab's logger, then replay the night through it.\n\n**You have:**\n- `replay(logger, night)` and `NIGHT` (see the evidence); every event carries the extra fields `staff_id`, `item_id` and `request_id`\n- `JsonFormatter`, finished and already in the editor: it turns one log record into one line of JSON (you write one like it in the next step)\n\n**Write** `setup_logger(name, console, audit)` that returns a named logger:\n- `logging.getLogger(name)`; clear its old handlers (`logger.handlers.clear()`); `propagate = False`; level `logging.INFO`\n- a `StreamHandler(console)` with `logging.Formatter(\"[%(levelname)s] %(message)s\")`\n- a `StreamHandler(audit)` with its own level `logging.WARNING` and a `JsonFormatter()`\n\n**Then** run the last four lines of the starter as they are: they replay `NIGHT` into `console` and `audit`, then print the audit.\n\n**Example:** a `book_borrowed` event gives the screen line `[INFO] book_borrowed` and nothing in the audit; an `item_deleted` event gives `[WARNING] item_deleted` on screen and one JSON line in the audit.",
                "starter": _JSON_FORMATTER + r'''
def setup_logger(name, console, audit):
    logger = logging.getLogger(name)
    # clear old handlers, stop propagation, set the level,
    # then add the screen handler and the audit handler
    return logger
''' + _JSON_RUN + r'''print(audit.getvalue())
''',
                "solution": _JSON_SETUP + _JSON_RUN + r'''print(audit.getvalue())
''',
                "tests": '''import io as _io, json as _json, logging as _lg
_night = [("SX", "lookup", "B9", "r-1"), ("SX", "borrow", "B9", "r-2"), ("SY", "delete", "B8", "r-3"),
          ("SZ", "cover", "B7", "r-4"), ("SX", "return", "B9", "r-5")]
_c, _a = _io.StringIO(), _io.StringIO()
_log = setup_logger("lab.check.trail", _c, _a)
assert isinstance(_log, _lg.Logger), "setup_logger should return the logger it set up"
assert _log.propagate is False, "set logger.propagate = False, so lines don't also go to the page's root logger"
assert _log.level == _lg.INFO, "the logger's own level should be logging.INFO (DEBUG lookups are dropped)"
replay(_log, _night)
_screen = [_x for _x in _c.getvalue().splitlines() if _x.startswith("[")]
assert _screen == ["[INFO] book_borrowed", "[WARNING] item_deleted", "[ERROR] cover_fetch_failed", "[INFO] book_returned"], f"the screen handler should show every INFO-and-above event as [LEVEL] event; expected 4 lines, got {_screen}"
_lines = _a.getvalue().splitlines()
assert len(_lines) == 2, f"the audit handler should keep only WARNING and above: 2 lines here, got {len(_lines)}. Did you give it setLevel(logging.WARNING)?"
try:
    _recs = [_json.loads(_x) for _x in _lines]
except ValueError:
    raise AssertionError("each audit line should be JSON: give the audit handler setFormatter(JsonFormatter())")
assert [_r.get("event") for _r in _recs] == ["item_deleted", "cover_fetch_failed"], f"the audit should hold the item_deleted and cover_fetch_failed events, got {_recs}"
_log2 = setup_logger("lab.check.trail", _io.StringIO(), _io.StringIO())
assert len(_log2.handlers) == 2, f"calling setup_logger twice should still leave exactly 2 handlers (clear the old ones first), got {len(_log2.handlers)}"
_exp = [_r for _s, _act, _i, _r in NIGHT if _act in ("delete", "cover")]
_got = [_json.loads(_x).get("request_id") for _x in audit.getvalue().splitlines()]
assert _got == _exp, f"after replaying NIGHT the audit should hold the requests {_exp}, got {_got}"''',
                "tips": [
                    "Start with `logger.handlers.clear()`, `logger.propagate = False` and `logger.setLevel(logging.INFO)`. The screen handler: `screen = logging.StreamHandler(console)`, `screen.setFormatter(logging.Formatter(\"[%(levelname)s] %(message)s\"))`, `logger.addHandler(screen)`.",
                    "The audit handler takes four lines: `audit_file = logging.StreamHandler(audit)`, `audit_file.setLevel(logging.WARNING)`, `audit_file.setFormatter(JsonFormatter())`, then `logger.addHandler(audit_file)`.",
                ],
                "reveal": "The screen shows the whole night; the audit file keeps only the warnings and errors. Now the audit lines need to say exactly who did what.",
            },
            {
                "notes": "**An audit line** is one JSON object with **exactly** these keys, and nothing else:\n- `\"level\"`: the level name, `record.levelname`\n- `\"logger\"`: the logger's name, `record.name`\n- `\"event\"`: the message, `record.getMessage()`\n- each of `\"staff_id\"`, `\"item_id\"` and `\"request_id\"` that the record actually has (a record only has them if they were passed with `extra=`)\n- `\"error\"`: the traceback as text, `self.formatException(record.exc_info)`, **only** when `record.exc_info` is set (it is set by `logger.exception(...)`)",
                "question": "**Goal:** write the formatter that turns every audit record into one searchable line of JSON.\n\n**You have:** `setup_logger`, finished and already in the editor (its audit handler uses `JsonFormatter()`), `replay` and `NIGHT`. `json` and `logging` are imported.\n\n**Write** the body of `JsonFormatter.format(self, record)`:\n- build a dict with the keys from the field notes, and no others\n- for the three extra fields, loop over `self.FIELDS` and use `hasattr(record, name)` / `getattr(record, name)`\n- return `json.dumps(...)` of the dict: one line of text\n\n**Then** run the last lines of the starter: they replay `NIGHT` and print the audit.\n\n**Example:** an `item_deleted` event logged by `lab.night` gives `{\"level\": \"WARNING\", \"logger\": \"lab.night\", \"event\": \"item_deleted\", \"staff_id\": \"S07\", \"item_id\": \"B020\", \"request_id\": \"req-9\"}`. A record with no extra fields and no traceback gives only `level`, `logger` and `event`.",
                "starter": _JSON_FORMAT_STARTER + _JSON_SETUP_FN + _JSON_RUN + r'''print(audit.getvalue())
''',
                "solution": _JSON_SETUP + _JSON_RUN + r'''print(audit.getvalue())
''',
                "tests": '''import io as _io, json as _json, logging as _lg
def _fmt(_record):
    _text = JsonFormatter().format(_record)
    assert isinstance(_text, str) and "\\n" not in _text, f"format should return one line of text, got {_text!r}"
    try:
        return _json.loads(_text)
    except ValueError:
        raise AssertionError(f"format should return JSON made with json.dumps(...), got {_text!r}")
_plain = _lg.LogRecord("lab.check", _lg.WARNING, "", 0, "plain_event", None, None)
_want = {"level": "WARNING", "logger": "lab.check", "event": "plain_event"}
_got = _fmt(_plain)
assert _got == _want, f"a record with no extra fields and no traceback should give exactly {_want}, got {_got}"
_rec = _lg.LogRecord("lab.check", _lg.WARNING, "", 0, "item_deleted", None, None)
_rec.staff_id, _rec.item_id, _rec.request_id = "S1", "B1", "r-1"
_want = {"level": "WARNING", "logger": "lab.check", "event": "item_deleted", "staff_id": "S1", "item_id": "B1", "request_id": "r-1"}
_got = _fmt(_rec)
assert _got == _want, f"with the three extra fields the line should have exactly these keys and values: {_want}, got {_got}"
_c, _a = _io.StringIO(), _io.StringIO()
_log = setup_logger("lab.check.format", _c, _a)
replay(_log, [("SZ", "cover", "B7", "r-4")])
_err = _json.loads(_a.getvalue().splitlines()[0])
_keys = sorted(_err)
_want_keys = sorted(["level", "logger", "event", "staff_id", "item_id", "request_id", "error"])
assert _keys == _want_keys, f"the cover_fetch_failed line should have exactly the keys {_want_keys}, got {_keys}"
assert _err["level"] == "ERROR" and "ConnectionError" in _err["error"], "when the record has exc_info, put the traceback under \\"error\\": self.formatException(record.exc_info)"
_exp = [_r for _s, _act, _i, _r in NIGHT if _act in ("delete", "cover")]
_got = [_json.loads(_x).get("request_id") for _x in audit.getvalue().splitlines()]
assert _got == _exp, f"after replaying NIGHT the audit should hold the requests {_exp}, got {_got}"''',
                "tips": [
                    "Start with `data = {\"level\": record.levelname, \"logger\": record.name, \"event\": record.getMessage()}`, then `for name in self.FIELDS:` and `if hasattr(record, name): data[name] = getattr(record, name)`.",
                    "After the loop: `if record.exc_info: data[\"error\"] = self.formatException(record.exc_info)`, then `return json.dumps(data)`.",
                ],
                "reveal": "The audit file holds only the night's warnings and errors, one JSON object each, every one signed with a staff id and a request id.",
            },
            {
                "notes": "Every `item_deleted` line in the audit is one deletion, signed with the `staff_id` of whoever made the request. `cover_fetch_failed` lines are errors from the cover server, not deletions.",
                "question": "**Goal:** read the audit trail and name the staff member who deleted the most books.\n\n**You have:** `audit`, the `io.StringIO` the night was logged into (the working logger from the last step is already in the editor). `audit.getvalue()` is the text: one JSON object per line.\n\n**Write** three variables:\n- `events`: a list of dicts, one per audit line, made with `json.loads`\n- `deletions`: a dict from `staff_id` to how many `item_deleted` events they have (an int); staff with no deletions are left out\n- `culprit`: the `staff_id` (a string) with the most deletions (there is no tie). `max(d, key=d.get)` gives the key of a dict `d` with the biggest value.\n\n**Then** print `culprit` (the starter does).\n\n**Example:** for the audit lines `{\"event\": \"item_deleted\", \"staff_id\": \"S1\"}`, `{\"event\": \"cover_fetch_failed\", \"staff_id\": \"S2\"}` and `{\"event\": \"item_deleted\", \"staff_id\": \"S1\"}`, `deletions` is `{\"S1\": 2}` and `culprit` is `\"S1\"`.",
                "starter": _JSON_SETUP + _JSON_RUN + r'''
events = []
deletions = {}
culprit = ...
print("Deleted the most:", culprit)
''',
                "solution": _JSON_SETUP + _JSON_RUN + r'''
events = [json.loads(line) for line in audit.getvalue().splitlines()]
deletions = {}
for event in events:
    if event["event"] == "item_deleted":
        deletions[event["staff_id"]] = deletions.get(event["staff_id"], 0) + 1
culprit = max(deletions, key=deletions.get)
print("Deleted the most:", culprit)
''',
                "tests": '''_exp_events = [_e for _e in (json.loads(_x) for _x in audit.getvalue().splitlines())]
assert events == _exp_events, f"events should hold one dict per audit line ({len(_exp_events)} here), made with json.loads"
_exp = {}
for _s, _act, _i, _r in NIGHT:
    if _act == "delete":
        _exp[_s] = _exp.get(_s, 0) + 1
assert deletions == _exp, f"deletions should be {_exp} on this evidence (count only item_deleted events), got {deletions!r}"
_best = max(_exp, key=_exp.get)
assert culprit == _best, f"culprit should be the staff id with the most deletions, {_best!r}, got {culprit!r}"''',
                "tips": [
                    "`audit.getvalue().splitlines()` gives the lines; a list comprehension with `json.loads(line)` turns each into a dict.",
                    "Loop over `events`, skip anything whose `event[\"event\"]` isn't `\"item_deleted\"`, and count with `deletions.get(staff, 0) + 1`. Then `culprit = max(deletions, key=deletions.get)`.",
                ],
                "reveal": "The cover server's errors were noise. One staff id signs deletion after deletion.",
            },
        ],
        "closing": "Case closed. Plain prints would have said \"deleted!\" and nothing more. Structured lines with a stable event name and a staff id turned the audit file into a witness statement.",
    },
    # ------------------------------------------------------------ test-bench (Q3)
    {
        "id": "book-inquest",
        "tier": "medium",
        "title": "The Book Inquest",
        "teaser": "Four clerks rewrote the lab's Book. Tests will decide whose version goes to trial.",
        "skills": ["test-bench", "dataclasses"],
        "story": "The Forensics Lab is moving BookVault into its new system, and four clerks each sent in a **rewrite** of the `Book` class. Someone has been quietly breaking the lab's tools, so no rewrite goes live until a test suite has tried it.\n\nForensics loaded for you:\n- the lab's real `Book` (the behaviour everyone must keep), `BookVaultError` and `ItemUnavailableError` (a kind of `ValueError`)\n- the mini pytest: `raises(...)`, `run_tests(globals())`, and `lab_run(name, suspect)`, which swaps the global `name` for `suspect`, runs every `test_` function quietly, puts the real one back and returns the **names of the tests that failed**\n- `SUSPECTS`, a dict from clerk name to that clerk's Book class (each one inherits from `Book` and changes one part)\n\n*(This is assignment Q3: at least 7 tests for `Book`.)*",
        "suspects": [
            {"name": "Hollis", "note": "Rewrote Book over a weekend."},
            {"name": "Ines", "note": "Says her version only tidies things up."},
            {"name": "Jory", "note": "Swears he tried every rule by hand."},
            {"name": "Kemp", "note": "Sent his rewrite in late, with no comments."},
        ],
        "variants": [
            _book_evidence([("Hollis", "pages"), ("Ines", "return"), ("Jory", "ok_borrow"), ("Kemp", "ok_repr")]),
            _book_evidence([("Hollis", "ok_return"), ("Ines", "onloan"), ("Jory", "words"), ("Kemp", "repr")]),
            _book_evidence([("Hollis", "title"), ("Ines", "ok_borrow"), ("Jory", "ok_repr"), ("Kemp", "twice")]),
        ],
        "steps": [
            {
                "notes": "**The lab's Book rules** (assignment Q3):\n- a new book keeps the `title`, `item_id`, `author` and `pages` it was given, and starts **available**\n- `pages` must be positive: `pages=0` raises `ValueError` whose message contains `\"positive\"`\n- the title can't be empty: `title=\"\"` raises `ValueError` whose message contains `\"empty\"`",
                "question": "**Goal:** test how a Book is created, then try every clerk's rewrite against your tests.\n\n**You have:** `Book`, `raises`, `run_tests`, `lab_run` and `SUSPECTS` (see the evidence).\n\n**Write** four tests (plain functions with no parameters):\n- `test_book_creation`: `Book(title=\"Clean Code\", item_id=\"B001\", author=\"Robert Martin\", pages=464)` has that title and `available is True`\n- `test_valid_book`: a second valid book, such as `Book(title=\"Dune\", item_id=\"B002\", author=\"Frank Herbert\", pages=412)`, keeps its `item_id`, `author` and `pages`\n- `test_pages_must_be_positive`: making a book with `pages=0` raises `ValueError` with `match=\"positive\"`\n- `test_title_cannot_be_empty`: making a book with `title=\"\"` raises `ValueError` with `match=\"empty\"`\n\n**Then** keep `run_tests(globals())` (it should print `4 passed, 0 failed`) and fill two variables:\n- `failures`: a dict from each clerk in `SUSPECTS` to `lab_run(\"Book\", their_class)`\n- `flagged`: the clerks whose list of failed tests is not empty, sorted A to Z\n\n**Example:** if Hollis's class accepts `pages=0`, then `failures[\"Hollis\"]` is `[\"test_pages_must_be_positive\"]` and `\"Hollis\"` is in `flagged`.",
                "starter": "# ---- the tests start here ----\n\n# write the four tests here\n\n\nrun_tests(globals())\n\nfailures = {}\nflagged = []\nprint(failures)\nprint(\"Flagged:\", flagged)\n",
                "solution": "# ---- the tests start here ----\n\n" + _BOOK_TESTS_1 + "\n\nrun_tests(globals())\n" + _BOOK_VERDICT + "flagged = sorted(clerk for clerk in failures if failures[clerk])\nprint(failures)\nprint(\"Flagged:\", flagged)\n",
                "tests": _BOOK_REF + _CHECK_RUN + '''for _n in ("test_book_creation", "test_valid_book", "test_pages_must_be_positive", "test_title_cannot_be_empty"):
    assert callable(globals().get(_n)), f"write a test function called {_n}"
_real = _lab_run("Book", Book)
assert _real == [], f"every test should pass on the lab's real Book, but these failed: {_real}"
class _NoPageCheck(Book):
    def __post_init__(self):
        if not self.title.strip():
            raise ValueError("title cannot be empty")
class _NoTitleCheck(Book):
    def __post_init__(self):
        if self.pages <= 0:
            raise ValueError("pages must be positive")
class _Swapped(Book):
    def __post_init__(self):
        if not self.title.strip():
            raise ValueError("pages must be positive")
        if self.pages <= 0:
            raise ValueError("title cannot be empty")
class _OnLoan(Book):
    def __post_init__(self):
        Book.__post_init__(self)
        self.available = False
class _Shouting(Book):
    def __post_init__(self):
        Book.__post_init__(self)
        self.title = self.title.upper()
class _NoAuthor(Book):
    def __post_init__(self):
        Book.__post_init__(self)
        self.author = ""
assert _lab_run("Book", _NoPageCheck), "your tests should fail on a Book that accepts pages=0"
assert _lab_run("Book", _NoTitleCheck), "your tests should fail on a Book that accepts an empty title"
assert _lab_run("Book", _Swapped), "check the messages too: match=\\"positive\\" for pages and match=\\"empty\\" for the title"
assert _lab_run("Book", _OnLoan), "test_book_creation should check that a new book is available: assert b.available is True"
assert _lab_run("Book", _Shouting), "test_book_creation should check the title: assert b.title == \\"Clean Code\\""
assert _lab_run("Book", _NoAuthor), "test_valid_book should check the author too"
_own_tests = [_n for _n, _f in list(globals().items()) if _n.startswith("test_") and callable(_f)]
assert len(_own_tests) >= 4, f"there should be at least 4 test_ functions, found {len(_own_tests)}"
_exp = {_c: _lab_run("Book", _s) for _c, _s in SUSPECTS.items()}
assert failures == _exp, f"failures should map each clerk to lab_run(\\"Book\\", their class); expected {_exp}, got {failures!r}"
_truth = sorted(_c for _c, _s in SUSPECTS.items() if _bad_creation(_s))
assert flagged == _truth, f"flagged should be {_truth} on this evidence (sorted, only clerks with failed tests), got {flagged!r}"''',
                "tips": [
                    "The two error tests put the `Book(...)` call inside the `with` block: `with raises(ValueError, match=\"positive\"):` and, indented, `Book(title=\"Clean Code\", item_id=\"B001\", author=\"Robert Martin\", pages=0)`.",
                    "For the verdict: `for clerk, suspect in SUSPECTS.items(): failures[clerk] = lab_run(\"Book\", suspect)`, then `flagged = sorted(clerk for clerk in failures if failures[clerk])` (an empty list counts as false).",
                ],
                "reveal": "Creation and validation already sort the honest rewrites from at least one broken one. But a Book also has to lend and come back.",
            },
            {
                "notes": "**More Book rules** (assignment Q3):\n- borrowing a book twice: the second `borrow()` raises `ValueError` (the lab's `ItemUnavailableError` is one) whose message contains `\"unavailable\"`\n- `return_item()` makes a borrowed book available again\n- `repr(book)` contains the class name (`\"Book\"`, also part of names like `HollisBook`) and the `item_id`",
                "question": "**Goal:** finish the seven-test suite and name every clerk whose rewrite breaks the rules.\n\n**You have:** your four tests from the last step (already in the editor), and the same evidence.\n\n**Write** three more tests:\n- `test_double_borrow_raises`: borrow a book once, then wrap the second `borrow()` in `with raises(ValueError, match=\"unavailable\"):`\n- `test_return_makes_available`: borrow, `return_item()`, then assert `available is True`\n- `test_repr_shows_class_and_id`: make `b = Book(title=\"Clean Code\", item_id=\"B001\", author=\"Robert Martin\", pages=464)` and assert `\"Book\"` and `\"B001\"` are both in `repr(b)`\n\n**Then** keep `run_tests(globals())` (7 passed) and the `failures` loop, and store `culprits`: the clerks with at least one failed test, sorted A to Z.\n\n**Example:** a rewrite whose `return_item` does nothing fails only `test_return_makes_available`, which is enough to put that clerk in `culprits`.",
                "starter": "# ---- the tests start here ----\n\n" + _BOOK_TESTS_1 + "\n# write the three new tests here\n\n\nrun_tests(globals())\n" + _BOOK_VERDICT + "culprits = []\nprint(failures)\nprint(\"Culprits:\", culprits)\n",
                "solution": "# ---- the tests start here ----\n\n" + _BOOK_TESTS_1 + _BOOK_TESTS_2 + "\n\nrun_tests(globals())\n" + _BOOK_VERDICT + "culprits = sorted(clerk for clerk in failures if failures[clerk])\nprint(failures)\nprint(\"Culprits:\", culprits)\n",
                "tests": _BOOK_REF + _CHECK_RUN + '''for _n in ("test_double_borrow_raises", "test_return_makes_available", "test_repr_shows_class_and_id"):
    assert callable(globals().get(_n)), f"write a test function called {_n}"
_real = _lab_run("Book", Book)
assert _real == [], f"every test should pass on the lab's real Book, but these failed: {_real}"
class _BorrowTwice(Book):
    def borrow(self):
        self.available = False
class _WrongWords(Book):
    def borrow(self):
        if not self.available:
            raise ValueError("already out")
        self.available = False
class _NoReturn(Book):
    def return_item(self):
        pass
class _NoId(Book):
    def __repr__(self):
        return f"Book({self.title!r})"
class _NoClass(Book):
    def __repr__(self):
        return f"<{self.item_id}>"
assert _lab_run("Book", _BorrowTwice), "test_double_borrow_raises should fail when the second borrow raises nothing"
assert _lab_run("Book", _WrongWords), "test_double_borrow_raises should check the message: match=\\"unavailable\\""
assert _lab_run("Book", _NoReturn), "test_return_makes_available should fail when return_item does nothing"
assert _lab_run("Book", _NoId), "test_repr_shows_class_and_id should check that \\"B001\\" is in repr(b)"
assert _lab_run("Book", _NoClass), "test_repr_shows_class_and_id should check that \\"Book\\" is in repr(b)"
_own_tests = [_n for _n, _f in list(globals().items()) if _n.startswith("test_") and callable(_f)]
assert len(_own_tests) >= 7, f"there should be at least 7 test_ functions, found {len(_own_tests)}"
_exp = {_c: _lab_run("Book", _s) for _c, _s in SUSPECTS.items()}
assert failures == _exp, f"failures should map each clerk to lab_run(\\"Book\\", their class); expected {_exp}, got {failures!r}"
_truth = sorted(_c for _c, _s in SUSPECTS.items() if _bad_creation(_s) or _bad_loans(_s))
assert culprits == _truth, f"culprits should be {_truth} on this evidence, got {culprits!r}"''',
                "tips": [
                    "In `test_double_borrow_raises` the first `b.borrow()` stays outside the `with`; only the second one goes inside it, so a bug in the first borrow can't hide.",
                    "`assert \"Book\" in repr(b)` and `assert \"B001\" in repr(b)`, then `culprits = sorted(clerk for clerk in failures if failures[clerk])`.",
                ],
                "reveal": "Seven tests, and the broken rewrites fall out one by one. Some that passed the creation tests were broken all along.",
            },
        ],
        "closing": "Case closed. Nobody had to read four rewrites line by line: seven small tests read them for the lab, and they will keep reading every rewrite that comes after.",
    },
    # ------------------------------------------------------------ test-bench (Q5)
    {
        "id": "fresh-evidence",
        "tier": "medium",
        "title": "Fresh Evidence",
        "teaser": "Tests pass alone and fail together. Somebody's fixtures are sharing evidence between tests.",
        "skills": ["test-bench", "dataclasses"],
        "story": "The lab's test suite has started acting strangely: a test passes when it runs alone and fails after another one. That smells like **contaminated evidence**: a fixture that hands one test's leftovers to the next.\n\nFour clerks each wrote their own `conftest.py`. Forensics loaded for you:\n- the mini pytest with fixtures: `@fixture`, `run_tests(globals())`, and `lab_fixtures(swaps)`, which swaps some of your fixtures for the ones in the dict `swaps`, runs every test quietly, puts yours back, and returns the **names of the tests that failed**\n- BookVault's `Book`, `Member` and `Library` (`add_item`, `add_member`, `borrow`, `len(...)`)\n- `SUSPECTS`, a dict from clerk name to that clerk's conftest: a **function** that builds their fixtures fresh and returns them as a dict, such as `{\"stocked_library\": ...}`\n\n*(This is assignment Q5: fixtures and fresh state.)*",
        "suspects": [
            {"name": "Nadia", "note": "Made the suite \"faster\" last week."},
            {"name": "Omar", "note": "Says his conftest has never failed him."},
            {"name": "Pia", "note": "Rewrote her fixtures from memory."},
            {"name": "Ravi", "note": "Changed one fixture last week and told nobody."},
        ],
        "variants": [
            _fix_evidence([("Nadia", "cache"), ("Omar", "ok"), ("Pia", "nomember"), ("Ravi", "ok_member")]),
            _fix_evidence([("Nadia", "ok"), ("Omar", "book"), ("Pia", "twobooks"), ("Ravi", "spare")]),
            _fix_evidence([("Nadia", "nomember"), ("Omar", "ok_member"), ("Pia", "ok"), ("Ravi", "cache")]),
        ],
        "steps": [
            {
                "notes": "**The lab's test data** (assignment Q5):\n- the empty library is `Library(\"Test Vault\")`\n- the book is Clean Code: `item_id` `\"B001\"`, author Robert Martin, 464 pages\n- the member is `M001`, Asha, `asha@example.com`\n- the stocked library is the empty library with that book and that member added",
                "question": "**Goal:** write the lab's four fixtures, then see which clerks' conftests break the three tests already written.\n\n**You have:** `fixture`, `run_tests`, `lab_fixtures`, `Book`, `Member`, `Library` and `SUSPECTS` (see the evidence).\n\n**Write** four fixtures, each with `@fixture` on the line above it:\n- `empty_library()`: returns `Library(\"Test Vault\")`\n- `clean_code()`: returns `Book(title=\"Clean Code\", item_id=\"B001\", author=\"Robert Martin\", pages=464)`\n- `member()`: returns `Member(member_id=\"M001\", name=\"Asha\", email=\"asha@example.com\")`\n- `stocked_library(empty_library, clean_code, member)`: adds the book and the member to the library and returns it\n- each fixture builds a **new** object every time it runs (no shared global objects)\n\n**Then** keep `run_tests(globals())` (it should print `3 passed, 0 failed`) and fill:\n- `failures`: a dict from each clerk to `lab_fixtures(conftest())`, where `conftest` is that clerk's value in `SUSPECTS` (call it, so every inquest starts fresh)\n- `flagged`: the clerks with at least one failed test, sorted A to Z\n\n**Example:** a conftest whose `stocked_library` forgets `add_member` makes `test_stocked_has_member` fail, so that clerk is flagged.",
                "starter": "# ---- the tests start here ----\n\n# write the four fixtures here\n\n\n" + _FIX_GIVEN_TESTS + "\nrun_tests(globals())\n\nfailures = {}\nflagged = []\nprint(failures)\nprint(\"Flagged:\", flagged)\n",
                "solution": "# ---- the tests start here ----\n\n" + _FIXTURES_SOLUTION + _FIX_GIVEN_TESTS + "\nrun_tests(globals())\n" + _FIX_VERDICT + "flagged = sorted(clerk for clerk in failures if failures[clerk])\nprint(failures)\nprint(\"Flagged:\", flagged)\n",
                "tests": _CHECK_FIX + '''for _n in ("empty_library", "clean_code", "member", "stocked_library"):
    assert _n in FIXTURES, f"add a fixture called {_n}, with @fixture on the line above it"
_e = FIXTURES["empty_library"]()
assert isinstance(_e, Library) and len(_e) == 0 and _e.name == "Test Vault", 'empty_library should return Library("Test Vault")'
_b = FIXTURES["clean_code"]()
assert isinstance(_b, Book) and (_b.title, _b.item_id, _b.pages) == ("Clean Code", "B001", 464), "clean_code should return the Clean Code book (B001, 464 pages)"
_m = FIXTURES["member"]()
assert isinstance(_m, Member) and _m.member_id == "M001" and _m.name == "Asha", "member should return Member M001, Asha"
assert FIXTURES["clean_code"]() is not _b, "clean_code should build a new Book every time it runs"
_p = sorted(inspect.signature(FIXTURES["stocked_library"]).parameters)
assert _p == ["clean_code", "empty_library", "member"], f"stocked_library should ask for empty_library, clean_code and member as parameters, not {_p}"
_lib = call_with_fixtures(FIXTURES["stocked_library"], {}, [])
assert isinstance(_lib, Library) and len(_lib) == 1 and "B001" in _lib.items and "M001" in _lib.members, "stocked_library should add the book and the member, then return the library"
for _n in ("empty_library", "member"):
    assert FIXTURES[_n]() is not FIXTURES[_n](), f"{_n} should build a new object every time it runs"
_own = _lab_fixtures({})
assert _own == [], f"every test should pass with your own fixtures, but these failed: {_own}"
_own_tests = [_n for _n, _f in list(globals().items()) if _n.startswith("test_") and callable(_f)]
assert len(_own_tests) >= 3, f"there should be at least 3 test_ functions, found {len(_own_tests)}"
_exp = {_c: _lab_fixtures(_make()) for _c, _make in SUSPECTS.items()}
assert failures == _exp, f"failures should map each clerk to lab_fixtures(conftest()); expected {_exp}, got {failures!r}"
_truth = sorted(_c for _c in _exp if _exp[_c])
assert flagged == _truth, f"flagged should be {_truth} on this evidence, got {flagged!r}"''',
                "tips": [
                    "A fixture is a normal function with `@fixture` on the line above. `stocked_library` lists the other three as its parameters, calls `empty_library.add_item(clean_code)` and `empty_library.add_member(member)`, then `return empty_library`.",
                    "`for clerk, conftest in SUSPECTS.items(): failures[clerk] = lab_fixtures(conftest())`, then `flagged = sorted(clerk for clerk in failures if failures[clerk])`.",
                ],
                "reveal": "The three tests catch a fixture that builds the wrong library. They can't see contamination yet: none of them changes anything.",
            },
            {
                "notes": "**Fresh state:** every test must get its own new objects. Anything one test changes (borrowing a book, adding an item) must be gone in the next test. A fixture that hands two tests the **same** library or the **same** book leaks evidence between them.\n\nThe runner runs tests in the order they are written in the file.",
                "question": "**Goal:** write tests that prove every test gets fresh state, and expose the contaminated conftests.\n\n**You have:** your fixtures and the three earlier tests (already in the editor).\n\n**Write** three more tests, below the others and **in this order**:\n- `test_borrow_does_not_leak(stocked_library)`: `stocked_library.borrow(\"B001\", \"M001\")`, then assert `stocked_library.items[\"B001\"].available is False`\n- `test_empty_after_borrow(empty_library)`: assert `len(empty_library) == 0`. It catches an `empty_library` fixture that hands out the same library every time: `stocked_library` filled it in an earlier test, so it isn't empty any more\n- `test_next_test_is_fresh(stocked_library)`: assert `stocked_library.items[\"B001\"].available is True`\n\n**Then** keep `run_tests(globals())` (6 passed) and the `failures` loop, and store `culprits`: the clerks with at least one failed test, sorted A to Z.\n\n**Example:** a `stocked_library` that builds the library once and hands it out again passes `test_borrow_does_not_leak`, then fails `test_next_test_is_fresh`, because the book is still out.",
                "starter": "# ---- the tests start here ----\n\n" + _FIXTURES_SOLUTION + _FIX_GIVEN_TESTS + "\n# write the three freshness tests here\n\n\nrun_tests(globals())\n" + _FIX_VERDICT + "culprits = []\nprint(failures)\nprint(\"Culprits:\", culprits)\n",
                "solution": "# ---- the tests start here ----\n\n" + _FIXTURES_SOLUTION + _FIX_GIVEN_TESTS + _FIX_FRESH_TESTS + "\nrun_tests(globals())\n" + _FIX_VERDICT + "culprits = sorted(clerk for clerk in failures if failures[clerk])\nprint(failures)\nprint(\"Culprits:\", culprits)\n",
                "tests": _FIX_MUTANTS + _CHECK_FIX + '''for _n in ("test_borrow_does_not_leak", "test_empty_after_borrow", "test_next_test_is_fresh"):
    assert callable(globals().get(_n)), f"write a test function called {_n}"
_names = [_n for _n in globals() if _n.startswith("test_")]
assert _names.index("test_borrow_does_not_leak") < _names.index("test_empty_after_borrow") < _names.index("test_next_test_is_fresh"), "write the three tests in the order given: borrow first, then the empty check, then the fresh check"
_lf = _lab_fixtures({})
assert _lf == [], f"every test should pass with your own fixtures, but these failed: {_lf}"
for _what, _swaps in _leaks():
    assert _lab_fixtures(_swaps), f"your tests should catch {_what}: borrow in one test, then check in a later test that nothing leaked"
_own_tests = [_n for _n, _f in list(globals().items()) if _n.startswith("test_") and callable(_f)]
assert len(_own_tests) >= 6, f"there should be at least 6 test_ functions, found {len(_own_tests)}"
_exp = {_c: _lab_fixtures(_make()) for _c, _make in SUSPECTS.items()}
assert failures == _exp, f"failures should map each clerk to lab_fixtures(conftest()); expected {_exp}, got {failures!r}"
_truth = sorted(_c for _c in _exp if _exp[_c])
assert culprits == _truth, f"culprits should be {_truth} on this evidence, got {culprits!r}"''',
                "tips": [
                    "Each test names the fixture it needs as a parameter: `def test_empty_after_borrow(empty_library):` then one `assert` line. Don't call the fixtures yourself.",
                    "Leaks only show up across tests, so the order matters: the test that borrows must come before the tests that check nothing leaked. Then `culprits = sorted(clerk for clerk in failures if failures[clerk])`.",
                ],
                "reveal": "With a test that dirties the evidence and two that check it later, every contaminated conftest gives itself away.",
            },
        ],
        "closing": "Case closed. The suite was never flaky: one or more fixtures handed out the same evidence twice, or built the wrong library. Fixtures that build everything fresh, and tests that prove it, put the lab's results back on solid ground.",
    },
    # ------------------------------------------------------------ test-bench (Q7)
    {
        "id": "loan-limit",
        "tier": "medium",
        "title": "The Loan Limit",
        "teaser": "One patron walked out with half the shelf. Add the limit, then test the clerks' versions of it.",
        "skills": ["test-bench", "inheritance", "project"],
        "story": "BookVault has no limit on loans, and someone noticed. Overnight one patron tried to empty the shelf. The Bureau's new policy: a member may hold only a few **active** loans at once.\n\nForensics loaded for you:\n- BookVault before the limit: `BookVaultError`, `ItemUnavailableError(BookVaultError, ValueError)`, `Book(item_id)`, `Loan` and `Library(name, max_active_loans=3)` with `add_item`, `active_loans(member_id)`, `borrow(item_id, member_id)` and `return_item(item_id)`. Its `borrow` ignores `max_active_loans`.\n- `LIMIT`, the limit the night desk should have used, `SHELF` (the item ids on the shelf) and `REQUESTS`, the night's requests as `(action, member_id, item_id)` with action `\"borrow\"` or `\"return\"`\n- the mini pytest (`raises`, `run_tests`, `lab_run`) and `SUSPECTS`: four clerks also wrote a limit, as subclasses of `Library`\n\n*(This is assignment Q7: a loan limit and `LoanLimitExceededError`.)*",
        "suspects": [
            {"name": "Tamsin", "note": "Wrote her limit in ten minutes."},
            {"name": "Ugo", "note": "Says his limit is \"obviously right\"."},
            {"name": "Vera", "note": "Wrote hers without looking at the policy."},
            {"name": "Wes", "note": "Never ran his limit before sending it in."},
        ],
        "variants": [
            _limit_evidence(r'''
LIMIT = 3
SHELF = ["B001", "B002", "B003", "B004", "B005", "B006", "B007", "B008"]
REQUESTS = [
    ("borrow", "M001", "B001"), ("borrow", "M001", "B002"), ("borrow", "M002", "B003"),
    ("borrow", "M001", "B004"), ("borrow", "M001", "B005"), ("return", "M001", "B002"),
    ("borrow", "M001", "B005"), ("borrow", "M002", "B001"), ("borrow", "M001", "B006"),
    ("borrow", "M003", "B006"), ("borrow", "M002", "B007"), ("borrow", "M002", "B008"),
    ("borrow", "M002", "B002"),
]
''', [("Tamsin", "returned"), ("Ugo", "ok"), ("Vera", "hardcoded"), ("Wes", "ok2")]),
            _limit_evidence(r'''
LIMIT = 2
SHELF = ["B001", "B002", "B003", "B004", "B005", "B006", "B007"]
REQUESTS = [
    ("borrow", "M010", "B001"), ("borrow", "M011", "B002"), ("borrow", "M011", "B003"),
    ("borrow", "M011", "B004"), ("borrow", "M010", "B002"), ("borrow", "M010", "B005"),
    ("return", "M011", "B002"), ("borrow", "M011", "B004"), ("borrow", "M011", "B006"),
    ("borrow", "M012", "B006"), ("borrow", "M011", "B007"), ("borrow", "M010", "B007"),
]
''', [("Tamsin", "ok2"), ("Ugo", "offbyone"), ("Vera", "ok"), ("Wes", "wrongexc")]),
            _limit_evidence(r'''
LIMIT = 4
SHELF = ["B001", "B002", "B003", "B004", "B005", "B006", "B007", "B008", "B009", "B010"]
REQUESTS = [
    ("borrow", "M020", "B001"), ("borrow", "M020", "B002"), ("borrow", "M021", "B003"),
    ("borrow", "M020", "B004"), ("borrow", "M020", "B005"), ("borrow", "M020", "B006"),
    ("borrow", "M021", "B001"), ("borrow", "M021", "B006"), ("borrow", "M021", "B007"),
    ("borrow", "M021", "B008"), ("borrow", "M021", "B009"), ("return", "M020", "B001"),
    ("borrow", "M021", "B001"), ("borrow", "M022", "B001"), ("borrow", "M021", "B010"),
]
''', [("Tamsin", "hardcoded"), ("Ugo", "ok2"), ("Vera", "returned"), ("Wes", "offbyone")]),
        ],
        "steps": [
            {
                "notes": "**The loan-limit policy** (assignment Q7):\n- a member may have at most `max_active_loans` **active** loans (the limit is set per library: `Library(name, max_active_loans=3)`)\n- **returned loans don't count**: `active_loans(member_id)` already lists only the loans not returned\n- a borrow that would go over the limit is refused with `LoanLimitExceededError`, a kind of `BookVaultError`\n- the limit is checked **before** anything else, so nothing is borrowed when it is refused",
                "question": "**Goal:** add the limit to BookVault and replay the night with it.\n\n**You have:** the BookVault classes, `LIMIT`, `SHELF` and `REQUESTS` (see the evidence).\n\n**Write:**\n- a class `LoanLimitExceededError` that inherits from `BookVaultError`\n- a class `LimitedLibrary(Library)` that overrides `borrow(self, item_id, member_id)`: if the member already has `self.max_active_loans` or more active loans, raise `LoanLimitExceededError`; otherwise return `super().borrow(item_id, member_id)`\n\n**Then** finish the replay loop in the starter: replace its catch-all `except BookVaultError` with two `except` blocks:\n- on `LoanLimitExceededError`, append the `member_id` to `refused`\n- on `ItemUnavailableError` (the book is already out), append the `item_id` to `unavailable`\n\nFinally store `hoarder`: the member id that appears most often in `refused` (there is no tie). Count them into a dict first; `max(d, key=d.get)` gives the key of a dict `d` with the biggest value (on a list, `max(items, key=items.count)` does the same in one step).\n\n**Example:** with a limit of 2, borrows of B1, B2, B3 by M1 put `\"M1\"` in `refused` once; after M1 returns B1, a borrow of B3 works.",
                "starter": "class LoanLimitExceededError(Exception):     # make it a BookVaultError\n    pass\n\nclass LimitedLibrary(Library):\n    pass    # override borrow here\n\n" + _LIMIT_REPLAY + "refused = []\nunavailable = []\nfor action, member_id, item_id in REQUESTS:\n    if action == \"return\":\n        desk.return_item(item_id)\n    else:\n        try:\n            desk.borrow(item_id, member_id)\n        except BookVaultError:\n            pass    # split this into the two kinds of refusal\n\nhoarder = ...\nprint(\"Refused:\", refused)\nprint(\"Unavailable:\", unavailable)\nprint(\"Hoarder:\", hoarder)\n",
                "solution": _LIMIT_SOLUTION + "\n" + _LIMIT_REPLAY + "refused = []\nunavailable = []\nfor action, member_id, item_id in REQUESTS:\n    if action == \"return\":\n        desk.return_item(item_id)\n    else:\n        try:\n            desk.borrow(item_id, member_id)\n        except LoanLimitExceededError:\n            refused.append(member_id)\n        except ItemUnavailableError:\n            unavailable.append(item_id)\n\nhoarder = max(refused, key=refused.count)\nprint(\"Refused:\", refused)\nprint(\"Unavailable:\", unavailable)\nprint(\"Hoarder:\", hoarder)\n",
                "tests": '''assert issubclass(LoanLimitExceededError, BookVaultError), "LoanLimitExceededError should inherit from BookVaultError"
assert issubclass(LimitedLibrary, Library), "LimitedLibrary should inherit from Library"
def _lib(_limit=3):
    _l = LimitedLibrary("Test Vault", max_active_loans=_limit)
    for _i in ("X1", "X2", "X3", "X4", "X5"):
        _l.add_item(Book(_i))
    return _l
_l = _lib()
for _i in ("X1", "X2", "X3"):
    _l.borrow(_i, "M9")
_l.borrow("X4", "M8")
try:
    _l.borrow("X5", "M9")
    raise AssertionError("a fourth active loan should raise LoanLimitExceededError (limit 3)")
except LoanLimitExceededError:
    pass
assert _l.items["X5"].available is True, "a refused borrow must not take the book: check the limit before calling super().borrow"
_l.return_item("X2")
_l.borrow("X5", "M9")
_one = _lib(1)
_one.borrow("X1", "M9")
try:
    _one.borrow("X2", "M9")
    raise AssertionError("with max_active_loans=1 the second borrow should be refused: use self.max_active_loans, not 3")
except LoanLimitExceededError:
    pass
class _Ref(Library):
    def borrow(self, _item, _member):
        if len(self.active_loans(_member)) >= self.max_active_loans:
            raise LoanLimitExceededError("limit")
        return Library.borrow(self, _item, _member)
_desk = _Ref("ref", max_active_loans=LIMIT)
for _i in SHELF:
    _desk.add_item(Book(_i))
_ref, _unav = [], []
for _a, _m, _i in REQUESTS:
    if _a == "return":
        _desk.return_item(_i)
        continue
    try:
        _desk.borrow(_i, _m)
    except LoanLimitExceededError:
        _ref.append(_m)
    except ItemUnavailableError:
        _unav.append(_i)
assert refused == _ref, f"refused should be {_ref} on this evidence, got {refused!r}"
assert unavailable == _unav, f"unavailable should be {_unav} on this evidence, got {unavailable!r}"
_top = max(_ref, key=_ref.count)
assert hoarder == _top, f"hoarder should be {_top!r}, the member refused most often, got {hoarder!r}"''',
                "tips": [
                    "The exception is two lines: `class LoanLimitExceededError(BookVaultError):` and `pass`. In `borrow`: `if len(self.active_loans(member_id)) >= self.max_active_loans: raise LoanLimitExceededError(...)`, then `return super().borrow(item_id, member_id)`.",
                    "Under `try: desk.borrow(item_id, member_id)` write `except LoanLimitExceededError:` and `except ItemUnavailableError:`, each with its own `append`. For the hoarder, `max(refused, key=refused.count)` picks the id that appears most often.",
                ],
                "reveal": "With the limit in place, the night's requests tell a clear story: one member kept coming back for more, long after the limit said no.",
            },
            {
                "notes": "**The loan-limit policy** (assignment Q7): at most `max_active_loans` active loans per member; returned loans don't count; going over raises `LoanLimitExceededError`; the limit is configurable, so `max_active_loans=1` must work too.",
                "question": "**Goal:** write the four tests the assignment asks for, and use them to check the clerks' versions of the limit.\n\n**You have:** your `LoanLimitExceededError` and `LimitedLibrary`, and `make_library(limit=3)`, which returns a `LimitedLibrary` holding B001 to B005 (all in the editor). `make_library` looks up the name `LimitedLibrary` each time it runs, so when `lab_run` swaps that name for a clerk's class, every test builds the clerk's version. `lab_run` and `SUSPECTS` are in the evidence.\n\n**Write** four tests (no parameters), each starting with `lib = make_library()` (or `make_library(limit=1)`):\n- `test_can_borrow_three`: M001 borrows B001, B002 and B003; assert `len(lib.active_loans(\"M001\")) == 3`\n- `test_fourth_borrow_raises`: after those three, `lib.borrow(\"B004\", \"M001\")` inside `with raises(LoanLimitExceededError):`\n- `test_return_frees_a_slot`: after the three, `lib.return_item(\"B002\")`, then borrowing B004 works; assert M001 has 3 active loans\n- `test_limit_of_one`: with `make_library(limit=1)`, M001 borrows B001, then B002 is refused with `LoanLimitExceededError`\n\n**Then** keep `run_tests(globals())` (4 passed) and fill:\n- `failures`: a dict from each clerk to `lab_run(\"LimitedLibrary\", their_class)`\n- `culprits`: the clerks with at least one failed test, sorted A to Z\n\n**Example:** a limit that counts returned loans too fails `test_return_frees_a_slot`.",
                "starter": _LIMIT_SOLUTION + _LIMIT_HELPER + "# ---- the tests start here ----\n\n# write the four tests here\n\n\nrun_tests(globals())\n\nfailures = {}\nculprits = []\nprint(failures)\nprint(\"Culprits:\", culprits)\n",
                "solution": _LIMIT_SOLUTION + _LIMIT_HELPER + "# ---- the tests start here ----\n\n" + _LIMIT_TESTS + "\n\nrun_tests(globals())\n\nfailures = {}\nfor clerk, suspect in SUSPECTS.items():\n    failures[clerk] = lab_run(\"LimitedLibrary\", suspect)\nculprits = sorted(clerk for clerk in failures if failures[clerk])\nprint(failures)\nprint(\"Culprits:\", culprits)\n",
                "tests": _CHECK_RUN + '''for _n in ("test_can_borrow_three", "test_fourth_borrow_raises", "test_return_frees_a_slot", "test_limit_of_one"):
    assert callable(globals().get(_n)), f"write a test function called {_n}"
_real = _lab_run("LimitedLibrary", LimitedLibrary)
assert _real == [], f"every test should pass on your LimitedLibrary, but these failed: {_real}"
class _NoLimit(Library):
    pass
class _CountsReturned(Library):
    def borrow(self, item_id, member_id):
        if len([_x for _x in self.loans if _x.member_id == member_id]) >= self.max_active_loans:
            raise LoanLimitExceededError("limit")
        return Library.borrow(self, item_id, member_id)
class _OffByOne(Library):
    def borrow(self, item_id, member_id):
        if len(self.active_loans(member_id)) > self.max_active_loans:
            raise LoanLimitExceededError("limit")
        return Library.borrow(self, item_id, member_id)
class _AlwaysThree(Library):
    def borrow(self, item_id, member_id):
        if len(self.active_loans(member_id)) >= 3:
            raise LoanLimitExceededError("limit")
        return Library.borrow(self, item_id, member_id)
class _WrongError(Library):
    def borrow(self, item_id, member_id):
        if len(self.active_loans(member_id)) >= self.max_active_loans:
            raise BookVaultError("limit")
        return Library.borrow(self, item_id, member_id)
class _NeverLends(Library):
    def borrow(self, item_id, member_id):
        raise LoanLimitExceededError("limit")
for _m, _msg in [(_NoLimit, "a library with no limit at all"), (_OffByOne, "a limit that allows one loan too many (> instead of >=)"),
                 (_CountsReturned, "a limit that also counts returned loans: test_return_frees_a_slot"),
                 (_AlwaysThree, "a limit stuck at 3 that ignores max_active_loans: test_limit_of_one"),
                 (_WrongError, "a limit that raises the wrong exception: use raises(LoanLimitExceededError)"),
                 (_NeverLends, "a library that refuses every borrow: test_can_borrow_three")]:
    assert _lab_run("LimitedLibrary", _m), f"your tests should catch {_msg}"
_own_tests = [_n for _n, _f in list(globals().items()) if _n.startswith("test_") and callable(_f)]
assert len(_own_tests) >= 4, f"there should be at least 4 test_ functions, found {len(_own_tests)}"
_exp = {_c: _lab_run("LimitedLibrary", _s) for _c, _s in SUSPECTS.items()}
assert failures == _exp, f"failures should map each clerk to lab_run(\\"LimitedLibrary\\", their class); expected {_exp}, got {failures!r}"
def _bad(_cls):
    def _mk(_limit=3):
        _l = _cls("t", max_active_loans=_limit)
        for _i in ("B001", "B002", "B003", "B004", "B005"):
            _l.add_item(Book(_i))
        return _l
    try:
        _l = _mk()
        for _i in ("B001", "B002", "B003"):
            _l.borrow(_i, "M001")
        try:
            _l.borrow("B004", "M001")
            return True
        except LoanLimitExceededError:
            pass
        _l.return_item("B002")
        _l.borrow("B004", "M001")
        _o = _mk(1)
        _o.borrow("B001", "M001")
        try:
            _o.borrow("B002", "M001")
            return True
        except LoanLimitExceededError:
            return False
    except Exception:
        return True
_truth = sorted(_c for _c, _s in SUSPECTS.items() if _bad(_s))
assert culprits == _truth, f"culprits should be {_truth} on this evidence, got {culprits!r}"''',
                "tips": [
                    "Each test builds its own library with `make_library()`, so no test depends on another. The refused borrow goes inside the `with raises(LoanLimitExceededError):` block, the borrows before it stay outside.",
                    "`for clerk, suspect in SUSPECTS.items(): failures[clerk] = lab_run(\"LimitedLibrary\", suspect)`, then `culprits = sorted(clerk for clerk in failures if failures[clerk])`.",
                ],
                "reveal": "Four tests, and every guilty limit falls over: each one breaks a different rule, and a different test catches it.",
            },
        ],
        "closing": "Case closed. The hoarder is on record, the limit is in BookVault, and four tests guard it. The next clerk who \"improves\" it will meet them first.",
    },
    # ------------------------------------------------------------ decoy-kit (Q8)
    {
        "id": "smuggled-records",
        "tier": "medium",
        "title": "Smuggled Records",
        "teaser": "Junk lines were slipped into a delivery manifest. Import the rest and find whose shift they came in on.",
        "skills": ["decoy-kit", "dataclasses"],
        "story": "A courier firm delivers the lab's catalogue updates as a **JSON Lines** manifest: one record per line. Tonight's manifest crashed the old importer halfway through. Someone has been slipping junk lines in, hoping the whole import fails and nobody looks closely.\n\nForensics loaded for you:\n- `MANIFEST`, the manifest's text (one line per record; some lines are blank, some are junk)\n- `KNOWN_TYPES`, the record types the lab accepts\n- `COURIERS`, the couriers' shifts as `(first_line, last_line, courier)`: who delivered which lines\n- `io`, `json`, `dataclass` and `field` are already imported\n\n*(This is assignment Q8: a JSON-lines loader that keeps going and returns an `ImportReport`. On your machine `load_items` takes a file path and opens it, and the tests write their files into pytest's `tmp_path`, as the card in the import-report lesson shows; this page has no files, so `io.StringIO` stands in.)*",
        "suspects": [
            {"name": "the couriers", "note": "Three of them handled tonight's manifest, one shift each."},
            {"name": "the old importer", "note": "Gave up at the first bad line. Was that the plan?"},
        ],
        "variants": [
            _SMUGGLE_HEAD + _jsonl([
                '{"type": "book", "title": "Clean Code", "item_id": "B001", "author": "Robert Martin", "pages": 464}',
                '{"type": "magazine", "title": "National Geographic", "item_id": "MG001", "issue": 247}',
                '',
                '{"type": "audiobook", "title": "Atomic Habits", "item_id": "A001", "narrator": "James Clear", "duration_min": 320}',
                'BAD JSON HERE',
                '{"type": "book", "title": "Dune", "item_id": "B002", "author": "Frank Herbert", "pages": 412}',
                '{"type": "dvd", "title": "Heat", "item_id": "D001"}',
                '{"type": "magazine", "title": "Wired", "item_id": "MG002", "issue": 12}',
                '{"type": "book", "title": "Emma"',
                '{"type": "book", "title": "Refactoring", "item_id": "B003", "author": "Martin Fowler", "pages": 448}',
                '',
                '["B004"]',
                '{"type": "audiobook", "title": "Sapiens", "item_id": "A002", "narrator": "Derek Perkins", "duration_min": 915}',
            ]) + 'COURIERS = [(1, 4, "Dara"), (5, 9, "Eli"), (10, 13, "Fen")]\n',
            _SMUGGLE_HEAD + _jsonl([
                '{"type": "book", "title": "Persuasion", "item_id": "B010", "author": "Jane Austen", "pages": 249}',
                'BAD JSON',
                '',
                '',
                '{"type": "magazine", "title": "Time", "item_id": "MG010", "issue": 12}',
                '{"type": "vhs", "title": "Alien", "item_id": "V001"}',
                "{'type': 'book', 'title': 'Emma'}",
                '"book"',
                '{"type": "audiobook", "title": "Dune", "item_id": "A010", "narrator": "Scott Brick", "duration_min": 1263}',
                '{"type": "book", "title": "Beloved", "item_id": "B011", "author": "Toni Morrison", "pages": 324}',
                '',
                '<record id="B012"/>',
            ]) + 'COURIERS = [(1, 5, "Gil"), (6, 8, "Hana"), (9, 12, "Ivo")]\n',
            _SMUGGLE_HEAD + _jsonl([
                '{"type": "book", "title": "Ulysses", "item_id": "B020", "author": "James Joyce", "pages": 730}',
                '{"type": "magazine", "title": "Mojo", "item_id": "MG020", "issue": 361}',
                '{"type": "cassette", "title": "Thriller", "item_id": "K001"}',
                '{"type": "book", "title": "Middlemarch", "item_id": "B021", "author": "George Eliot", "pages": 880}',
                '',
                '{"type": "audiobook", "title": "Becoming", "item_id": "A020", "narrator": "Michelle Obama", "duration_min": 1149}',
                '{"title": "No Type", "item_id": "B099"}',
                'BAD JSON',
                '{"type": "book", "title": "Hamlet",',
                '42',
            ]) + 'COURIERS = [(1, 3, "Jun"), (4, 7, "Kit"), (8, 10, "Lee")]\n',
        ],
        "steps": [
            {
                "notes": "**What the lab accepts:** a line is a good record when it is valid JSON, the JSON is an **object** (a dict, not a list, number or string), and its `\"type\"` is one of `KNOWN_TYPES`. Anything else is a bad line.\n\n**Line numbers** count from 1, like an editor does, and blank lines count too (they are skipped, not errors), so the numbers match the file.\n\n`json.loads` raises `json.JSONDecodeError` for broken JSON, and that error is a kind of `ValueError`.",
                "question": "**Goal:** import every good record, and write down every bad line instead of crashing.\n\n**You have:** `MANIFEST` (a string) and `KNOWN_TYPES`. `io.StringIO(MANIFEST)` turns the text into a file-like object you can loop over line by line.\n\n**Write:**\n- `parse_record(raw)`: `json.loads(raw)`; if the result is not a dict, or its `\"type\"` is not in `KNOWN_TYPES`, raise `ValueError`; otherwise return the dict\n- `load_items(f)`, which returns an `ImportReport`:\n  - loop with `enumerate(f, start=1)`; strip each line; add 1 to `total_lines` for **every** line\n  - skip blank lines\n  - append `parse_record(raw)` to `items`; if it raises `ValueError`, append `{\"line\": line_no, \"raw\": raw, \"error\": str(e)}` to `errors` and keep going\n\n**Then** run the two lines at the end of the starter: they store `report` and print its counts.\n\n**Example:** for the lines `{\"type\": \"book\"}`, a blank line, `oops`, the report has 1 item, 1 error on line 3 with `\"raw\": \"oops\"`, and `total_lines` 3.",
                "starter": r'''@dataclass
class ImportReport:
    items: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    total_lines: int = 0

    @property
    def loaded_count(self):
        return len(self.items)

    @property
    def error_count(self):
        return len(self.errors)

def parse_record(raw):
    ...

def load_items(f):
    report = ImportReport()
    # loop over the lines here
    return report
''' + _REPORT_RUN,
                "solution": _REPORT_SOLUTION + _REPORT_RUN,
                "tests": '''import io as _io
_r = load_items(_io.StringIO('{"type": "book", "item_id": "B1"}\\n\\nnot json\\n{"type": "magazine", "item_id": "MG1"}\\n   \\n[1, 2]\\n{"type": "dvd"}\\n'))
assert isinstance(_r, ImportReport), "load_items should return an ImportReport"
assert [_i.get("item_id") for _i in _r.items] == ["B1", "MG1"], f"items should hold the two good records, got {_r.items}"
assert _r.total_lines == 7, f"total_lines should count every line, blank ones too: expected 7, got {_r.total_lines}"
assert [_e.get("line") for _e in _r.errors] == [3, 6, 7], f"the bad lines are 3 (not JSON), 6 (a list) and 7 (unknown type); got {[_e.get('line') for _e in _r.errors]}"
assert _r.errors[0].get("raw") == "not json" and _r.errors[0].get("error"), "each error keeps the stripped raw line under \\"raw\\" and a reason under \\"error\\""
assert isinstance(getattr(ImportReport, "loaded_count", None), property) and isinstance(getattr(ImportReport, "error_count", None), property), "add loaded_count and error_count as @property methods"
assert _r.loaded_count == 2 and _r.error_count == 3, "loaded_count and error_count should be the lengths of items and errors"
for _bad in ("[1]", '"book"', "42", '{"type": "comic"}', '{"title": "x"}'):
    try:
        parse_record(_bad)
        raise AssertionError(f"parse_record({_bad!r}) should raise ValueError")
    except ValueError:
        pass
_lines = MANIFEST.split("\\n")[:-1]
_good, _errs = [], []
for _n, _l in enumerate(_lines, start=1):
    _l = _l.strip()
    if not _l:
        continue
    try:
        _d = json.loads(_l)
        if isinstance(_d, dict) and _d.get("type") in KNOWN_TYPES:
            _good.append(_d)
            continue
    except ValueError:
        pass
    _errs.append(_n)
assert report.items == _good, f"on this manifest {len(_good)} records should load, got {report.loaded_count}"
assert [_e["line"] for _e in report.errors] == _errs, f"on this manifest the bad lines are {_errs}, got {[_e['line'] for _e in report.errors]}"
assert report.total_lines == len(_lines), f"this manifest has {len(_lines)} lines, got total_lines={report.total_lines}"''',
                "tips": [
                    "`parse_record` needs one `if` with `not isinstance(data, dict) or data.get(\"type\") not in KNOWN_TYPES`.",
                    "The `try` goes **inside** the loop, around one line: `try: report.items.append(parse_record(raw))` and `except ValueError as e: report.errors.append({\"line\": line_no, \"raw\": raw, \"error\": str(e)})`.",
                ],
                "reveal": "The import runs to the end. The good records are in, and every junk line is on file with its line number and its exact text.",
            },
            {
                "notes": "**Shifts:** a courier delivered every line from `first_line` to `last_line`, both included. A bad line belongs to the courier whose shift contains its line number. Blank lines are not bad lines.",
                "question": "**Goal:** find whose shift the junk lines came in on.\n\n**You have:** `report` from the last step (the working loader is in the editor) and `COURIERS`, a list of `(first_line, last_line, courier)`.\n\n**Write** three variables:\n- `error_lines`: the line numbers of the errors in `report.errors`, in order (a list of ints)\n- `errors_by_courier`: a dict from courier name to how many error lines fall in their shift; couriers with no errors are left out\n- `smuggler`: the courier with the most error lines (there is no tie). `max(d, key=d.get)` gives the key of a dict `d` with the biggest value.\n\n**Then** print `smuggler` (the starter does).\n\n**Example:** with shifts `[(1, 3, \"Ann\"), (4, 6, \"Bo\")]` and errors on lines 2, 4 and 5, `errors_by_courier` is `{\"Ann\": 1, \"Bo\": 2}` and `smuggler` is `\"Bo\"`.",
                "starter": _REPORT_SOLUTION + _REPORT_RUN + r'''
error_lines = []
errors_by_courier = {}
smuggler = ...
print("Smuggler:", smuggler)
''',
                "solution": _REPORT_SOLUTION + _REPORT_RUN + r'''
error_lines = [error["line"] for error in report.errors]
errors_by_courier = {}
for line_no in error_lines:
    for first, last, courier in COURIERS:
        if first <= line_no <= last:
            errors_by_courier[courier] = errors_by_courier.get(courier, 0) + 1
smuggler = max(errors_by_courier, key=errors_by_courier.get)
print("Smuggler:", smuggler)
''',
                "tests": '''_lines = [_e["line"] for _e in report.errors]
assert error_lines == _lines, f"error_lines should be {_lines} on this manifest, got {error_lines!r}"
_exp = {}
for _n in _lines:
    for _a, _b, _c in COURIERS:
        if _a <= _n <= _b:
            _exp[_c] = _exp.get(_c, 0) + 1
assert errors_by_courier == _exp, f"errors_by_courier should be {_exp} on this manifest, got {errors_by_courier!r}"
_top = max(_exp, key=_exp.get)
assert smuggler == _top, f"smuggler should be {_top!r}, the courier with the most bad lines, got {smuggler!r}"''',
                "tips": [
                    "`error_lines = [error[\"line\"] for error in report.errors]`. Then, for each line number, loop over `COURIERS` and check `first <= line_no <= last`.",
                    "Count with `errors_by_courier[courier] = errors_by_courier.get(courier, 0) + 1`, then `smuggler = max(errors_by_courier, key=errors_by_courier.get)`.",
                ],
                "reveal": "The junk lines cluster in one shift. The other couriers had a stray bad line at most.",
            },
        ],
        "closing": "Case closed. The smuggler counted on the importer falling over at the first junk line. An importer that keeps going and writes everything down turned the junk itself into the evidence.",
    },
    # ------------------------------------------------------------ decoy-kit (Q10)
    {
        "id": "fake-clock",
        "tier": "medium",
        "title": "The Fake Clock",
        "teaser": "The lab's tests pass on Mondays and fail on Fridays. Someone's code is reading the real clock.",
        "skills": ["decoy-kit", "test-bench"],
        "story": "The lab's tests have turned **flaky**: green one day, red the next, and once they tried to call a real cover server. Three clerks each rewrote the lab's three \"unstable\" functions, the ones that read settings, the date, and a web API. Somewhere in there, a rewrite reads the real world instead of what it is given.\n\nForensics loaded for you:\n- the lab's code: `data_path(env=os.environ)`, `days_late(due, clock=date.today)` and `cover_url(isbn, fetch=real_fetch)`; `real_fetch` raises an error, so any real network call fails loudly\n- the mini pytest: `raises`, `run_tests(globals())`, and `lab_swap(swaps)`, which swaps several functions at once (a dict from name to function), runs every test quietly, puts the real ones back, and returns the **names of the tests that failed**\n- `SUSPECTS`, a dict from clerk name to a dict of that clerk's three functions, ready for `lab_swap`\n- `os`, `date` and `MagicMock` are already imported\n\n*(This is assignment Q10: control the environment, the clock and the API in tests. The assignment uses pytest's `monkeypatch`; this case passes the settings, the clock and the fetcher in as arguments instead, which works in the page. The monkeypatch version is on the card in the test-doubles lesson.)*",
        "suspects": [
            {"name": "Mara", "note": "Writes compact code and rarely leaves comments."},
            {"name": "Nico", "note": "Tested everything \"by hand, on my machine\"."},
            {"name": "Odile", "note": "Says her rewrite is a straight copy of the lab's."},
        ],
        "variants": [
            _clock_evidence([("Mara", "ok", "ok", "ok2"), ("Nico", "env_real", "ok2", "ok"), ("Odile", "ok2", "ok", "twice")]),
            _clock_evidence([("Mara", "ok2", "today", "ok"), ("Nico", "ok", "ok", "ignores"), ("Odile", "default", "ok2", "wrong_url")]),
            _clock_evidence([("Mara", "ok", "negative", "ok"), ("Nico", "ok2", "ok2", "network"), ("Odile", "ok", "ok", "ok2")]),
        ],
        "steps": [
            {
                "notes": "**The lab's rules for these functions** (assignment Q10):\n- `data_path(env)` returns `env[\"BOOKVAULT_DATA_PATH\"]` when that key is set, otherwise `\"data/books.jsonl\"`\n- `days_late(due, clock)` is the number of whole days from `due` to `clock()` (today), and never less than 0\n\nA **deterministic** test gives the same result every day, on every machine: it passes the settings in as a plain dict and passes a **fake clock** (a function that always returns the same date). It never reads the real date or the real `os.environ`.",
                "question": "**Goal:** write deterministic tests for the settings and the clock, then try each clerk's rewrite.\n\n**You have:** `data_path`, `days_late`, `run_tests`, `lab_swap` and `SUSPECTS` (see the evidence).\n\n**Write** three tests (no parameters):\n- `test_path_from_env`: `data_path({\"BOOKVAULT_DATA_PATH\": \"/tmp/test.jsonl\"})` returns `\"/tmp/test.jsonl\"`\n- `test_default_path`: `data_path({})` returns `\"data/books.jsonl\"`\n- `test_days_late`: with `fake_clock = lambda: date(2026, 5, 18)`, a book due `date(2026, 5, 1)` is `17` days late, and a book due `date(2026, 6, 1)` is `0` days late\n\nDon't call `date.today()` and don't change `os.environ`.\n\n**Then** keep `run_tests(globals())` (3 passed) and fill:\n- `failures`: a dict from each clerk to `lab_swap(their_functions)`\n- `flagged`: the clerks with at least one failed test, sorted A to Z\n\n**Example:** a `days_late` that ignores `clock` and asks the real date gives a big number instead of 17, so `test_days_late` fails for that clerk.",
                "starter": "# ---- the tests start here ----\n\n# write test_path_from_env, test_default_path and test_days_late here\n\n\nrun_tests(globals())\n\nfailures = {}\nflagged = []\nprint(failures)\nprint(\"Flagged:\", flagged)\n",
                "solution": "# ---- the tests start here ----\n\n" + _CLOCK_TESTS_1 + "\n\nrun_tests(globals())\n" + _CLOCK_VERDICT + "flagged = sorted(clerk for clerk in failures if failures[clerk])\nprint(failures)\nprint(\"Flagged:\", flagged)\n",
                "tests": _CHECK_SWAP + '''for _n in ("test_path_from_env", "test_default_path", "test_days_late"):
    assert callable(globals().get(_n)), f"write a test function called {_n}"
_real = _lab_swap({})
assert _real == [], f"every test should pass on the lab's own code, but these failed: {_real}"
def _ignores_env(env=None):
    return "data/books.jsonl"
def _wrong_default(env=os.environ):
    return env.get("BOOKVAULT_DATA_PATH", "books.json")
def _ignores_clock(due, clock=None):
    return max(0, (date(2026, 1, 1) - due).days)
def _negative(due, clock=date.today):
    return (clock() - due).days
assert _lab_swap({"data_path": _ignores_env}), "test_path_from_env should pass a dict holding BOOKVAULT_DATA_PATH and check that path comes back"
assert _lab_swap({"data_path": _wrong_default}), "test_default_path should pass an empty dict and check for \\"data/books.jsonl\\""
assert _lab_swap({"days_late": _ignores_clock}), "test_days_late should pass a fake clock (clock=...) and check the answer 17"
assert _lab_swap({"days_late": _negative}), "test_days_late should also check that a book due after the fake today is 0 days late"
assert "date.today()" not in __source__, "don't call date.today() in a test: the answer would change every day"
assert "os.environ[" not in __source__ and "setenv" not in __source__ and "putenv" not in __source__, "don't change os.environ: pass a plain dict instead"
_own_tests = [_n for _n, _f in list(globals().items()) if _n.startswith("test_") and callable(_f)]
assert len(_own_tests) >= 3, f"there should be at least 3 test_ functions, found {len(_own_tests)}"
_exp = {_c: _lab_swap(_s) for _c, _s in SUSPECTS.items()}
assert failures == _exp, f"failures should map each clerk to lab_swap(their functions); expected {_exp}, got {failures!r}"
def _bad1(_s):
    try:
        if _s["data_path"]({"BOOKVAULT_DATA_PATH": "/x/y.jsonl"}) != "/x/y.jsonl" or _s["data_path"]({}) != "data/books.jsonl":
            return True
        _clk = lambda: date(2026, 3, 10)
        return _s["days_late"](date(2026, 3, 1), clock=_clk) != 9 or _s["days_late"](date(2026, 4, 1), clock=_clk) != 0
    except Exception:
        return True
_truth = sorted(_c for _c, _s in SUSPECTS.items() if _bad1(_s))
assert flagged == _truth, f"flagged should be {_truth} on this evidence, got {flagged!r}"''',
                "tips": [
                    "Pass the fake straight in: `assert data_path({}) == \"data/books.jsonl\"`, and `assert days_late(date(2026, 5, 1), clock=fake_clock) == 17`.",
                    "`for clerk, swaps in SUSPECTS.items(): failures[clerk] = lab_swap(swaps)`, then `flagged = sorted(clerk for clerk in failures if failures[clerk])`.",
                ],
                "reveal": "With the settings and the clock passed in, the tests give the same answer every day, and a rewrite that peeks at the real world stands out.",
            },
            {
                "notes": "**The cover rule:** `cover_url(isbn, fetch)` asks the cover API **once**, for the URL `https://covers.example/<isbn>`, and returns the `\"url\"` from the reply.\n\nA test must never reach the real API. A `MagicMock(return_value=...)` is a fake function: it returns what you tell it and remembers every call, so the test can check how often it was called (`assert_called_once()`) and with what (`call_args`).",
                "question": "**Goal:** test the cover lookup without the network, and name every clerk whose rewrite breaks a rule.\n\n**You have:** your three tests from the last step (in the editor), `cover_url`, `MagicMock` and the same evidence.\n\n**Write** a test `test_cover_url` that:\n- makes `fake = MagicMock(return_value={\"url\": \"https://img.example/B001.jpg\"})`\n- asserts `cover_url(\"9780132350884\", fake)` returns that URL\n- calls `fake.assert_called_once()`\n- takes `args, kwargs = fake.call_args` and asserts `\"9780132350884\"` is in `args[0]` (the URL that was asked for)\n\n**Then** keep `run_tests(globals())` (4 passed) and the `failures` loop, and store `culprits`: the clerks with at least one failed test, sorted A to Z.\n\n**Example:** a `cover_url` that calls `fetch` twice still returns the right URL, but `fake.assert_called_once()` fails, so that clerk is a culprit.",
                "starter": "# ---- the tests start here ----\n\n" + _CLOCK_TESTS_1 + "\n# write test_cover_url here\n\n\nrun_tests(globals())\n" + _CLOCK_VERDICT + "culprits = []\nprint(failures)\nprint(\"Culprits:\", culprits)\n",
                "solution": "# ---- the tests start here ----\n\n" + _CLOCK_TESTS_1 + _CLOCK_TESTS_2 + "\n\nrun_tests(globals())\n" + _CLOCK_VERDICT + "culprits = sorted(clerk for clerk in failures if failures[clerk])\nprint(failures)\nprint(\"Culprits:\", culprits)\n",
                "tests": _CHECK_SWAP + '''assert callable(globals().get("test_cover_url")), "write a test function called test_cover_url"
_real = _lab_swap({})
assert _real == [], f"every test should pass on the lab's own code, but these failed: {_real}"
assert "MagicMock(" in __source__.split("def test_cover_url", 1)[-1], "make the fake inside test_cover_url with MagicMock(return_value=...)"
def _twice(isbn, fetch=real_fetch):
    fetch(f"https://covers.example/{isbn}")
    return fetch(f"https://covers.example/{isbn}")["url"]
def _wrong_isbn(isbn, fetch=real_fetch):
    return fetch("https://covers.example/" + isbn[:3])["url"]
def _ignores_reply(isbn, fetch=real_fetch):
    fetch(f"https://covers.example/{isbn}")
    return "https://img.example/default.jpg"
assert _lab_swap({"cover_url": _ignores_reply}), "test_cover_url should check that cover_url returns the URL from the fake's reply"
assert _lab_swap({"cover_url": _twice}), "test_cover_url should catch a cover_url that calls the API twice: fake.assert_called_once()"
assert _lab_swap({"cover_url": _wrong_isbn}), "test_cover_url should check the requested URL: args, kwargs = fake.call_args, then look for the ISBN in args[0]"
_own_tests = [_n for _n, _f in list(globals().items()) if _n.startswith("test_") and callable(_f)]
assert len(_own_tests) >= 4, f"there should be at least 4 test_ functions, found {len(_own_tests)}"
_exp = {_c: _lab_swap(_s) for _c, _s in SUSPECTS.items()}
assert failures == _exp, f"failures should map each clerk to lab_swap(their functions); expected {_exp}, got {failures!r}"
def _bad(_s):
    try:
        if _s["data_path"]({"BOOKVAULT_DATA_PATH": "/x/y.jsonl"}) != "/x/y.jsonl" or _s["data_path"]({}) != "data/books.jsonl":
            return True
        _clk = lambda: date(2026, 3, 10)
        if _s["days_late"](date(2026, 3, 1), clock=_clk) != 9 or _s["days_late"](date(2026, 4, 1), clock=_clk) != 0:
            return True
        _f = MagicMock(return_value={"url": "u"})
        if _s["cover_url"]("97812", _f) != "u":
            return True
        return _f.call_count != 1 or "97812" not in _f.call_args[0][0]
    except Exception:
        return True
_truth = sorted(_c for _c, _s in SUSPECTS.items() if _bad(_s))
assert culprits == _truth, f"culprits should be {_truth} on this evidence, got {culprits!r}"''',
                "tips": [
                    "Build the mock first, pass it as the second argument of `cover_url`, and only then check how it was called.",
                    "`fake.assert_called_once()`, then `args, kwargs = fake.call_args` and `assert \"9780132350884\" in args[0]`. The culprits line is the same as `flagged`, over the new `failures`.",
                ],
                "reveal": "The fake API remembers every call it got. The rewrite that asked twice, asked for the wrong book, or went to the real server can't hide it.",
            },
        ],
        "closing": "Case closed. The flaky tests were never random: a rewrite was reading the real world. Settings, clock and API now come in through the front door, and the tests give the same verdict every day.",
    },
    # ------------------------------------------------------------ decoy-kit (Q14)
    {
        "id": "paper-trail",
        "tier": "medium",
        "title": "The Paper Trail",
        "teaser": "Forged catalogue records hide among water-damaged ones. Validate every line and follow the signatures.",
        "skills": ["decoy-kit", "streams", "dataclasses"],
        "story": "The Bureau's archive sent over its catalogue as JSON Lines. Some lines were damaged by a burst pipe; that's bad luck. Others look perfectly tidy but describe items that don't exist or leave out required details: those are **forgeries**, slipped in to cover for books that went missing. Every well-formed record is signed with an `added_by` field.\n\nForensics loaded for you:\n- `CATALOG`, the catalogue text\n- the item classes `Book`, `Magazine` and `AudioBook`, with `KINDS` (type name to class) and `REQUIRED` (type name to the list of required fields)\n- `ImportReport` (with `items`, `errors`, `total_lines`, `skipped`, `loaded_count`, `error_count`) and `ImportRecordError(line_no, reason)`, which keeps `.line_no`\n- `io`, `json`, `dataclass` and `field` are already imported\n\n*(This is assignment Q14: a production import pipeline. Q14 also asks for seven pytest tests: valid file, blank lines, malformed JSON, unknown type, missing field, strict mode raises, non-strict mode continues. Here the lab's checker runs those scenarios on your code; on your machine, write them with pytest and `tmp_path` as the cards in the import-report and validate-and-stream lessons show.)*",
        "suspects": [
            {"name": "the archive clerks", "note": "Three of them sign the records they add with added_by."},
            {"name": "the burst pipe", "note": "Ruined some lines beyond reading. It can't sign anything."},
        ],
        "variants": [
            _PAPER_HEAD + _catalog([
                '{"type": "book", "title": "Clean Code", "item_id": "B001", "author": "Robert Martin", "pages": 464, "added_by": "Quill"}',
                '{"type": "magazine", "title": "National Geographic", "item_id": "MG001", "issue": 247, "added_by": "Rook"}',
                '',
                '{"type": "book", "title": "Dune", "item_id": "B002", "added_by": "Sable"}',
                '{"type": "audiobook", "title": "Atomic Habits", "item_id": "A001", "narrator": "James Clear", "duration_min": 320, "added_by": "Quill"}',
                'BAD JSON HERE',
                '{"type": "dvd", "title": "Heat", "item_id": "D001", "added_by": "Sable"}',
                '{"type": "book", "title": "Refactoring", "item_id": "B003", "author": "Martin Fowler", "pages": 448, "added_by": "Rook"}',
                '{"type": "magazine", "title": "Wired", "item_id": "MG002", "added_by": "Rook"}',
                '{"type": "audiobook", "title": "Sapiens", "item_id": "A002", "narrator": "Derek Perkins", "added_by": "Sable"}',
            ]),
            _PAPER_HEAD + _catalog([
                '{"type": "audiobook", "title": "Becoming", "item_id": "A010", "narrator": "Michelle Obama", "duration_min": 1149, "added_by": "Ulla"}',
                '{"type": "book", "title": "Emma", "item_id": "B010", "author": "Jane Austen", "pages": 474, "added_by": "Tarn"}',
                '{"type": "book", "title": "Persua',
                '{"type": "book", "title": "Ulysses", "item_id": "B011", "author": "James Joyce", "added_by": "Ulla"}',
                '',
                '{"type": "comic", "title": "Watchmen", "item_id": "C001", "added_by": "Ulla"}',
                '{"type": "magazine", "title": "Time", "item_id": "MG010", "issue": 12, "added_by": "Vos"}',
                '[1, 2]',
                '{"type": "magazine", "title": "Vogue", "item_id": "MG011", "added_by": "Vos"}',
                '{"type": "book", "title": "Beloved", "item_id": "B012", "pages": 324, "added_by": "Ulla"}',
            ]),
            _PAPER_HEAD + _catalog([
                '',
                'BAD JSON',
                '{"type": "book", "title": "Middlemarch", "item_id": "B020", "author": "George Eliot", "pages": 880, "added_by": "Yara"}',
                '{"type": "audiobook", "title": "Dune", "item_id": "A020", "narrator": "Scott Brick", "added_by": "Wynn"}',
                '{"type": "magazine", "title": "Mojo", "item_id": "MG020", "issue": 361, "added_by": "Yara"}',
                '{"type": "pamphlet", "title": "Notice", "item_id": "P001", "added_by": "Xan"}',
                '{"type": "book", "title": "Hamlet", "item_id": "B021", "author": "William Shakespeare", "pages": 342, "added_by": "Yara"}',
                '{"type": "book", "item_id": "B022", "author": "Anon", "pages": 10, "added_by": "Wynn"}',
                '"just a string"',
                '{"type": "audiobook", "title": "Educated", "item_id": "A021", "narrator": "Julia Whelan", "duration_min": 732, "added_by": "Xan"}',
                '{"type": "magazine", "title": "Uncut", "item_id": "MG021", "added_by": "Wynn"}',
                '{"type": "book", "title": "Ulys',
            ]),
        ],
        "steps": [
            {
                "notes": "**A valid record** (assignment Q14):\n- the line is valid JSON, and the JSON is an **object** (a dict)\n- its `\"type\"` is a key of `KINDS`\n- it has **every** field listed in `REQUIRED` for that type (extra fields, such as `added_by`, are allowed and ignored)\n\n**Streaming:** the import must read the file **one line at a time**, never the whole file at once, so a huge catalogue doesn't fill the memory.",
                "question": "**Goal:** a streaming line reader and a validator that turns good lines into objects.\n\n**You have:** `CATALOG`, `KINDS`, `REQUIRED` and the item classes (see the evidence).\n\n**Write:**\n- a generator `numbered_lines(f)`: loop with `enumerate(f, start=1)` and `yield line_no, raw.strip()` (no `read()` or `readlines()`)\n- `parse_record(raw)`, which returns a `Book`, `Magazine` or `AudioBook`, or raises `ValueError`:\n  - `data = json.loads(raw)`; if `data` isn't a dict, raise `ValueError`\n  - if `data.get(\"type\")` isn't a key of `KINDS`, raise `ValueError`\n  - if any name in `REQUIRED[kind]` is missing from `data`, raise `ValueError`\n  - otherwise build `KINDS[kind]` from the required fields **only**, with `**`\n\n**Then** run the loop at the end of the starter: it stores `accepted`, the `item_id` of every line that parsed, in file order.\n\n**Example:** `parse_record('{\"type\": \"magazine\", \"title\": \"Wired\", \"item_id\": \"MG2\", \"issue\": 12, \"added_by\": \"X\"}')` gives `Magazine(title='Wired', item_id='MG2', issue=12)`; the same line without `issue` raises `ValueError`.",
                "starter": r'''def numbered_lines(f):
    return []        # make this a generator

def parse_record(raw):
    raise ValueError("not written yet")
''' + _PAPER_ACCEPT,
                "solution": _PAPER_PARSE + _PAPER_ACCEPT,
                "tests": _SPY + '''_s = _Spy(['{"id": 1}\\n', "\\n", "  x  \\n"])
import inspect as _inspect
_g = numbered_lines(_s)
assert _inspect.isgenerator(_g), "numbered_lines should be a generator: put yield inside its loop instead of returning a list"
assert _s.pulled == 0, "numbered_lines should be a generator (use yield): nothing should be read until the first line is asked for"
assert next(_g) == (1, '{"id": 1}'), "the first item should be (1, the stripped first line)"
assert _s.pulled == 1, "read one line at a time: after the first item only one line should have been read (loop over f; no read() or readlines())"
assert list(_g) == [(2, ""), (3, "x")], "yield every line, numbered from 1 and stripped, blank ones included"
_a = parse_record('{"type": "audiobook", "title": "T", "item_id": "A9", "narrator": "N", "duration_min": 5, "added_by": "Z", "isbn": "1"}')
assert isinstance(_a, AudioBook) and _a.item_id == "A9" and _a.duration_min == 5, "an audiobook line should become an AudioBook, with extra fields ignored"
assert isinstance(parse_record('{"type": "book", "title": "T", "item_id": "B9", "author": "A", "pages": 3}'), Book), "a book line should become a Book"
for _bad, _why in [("BAD", "bad JSON"), ("[1, 2]", "a JSON list"), ('"book"', "a JSON string"), ('{"type": "vhs", "title": "T", "item_id": "V1"}', "an unknown type"),
                   ('{"title": "T", "item_id": "B8"}', "a missing type"), ('{"type": "book", "title": "T", "item_id": "B7", "author": "A"}', "a book without pages"),
                   ('{"type": "audiobook", "title": "T", "item_id": "A7", "narrator": "N"}', "an audiobook without duration_min")]:
    try:
        parse_record(_bad)
    except ValueError:
        continue
    except Exception as _e:
        raise AssertionError(f"{_why} should raise ValueError, not {type(_e).__name__}")
    raise AssertionError(f"{_why} should raise ValueError, but parse_record returned a value")
_exp = []
for _l in CATALOG.split("\\n"):
    try:
        _d = json.loads(_l)
    except ValueError:
        continue
    if isinstance(_d, dict) and _d.get("type") in REQUIRED and all(_k in _d for _k in REQUIRED[_d["type"]]):
        _exp.append(_d["item_id"])
assert accepted == _exp, f"on this catalogue the valid records are {_exp}, got {accepted!r}"''',
                "tips": [
                    "A generator is a function with `yield` inside its loop: `for line_no, raw in enumerate(f, start=1):` then `yield line_no, raw.strip()`.",
                    "In `parse_record`: `kind = data.get(\"type\")`, `missing = [name for name in REQUIRED[kind] if name not in data]`, and finally `return KINDS[kind](**{name: data[name] for name in REQUIRED[kind]})`.",
                ],
                "reveal": "The tidy forgeries fail validation just like the water-damaged lines. Only real, complete records become objects.",
            },
            {
                "notes": "**The import rules** (assignment Q14):\n- every line counts in `total_lines`; a blank line adds 1 to `skipped` and is not an error\n- a bad line is recorded as `{\"line\": line_no, \"raw\": raw, \"error\": str(e)}` and the import **continues**\n- in **strict mode** (`strict=True`) the import stops at the **first** bad line by raising `ImportRecordError(line_no, reason)`",
                "question": "**Goal:** the full import: keep going in normal mode, stop at once in strict mode.\n\n**You have:** your `numbered_lines` and `parse_record` (in the editor), `ImportReport` and `ImportRecordError` (in the evidence).\n\n**Write** `import_catalog(f, strict=False)` that returns an `ImportReport`:\n- loop over `numbered_lines(f)` (so the file is streamed); add 1 to `total_lines` for every line\n- blank line: add 1 to `skipped` and move on\n- try `parse_record(raw)` and append the result to `items`\n- on `ValueError`: if `strict`, raise `ImportRecordError(line_no, str(e))`; otherwise append the error dict to `errors`\n\n**Then** run the lines at the end of the starter: they store `report` (normal mode) and `stopped_at`, the line number where strict mode stopped (`None` if it never stopped).\n\n**Example:** for a good line, a blank line and `oops`, normal mode gives 1 item, `skipped` 1 and an error on line 3; strict mode raises `ImportRecordError` with `line_no` 3.",
                "starter": _PAPER_PARSE + r'''
def import_catalog(f, strict=False):
    report = ImportReport()
    # loop over numbered_lines(f) here
    return report
''' + _PAPER_RUN + r'''print(report.loaded_count, "loaded,", report.error_count, "errors,", report.skipped, "blank; strict mode stopped at", stopped_at)
''',
                "solution": _PAPER_PARSE + "\n" + _PAPER_IMPORT + _PAPER_RUN + r'''print(report.loaded_count, "loaded,", report.error_count, "errors,", report.skipped, "blank; strict mode stopped at", stopped_at)
''',
                "tests": '''import io as _io
_good = '{"type": "book", "title": "T", "item_id": "B1", "author": "A", "pages": 9}\\n'
_mag = '{"type": "magazine", "title": "M", "item_id": "MG1", "issue": 4}\\n'
_txt = _good + "\\n" + '{"type": "dvd", "title": "Heat", "item_id": "D1"}\\n' + _mag + "{broken\\n" + "\\n"
_r = import_catalog(_io.StringIO(_txt))
assert isinstance(_r, ImportReport), "import_catalog should return an ImportReport"
assert [_i.item_id for _i in _r.items] == ["B1", "MG1"], f"the two good lines should be imported as objects, got {_r.items}"
assert _r.total_lines == 6 and _r.skipped == 2, f"expected 6 lines with 2 blank ones, got total_lines={_r.total_lines}, skipped={_r.skipped}"
assert [_e.get("line") for _e in _r.errors] == [3, 5], f"errors should be on lines [3, 5], got {[_e.get('line') for _e in _r.errors]}"
assert _r.errors[0].get("raw", "").startswith('{"type": "dvd"') and _r.errors[0].get("error"), "each error needs the raw line and a reason"
try:
    import_catalog(_io.StringIO(_txt), strict=True)
    raise AssertionError("strict=True should raise ImportRecordError at the first bad line")
except ImportRecordError as _e:
    assert _e.line_no == 3, f"strict mode should stop at the first bad line, 3, not {_e.line_no}"
_clean = import_catalog(_io.StringIO(_good + _mag), strict=True)
assert _clean.loaded_count == 2 and _clean.error_count == 0, "strict mode on a clean file should import everything"
''' + _SPY + '''_sp = _Spy([_good, "oops\\n", _mag, _mag])
try:
    import_catalog(_sp, strict=True)
except ImportRecordError:
    pass
assert _sp.pulled == 2, f"strict mode should stop reading at the bad line (line 2), but {_sp.pulled} lines were read: loop over numbered_lines(f)"
_bad_lines, _n_items, _blank = [], 0, 0
for _n, _l in enumerate(CATALOG.split("\\n")[:-1], start=1):
    if not _l.strip():
        _blank += 1
        continue
    try:
        _d = json.loads(_l)
        _ok = isinstance(_d, dict) and _d.get("type") in REQUIRED and all(_k in _d for _k in REQUIRED[_d["type"]])
    except ValueError:
        _ok = False
    if _ok:
        _n_items += 1
    else:
        _bad_lines.append(_n)
assert [_e["line"] for _e in report.errors] == _bad_lines, f"on this catalogue the bad lines are {_bad_lines}, got {[_e['line'] for _e in report.errors]}"
assert report.loaded_count == _n_items and report.skipped == _blank, f"expected {_n_items} items and {_blank} blank lines on this catalogue"
assert stopped_at == _bad_lines[0], f"strict mode should stop at line {_bad_lines[0]} on this catalogue, got {stopped_at!r}"''',
                "tips": [
                    "`for line_no, raw in numbered_lines(f):` (the lines come already stripped). The `try` goes inside the loop, around `report.items.append(parse_record(raw))`.",
                    "`except ValueError as e:` then `if strict: raise ImportRecordError(line_no, str(e))`, and after that `if`, `report.errors.append({\"line\": line_no, \"raw\": raw, \"error\": str(e)})`.",
                ],
                "reveal": "Normal mode keeps every good record and lists every bad one with its original text. Strict mode would have stopped the archive cold at the first bad line.",
            },
            {
                "notes": "**Forgery or damage?** A bad line whose raw text is a well-formed JSON **object** (`json.loads` works and gives a dict) is a **forgery**: it was written on purpose and fails validation. A bad line that isn't valid JSON, or is JSON but not an object, is **damage**. Only forgeries carry an `added_by` signature.",
                "question": "**Goal:** separate forgeries from damage and name the clerk who signed the most forgeries.\n\n**You have:** `report` from the last step (the working import is in the editor). Each error in `report.errors` keeps the original line under `\"raw\"`.\n\n**Write** two variables:\n- `forged`: a dict from `added_by` name to how many forgeries they signed; for each error, try `json.loads(error[\"raw\"])`, skip it if that raises `ValueError` or the result isn't a dict, otherwise count its `\"added_by\"`\n- `forger`: the name with the most forgeries (there is no tie). `max(d, key=d.get)` gives the key of a dict `d` with the biggest value.\n\n**Then** print `forger` (the starter does).\n\n**Example:** errors with raw lines `BAD`, `{\"type\": \"vhs\", \"added_by\": \"Kay\"}` and `[1]` give `forged == {\"Kay\": 1}`.",
                "starter": _PAPER_PARSE + "\n" + _PAPER_IMPORT + _PAPER_RUN + r'''
forged = {}
forger = ...
print("Forger:", forger)
''',
                "solution": _PAPER_PARSE + "\n" + _PAPER_IMPORT + _PAPER_RUN + r'''
forged = {}
for error in report.errors:
    try:
        data = json.loads(error["raw"])
    except ValueError:
        continue
    if isinstance(data, dict):
        forged[data["added_by"]] = forged.get(data["added_by"], 0) + 1
forger = max(forged, key=forged.get)
print("Forger:", forger)
''',
                "tests": '''_exp = {}
for _l in CATALOG.split("\\n"):
    try:
        _d = json.loads(_l)
    except ValueError:
        continue
    if isinstance(_d, dict) and not (_d.get("type") in REQUIRED and all(_k in _d for _k in REQUIRED[_d["type"]])):
        _exp[_d["added_by"]] = _exp.get(_d["added_by"], 0) + 1
assert forged == _exp, f"forged should be {_exp} on this catalogue (count only bad lines that are JSON objects), got {forged!r}"
_top = max(_exp, key=_exp.get)
assert forger == _top, f"forger should be {_top!r}, the clerk who signed the most forgeries, got {forger!r}"''',
                "tips": [
                    "Inside `for error in report.errors:`, put `data = json.loads(error[\"raw\"])` under `try:` and `continue` in the `except ValueError:` block: damaged lines are skipped.",
                    "`if isinstance(data, dict):` then count `data[\"added_by\"]` with `forged.get(name, 0) + 1`; finally `forger = max(forged, key=forged.get)`.",
                ],
                "reveal": "The water damage is spread at random. The forgeries are not: one signature turns up again and again.",
            },
        ],
        "closing": "Case closed. A validating, streaming import kept every honest record, logged every bad one with its original text, and let the forger's own signatures do the talking.",
    },
]

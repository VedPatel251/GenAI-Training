"""Detective X Day 2: medium cases for chapter 6 (Task Force: concurrency, async, retries, providers).

Case format (see .claude/skills/write-cases/SKILL.md for the full rules):
  id, tier ("small" | "medium" | "big"), title, teaser, skills, story, suspects,
  variants  2-3 evidence scripts; the trainee's code runs on each, answers must differ
  steps     [{notes, question, starter, solution, tests, tips: [2 tips], reveal}]
  closing   text shown when the case is closed; optional "fragment" (an X clue, big cases)
Check with:  python engine/build_game.py --check cases_taskforce --day day2

The browser can't run real concurrency, so the evidence carries the same stand-ins the lessons
teach: the mini executor (fake durations, completion order), the generator-based `gather` model,
injected fake sleep and clock. The trainee never has to write that machinery.
"""

# ---------------------------------------------------------------- shared evidence machinery

# The mini executor from the `executors` lesson.
_MINI_POOL = r'''class MiniFuture:
    """Stand-in for a real Future: when the job would finish, and what it returned or raised."""
    def __init__(self, fn, arg, finish_ms):
        self.finish_ms = finish_ms
        try:
            self._value, self._error = fn(arg), None
        except Exception as e:
            self._value, self._error = None, e

    def result(self):
        if self._error is not None:
            raise self._error
        return self._value

class MiniExecutor:
    """A pretend pool (the executors lesson): each job says how long it takes; nothing really waits."""
    def __init__(self, max_workers):
        self.free_at = [0] * max_workers       # when each worker is next free

    def submit(self, fn, arg, takes_ms):
        w = self.free_at.index(min(self.free_at))   # the worker free soonest
        self.free_at[w] += takes_ms
        return MiniFuture(fn, arg, self.free_at[w])

def as_completed(futures):
    return sorted(futures, key=lambda f: f.finish_ms)   # fastest first
'''

# The gather model from the `async-patterns` lesson.
_GATHER = r'''def gather(tasks, limit=None, timeout=None):
    """Model of asyncio.gather(..., return_exceptions=True) with a Semaphore(limit) and timeouts (ms)."""
    clock = 0
    results = [None] * len(tasks)
    queue = list(enumerate(tasks))
    running = []
    while queue or running:
        while queue and (limit is None or len(running) < limit):
            i, task = queue.pop(0)
            deadline = None if timeout is None else clock + timeout
            running.append((clock, i, task, deadline, False))
        running.sort(key=lambda r: (r[0], r[1]))
        wake, i, task, deadline, timed_out = running.pop(0)
        clock = max(clock, wake)
        if timed_out:
            task.close()
            results[i] = TimeoutError(f"no answer within {timeout} ms")
            continue
        try:
            wait = next(task)
        except StopIteration as finished:
            results[i] = finished.value
            continue
        except Exception as error:
            results[i] = error
            continue
        if deadline is not None and clock + wait > deadline:
            running.append((deadline, i, task, deadline, True))
        else:
            running.append((clock + wait, i, task, deadline, False))
    return results, clock
'''


def _pool_ms(latencies, workers):
    """What the mini executor reports as the batch time (used to build honest benchmark reports)."""
    free = [0] * workers
    for t in latencies:
        w = free.index(min(free))
        free[w] += t
    return max(free)


# ---------------------------------------------------------------- cover-raid (Q11)

_FAKE_CLOCK = r'''class FakeClock:
    """Plays time.perf_counter() and time.sleep(): sleep(ms) moves `now` forward without waiting."""
    def __init__(self):
        self.now = 0

    def sleep(self, ms):
        self.now += ms
'''


def _cover_raid(latency, reports):
    """latency: [(isbn, ms)]; reports: [(name, workers, faked_ms or None for an honest report)]."""
    ms = [t for _, t in latency]
    out = {}
    for name, workers, faked in reports:
        true = _pool_ms(ms, workers)
        if faked is not None:
            assert faked != true, (name, faked, true)
        out[name] = {"workers": workers, "ms": true if faked is None else faked}
    lines = [_MINI_POOL, "\n", _FAKE_CLOCK, "\n"]
    lines.append(f"isbns = {[i for i, _ in latency]!r}\n")
    lines.append("latency_ms = {\n" + "".join(f"    {i!r}: {t},\n" for i, t in latency) + "}\n")
    lines.append("reports = {\n" + "".join(f"    {n!r}: {r!r},\n" for n, r in out.items()) + "}\n")
    return "".join(lines)


_CR_FETCH = '''def fetch_cover_sync(isbn, sleep):
    sleep(latency_ms[isbn])
    return isbn, f"https://covers.example/{isbn}.jpg"

def quick_fetch(isbn):
    # for the pool: its takes_ms plays the waiting, so this sleep does nothing
    return fetch_cover_sync(isbn, lambda ms: None)
'''

_CR_POOLED = '''def import_pooled(isbns, max_workers):
    pool = MiniExecutor(max_workers)
    futures = {pool.submit(quick_fetch, isbn, latency_ms[isbn]): isbn for isbn in isbns}
    covers = {}
    arrival = []
    for future in as_completed(futures):
        isbn, url = future.result()
        covers[isbn] = url
        arrival.append(isbn)
    return covers, arrival, max(pool.free_at)
'''

COVER_RAID = {
    "id": "cover-raid",
    "tier": "medium",
    "title": "The Cover Raid",
    "teaser": "The new thread pool is 'ten times faster', says one benchmark. One of them is lying.",
    "skills": ["functions", "decoy-kit", "task-force"],
    "story": "The Forensics Lab photographs every seized book, and the cover images come from a slow cover server. The old import fetched them one at a time. Four technicians each rebuilt it with a **thread pool** and filed a benchmark: how many workers they used and how long the batch took.\n\nSomeone has been tampering with the lab's tools, and a forged benchmark would hide it. The browser can't run real threads, so forensics loaded the lab's **mini executor** (`MiniExecutor`, `as_completed`, from the executors lesson) and a `FakeClock`, plus `isbns`, how long each cover takes (`latency_ms`) and the four `reports`.\n\n*(This is the official assignment Q11: a fake cover import with ThreadPoolExecutor, a benchmark, and tests that don't really sleep.)*",
    "suspects": [
        {"name": "Technician Rao", "note": "Says the pool made the import much faster."},
        {"name": "Technician Okafor", "note": "Says every number came straight off the clock."},
        {"name": "Technician Lind", "note": "Says more workers are always faster."},
        {"name": "Technician Mbeki", "note": "Says they ran the batch twice to be sure."},
    ],
    "variants": [
        _cover_raid(
            [("978-A01", 400), ("978-A02", 900), ("978-A03", 200), ("978-A04", 700),
             ("978-A05", 300), ("978-A06", 500), ("978-A07", 100), ("978-A08", 600)],
            [("Technician Rao", 5, None), ("Technician Okafor", 1, None),
             ("Technician Lind", 3, 1200), ("Technician Mbeki", 8, None)],
        ),
        _cover_raid(
            [("978-B01", 800), ("978-B02", 150), ("978-B03", 650), ("978-B04", 300),
             ("978-B05", 1000), ("978-B06", 250), ("978-B07", 450)],
            [("Technician Rao", 5, None), ("Technician Okafor", 2, None),
             ("Technician Lind", 1, None), ("Technician Mbeki", 4, 900)],
        ),
        _cover_raid(
            [("978-C01", 300), ("978-C02", 300), ("978-C03", 1200), ("978-C04", 400),
             ("978-C05", 200), ("978-C06", 800), ("978-C07", 500), ("978-C08", 100), ("978-C09", 700)],
            [("Technician Rao", 6, None), ("Technician Okafor", 2, 2000),
             ("Technician Lind", 4, None), ("Technician Mbeki", 1, None)],
        ),
    ],
    "steps": [
        {
            "notes": "How the lab times an import:\n- Each cover takes `latency_ms[isbn]` milliseconds to arrive.\n- Fetched **one after another**, the waits add up: the total time is the sum of all the latencies.\n- Real code reads `time.perf_counter()` before and after and subtracts. Here `FakeClock` plays the clock: `clock.sleep(ms)` moves `clock.now` forward by `ms` and returns at once, so nothing really waits.\n- A cover's address is `https://covers.example/<isbn>.jpg`.",
            "question": "**Goal:** rebuild the old one-at-a-time import and time it, without really waiting.\n\n**You have:**\n- `isbns`, a list of ISBN strings, e.g. `[\"978-A01\", \"978-A02\"]`\n- `latency_ms`, a dict from ISBN to milliseconds, e.g. `{\"978-A01\": 400}`\n- `FakeClock`, a class: `clock = FakeClock()` starts at `clock.now == 0`, and `clock.sleep(ms)` adds `ms` to `clock.now`\n\n**Write** a function `fetch_cover_sync(isbn, sleep)`:\n- `sleep` is a function that takes milliseconds (inject it: never call `time.sleep`)\n- it calls `sleep(latency_ms[isbn])` exactly once\n- then returns the tuple `(isbn, url)` with the url from the field notes\n\n**Write** a function `import_sequential(isbns, sleep)`:\n- it fetches every ISBN in order with `fetch_cover_sync(isbn, sleep)`\n- it returns a dict from each ISBN to its URL\n\n**Then** make `clock = FakeClock()`, store `covers = import_sequential(isbns, clock.sleep)`, and store the time it took in `sequential_ms` (it is `clock.now`, since the clock started at 0).\n\n**Example:** if `latency_ms` were `{\"X1\": 200, \"X2\": 300}`, then `import_sequential([\"X1\", \"X2\"], clock.sleep)` returns `{\"X1\": \"https://covers.example/X1.jpg\", \"X2\": \"https://covers.example/X2.jpg\"}` and moves a new clock to `500`.",
            "starter": "def fetch_cover_sync(isbn, sleep):\n    return isbn, f\"https://covers.example/{isbn}.jpg\"\n\ndef import_sequential(isbns, sleep):\n    covers = {}\n    return covers\n\nclock = FakeClock()\ncovers = import_sequential(isbns, clock.sleep)\nsequential_ms = clock.now\nprint(len(covers), \"covers in\", sequential_ms, \"ms\")\n",
            "solution": "def fetch_cover_sync(isbn, sleep):\n    sleep(latency_ms[isbn])\n    return isbn, f\"https://covers.example/{isbn}.jpg\"\n\ndef import_sequential(isbns, sleep):\n    covers = {}\n    for isbn in isbns:\n        key, url = fetch_cover_sync(isbn, sleep)\n        covers[key] = url\n    return covers\n\nclock = FakeClock()\ncovers = import_sequential(isbns, clock.sleep)\nsequential_ms = clock.now\nprint(len(covers), \"covers in\", sequential_ms, \"ms\")\n",
            "tests": '''_waits = []
_got = fetch_cover_sync(isbns[0], _waits.append)
assert _got == (isbns[0], f"https://covers.example/{isbns[0]}.jpg"), f"fetch_cover_sync({isbns[0]!r}, sleep) should return the tuple (isbn, url), got {_got!r}"
assert _waits == [latency_ms[isbns[0]]], f"fetch_cover_sync should call sleep({latency_ms[isbns[0]]}) once for {isbns[0]}, but sleep got {_waits}"
_exp = {_i: f"https://covers.example/{_i}.jpg" for _i in isbns}
assert covers == _exp, f"covers should map all {len(isbns)} ISBNs to their URLs, got {covers!r}"
_total = sum(latency_ms[_i] for _i in isbns)
assert sequential_ms == _total, f"one after another the waits add up to {_total} ms on this evidence, got {sequential_ms!r}"
_w2 = []
assert import_sequential(isbns[:2], _w2.append) == {_i: _exp[_i] for _i in isbns[:2]}, "import_sequential should work for any list of ISBNs"
assert _w2 == [latency_ms[_i] for _i in isbns[:2]], "import_sequential should sleep once per ISBN, in order, through the sleep it was given"''',
            "tips": [
                "`fetch_cover_sync` is two lines: `sleep(latency_ms[isbn])`, then the `return` that is already there.",
                "In `import_sequential`, loop `for isbn in isbns:`, unpack `key, url = fetch_cover_sync(isbn, sleep)` and store `covers[key] = url`.",
            ],
            "reveal": "The old import really is slow: every cover waits for the one before it. The technicians' pools should do much better.",
        },
        {
            "notes": "How a thread pool shares the work:\n- A pool with `max_workers` workers runs that many fetches **at the same time**; the next job goes to the worker that is free first (`MiniExecutor` already does this).\n- The batch is done when the **last** worker finishes: with the mini executor that is `max(pool.free_at)`.\n- Covers come back in the order they **finish**, not the order they were sent.\n- **Speedup** = sequential time / pooled time. A speedup of 4.0 means four times faster.",
            "question": "**Goal:** run the import on a pool of 5 workers and measure the speedup honestly.\n\n**You have:** the evidence from step 1, and in the editor `fetch_cover_sync`, `quick_fetch(isbn)` (the same fetch without the sleep: the pool's `takes_ms` plays the waiting) and `sequential_ms`. Also the mini executor: `pool = MiniExecutor(max_workers)`, `pool.submit(fn, arg, takes_ms)` returns a future, `as_completed(futures)` lists futures in finishing order, `future.result()` gives the job's return value.\n\n**Write** a function `import_pooled(isbns, max_workers)`:\n- create `pool = MiniExecutor(max_workers)`\n- submit one job per ISBN, in the order of `isbns`: `pool.submit(quick_fetch, isbn, latency_ms[isbn])`, and keep a dict from each future to its ISBN\n- loop over `as_completed(...)` and build a dict from ISBN to URL and a list of the ISBNs in the order they finished\n- return the tuple `(covers, arrival, elapsed_ms)`, where `elapsed_ms` is `max(pool.free_at)`\n\n**Then** store `pooled_covers, arrival, pooled_ms = import_pooled(isbns, 5)` and `speedup`, the speedup from the field notes rounded to 1 decimal place.\n\n**Example:** three ISBNs taking 300, 100 and 200 ms on 5 workers arrive in the order: the 100 ms one, the 200 ms one, then the 300 ms one; `elapsed_ms` is 300, one after another took 600, so the speedup is `2.0`.",
            "starter": _CR_FETCH + "\nsequential_ms = sum(latency_ms.values())   # from step 1\n\ndef import_pooled(isbns, max_workers):\n    pool = MiniExecutor(max_workers)\n    covers = {}\n    arrival = []\n    # submit every ISBN, then loop over as_completed(...)\n    return covers, arrival, max(pool.free_at)\n\npooled_covers, arrival, pooled_ms = import_pooled(isbns, 5)\nspeedup = ...\nprint(pooled_ms, \"ms with 5 workers; speedup\", speedup)\n",
            "solution": _CR_FETCH + "\nsequential_ms = sum(latency_ms.values())   # from step 1\n\n" + _CR_POOLED + "\npooled_covers, arrival, pooled_ms = import_pooled(isbns, 5)\nspeedup = round(sequential_ms / pooled_ms, 1)\nprint(pooled_ms, \"ms with 5 workers; speedup\", speedup)\n",
            "tests": '''_pool = MiniExecutor(5)
_futs = {_pool.submit(quick_fetch, _i, latency_ms[_i]): _i for _i in isbns}
_order = [_futs[_f] for _f in as_completed(_futs)]
_ms = max(_pool.free_at)
_exp = {_i: f"https://covers.example/{_i}.jpg" for _i in isbns}
assert pooled_covers == _exp, f"pooled_covers should map every ISBN to its URL, got {pooled_covers!r}"
assert arrival == _order, f"arrival should list the ISBNs in finishing order: {_order}, got {arrival!r}"
assert pooled_ms == _ms, f"with 5 workers the batch takes {_ms} ms on this evidence (max(pool.free_at)), got {pooled_ms!r}"
_sp = round(sum(latency_ms.values()) / _ms, 1)
assert speedup == _sp, f"speedup should be {_sp} (sequential / pooled, rounded to 1 decimal), got {speedup!r}"
_c1, _a1, _t1 = import_pooled(isbns, 1)
assert _t1 == sum(latency_ms.values()) and _a1 == isbns, "with max_workers=1 the pool should take as long as one after another, in input order"
_RealPool = MiniExecutor
_submitted = []
class _SpyPool(_RealPool):
    def submit(self, fn, arg, takes_ms):
        _submitted.append(arg)
        return _RealPool.submit(self, fn, arg, takes_ms)
MiniExecutor = _SpyPool
try:
    import_pooled(isbns, 5)
finally:
    MiniExecutor = _RealPool
assert sorted(_submitted) == sorted(isbns), f"import_pooled should submit one job per ISBN to MiniExecutor; it submitted {_submitted}"''',
            "tips": [
                "Build the futures in one line: `futures = {pool.submit(quick_fetch, isbn, latency_ms[isbn]): isbn for isbn in isbns}`.",
                "`for future in as_completed(futures):` then `isbn, url = future.result()`, store `covers[isbn] = url` and `arrival.append(isbn)`. Finally `speedup = round(sequential_ms / pooled_ms, 1)`.",
            ],
            "reveal": "Five workers cut the batch down to the slowest worker's share. Now the lab knows what an honest benchmark looks like.",
        },
        {
            "notes": "Checking a benchmark: a report is **true** if its time equals what the pool really takes with that many workers on this same batch. Any other time was made up (nobody gets a different time from the same fake durations).",
            "question": "**Goal:** find the technician who forged a benchmark.\n\n**You have:** everything from step 2 (in the editor), and `reports`, a dict from technician name to their report, e.g. `{\"Technician Rao\": {\"workers\": 5, \"ms\": 1000}}`.\n\n**Write** a function `pool_time(max_workers)`:\n- it returns the `elapsed_ms` of `import_pooled(isbns, max_workers)` (an int)\n\n**Then** store:\n- `true_times`: a dict from each technician's name to `pool_time` of the workers they reported\n- `liar`: the name of the one technician whose reported `ms` doesn't match their true time\n\n**Example:** if a report says `{\"workers\": 3, \"ms\": 1200}` but `pool_time(3)` is `1500`, that technician is the liar.",
            "starter": _CR_FETCH + "\n" + _CR_POOLED + "\ndef pool_time(max_workers):\n    ...\n\ntrue_times = {}\nliar = None\nprint(true_times, \"liar:\", liar)\n",
            "solution": _CR_FETCH + "\n" + _CR_POOLED + "\ndef pool_time(max_workers):\n    covers, arrival, elapsed_ms = import_pooled(isbns, max_workers)\n    return elapsed_ms\n\ntrue_times = {}\nliar = None\nfor name, report in reports.items():\n    true_times[name] = pool_time(report[\"workers\"])\n    if report[\"ms\"] != true_times[name]:\n        liar = name\nprint(true_times, \"liar:\", liar)\n",
            "tests": '''def _time(_w):
    _p = MiniExecutor(_w)
    for _i in isbns:
        _p.submit(quick_fetch, _i, latency_ms[_i])
    return max(_p.free_at)
for _w in (1, 2, 3, 7):
    assert pool_time(_w) == _time(_w), f"pool_time({_w}) should be {_time(_w)} ms on this evidence, got {pool_time(_w)!r}"
_true = {_n: _time(_r["workers"]) for _n, _r in reports.items()}
assert true_times == _true, f"true_times should be {_true}, got {true_times!r}"
_liars = [_n for _n in reports if reports[_n]["ms"] != _true[_n]]
assert liar == _liars[0], f"the forged report is the one whose ms doesn't match its true time; got {liar!r}"''',
            "tips": [
                "`pool_time` unpacks the tuple and returns the last part: `covers, arrival, elapsed_ms = import_pooled(isbns, max_workers)`, then `return elapsed_ms`.",
                "Loop `for name, report in reports.items():`, store `true_times[name] = pool_time(report[\"workers\"])`, and if `report[\"ms\"] != true_times[name]`, set `liar = name`.",
            ],
            "reveal": "One report claims a time no pool could ever reach with that many workers. The numbers were typed in, not measured.",
        },
    ],
    "closing": "Case closed. The forged benchmark was meant to get a broken import approved. The slowest report was the red herring: one worker, a slow batch, and every millisecond of it true. Fake durations made every claim checkable.",
}


# ---------------------------------------------------------------- merged-manifests (Q15)

_IMPORT_CATALOG = r'''from dataclasses import dataclass, field

@dataclass
class ImportReport:
    loaded: list = field(default_factory=list)    # book ids, in file order
    errors: list = field(default_factory=list)    # one string per problem

def import_catalog(path):
    """Import one manifest (given). Bad rows become errors; a file that can't be read raises."""
    if path not in files:
        raise FileNotFoundError(path)
    lines = files[path].strip().split("\n")
    if lines[0] != "id,title,copies":
        raise ValueError(f"{path} is not a manifest")
    report = ImportReport()
    for n, line in enumerate(lines[1:], start=2):
        parts = line.split(",")
        if len(parts) != 3 or not parts[2].strip().isdigit():
            report.errors.append(f"{path} line {n}: bad row")
        else:
            report.loaded.append(parts[0].strip())
    return report
'''

_CLERKS = {
    "01_dock.csv": "Clerk Ayodele",
    "02_vault.csv": "Clerk Brandt",
    "03_annex.csv": "Clerk Castillo",
    "04_reading_room.csv": "Clerk Dhawan",
}


def _manifests(files, paths, durations):
    lines = [_MINI_POOL, "\n", "files = {\n"]
    lines += [f"    {p!r}: {t!r},\n" for p, t in files.items()]
    lines.append("}\n\n" + _IMPORT_CATALOG + "\n")
    lines.append(f"paths = {paths!r}\n")
    lines.append(f"durations = {durations!r}\n")
    lines.append("clerks = {\n" + "".join(f"    {p!r}: {c!r},\n" for p, c in _CLERKS.items()) + "}\n")
    return "".join(lines)


_MM_IMPORT_MANY = '''def import_many(paths, *, max_workers=4):
    pool = MiniExecutor(max_workers)
    futures = {pool.submit(import_catalog, path, durations[path]): path for path in paths}
    per_path = {}
    for future in as_completed(futures):
        path = futures[future]
        try:
            per_path[path] = future.result()
        except Exception as e:
            per_path[path] = ImportReport([], [f"{path}: {type(e).__name__}"])
    merged = ImportReport()
    for path in sorted(per_path):
        merged.loaded.extend(per_path[path].loaded)
        merged.errors.extend(per_path[path].errors)
    return merged
'''

MERGED_MANIFESTS = {
    "id": "merged-manifests",
    "tier": "medium",
    "title": "The Merged Manifests",
    "teaser": "Four intake desks, one merged catalog, and a book that arrived twice.",
    "skills": ["dataclasses", "decoy-kit", "task-force"],
    "story": "Every night the lab's four intake desks each send a manifest of the books they logged. A night job imports them **all at once** on a thread pool and merges them into one report. Last week the merged report came out in a different order every night, and this week the catalog holds **ghost copies**: books logged twice so they can quietly leave the building once.\n\nForensics loaded the manifests (`files`, a dict from file name to its text), the list of `paths` to import, how long each import takes (`durations`), who sent each file (`clerks`), the lab's one-file importer `import_catalog` with its `ImportReport`, and the mini executor (`MiniExecutor`, `as_completed`).\n\n*(This is the official assignment Q15: a concurrent multi-file import with a deterministic merge.)*",
    "suspects": [
        {"name": "Clerk Ayodele", "note": "Runs the loading dock desk; logs the first manifest every night."},
        {"name": "Clerk Brandt", "note": "Runs the vault desk; handles the rare books."},
        {"name": "Clerk Castillo", "note": "Runs the annex desk; started this month."},
        {"name": "Clerk Dhawan", "note": "Runs the reading room desk; was off sick on Tuesday."},
    ],
    "variants": [
        _manifests(
            {
                "01_dock.csv": "id,title,copies\nB101,Glass Harbour,2\nB102,Night Trains,1\nB103,Salt Roads,x\nB104,The Lantern Men,3\n",
                "02_vault.csv": "%PDF-1.4 ??? scrambled bytes ???\n",
                "03_annex.csv": "id,title,copies\nB301,Cold Orchard,1\nB102,Night Trains,4\nB302,Paper Moons,2\n",
                "04_reading_room.csv": "id,title,copies\nB401,Iron Bells,1\nB402,Quiet Rooms,2\n",
            },
            ["04_reading_room.csv", "02_vault.csv", "01_dock.csv", "03_annex.csv"],
            {"01_dock.csv": 900, "02_vault.csv": 100, "03_annex.csv": 400, "04_reading_room.csv": 200},
        ),
        _manifests(
            {
                "01_dock.csv": "id,title,copies\nB110,Harbour Lights,1\nB111,The Long Winter,2\nB112,Red Ledger,1\n",
                "02_vault.csv": "id,title,copies\nB210,Old Maps,1\nB211,Silver Keys\nB111,The Long Winter,3\nB212,Blue Hour,2\n",
                "03_annex.csv": "id,title,copies\nB310,Field Guide,4\nB311,Small Gods,1\n",
            },
            ["03_annex.csv", "01_dock.csv", "04_reading_room.csv", "02_vault.csv"],
            {"01_dock.csv": 700, "02_vault.csv": 150, "03_annex.csv": 300, "04_reading_room.csv": 50},
        ),
        _manifests(
            {
                "01_dock.csv": "id,title,copies\nB120,Ash and Amber,2\nB121,North Window,1\nB122,The Quiet Pier,1\n",
                "02_vault.csv": "id,title,copies\nB220,Paper Wings,one\nB221,Brass Clocks,2\nB222,Tin Soldiers,\n",
                "03_annex.csv": "<<< disk read error >>>\n",
                "04_reading_room.csv": "id,title,copies\nB420,Late Trains,1\nB120,Ash and Amber,1\nB121,North Window,2\n",
            },
            ["02_vault.csv", "04_reading_room.csv", "03_annex.csv", "01_dock.csv"],
            {"01_dock.csv": 350, "02_vault.csv": 800, "03_annex.csv": 100, "04_reading_room.csv": 250},
        ),
    ],
    "steps": [
        {
            "notes": "The night job's rules:\n- Import every file in `paths` with `import_catalog(path)`, using the pool.\n- **One bad file must not stop the import.** If `import_catalog` raises for a file, that file counts as no books and one error: `f\"{path}: {type(e).__name__}\"`, e.g. `\"02_vault.csv: ValueError\"`.\n- **Deterministic merge:** files finish in a different order every night, so build the merged report by going through the files **sorted by name**: first all of the first file's books and errors, then the next file's, and so on.\n- So the result must be the same whatever order `paths` comes in and however many workers run.",
            "question": "**Goal:** merge the four manifests into one report that comes out the same every night.\n\n**You have:**\n- `paths`, a list of file names, e.g. `[\"04_reading_room.csv\", \"01_dock.csv\"]` (not sorted)\n- `durations`, a dict from file name to how many ms its import takes\n- `import_catalog(path)`, which returns an `ImportReport` or raises if the file can't be read\n- `ImportReport`, a dataclass with two lists: `loaded` (book ids) and `errors` (strings); `ImportReport()` is empty, `ImportReport([\"B1\"], [\"x\"])` has one of each\n- the mini executor: `MiniExecutor`, `pool.submit(fn, arg, takes_ms)`, `as_completed`, `future.result()`\n\n**Write** a function `import_many(paths, *, max_workers=4)`:\n- create a `MiniExecutor(max_workers)` and submit `import_catalog` for every path, with `takes_ms=durations[path]`\n- loop over `as_completed(...)`; call `future.result()` inside `try` / `except Exception`, and turn a failed file into the one-error report from the field notes\n- return one merged `ImportReport` built in sorted file-name order (field notes)\n\n**Then** store `report = import_many(paths)`.\n\n**Example:** if `a.csv` loads `[\"B1\"]` and `b.csv` raises `FileNotFoundError`, the merged report is `ImportReport([\"B1\"], [\"b.csv: FileNotFoundError\"])`, whichever file finishes first.",
            "starter": "def import_many(paths, *, max_workers=4):\n    # the old job: one file after another, in whatever order paths came, bad files silently dropped\n    merged = ImportReport()\n    for path in paths:\n        try:\n            part = import_catalog(path)\n        except Exception:\n            continue\n        merged.loaded.extend(part.loaded)\n        merged.errors.extend(part.errors)\n    return merged\n\nreport = import_many(paths)\nprint(report)\n",
            "solution": _MM_IMPORT_MANY + "\nreport = import_many(paths)\nprint(report)\n",
            "tests": '''_exp = ImportReport()
for _p in sorted(paths):
    try:
        _part = import_catalog(_p)
    except Exception as _e:
        _part = ImportReport([], [f"{_p}: {type(_e).__name__}"])
    _exp.loaded.extend(_part.loaded)
    _exp.errors.extend(_part.errors)
assert isinstance(report, ImportReport), f"import_many should return an ImportReport, got {type(report).__name__}"
assert report.loaded == _exp.loaded, f"report.loaded should be {_exp.loaded} (files in sorted name order), got {report.loaded!r}"
assert report.errors == _exp.errors, f"report.errors should be {_exp.errors}, got {report.errors!r}"
assert import_many(paths, max_workers=1) == _exp, "max_workers=1 should give exactly the same report as the concurrent run"
assert import_many(list(reversed(paths)), max_workers=2) == _exp, "the report must not depend on the order of paths or the number of workers: merge in sorted file-name order"
_RealPool = MiniExecutor
_submitted = []
class _SpyPool(_RealPool):
    def submit(self, fn, arg, takes_ms):
        _submitted.append(arg)
        return _RealPool.submit(self, fn, arg, takes_ms)
MiniExecutor = _SpyPool
try:
    import_many(paths)
finally:
    MiniExecutor = _RealPool
assert sorted(_submitted) == sorted(paths), f"import_many should submit one import_catalog job per path to MiniExecutor; it submitted {_submitted}"''',
            "tips": [
                "Keep a dict from future to path: `futures = {pool.submit(import_catalog, path, durations[path]): path for path in paths}`. Then in the `as_completed` loop store each file's report in a dict `per_path[path]`.",
                "In `except Exception as e:` store `ImportReport([], [f\"{path}: {type(e).__name__}\"])`. After the loop, `for path in sorted(per_path):` extend `merged.loaded` and `merged.errors`.",
            ],
            "reveal": "The merged report finally reads the same every night. And there, in black and white, a book id shows up more than once.",
        },
        {
            "notes": "Ghost copies:\n- A book id may be loaded **only once** across all the manifests.\n- Files are named in the order they arrived: `01_...` came in first, then `02_...`, and so on.\n- When a later file loads an id that an earlier file already loaded, the **later** file holds the ghost copy, and the clerk who sent it is the smuggler.\n- A file that can't be read, or a bad row, is damage, not smuggling.",
            "question": "**Goal:** find the ghost copies and the clerk who smuggled them in.\n\n**You have:** `import_many` and `report` from step 1 (in the editor), `import_catalog`, `paths`, and `clerks`, a dict from file name to the clerk who sent it, e.g. `{\"01_dock.csv\": \"Clerk Ayodele\"}`.\n\n**Write** two variables:\n- `ghost_ids`: a sorted list of the book ids that appear more than once in `report.loaded` (each id listed once)\n- `smuggler`: the clerk of the file that loaded an id an earlier file had already loaded (field notes). Go through `sorted(paths)`, call `import_catalog(path)` inside `try` / `except Exception` (skip files that can't be read), and keep a set of the ids seen so far.\n\n**Example:** if `01_a.csv` loads `[\"B1\", \"B2\"]` and `02_b.csv` loads `[\"B3\", \"B1\"]`, then `ghost_ids` is `[\"B1\"]` and the smuggler is the clerk of `02_b.csv`.",
            "starter": _MM_IMPORT_MANY + "\nreport = import_many(paths)\n\nghost_ids = []\nsmuggler = None\nprint(ghost_ids, smuggler)\n",
            "solution": _MM_IMPORT_MANY + "\nreport = import_many(paths)\n\nghost_ids = sorted({b for b in report.loaded if report.loaded.count(b) > 1})\n\nseen = set()\nsmuggler = None\nfor path in sorted(paths):\n    try:\n        part = import_catalog(path)\n    except Exception:\n        continue\n    for book_id in part.loaded:\n        if book_id in seen:\n            smuggler = clerks[path]\n        seen.add(book_id)\nprint(ghost_ids, smuggler)\n",
            "tests": '''_all = []
_who = None
for _p in sorted(paths):
    try:
        _ids = import_catalog(_p).loaded
    except Exception:
        continue
    for _b in _ids:
        if _b in _all:
            _who = clerks[_p]
        _all.append(_b)
_ghosts = sorted({_b for _b in _all if _all.count(_b) > 1})
assert ghost_ids == _ghosts, f"ghost_ids should be {_ghosts} on this evidence (sorted, each once), got {ghost_ids!r}"
assert smuggler == _who, f"the smuggler is the clerk of the later file that repeats an id; got {smuggler!r}"''',
            "tips": [
                "For `ghost_ids`, a set comprehension removes repeats: `sorted({b for b in report.loaded if report.loaded.count(b) > 1})`.",
                "Start with `seen = set()`. For each path in `sorted(paths)` (skipping files that raise), loop over `part.loaded`: if the id is already in `seen`, set `smuggler = clerks[path]`; then `seen.add(book_id)`.",
            ],
            "reveal": "The ghost copies all came from one desk, logged after the originals had already arrived.",
        },
    ],
    "closing": "Case closed. An unreadable file or a bad row is damage, not smuggling: it costs books, it doesn't add them. Once the merge stopped depending on which thread finished first, the repeated ids had nowhere to hide, and the file that repeated them named its clerk.",
}


# ---------------------------------------------------------------- switchboard-jam (Q16)

_FAKE_COVER_API = r'''class FakeCoverAPI:
    """A pretend cover server (no network): for each ISBN, how long it takes to answer (ms) and its HTTP status."""
    def __init__(self, replies):
        self.replies = replies
        self.asked = []

    def lookup(self, isbn):
        self.asked.append(isbn)
        return self.replies[isbn]          # a tuple (ms, status)
'''

_KEEPERS = {"north": "Engineer Petrov", "east": "Engineer Quist", "west": "Engineer Ramos"}


def _switchboard(rows):
    """rows: [(isbn, ms, status, mirror)]."""
    lines = ["from dataclasses import dataclass\n\n", _GATHER, "\n", _FAKE_COVER_API, "\n"]
    lines.append("api = FakeCoverAPI({\n" + "".join(f"    {i!r}: ({ms}, {st}),\n" for i, ms, st, _ in rows) + "})\n")
    lines.append(f"isbns = {[r[0] for r in rows]!r}\n")
    lines.append("mirror_of = {\n" + "".join(f"    {i!r}: {m!r},\n" for i, _, _, m in rows) + "}\n")
    lines.append(f"keepers = {_KEEPERS!r}\n")
    return "".join(lines)


_SJ_RESULT = '''@dataclass(frozen=True)
class CoverResult:
    isbn: str
    url: str | None
    error: str | None = None
'''

_SJ_INIT = '''    def __init__(self, *, base_url, client, concurrency=5, timeout=2000):
        self.base_url = base_url
        self.client = client
        self.concurrency = concurrency
        self.timeout = timeout
        self.elapsed_ms = 0

    def fetch_one(self, client, isbn):
        ms, status = client.lookup(isbn)
        yield ms                            # like: response = await client.get(...)
        if status == 200:
            return CoverResult(isbn, f"{self.base_url}/{isbn}.jpg")
        return CoverResult(isbn, None, f"HTTP {status}")
'''

_SJ_FETCH_ALL = '''
    def fetch_all(self, isbns):
        tasks = [self.fetch_one(self.client, isbn) for isbn in isbns]
        results, self.elapsed_ms = gather(tasks, limit=self.concurrency, timeout=self.timeout)
        found = {}
        for isbn, r in zip(isbns, results):
            if isinstance(r, TimeoutError):
                found[isbn] = CoverResult(isbn, None, "timeout")
            elif isinstance(r, Exception):
                found[isbn] = CoverResult(isbn, None, type(r).__name__)
            else:
                found[isbn] = r
        return found
'''

_SJ_FULL = _SJ_RESULT + "\nclass CoverFetcher:\n" + _SJ_INIT + _SJ_FETCH_ALL

_SJ_RUN = '\nfetcher = CoverFetcher(base_url="https://covers.example", client=api, concurrency=3, timeout=1000)\nresults = fetcher.fetch_all(isbns)\nbatch_ms = fetcher.elapsed_ms\n'

SWITCHBOARD_JAM = {
    "id": "switchboard-jam",
    "tier": "medium",
    "title": "The Switchboard Jam",
    "teaser": "The cover lookup hangs for minutes. Somebody rigged a mirror to stall.",
    "skills": ["dataclasses", "task-force", "switchboard"],
    "story": "The lab's cover lookups go through a switchboard of three mirror servers (north, east and west). Since Monday the nightly batch **hangs**: one stalled call holds up the whole report. The Bureau wants an async `CoverFetcher` that caps how many calls are open at once, gives every call a deadline, and returns **partial results** instead of crashing. Then it wants to know who rigged a mirror to stall.\n\nThe browser can't run `asyncio`, so forensics loaded the lab's **`gather` model** from the async-patterns lesson (generator tasks, `yield ms` stands in for `await`, with `limit` playing the Semaphore and `timeout` the deadline), a pretend server `api` (a `FakeCoverAPI`: no real calls in tests), the `isbns` to fetch, which mirror serves each (`mirror_of`) and who keeps each mirror (`keepers`).\n\n*(This is the official assignment Q16: an async CoverFetcher with a Semaphore, a timeout and partial failures.)*",
    "suspects": [
        {"name": "Engineer Petrov", "note": "Keeps the north mirror; says it has never once been down."},
        {"name": "Engineer Quist", "note": "Keeps the east mirror; blames the network for everything."},
        {"name": "Engineer Ramos", "note": "Keeps the west mirror; was on call on Sunday night."},
    ],
    "variants": [
        _switchboard([
            ("978-S01", 300, 200, "east"), ("978-S02", 4000, 200, "north"), ("978-S03", 200, 404, "east"),
            ("978-S04", 5000, 200, "north"), ("978-S05", 100, 503, "east"), ("978-S06", 600, 200, "west"),
            ("978-S07", 250, 404, "east"), ("978-S08", 9000, 200, "north"), ("978-S09", 150, 503, "east"),
            ("978-S10", 1500, 200, "west"),
        ]),
        _switchboard([
            ("978-T01", 7000, 200, "east"), ("978-T02", 300, 404, "north"), ("978-T03", 450, 200, "west"),
            ("978-T04", 200, 404, "north"), ("978-T05", 6500, 200, "east"), ("978-T06", 800, 503, "north"),
            ("978-T07", 3000, 200, "east"), ("978-T08", 2500, 200, "west"), ("978-T09", 120, 200, "west"),
        ]),
        _switchboard([
            ("978-U01", 900, 200, "north"), ("978-U02", 8000, 200, "west"), ("978-U03", 400, 503, "north"),
            ("978-U04", 2000, 200, "east"), ("978-U05", 6000, 200, "west"), ("978-U06", 350, 404, "north"),
            ("978-U07", 4500, 200, "west"), ("978-U08", 700, 200, "east"), ("978-U09", 3500, 200, "west"),
            ("978-U10", 100, 404, "east"), ("978-U11", 300, 500, "north"),
        ]),
    ],
    "steps": [
        {
            "notes": "The cover API's rules:\n- `client.lookup(isbn)` tells you `(ms, status)`: how long the server takes to answer, and its HTTP status.\n- Status **200** means the cover exists; its address is `<base_url>/<isbn>.jpg`.\n- Any other status is a failed lookup; record it as the text `\"HTTP <status>\"`, e.g. `\"HTTP 404\"`.\n- In the model, a task waits for the answer with `yield ms` (real code: `await client.get(...)`).\n- The `client` (the server connection) is passed in, so tests can hand in a fake server; later, `fetch_all` passes `self.client`.\n- In the model all times are in **milliseconds**, so `timeout=2000` means 2 seconds (the assignment writes `timeout=2.0`, in seconds).",
            "question": "**Goal:** build the fetcher's pieces and run every lookup once, with no deadline, to see the jam.\n\n**You have:**\n- `api`, a `FakeCoverAPI`: `api.lookup(\"978-S01\")` gives a tuple like `(300, 200)`\n- `isbns`, a list of ISBN strings\n- `gather(tasks)` from the lesson: runs generator tasks together and returns `(results, total_ms)`, results in the order of `tasks`\n- `CoverResult`, a frozen dataclass already in the editor: `CoverResult(isbn, url)` for a found cover, `CoverResult(isbn, None, error)` for a failure\n\n**Write** a class `CoverFetcher`:\n- `__init__(self, *, base_url, client, concurrency=5, timeout=2000)` stores all four as attributes with those names, plus `self.elapsed_ms = 0` (times are in ms in the model)\n- a generator method `fetch_one(self, client, isbn)`: get `ms, status` from `client.lookup(isbn)`, `yield ms`, then **return** `CoverResult(isbn, url)` for status 200, or `CoverResult(isbn, None, \"HTTP <status>\")` otherwise (field notes)\n\n**Then** make `fetcher = CoverFetcher(base_url=\"https://covers.example\", client=api, concurrency=3, timeout=1000)` and run one `fetch_one` task per ISBN with plain `gather` (no limit, no timeout), storing `first_pass, first_ms = gather([...])`.\n\n**Example:** if the API said `{\"X1\": (50, 200), \"X2\": (70, 404)}`, the two tasks give `[CoverResult(\"X1\", \"https://covers.example/X1.jpg\"), CoverResult(\"X2\", None, \"HTTP 404\")]` and `70` ms.",
            "starter": _SJ_RESULT + "\nclass CoverFetcher:\n    def __init__(self, *, base_url, client, concurrency=5, timeout=2000):\n        self.base_url = base_url\n\n    def fetch_one(self, client, isbn):\n        yield 0\n        return None\n\nfetcher = CoverFetcher(base_url=\"https://covers.example\", client=api, concurrency=3, timeout=1000)\nfirst_pass, first_ms = [], 0\nprint(first_ms, \"ms\", first_pass)\n",
            "solution": _SJ_RESULT + "\nclass CoverFetcher:\n" + _SJ_INIT + "\nfetcher = CoverFetcher(base_url=\"https://covers.example\", client=api, concurrency=3, timeout=1000)\nfirst_pass, first_ms = gather([fetcher.fetch_one(api, isbn) for isbn in isbns])\nprint(first_ms, \"ms\", first_pass)\n",
            "tests": '''import types
_r = CoverResult("X", "u")
assert _r.error is None, "CoverResult's error should default to None"
_frozen = False
try:
    _r.url = "changed"
except Exception:
    _frozen = True
assert _frozen, "CoverResult should be frozen: @dataclass(frozen=True)"
_f = CoverFetcher(base_url="https://b.example", client=api)
assert (_f.base_url, _f.client, _f.concurrency, _f.timeout) == ("https://b.example", api, 5, 2000), "CoverFetcher should store base_url, client, concurrency (default 5) and timeout (default 2000)"
assert isinstance(_f.fetch_one(api, isbns[0]), types.GeneratorType), "fetch_one must be a generator task: wait for the answer with yield ms"
_mini = FakeCoverAPI({"X1": (50, 200), "X2": (70, 404)})
_got = gather([_f.fetch_one(_mini, "X1"), _f.fetch_one(_mini, "X2")])
assert _got == ([CoverResult("X1", "https://b.example/X1.jpg"), CoverResult("X2", None, "HTTP 404")], 70), f"fetch_one should return a CoverResult after waiting; got {_got!r}"
assert _mini.asked == ["X1", "X2"], "fetch_one should ask the client it was given (client.lookup(isbn))"
_exp = []
for _i in isbns:
    _ms, _st = api.replies[_i]
    _exp.append(CoverResult(_i, f"https://covers.example/{_i}.jpg") if _st == 200 else CoverResult(_i, None, f"HTTP {_st}"))
assert first_pass == _exp, f"first_pass should hold one CoverResult per ISBN in order; got {first_pass!r}"
_slow = max(api.replies[_i][0] for _i in isbns)
assert first_ms == _slow, f"with no deadline the batch waits for the slowest call: {_slow} ms on this evidence, got {first_ms!r}"''',
            "tips": [
                "In `__init__`, store each parameter: `self.client = client`, `self.concurrency = concurrency`, and so on. In `fetch_one`, `ms, status = client.lookup(isbn)` then `yield ms`.",
                "After the `yield`: `if status == 200: return CoverResult(isbn, f\"{self.base_url}/{isbn}.jpg\")`, else `return CoverResult(isbn, None, f\"HTTP {status}\")`. Then `first_pass, first_ms = gather([fetcher.fetch_one(api, isbn) for isbn in isbns])`.",
            ],
            "reveal": "One call alone kept the whole batch waiting for seconds. With no deadline, a single stalled mirror jams the switchboard.",
        },
        {
            "notes": "How the fetcher protects the batch:\n- **Concurrency cap:** at most `concurrency` lookups open at once (real code: `asyncio.Semaphore`; in the model: `gather(..., limit=...)`). It limits how many run at the same moment, not how many per second.\n- **Deadline:** each lookup gets `timeout` ms from the moment it starts (real code: `asyncio.timeout`; in the model: `gather(..., timeout=...)`). A lookup past its deadline is cancelled and its result is a `TimeoutError`.\n- **Partial failures:** a timed-out lookup becomes `CoverResult(isbn, None, \"timeout\")`; a lookup that raised any other error becomes `CoverResult(isbn, None, <the error's class name>)`, e.g. `\"ConnectionError\"`. The batch never crashes.",
            "question": "**Goal:** fetch the whole batch safely and get every answer back, good or bad.\n\n**You have:** `CoverResult` and `CoverFetcher` from step 1 (in the editor), `api`, `isbns`, and `gather(tasks, limit=None, timeout=None)`, which returns `(results, total_ms)`; a failed task's result is the error object itself.\n\n**Write** a method `fetch_all(self, isbns)` on `CoverFetcher`:\n- make one `self.fetch_one(self.client, isbn)` task per ISBN\n- run them with `gather`, using `limit=self.concurrency` and `timeout=self.timeout`\n- store the batch time in `self.elapsed_ms`\n- return a dict from each ISBN to its `CoverResult`, with the keys in the same order as `isbns`, turning errors into results as in the field notes (check `TimeoutError` before other exceptions)\n\n**Then** store `results = fetcher.fetch_all(isbns)` and `batch_ms = fetcher.elapsed_ms`, with the fetcher already made in the editor (concurrency 3, deadline 1000 ms).\n\n**Example:** four lookups of 100 ms each with `concurrency=2` take 200 ms; a lookup of 1500 ms with `timeout=1000` gives `CoverResult(isbn, None, \"timeout\")`.",
            "starter": _SJ_RESULT + "\nclass CoverFetcher:\n" + _SJ_INIT + "\n    def fetch_all(self, isbns):\n        return {}\n" + _SJ_RUN + "print(batch_ms, \"ms\")\nfor isbn, r in results.items():\n    print(isbn, r.url or r.error)\n",
            "solution": _SJ_FULL + _SJ_RUN + "print(batch_ms, \"ms\")\nfor isbn, r in results.items():\n    print(isbn, r.url or r.error)\n",
            "tests": '''_tasks = [fetcher.fetch_one(api, _i) for _i in isbns]
_res, _ms = gather(_tasks, limit=3, timeout=1000)
_exp = {}
for _i, _r in zip(isbns, _res):
    _exp[_i] = CoverResult(_i, None, "timeout") if isinstance(_r, TimeoutError) else _r
assert isinstance(results, dict) and list(results) == isbns, f"results should be a dict with one entry per ISBN, in order; got {results!r}"
for _i in isbns:
    assert results[_i] == _exp[_i], f"{_i} should be {_exp[_i]!r} on this evidence, got {results[_i]!r}"
assert batch_ms == _ms, f"with 3 at once and a 1000 ms deadline the batch takes {_ms} ms on this evidence, got {batch_ms!r}"
_q = CoverFetcher(base_url="b", client=FakeCoverAPI({f"Q{_n}": (100, 200) for _n in range(4)}), concurrency=2, timeout=1000)
_q.fetch_all([f"Q{_n}" for _n in range(4)])
assert _q.elapsed_ms == 200, f"concurrency=2 should let only 2 lookups run at once (four 100 ms lookups: 200 ms), got {_q.elapsed_ms}"
class _Dead:
    def lookup(self, isbn):
        raise ConnectionError("line dead")
_d = CoverFetcher(base_url="b", client=_Dead()).fetch_all(["Z9"])
assert _d == {"Z9": CoverResult("Z9", None, "ConnectionError")}, f"an error that isn't a timeout should become CoverResult(isbn, None, 'ConnectionError'), got {_d!r}"''',
            "tips": [
                "`results, self.elapsed_ms = gather(tasks, limit=self.concurrency, timeout=self.timeout)`, then loop `for isbn, r in zip(isbns, results):`.",
                "Inside the loop: `if isinstance(r, TimeoutError):` gives `CoverResult(isbn, None, \"timeout\")`, `elif isinstance(r, Exception):` gives `CoverResult(isbn, None, type(r).__name__)`, `else:` keep `r`.",
            ],
            "reveal": "With a cap of 3 and a deadline on every call, the batch now ends in under three seconds instead of waiting on the slowest call, and every cover that answered in time is in the results. The timeouts are the interesting part.",
        },
        {
            "notes": "Reading the failures:\n- A **timeout** means the mirror never answered in time: that is what a rigged, stalling mirror does.\n- **HTTP 404** (not found) and **503** (busy) are ordinary errors: the cover is missing or the server is overloaded. They don't count as stalling.\n- The rigged mirror is the one with the **most timeouts**; its keeper is the saboteur.",
            "question": "**Goal:** find the rigged mirror and its keeper.\n\n**You have:** `results` from step 2 (in the editor), `mirror_of`, a dict from ISBN to mirror name (e.g. `{\"978-S01\": \"east\"}`), and `keepers`, a dict from mirror name to engineer (e.g. `{\"north\": \"Engineer Petrov\"}`).\n\n**Write** three variables:\n- `timeouts_by_mirror`: a dict from **every** mirror in `keepers` to how many of its ISBNs ended with `error == \"timeout\"` (0 if none)\n- `rigged_mirror`: the mirror with the most timeouts\n- `saboteur`: the keeper of `rigged_mirror`\n\n**Example:** if north had 3 timeouts, east 0 (but four 404s) and west 1, then `rigged_mirror` is `\"north\"`.",
            "starter": _SJ_FULL + _SJ_RUN + "\ntimeouts_by_mirror = {}\nrigged_mirror = None\nsaboteur = None\nprint(timeouts_by_mirror, rigged_mirror, saboteur)\n",
            "solution": _SJ_FULL + _SJ_RUN + "\ntimeouts_by_mirror = {mirror: 0 for mirror in keepers}\nfor isbn, r in results.items():\n    if r.error == \"timeout\":\n        timeouts_by_mirror[mirror_of[isbn]] += 1\nrigged_mirror = max(timeouts_by_mirror, key=timeouts_by_mirror.get)\nsaboteur = keepers[rigged_mirror]\nprint(timeouts_by_mirror, rigged_mirror, saboteur)\n",
            "tests": '''_res, _ = gather([fetcher.fetch_one(api, _i) for _i in isbns], limit=3, timeout=1000)
_count = {_m: 0 for _m in keepers}
for _i, _r in zip(isbns, _res):
    if isinstance(_r, TimeoutError):
        _count[mirror_of[_i]] += 1
assert timeouts_by_mirror == _count, f"timeouts_by_mirror should be {_count} on this evidence, got {timeouts_by_mirror!r}"
_top = max(_count, key=_count.get)
assert rigged_mirror == _top, f"the rigged mirror is the one with the most timeouts, got {rigged_mirror!r}"
assert saboteur == keepers[_top], f"the saboteur is the keeper of the rigged mirror, got {saboteur!r}"''',
            "tips": [
                "Start every mirror at zero: `timeouts_by_mirror = {mirror: 0 for mirror in keepers}`, then add 1 to `timeouts_by_mirror[mirror_of[isbn]]` for each result whose `error == \"timeout\"`.",
                "`max(timeouts_by_mirror, key=timeouts_by_mirror.get)` gives the key with the biggest count. Then `saboteur = keepers[rigged_mirror]`.",
            ],
            "reveal": "Most of the stalls came from one mirror, and that mirror has exactly one keeper.",
        },
    ],
    "closing": "Case closed. A 404 or a 503 is an ordinary failure: a missing cover or a busy server. The rigged mirror never sent an error code at all; it just answered too slowly, which only a deadline can catch. A semaphore, a timeout and partial results turned a hung batch into evidence.",
}


# ---------------------------------------------------------------- retry-storm (Q18)

_FAKE_SERVER = r'''class HTTPError(Exception):
    def __init__(self, status):
        super().__init__(f"HTTP {status}")
        self.status = status

class FakeCoverServer:
    """Plays back a script per ISBN: 200 = the cover, "timeout" = no answer, any other number = that HTTP error."""
    def __init__(self, script):
        self.script = {isbn: list(replies) for isbn, replies in script.items()}
        self.calls = []

    def get(self, isbn):
        self.calls.append(isbn)
        reply = self.script[isbn].pop(0)
        if reply == 200:
            return f"https://covers.example/{isbn}.jpg"
        if reply == "timeout":
            raise TimeoutError(f"no answer for {isbn}")
        raise HTTPError(reply)
'''


def _retry_storm(script, log):
    lines = [_FAKE_SERVER, "\n", "script = {\n"]
    lines += [f"    {i!r}: {r!r},\n" for i, r in script.items()]
    lines.append("}\n")
    lines.append("access_log = {\n" + "".join(f"    {n!r}: {a!r},\n" for n, a in log.items()) + "}\n")
    return "".join(lines)


_RS_BASICS = '''def is_transient(error):
    if isinstance(error, TimeoutError):
        return True
    return isinstance(error, HTTPError) and error.status in {429, 500, 502, 503, 504}

def backoff(attempt, base=0.1, cap=2.0):
    return min(cap, base * 2 ** attempt)
'''

_RS_FETCH = '''
def fetch_with_retry(server, isbn, *, attempts=4, sleep, jitter=None):
    for attempt in range(attempts):
        try:
            return server.get(isbn)
        except Exception as error:
            if not is_transient(error) or attempt == attempts - 1:
                raise
            delay = backoff(attempt)
            if jitter is not None:
                delay = jitter(delay)
            sleep(delay)
'''

_RS_RETRY = _RS_BASICS + _RS_FETCH

_RS_BATCH = '''
server = FakeCoverServer(script)
waits = []
outcomes = {}
for isbn in script:
    try:
        outcomes[isbn] = fetch_with_retry(server, isbn, sleep=waits.append)
    except (HTTPError, TimeoutError):
        outcomes[isbn] = "gave up"
total_wait = round(sum(waits), 2)
calls_made = len(server.calls)
'''

# Test helper: what fetch_with_retry should do on a script, worked out independently.
_RS_SIMULATE = '''def _simulate(_replies, _attempts=4):
    _w = []
    for _n in range(_attempts):
        _rep = _replies[_n]
        if _rep == 200:
            return "ok", _w
        _tr = _rep == "timeout" or _rep in (429, 500, 502, 503, 504)
        if not _tr or _n == _attempts - 1:
            return "gave up", _w
        _w.append(min(2.0, 0.1 * 2 ** _n))
'''

RETRY_STORM = {
    "id": "retry-storm",
    "tier": "medium",
    "title": "The Retry Storm",
    "teaser": "The cover server went down under a flood of retries. Whose client caused it?",
    "skills": ["errors", "decoy-kit", "field-resilience"],
    "story": "At 2 am the lab's cover server fell over. Its logs show a **retry storm**: a client hammering it with tries it should never have made. The Bureau wants the lab's own client fixed first: retry only the errors worth retrying, back off exponentially, and keep the tests fast by never really sleeping. Then it wants the client who broke the lab's retry policy.\n\nForensics loaded a pretend server, `FakeCoverServer` (it plays back a `script` of replies per ISBN), `HTTPError` (an error that carries a `status`), and the server's `access_log` of each client's attempts.\n\n*(This is the official assignment Q18: retry with exponential backoff, without slow tests.)*",
    "suspects": [
        {"name": "Client Hale", "note": "The lab's scanner app."},
        {"name": "Client Ines", "note": "A night-shift script."},
        {"name": "Client Juno", "note": "Says its retry code came straight from the lesson."},
        {"name": "Client Kade", "note": "Written in a hurry last Friday."},
    ],
    "variants": [
        _retry_storm(
            {"978-R01": [503, 503, 200], "978-R02": [404], "978-R03": ["timeout", 500, 502, 504, 200],
             "978-R04": [200], "978-R05": [429, 200]},
            {"Client Hale": [(0, 503), (100, 503), (300, 200)], "Client Ines": [(0, 404)],
             "Client Juno": [(0, 500), (150, 502), (400, 503), (900, 504)],
             "Client Kade": [(0, 404), (100, 404), (300, 404)]},
        ),
        _retry_storm(
            {"978-R11": [500, 200], "978-R12": [503, "timeout", 503, 200], "978-R13": [401],
             "978-R14": [200], "978-R15": [502, 403]},
            {"Client Hale": [(0, 404)], "Client Ines": [(0, 429), (120, 200)],
             "Client Juno": [(0, 503), (100, 503), (200, 503), (300, 503)],
             "Client Kade": [(0, 500), (100, 502), (300, 504), (700, 200)]},
        ),
        _retry_storm(
            {"978-R21": [200], "978-R22": ["timeout", "timeout", 200], "978-R23": [504, 504, 504, 504, 504],
             "978-R24": [400], "978-R25": [429, 429, 200]},
            {"Client Hale": [(0, 503), (100, 503), (300, 503), (700, 503), (1500, 503), (3100, 200)],
             "Client Ines": [(0, 500), (200, 500), (500, 500), (1000, 500)],
             "Client Juno": [(0, 401)], "Client Kade": [(0, 504), (400, 200)]},
        ),
    ],
    "steps": [
        {
            "notes": "Which errors are worth retrying:\n- **Transient** errors may work on a second try: retry them. These are HTTP **429, 500, 502, 503, 504**, and a timeout (`TimeoutError`).\n- **Permanent** errors give the same answer every time: never retry them. These are HTTP **400, 401, 403, 404**, and any other error.\n\nHow long to wait (**exponential backoff**): before retry number `n` (the first retry is `n = 0`) wait `min(cap, base * 2 ** n)` seconds, with `base = 0.1` and `cap = 2.0`: 0.1, 0.2, 0.4, 0.8, 1.6, 2.0, 2.0 ...",
            "question": "**Goal:** the two building blocks of a polite retry: which errors to retry, and how long to wait.\n\n**You have:**\n- `HTTPError(status)`, an error class; `HTTPError(503).status` is `503`\n- `script`, a dict from ISBN to the replies the server will give for it, in order, e.g. `{\"978-R01\": [503, 503, 200]}`. In a reply list, `200` means the cover, `\"timeout\"` means no answer, and any other number is that HTTP error.\n\n**Write** a function `is_transient(error)`:\n- returns `True` for a transient error (field notes), `False` for anything else\n\n**Write** a function `backoff(attempt, base=0.1, cap=2.0)`:\n- returns the delay in seconds before retry number `attempt` (field notes)\n\n**Then** store `worth_retrying`: a list of the ISBNs in `script` (in order) whose **first** reply is a transient error. Turn a reply into an error first: `\"timeout\"` becomes `TimeoutError()`, any number except 200 becomes `HTTPError(number)`; `200` is not an error at all.\n\n**Example:** `is_transient(HTTPError(503))` is `True`, `is_transient(HTTPError(404))` is `False`; `[backoff(n) for n in range(4)]` is `[0.1, 0.2, 0.4, 0.8]`. For `{\"A\": [503, 200], \"B\": [404], \"C\": [200]}`, `worth_retrying` is `[\"A\"]`.",
            "starter": "def is_transient(error):\n    return True\n\ndef backoff(attempt, base=0.1, cap=2.0):\n    return base\n\nworth_retrying = []\nprint(worth_retrying)\n",
            "solution": _RS_BASICS + "\nworth_retrying = []\nfor isbn, replies in script.items():\n    first = replies[0]\n    if first == 200:\n        continue\n    error = TimeoutError() if first == \"timeout\" else HTTPError(first)\n    if is_transient(error):\n        worth_retrying.append(isbn)\nprint(worth_retrying)\n",
            "tests": '''for _s in (429, 500, 502, 503, 504):
    assert is_transient(HTTPError(_s)) is True, f"HTTP {_s} is transient: retry it"
for _s in (400, 401, 403, 404):
    assert is_transient(HTTPError(_s)) is False, f"HTTP {_s} is permanent: never retry it"
assert is_transient(TimeoutError()) is True, "a timeout is transient"
assert is_transient(ValueError("bad")) is False, "an error that isn't HTTP or a timeout is not transient"
assert [round(backoff(_n), 6) for _n in range(7)] == [0.1, 0.2, 0.4, 0.8, 1.6, 2.0, 2.0], "backoff should double from 0.1 and stop at the cap of 2.0"
assert round(backoff(2, base=1, cap=30), 6) == 4 and backoff(10, base=1, cap=30) == 30, "backoff should use its base and cap parameters"
_exp = [_i for _i, _r in script.items() if _r[0] == "timeout" or _r[0] in (429, 500, 502, 503, 504)]
assert worth_retrying == _exp, f"worth_retrying should be {_exp} on this evidence, got {worth_retrying!r}"''',
            "tips": [
                "`is_transient`: check `isinstance(error, TimeoutError)` first, then return `isinstance(error, HTTPError) and error.status in {429, 500, 502, 503, 504}`. `backoff` is one line: `return min(cap, base * 2 ** attempt)`.",
                "Loop `for isbn, replies in script.items():`, skip when `replies[0] == 200`, make `error = TimeoutError() if replies[0] == \"timeout\" else HTTPError(replies[0])`, and append the ISBN if `is_transient(error)`.",
            ],
            "reveal": "Some of tonight's covers fail first time but are worth another try; others never will be. The client has to tell them apart.",
        },
        {
            "notes": "The lab's retry rules:\n- Make at most `attempts` tries in all. Retry only transient errors, waiting `backoff(n)` seconds before retry `n`.\n- Stop at once on a permanent error, and stop after the last try; in both cases **re-raise** the error so the caller sees what went wrong. No sleep after the last try.\n- **Jitter** (optional): if a `jitter` function is given, wait `jitter(delay)` instead of `delay`.\n\nPython reminder: inside an `except` block, a bare `raise` (with nothing after it) re-raises the error being handled.",
            "question": "**Goal:** a cover fetch that retries the right errors, backs off, and can be tested without ever waiting; then run tonight's batch through it.\n\n**You have:** `is_transient` and `backoff` from step 1 (in the editor), `HTTPError`, `script`, and `FakeCoverServer(script)`: `server.get(isbn)` returns the URL `https://covers.example/<isbn>.jpg`, or raises `HTTPError` or `TimeoutError`, following that ISBN's replies; `server.calls` lists every call it got.\n\n**Write** a function `fetch_with_retry(server, isbn, *, attempts=4, sleep, jitter=None)`:\n- calls `server.get(isbn)` and returns its URL as soon as one try works\n- follows the retry rules in the field notes\n- waits by calling `sleep(delay)` (the injected sleep; never `time.sleep`)\n\n**Then** run the batch: make one `server = FakeCoverServer(script)` and one list `waits`, and fetch every ISBN in `script`, in order, with `sleep=waits.append`. Store:\n- `outcomes`: a dict from each ISBN to its URL, or `\"gave up\"` if `fetch_with_retry` raised `HTTPError` or `TimeoutError`\n- `total_wait`: the sum of `waits` in seconds, rounded to 2 decimal places\n- `calls_made`: `len(server.calls)`\n\n**Example:** replies `[503, \"timeout\", 200]` return the URL after sleeping `[0.1, 0.2]`; replies `[404]` raise at once with no sleep. So a script `{\"A\": [503, 200], \"B\": [404]}` gives `{\"A\": \"https://covers.example/A.jpg\", \"B\": \"gave up\"}`, `total_wait` `0.1` and `calls_made` `3`.",
            "starter": _RS_BASICS + "\ndef fetch_with_retry(server, isbn, *, attempts=4, sleep, jitter=None):\n    return server.get(isbn)\n\nserver = FakeCoverServer(script)\nwaits = []\noutcomes = {}\ntotal_wait = 0\ncalls_made = 0\nprint(outcomes, total_wait, calls_made)\n",
            "solution": _RS_RETRY + _RS_BATCH + "print(outcomes, total_wait, calls_made)\n",
            "tests": _RS_SIMULATE + '''_w = []
_srv = FakeCoverServer({"T": [503, "timeout", 200]})
assert fetch_with_retry(_srv, "T", sleep=_w.append) == "https://covers.example/T.jpg", "after 2 transient failures the third try should succeed"
assert [round(_x, 6) for _x in _w] == [0.1, 0.2], f"the fake sleep should get the backoff delays [0.1, 0.2], got {_w}"
_w = []
_srv = FakeCoverServer({"T": [503, 503, 503, 503, 200]})
try:
    fetch_with_retry(_srv, "T", attempts=3, sleep=_w.append)
    raise AssertionError("with attempts=3 and three 503s, fetch_with_retry should re-raise the HTTPError")
except HTTPError:
    pass
assert len(_srv.calls) == 3 and len(_w) == 2, f"attempts=3 means 3 calls and 2 sleeps (none after the last try); got {len(_srv.calls)} calls, sleeps {_w}"
_w = []
_srv = FakeCoverServer({"T": [404, 200]})
try:
    fetch_with_retry(_srv, "T", sleep=_w.append)
    raise AssertionError("a 404 should be re-raised at once")
except HTTPError:
    pass
assert len(_srv.calls) == 1 and _w == [], "404 is permanent: one call, no sleep"
_w = []
fetch_with_retry(FakeCoverServer({"T": [500, 500, 200]}), "T", sleep=_w.append, jitter=lambda _d: _d / 2)
assert [round(_x, 6) for _x in _w] == [0.05, 0.1], f"with jitter, sleep should get jitter(delay); got {_w}"
_out, _wall, _calls = {}, [], 0
for _i, _reps in script.items():
    _res, _ws = _simulate(_reps)
    _out[_i] = "gave up" if _res == "gave up" else f"https://covers.example/{_i}.jpg"
    _wall += _ws
    _calls += len(_ws) + 1
assert outcomes == _out, f"outcomes should be {_out} on this evidence, got {outcomes!r}"
assert total_wait == round(sum(_wall), 2), f"total_wait should be {round(sum(_wall), 2)} seconds, got {total_wait!r}"
assert calls_made == _calls, f"the server should get {_calls} calls on this evidence, got {calls_made!r}"''',
            "tips": [
                "Loop `for attempt in range(attempts):` with `try: return server.get(isbn)`. In `except Exception as error:` use a bare `raise` if `not is_transient(error) or attempt == attempts - 1`; otherwise `delay = backoff(attempt)`, pass it through `jitter` if one was given, and `sleep(delay)`.",
                "For the batch: `for isbn in script:` with `try: outcomes[isbn] = fetch_with_retry(server, isbn, sleep=waits.append)` and `except (HTTPError, TimeoutError): outcomes[isbn] = \"gave up\"`. Then `total_wait = round(sum(waits), 2)` and `calls_made = len(server.calls)`.",
            ],
            "reveal": "The lab's client gives up at once on a permanent error and backs off politely on a busy server, and the whole batch ran without a single real second of sleep. Whoever caused the storm was doing something very different.",
        },
        {
            "notes": "How the server audits a client. Each attempt in the log is `(time_ms, status)`. The lab's internal clients use plain backoff (no jitter), so in milliseconds the wait before retry `n` must be at least `min(2000, 100 * 2 ** n)`: 100, 200, 400, 800, 1600, 2000 ... A client **breaks the policy** if any of these is true:\n- it made an attempt right after a **permanent** status (400, 401, 403, 404)\n- it made **more than 4** attempts\n- the gap between attempt `n` and attempt `n + 1` (counting from 0) is **shorter** than the backoff for `n`\n\nA client that makes many attempts but follows every rule is innocent.",
            "question": "**Goal:** find the client that caused the retry storm.\n\n**You have:** `access_log`, a dict from client name to its list of attempts, each a tuple `(time_ms, status)`, e.g. `{\"Client Hale\": [(0, 503), (100, 503), (300, 200)]}`.\n\n**Write** a function `follows_policy(attempts)`:\n- `attempts` is one client's list of `(time_ms, status)` tuples\n- it returns `False` if any rule in the field notes is broken, otherwise `True`\n\n**Then** store `storm_client`: the name of the one client in `access_log` whose attempts break the policy.\n\n**Example:** `[(0, 503), (100, 503), (300, 200)]` follows the policy (gaps 100 and 200). `[(0, 503), (100, 503), (200, 503)]` breaks it (the second gap is 100, but needs 200). `[(0, 404), (500, 404)]` breaks it (it retried a 404).",
            "starter": "def follows_policy(attempts):\n    return True\n\nstorm_client = None\nprint(storm_client)\n",
            "solution": "def follows_policy(attempts):\n    if len(attempts) > 4:\n        return False\n    for n in range(len(attempts) - 1):\n        time_ms, status = attempts[n]\n        if status in {400, 401, 403, 404}:\n            return False\n        gap = attempts[n + 1][0] - time_ms\n        if gap < min(2000, 100 * 2 ** n):\n            return False\n    return True\n\nstorm_client = None\nfor name, attempts in access_log.items():\n    if not follows_policy(attempts):\n        storm_client = name\nprint(storm_client)\n",
            "tests": '''def _ok(_a):
    if len(_a) > 4:
        return False
    for _n in range(len(_a) - 1):
        if _a[_n][1] in (400, 401, 403, 404) or _a[_n + 1][0] - _a[_n][0] < min(2000, 100 * 2 ** _n):
            return False
    return True
assert follows_policy([(0, 503), (100, 503), (300, 200)]) is True, "gaps of 100 and 200 ms follow the backoff"
assert follows_policy([(0, 503), (100, 503), (200, 503)]) is False, "a second gap of 100 ms is too short (needs 200)"
assert follows_policy([(0, 404), (500, 404)]) is False, "retrying after a 404 breaks the policy"
assert follows_policy([(0, 500), (100, 500), (300, 500), (700, 500), (1500, 200)]) is False, "5 attempts is more than 4"
assert follows_policy([(0, 401)]) is True, "a single attempt that fails permanently is fine: no retry"
for _name, _a in access_log.items():
    assert follows_policy(_a) is _ok(_a), f"follows_policy is wrong for {_name}'s attempts {_a}"
_bad = [_n for _n, _a in access_log.items() if not _ok(_a)]
assert storm_client == _bad[0], f"storm_client should be the client that breaks the policy; got {storm_client!r}"''',
            "tips": [
                "Check the count first: `if len(attempts) > 4: return False`. Then loop `for n in range(len(attempts) - 1):` so you can look at `attempts[n]` and `attempts[n + 1]`.",
                "Inside the loop: return `False` if `attempts[n][1]` is in `{400, 401, 403, 404}`, or if `attempts[n + 1][0] - attempts[n][0] < min(2000, 100 * 2 ** n)`. After the loop, `return True`.",
            ],
            "reveal": "One client's log breaks the lab's policy outright. The others failed too, but they failed by the rules.",
        },
    ],
    "closing": "Case closed. Retrying is not a crime on its own: retrying a permanent error, retrying too fast or never giving up is. An injected fake sleep let the lab prove its own client follows the rules without waiting a single second, and the server's log did the rest.",
}


# ---------------------------------------------------------------- false-informant (Q19)

_PROVIDER_BASE = r'''import json
from abc import ABC, abstractmethod

class ProviderError(Exception):
    """The provider failed or gave an answer we can't use."""

class LLMProvider(ABC):
    @abstractmethod
    def complete_json(self, prompt: str) -> dict:
        """Send the prompt; return the model's answer as a dict."""

CATEGORIES = {"programming", "fiction", "science", "history"}
'''


def _r(category, confidence):
    return f'{{"category": "{category}", "confidence": {confidence}}}'


def _informant(books, replies):
    lines = [_PROVIDER_BASE, "\n"]
    lines.append("books = [\n" + "".join(f"    {t!r},\n" for t, _ in books) + "]\n")
    lines.append("answer_key = {\n" + "".join(f"    {t!r}: {c!r},\n" for t, c in books) + "}\n")
    lines.append("informants = {\n")
    for name, reps in replies.items():
        lines.append(f"    {name!r}: [\n" + "".join(f"        {x!r},\n" for x in reps) + "    ],\n")
    lines.append("}\n")
    return "".join(lines)


_FI_SCRIPTED = '''class ScriptedProvider(LLMProvider):
    def __init__(self, replies):
        self.replies = list(replies)
        self.prompts = []

    def complete_json(self, prompt):
        self.prompts.append(prompt)
        reply = self.replies.pop(0)
        if reply == "TIMEOUT":
            raise TimeoutError("no reply in time")
        try:
            return json.loads(reply)
        except json.JSONDecodeError as e:
            raise ProviderError("reply is not valid JSON") from e
'''

_FI_CLASSIFIER = '''
class BookClassifier:
    def __init__(self, provider: LLMProvider):
        self.provider = provider

    def classify(self, title):
        try:
            data = self.provider.complete_json(f"Classify this book: {title}. Reply as JSON.")
        except TimeoutError as e:
            raise ProviderError("timeout") from e
        if not isinstance(data, dict) or data.get("category") not in CATEGORIES:
            raise ProviderError(f"unusable reply: {data}")
        confidence = data.get("confidence")
        if isinstance(confidence, bool) or not isinstance(confidence, (int, float)) or not 0 <= confidence <= 1:
            raise ProviderError(f"bad confidence: {confidence}")
        return {"category": data["category"], "confidence": float(confidence)}
'''

_FI_PROVIDER = _FI_SCRIPTED + _FI_CLASSIFIER

_FI_REPORT = '''
report = {}
for name, replies in informants.items():
    classifier = BookClassifier(ScriptedProvider(replies))
    counts = {"correct": 0, "wrong": 0, "failed": 0}
    for title in books:
        try:
            verdict = classifier.classify(title)
        except ProviderError:
            counts["failed"] += 1
            continue
        if verdict["category"] == answer_key[title]:
            counts["correct"] += 1
        else:
            counts["wrong"] += 1
    report[name] = counts
'''

# Test helper: an independent check of one raw reply ("ok:<category>" or "failed").
_FI_JUDGE = '''def _judge(_text):
    if _text == "TIMEOUT":
        return "failed"
    try:
        _d = json.loads(_text)
    except Exception:
        return "failed"
    if not isinstance(_d, dict) or _d.get("category") not in CATEGORIES:
        return "failed"
    _c = _d.get("confidence")
    if type(_c) not in (int, float) or not 0 <= _c <= 1:
        return "failed"
    return "ok:" + _d["category"]
'''

FALSE_INFORMANT = {
    "id": "false-informant",
    "tier": "medium",
    "title": "The False Informant",
    "teaser": "Three AI informants classify the lab's books. One of them lies with confidence.",
    "skills": ["inheritance", "errors", "field-resilience"],
    "story": "The lab is getting ready for AI: a `BookClassifier` will ask a language model which shelf each seized book belongs on. Three **informants** (model providers) were trialled overnight, and their raw replies were recorded. One of them was tampered with: it answers in perfect JSON, with high confidence, and gets the shelf wrong.\n\nNo real model may be called in the lab, so forensics loaded the recorded replies (`informants`, a dict from informant name to its list of reply texts, one per book), the `books` they were asked about, the archive's `answer_key`, and the lab's interface: `LLMProvider` (an ABC), `ProviderError` and `CATEGORIES`.\n\n*(This is the official assignment Q19: an LLM provider interface, a fake provider, dependency injection, timeouts and validation of malformed replies.)*",
    "suspects": [
        {"name": "Informant Atlas", "note": "A big cloud model. Expensive and sure of itself."},
        {"name": "Informant Briar", "note": "A small local model running on the lab's own laptop."},
        {"name": "Informant Corvo", "note": "A new provider nobody had heard of last month."},
    ],
    "variants": [
        _informant(
            [("Fluent Python", "programming"), ("Dune", "fiction"), ("Cosmos", "science"),
             ("SPQR", "history"), ("Clean Code", "programming"), ("The Hobbit", "fiction")],
            {
                "Informant Atlas": [_r("programming", 0.93), _r("fiction", 0.88), _r("science", 0.9),
                                    "TIMEOUT", _r("programming", 0.97), _r("fiction", 0.81)],
                "Informant Briar": ['Sure! Here is the JSON: {"category": "programming"}', _r("fiction", 7),
                                    "TIMEOUT", _r("history", 0.7), '["programming"]', _r("cookery", 0.9)],
                "Informant Corvo": [_r("fiction", 0.91), _r("fiction", 0.9), _r("history", 0.95),
                                    _r("science", 0.89), _r("programming", 0.92), _r("programming", 0.94)],
            },
        ),
        _informant(
            [("The Selfish Gene", "science"), ("Emma", "fiction"), ("Automate the Boring Stuff", "programming"),
             ("The Guns of August", "history"), ("Neuromancer", "fiction")],
            {
                "Informant Atlas": [_r("history", 0.96), _r("fiction", 0.93), _r("science", 0.91),
                                    _r("fiction", 0.95), _r("programming", 0.9)],
                "Informant Briar": [_r("science", 0.74), "TIMEOUT", _r("programming", "high"),
                                    "TIMEOUT", _r("fiction", 0.66)],
                "Informant Corvo": [_r("science", 0.85), _r("fiction", 0.79), "I think it's programming.",
                                    _r("history", 0.88), _r("fiction", 1.4)],
            },
        ),
        _informant(
            [("Python Crash Course", "programming"), ("Middlemarch", "fiction"), ("The Gene", "science"),
             ("Team of Rivals", "history"), ("Refactoring", "programming"), ("Brief Answers", "science"),
             ("Wolf Hall", "fiction")],
            {
                "Informant Atlas": [_r("programming", 0.9), "TIMEOUT", _r("science", 0.83), _r("history", 0.9),
                                    '{"category": "programming", "confidence": true}', _r("science", 0.87), _r("fiction", 0.8)],
                "Informant Briar": [_r("history", 0.97), _r("fiction", 0.92), _r("programming", 0.95),
                                    _r("fiction", 0.9), _r("programming", 0.93), _r("history", 0.96), _r("history", 0.91)],
                "Informant Corvo": ["TIMEOUT", _r("fiction", 0.7), "TIMEOUT", '{"category": "history"}',
                                    _r("programming", 0.88), "{bad json", _r("poetry", 0.5)],
            },
        ),
    ],
    "steps": [
        {
            "notes": "What a recorded reply can be:\n- A model replies with **text** that should be JSON, e.g. `'{\"category\": \"fiction\", \"confidence\": 0.9}'`.\n- The text `\"TIMEOUT\"` in a recording means the model gave no reply in time.\n- Some replies are not JSON at all (a model may chat: `\"Sure! Here is...\"`).\n\nThe lab's rule: the provider turns text into Python data, and invalid JSON is caught **inside the provider itself** and turned into the lab's domain error, `ProviderError`. (Unlike the lesson's demo, where the classifier caught `JSONDecodeError`.)",
            "question": "**Goal:** a fake provider that plays back an informant's recorded replies, so no real model is ever called.\n\n**You have:** `LLMProvider` (an ABC with one abstract method, `complete_json(self, prompt)`), `ProviderError`, `json` (imported), `books` (a list of titles) and `informants` (a dict from informant name to its list of reply texts).\n\n**Write** a class `ScriptedProvider(LLMProvider)`:\n- `__init__(self, replies)` stores a copy of the list of reply texts in `self.replies` (`list(replies)`), and an empty list `self.prompts`\n- `complete_json(self, prompt)` appends `prompt` to `self.prompts`, then takes the next reply with `self.replies.pop(0)`, and:\n  - raises `TimeoutError` if the reply is `\"TIMEOUT\"`\n  - otherwise returns `json.loads(reply)`, but raises `ProviderError` instead if `json.loads` raises `json.JSONDecodeError`\n\n**Then** play back the first informant, `list(informants)[0]`: make **one** `ScriptedProvider` with its replies, call `complete_json` once per title in `books` (in order, with any prompt that contains the title), and store `parsed`, a list with one entry per call: the value returned, or `\"timeout\"` if it raised `TimeoutError`, or `\"bad json\"` if it raised `ProviderError`.\n\n**Example:** with replies `['{\"a\": 1}', \"TIMEOUT\", \"oops\"]`, three calls give `[{\"a\": 1}, \"timeout\", \"bad json\"]`.",
            "starter": "class ScriptedProvider(LLMProvider):\n    def __init__(self, replies):\n        self.replies = list(replies)\n        self.prompts = []\n\n    def complete_json(self, prompt):\n        return {}\n\nparsed = []\nprint(parsed)\n",
            "solution": _FI_SCRIPTED + "\nprovider = ScriptedProvider(informants[list(informants)[0]])\nparsed = []\nfor title in books:\n    try:\n        parsed.append(provider.complete_json(f\"Classify this book: {title}. Reply as JSON.\"))\n    except TimeoutError:\n        parsed.append(\"timeout\")\n    except ProviderError:\n        parsed.append(\"bad json\")\nprint(parsed)\n",
            "tests": '''assert isinstance(ScriptedProvider([]), LLMProvider), "ScriptedProvider must be a subclass of LLMProvider"
_p = ScriptedProvider(['{"category": "fiction", "confidence": 1}', "TIMEOUT", "Sure! {", '["x"]'])
assert _p.complete_json("Dune?") == {"category": "fiction", "confidence": 1}, "a JSON reply should come back as Python data (json.loads)"
assert _p.prompts == ["Dune?"], "complete_json should record each prompt in self.prompts"
try:
    _p.complete_json("p2")
    raise AssertionError("a \\"TIMEOUT\\" reply should raise TimeoutError")
except TimeoutError:
    pass
try:
    _p.complete_json("p3")
    raise AssertionError("a reply that isn't valid JSON should raise ProviderError")
except ProviderError:
    pass
assert _p.complete_json("p4") == ["x"], "each call should use the next recorded reply, in order"
_src = ['{"a": 1}']
ScriptedProvider(_src).complete_json("p")
assert _src == ['{"a": 1}'], "ScriptedProvider should store a copy of the replies (list(replies)), not empty the caller's list"
_exp = []
for _text in informants[list(informants)[0]][:len(books)]:
    if _text == "TIMEOUT":
        _exp.append("timeout")
    else:
        try:
            _exp.append(json.loads(_text))
        except Exception:
            _exp.append("bad json")
assert parsed == _exp, f"parsed should be {_exp!r} on this evidence, got {parsed!r}"''',
            "tips": [
                "In `complete_json`: `self.prompts.append(prompt)`, `reply = self.replies.pop(0)`, then `if reply == \"TIMEOUT\": raise TimeoutError(\"no reply\")`.",
                "Wrap the parse: `try: return json.loads(reply)` and `except json.JSONDecodeError as e: raise ProviderError(\"reply is not valid JSON\") from e`. For `parsed`, call it inside `try` with two `except` blocks.",
            ],
            "reveal": "The recordings play back like a real model, timeouts and garbled text included, without a single network call.",
        },
        {
            "notes": "When is a reply usable? It must be a JSON **object** (a dict) with:\n- a `category` that is in `CATEGORIES`\n- a `confidence` that is a number (int or float) from 0 to 1\n\nAnything else is unusable: not an object, an unknown or missing category, a missing confidence, or a confidence out of range or not a number.\n\nPython reminder: `True` and `False` count as ints (`isinstance(True, int)` is `True`), so check `isinstance(c, bool)` first and reject it.",
            "question": "**Goal:** a classifier that takes its provider from outside and only accepts usable answers.\n\n**You have:** `ScriptedProvider` from step 1 (in the editor), `LLMProvider`, `ProviderError`, `CATEGORIES`, `books` and `informants`.\n\n**Write** a class `BookClassifier`:\n- `__init__(self, provider)` stores the provider it is **given** in `self.provider` (dependency injection: never create a provider inside)\n- `classify(self, title)` calls `self.provider.complete_json(prompt)` with a prompt that contains the title, e.g. `f\"Classify this book: {title}. Reply as JSON.\"`\n- if that call raises `TimeoutError`, `classify` raises `ProviderError` instead (any `ProviderError` from the provider just passes through)\n- if the reply isn't usable (field notes), it raises `ProviderError`\n- otherwise it returns a new dict `{\"category\": ..., \"confidence\": ...}` with the confidence as a float\n\n**Then** store `sample`: the first informant's verdict on the first book, `BookClassifier(ScriptedProvider(informants[list(informants)[0]])).classify(books[0])`, or the text `\"failed\"` if that raises `ProviderError`.\n\n**Example:** with replies `['{\"category\": \"fiction\", \"confidence\": 1}']`, `classify(\"Dune\")` returns `{\"category\": \"fiction\", \"confidence\": 1.0}`; with `['{\"category\": \"fiction\", \"confidence\": 7}']` it raises `ProviderError`.",
            "starter": _FI_SCRIPTED + "\nclass BookClassifier:\n    def __init__(self, provider):\n        self.provider = provider\n\n    def classify(self, title):\n        return self.provider.complete_json(title)\n\nsample = None\nprint(sample)\n",
            "solution": _FI_PROVIDER + "\ntry:\n    sample = BookClassifier(ScriptedProvider(informants[list(informants)[0]])).classify(books[0])\nexcept ProviderError:\n    sample = \"failed\"\nprint(sample)\n",
            "tests": _FI_JUDGE + '''_p = ScriptedProvider(['{"category": "fiction", "confidence": 1}', '{"category": "science", "confidence": 0.5}'])
_c = BookClassifier(_p)
assert _c.provider is _p, "BookClassifier should store the provider it is given in self.provider"
_v = _c.classify("Dune")
assert _v == {"category": "fiction", "confidence": 1.0} and type(_v["confidence"]) is float, f"a good reply should give a dict with a float confidence, got {_v!r}"
assert "Dune" in _p.prompts[0], "the prompt sent to the provider should contain the book's title"
assert _c.classify("Cosmos")["category"] == "science" and len(_p.prompts) == 2, "each call should use the next recorded reply"
class _Echo(LLMProvider):
    def complete_json(self, prompt):
        return {"category": "history", "confidence": 0.5}
assert BookClassifier(_Echo()).classify("SPQR") == {"category": "history", "confidence": 0.5}, "BookClassifier should work with any LLMProvider it is given"
_bad = ["TIMEOUT", "Sure! {", '["fiction"]', '{"category": "cookery", "confidence": 0.9}', '{"confidence": 0.9}',
        '{"category": "fiction"}', '{"category": "fiction", "confidence": 7}', '{"category": "fiction", "confidence": -0.1}',
        '{"category": "fiction", "confidence": true}', '{"category": "fiction", "confidence": "high"}']
for _text in _bad:
    try:
        BookClassifier(ScriptedProvider([_text])).classify("X")
        raise AssertionError(f"the reply {_text!r} is unusable: classify should raise ProviderError")
    except ProviderError:
        pass
_first = informants[list(informants)[0]][0]
_j = _judge(_first)
if _j == "failed":
    _exp = "failed"
else:
    _exp = {"category": _j[3:], "confidence": float(json.loads(_first)["confidence"])}
assert sample == _exp, f"sample should be {_exp!r} on this evidence, got {sample!r}"''',
            "tips": [
                "Wrap the call: `try: data = self.provider.complete_json(...)` with `except TimeoutError as e: raise ProviderError(\"timeout\") from e`. Then `if not isinstance(data, dict) or data.get(\"category\") not in CATEGORIES: raise ProviderError(...)`.",
                "For the confidence `c = data.get(\"confidence\")`: raise `ProviderError` if `isinstance(c, bool) or not isinstance(c, (int, float)) or not 0 <= c <= 1`. Otherwise return `{\"category\": data[\"category\"], \"confidence\": float(c)}`.",
            ],
            "reveal": "The classifier now refuses every malformed reply. Whatever is left is an answer the informant stands behind.",
        },
        {
            "notes": "Scoring an informant on one book:\n- **failed**: `classify` raised `ProviderError` (no usable answer: slow or garbled, but not a lie)\n- **correct**: a usable answer whose category matches `answer_key[title]`\n- **wrong**: a usable answer with a different category: a confident false statement\n\nThe false informant is the one with the **most wrong** answers. Many failures make an informant unreliable, not a liar.",
            "question": "**Goal:** interrogate each informant and expose the one that lies.\n\n**You have:** `ScriptedProvider` and `BookClassifier` from steps 1 and 2 (in the editor), `informants`, `books` (in the order the replies were recorded) and `answer_key`, a dict from title to its true category.\n\n**Write** a loop over `informants` that, for each informant, injects a fresh `ScriptedProvider(replies)` into **one** `BookClassifier` and classifies every title in `books`, in order.\n\n**Then** store:\n- `report`: a dict from informant name to a dict of counts `{\"correct\": n, \"wrong\": n, \"failed\": n}` (field notes)\n- `false_informant`: the name with the most `\"wrong\"` answers\n\n**Example:** an informant whose replies are one timeout, one right shelf and one wrong shelf scores `{\"correct\": 1, \"wrong\": 1, \"failed\": 1}`.",
            "starter": _FI_PROVIDER + "\nreport = {}\nfalse_informant = None\nprint(report, false_informant)\n",
            "solution": _FI_PROVIDER + _FI_REPORT + "false_informant = max(report, key=lambda name: report[name][\"wrong\"])\nprint(report, false_informant)\n",
            "tests": _FI_JUDGE + '''_exp = {}
for _name, _reps in informants.items():
    _cnt = {"correct": 0, "wrong": 0, "failed": 0}
    for _t, _text in zip(books, _reps):
        _j = _judge(_text)
        if _j == "failed":
            _cnt["failed"] += 1
        elif _j[3:] == answer_key[_t]:
            _cnt["correct"] += 1
        else:
            _cnt["wrong"] += 1
    _exp[_name] = _cnt
for _name in _exp:
    _want = _exp[_name]
    _got = report.get(_name)
    assert _got == _want, f"{_name} should score {_want} on this evidence, got {_got!r}"
_liar = max(_exp, key=lambda _n: _exp[_n]["wrong"])
assert false_informant == _liar, f"the false informant is the one with the most wrong answers; got {false_informant!r}"''',
            "tips": [
                "For each `name, replies in informants.items()`, make `classifier = BookClassifier(ScriptedProvider(replies))` once, then loop over `books` with `try: verdict = classifier.classify(title)` and `except ProviderError:` adding to `failed`.",
                "Compare `verdict[\"category\"] == answer_key[title]` to count `correct` or `wrong`. Then `false_informant = max(report, key=lambda name: report[name][\"wrong\"])`.",
            ],
            "reveal": "One informant never timed out and never garbled a reply, and still put book after book on the wrong shelf.",
        },
    ],
    "closing": "Case closed. The informant with the most failures was only unreliable; the liar never failed once. Because the classifier took its provider by injection, the lab questioned all three recordings with the same code, without calling a real model.\n\nThe assignment's research note asks what changes for a real provider. Answer it the same way: an `OpenAIProvider`, `AnthropicProvider` or `OllamaProvider` is just another `LLMProvider` subclass. Each needs its own client library, API key (none for a local Ollama model), model name, request format and JSON mode, plus its own rate limits and errors to map onto `ProviderError`. The classifier and its tests don't change.",
}


CASES = [
    COVER_RAID,
    MERGED_MANIFESTS,
    SWITCHBOARD_JAM,
    RETRY_STORM,
    FALSE_INFORMANT,
]

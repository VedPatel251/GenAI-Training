---
name: new-division
description: End-to-end pipeline that turns one training day's material (deck, assignments, code examples) into a new Detective X division — research, Academy lessons, cases, browser verification and shipping. Use when the user wants to build/start/create the next day (e.g. "do Day 2", "/new-division day3").
argument-hint: dayN
---

# New Detective X division: $ARGUMENTS

Build the day as a Detective X division. Run the stages in order; each ends at a **gate** where the user
reviews before the next stage starts. Keep the task list current: one step per stage.

Read `CLAUDE.md` first (layout, content rules, guardrails). Then check where the day already is, so a
re-run resumes instead of starting over:
- `docs/<day>/OUTLINE.md` exists and approved (says `Status: approved`) → skip stage 1.
- `days/<day>/lessons.py` has lessons → stage 2 partly done; `python engine/build_game.py --day <day> --no-write` shows what passes.
- `days/<day>/cases_*.py` have cases → stage 3 partly done.
- `<day>` in `DIVISIONS` in `engine/build_game.py` → already shipped; only changes remain.

## Stage 0 · Scaffold (no gate)
```
python engine/new_day.py <day> "<Division name>" "<one-line tagline>"
```
Pick a division name that fits the bureau story (Day 2 is planned as "Forensics Lab", see
`docs/DETECTIVE_X_PLAN.md` section on later days). Safe to re-run: it never overwrites.

## Stage 1 · Research → `/research-day <day>`
Produces `docs/<day>/OUTLINE.md`: coverage map of every slide topic and assignment question, skills
and chapters, assignment→case mapping, the division's story, and the gaps the deck doesn't teach.
**Gate:** show the user the outline summary (skills, chapters, case list, gaps, browser vs local) and
wait for approval or changes. Mark the outline `Status: approved` once they agree.

## Stage 2 · Academy lessons → `/write-lessons <day>`
One part at a time. For each part, a `lesson-writer` agent drafts; the hook checks it on every save;
then a `beginner-reviewer` agent reviews and you fix what it finds.
**Gate:** after all parts pass `python engine/build.py <day>`, summarise lessons per part and the
reviewer's main points, and offer a play-test preview: `python engine/build_game.py --day <day>`
writes the game *including* the unshipped day, then `python serve_lan.py 8095` and open
http://localhost:8095. (Don't publish or commit a preview build; stage 4 rebuilds properly.)

## Stage 3 · Cases → `/write-cases <day>`
Order: small → medium (assignment reskins) → big (one per chapter) → exam (+ capstone if the day has
a deliverable). `case-writer` agents draft by file; `case-auditor` reviews for guessability, difficulty
curve and story consistency.
**Gate:** show the case board (tier counts, XP total, unlock chain) and ask for go-ahead to ship.

## Stage 4 · Ship candidate
Add `<day>` to `DIVISIONS` in `engine/build_game.py`, then `python engine/build_game.py` (must pass for
ALL days), then `/verify-brython`. Fix everything it reports, rebuild, re-run.

## Stage 5 · Ship → `/ship-division <day>`
Publish the artifact, update README/docs, commit, tell the user what to upload and restart.

## One step at a time (the user's rule)
**Never run anything in parallel unless the user explicitly asks for it in that task.** No several agents
at once, no extra sessions, no workflows. Parallel Opus agents burned the user's usage limit in minutes.
Work one file at a time: write a part's lessons (yourself or with one `lesson-writer` agent), wait for it,
check it, then the next part; same for case files with `case-writer`, and for reviews. Give each agent the
day, the exact lessons/cases from OUTLINE.md, the file to write, and which skills come before. For small
fixes, edit directly instead of starting an agent. When a conversation gets very long, suggest a fresh
session (the outline and `docs/<day>/` notes carry the context).

---
name: research-day
description: Read one training day's source material (deck, assignment sheet, code examples in ../extracted/<day>) and write docs/<day>/OUTLINE.md — the coverage map, skills, chapters, assignment-to-case mapping and story for its Detective X division. Use as stage 1 of /new-division, or when the user asks what a day covers.
argument-hint: dayN
---

# Research $ARGUMENTS

Goal: an outline the user can approve, in which **nothing from the day's material is missing**.

## 1. Extract
```
python engine/extract_sources.py <day>
```
Writes `docs/<day>/sources/slides.md`, `assignments.md`, `code.md` (git-ignored). It skips `.env` and
key files; never open those yourself. If the day's folder is missing, ask the user to unzip `<Day>.zip`
into `../extracted/`. Zips inside the folder are read in memory; do not extract or run their code.

For a long deck, hand the reading to the `day-researcher` agent (it returns the coverage map so the
source text stays out of your context). For a short one, read the three files yourself.

## 2. Coverage map
List **every** teaching point in the deck (by slide) and **every** assignment question. For each, decide:
- the lesson that teaches it (lessons stay small: one idea, one demo, a challenge, practice parts);
- **browser** (runs in Brython: plain Python, `logging`, `unittest.mock`, `re`, `json`, `dataclasses`,
  generators, `threading.Lock` as context manager...) or **local card** (asyncio, pytest itself, real
  threads/processes, httpx, LangChain, Ollama, FastAPI, SQLAlchemy, Celery, JWT libraries...). For local
  topics, plan a browser-runnable plain-Python lesson that teaches the *idea* plus the local card.
  Check `docs/PLAN.md` for what Brython can and can't do; test anything unsure in the browser later.
- which skill it belongs to, and which cases will practise it.

Also list **gaps**: things the assignments need that the deck never teaches (Day 1 needed type hints,
custom exceptions, JSON files, packages and argparse). Add lessons for them.

## 3. Skills, chapters, cases
- Skills: 3–8 per day, each 1–5 lessons, in teaching order. Ids unique across all days.
- Chapters: 1–3 per day, numbered after the previous days (`new_day.py` printed the first number).
  Each chapter ends with a big case (its `finale`).
- Cases: every assignment question becomes a case (small if one skill, medium if several), keeping
  its spec; add small cases until every skill has at least one; one big case per chapter; an exam
  (10–15 questions) for the division; a capstone if the day has a project deliverable.
- Story: the division's setting and recurring characters, how each big case connects, and what the
  X thread reveals this day (one X `fragment` per big case; 16 across the course, Day 1 used 4).

## 4. Write docs/<day>/OUTLINE.md
Fill the template `new_day.py` created. Put `Status: draft` at the top. Keep it scannable: tables, not prose.

## 5. Gate
Summarise for the user: skills and chapters, lesson count, browser vs local split, case list by tier,
assignment coverage, gaps you added, open questions. Wait for approval; then change the status to
`Status: approved`.

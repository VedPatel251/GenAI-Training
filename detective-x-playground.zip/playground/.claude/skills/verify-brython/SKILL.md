---
name: verify-brython
description: Run every Academy lesson and every case step of Detective X inside the real browser Python (Brython) and report anything that fails there, since the CPython build can pass while the browser fails. Use before shipping or publishing, after changing the game template or runner, or when a trainee reports "it works locally but not on the page".
argument-hint: "[ids to check, optional]"
---

# Verify in the browser's Python

1. Build what you want to test. Shipped days: `python engine/build_game.py`. A day not in DIVISIONS yet:
   `python engine/build_game.py --day <day>` (a preview build; rebuild without `--day` before publishing).
2. Start a test server in the background on port **8095** (8080 is the trainer's, 8000 belongs to another
   project — never stop either): `python serve_lan.py 8095` with `run_in_background`.
3. In the browser pane open `http://localhost:8095/detective-x.html`.
4. Optional: to check only some lessons or cases, first run `window.CHECK_ONLY = ["id1", "id2"]` with the
   JavaScript tool.
5. Read `engine/brython_check.js` and run its whole text with the browser JavaScript tool. It waits for
   the engine (up to 60 s on first load), then returns `{lessons, parts, cases, caseRuns, bad}`.
6. `bad` must be empty. For each entry:
   - `error|...` in Brython but the CPython build passes → a Brython gap. Check `docs/PLAN.md` for a known
     quirk; rewrite the content to avoid it, or patch the runner in `engine/game_template.html` (as was
     done for `dict.setdefault` and json errors) and record the quirk in `docs/PLAN.md`.
   - `starter already passes` → make the starter fail (Brython may evaluate something differently).
7. Rebuild and rerun until clean. Stop the server with TaskStop when done, and say what was checked
   (counts from the result).

Also click through one new lesson and one new case by hand (Run button, a wrong answer, a right answer)
to see the output panel, hints and solved state, and check the case board's locks and the Academy's
chapters for the new day.

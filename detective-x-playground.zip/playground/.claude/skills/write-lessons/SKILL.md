---
name: write-lessons
description: Write or fix Detective X Academy lessons in days/<day>/lessons.py — idea, runnable demo, line-by-line walkthrough, mistakes, local cards, challenge and multi-part practice — to the course's beginner standard. Use for stage 2 of /new-division, or whenever lesson content is added or changed.
argument-hint: dayN [part or lesson ids]
---

# Academy lessons for $ARGUMENTS

Source of truth for what to write: the approved `docs/<day>/OUTLINE.md`. Good examples to copy the
style of: `days/day1/project.py` (a whole part written natively), `days/day1/practice_a.py` (practice parts).

## Lesson shape
```python
{
    "id": "log-levels",              # unique across ALL days
    "part": 0,                       # index into PARTS
    "title": "Logging levels",
    "slides": "14-16",               # where it comes from in the deck
    "idea": "...",                   # markdown, see "Writing the idea"
    "predict": {"q": "...", "options": [...], "answer": 1, "why": "..."},   # optional guess-first quiz
    "code": '''...''',               # the demo, runs in the browser
    "walkthrough": [["code line", "what it does, in plain English"], ...],
    "mistakes": ["...", "..."],
    "local": [{"title": "Run it with real pytest", "note": "...", "code": "...", "output": "..."}],  # optional
    "challenge": {"task": "...", "starter": "...", "solution": "...", "tests": "...", "hints": ["...", "..."]},
    "practice": [ {same shape as challenge}, ... ],
}
```
Add `"needs_demo": True` to a task whose code uses names defined by the lesson's demo (the demo then runs first).

## Writing the idea
- 1–3 short paragraphs, then a bullet list of the things to remember. The page turns the first sentence
  into a headline and bullets into cards, so lead with the point.
- **Bold** each new term the first time; `code` for anything typed. No jargon without a definition.
- Say *why* it matters with a BookVault or detective example, and connect to earlier days when useful.

## The demo and walkthrough
- Short (5–20 lines), prints something for every idea it shows, runs with no input, files, network,
  `async`, real threads or third-party packages. Only syntax taught earlier (Day 1 is all known).
- Walkthrough: one entry per line that teaches something. Explain what the line does and why.

## Challenge and practice
- The challenge practises the lesson's main idea. **Practice parts cover everything else the lesson
  teaches**: list the lesson's teaching points, and make sure each is practised by at least one task.
- Every task: clear `task` (what to build, exact names to use), a `starter` that runs but fails the tests,
  a `solution`, exactly 2 `hints` (first a nudge, second nearly the answer).
- Tests are `assert`s with plain-English messages (shown to the trainee as-is). Prefer re-running the
  trainee's function with other inputs over checking one printed value. `__output__` holds printed text,
  `__source__` the trainee's code (use it to check that e.g. a `with` block or `logging.getLogger` is used).
  Name test-only variables with a leading `_` so they don't clash with trainee names.

## Things the browser can't run
Teach the idea with plain Python in the demo (a tiny in-page test runner instead of pytest, an
interleaving scheduler instead of real threads, a fake LLM function instead of an API), and add a `local`
card with the real code and its real expected output, copied from the day's examples when possible.
Never claim the browser version *is* the real library.

## Checking
Every save of `days/<day>/*.py` triggers the content-check hook. Also run `python engine/build.py <day>`.
Then have the `beginner-reviewer` agent read the part (give it the lesson ids and the skills that come
before) and fix what it reports. Brython is verified later by `/verify-brython`; when a demo uses a
module not listed as working in `docs/PLAN.md`, test it early in the browser.

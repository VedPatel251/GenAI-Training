---
name: ship-division
description: Ship a finished Detective X division — final build, publish the game artifact to its existing URL, update README and docs, commit locally, and tell the trainer what to restart and upload to GitHub. Use as the last stage of /new-division, or after any content change the trainees should get.
argument-hint: dayN
---

# Ship $ARGUMENTS

1. **Build.** `<day>` must be in `DIVISIONS` in `engine/build_game.py`. Run `python engine/build_game.py`
   (no `--day`, so the page has exactly the shipped days). Every day must pass.
2. **Verify.** `/verify-brython` must have passed on this build (rerun it if content changed since).
3. **Publish.** Republish `site/detective-x.html` with the Artifact tool to
   `https://claude.ai/artifact/VWT6wxg76hkS69XQxSSWih` (pass `url`; omit `capabilities` so the leaderboard's
   `db` + `user` rules carry over). Never publish a `--day` preview build.
4. **Docs.**
   - `README.md`: the Detective X row (skills, cases, days) and the project layout tree.
   - `docs/DETECTIVE_X_PLAN.md`: the status line (divisions, skills, cases, steps).
   - `docs/PLAN.md`: mark the day done; add any new Brython quirk found.
   - `docs/<day>/OUTLINE.md`: `Status: shipped`.
5. **Commit.** Only the repo folder (this one). Stage the day's files, `engine/`, `site/detective-x.html`,
   docs. Never stage `lan/`, `.venv/`, `docs/*/sources/` or anything with secrets. End the message with the
   Co-Authored-By line the session gives. Don't push: the user uploads to GitHub by hand.
6. **Tell the trainer** (in this order):
   - what's new: skills, lessons, cases by tier, XP added, anything unusual;
   - restart the laptop server (Ctrl+C, then `start.bat`) so the team gets the new day;
   - the exact files to upload to GitHub: list them from `git show --name-status HEAD` (or the range of
     commits since their last upload), including deletions;
   - the artifact link, and that trainees need Contributor access for the leaderboard.

---
name: write-cases
description: Write or fix Detective X cases (small, medium, big murder mysteries, division exam, capstone) in days/<day>/cases_*.py, with evidence variants that defeat guessing, tests that compute the answer from the evidence, tips, unlock rules and story. Use for stage 3 of /new-division, or whenever cases are added or changed.
argument-hint: dayN [tier or case ids]
---

# Cases for $ARGUMENTS

Plan: the approved `docs/<day>/OUTLINE.md`. Examples to copy the style of: `days/day1/cases_small.py`
(`phone-records`), `cases_medium.py` (assignment reskins), `cases_big.py` (`grand-library-murder`),
`cases_project.py`, `cases_final.py` (exam + capstone).

## Case shape
```python
{
    "id": "late-night-log",                      # unique across ALL days
    "tier": "small",                             # small | medium | big | exam | capstone
    "title": "The Late-Night Log",
    "teaser": "One line for the case board.",
    "skills": ["logbook"],                       # all skills the steps need (gates the case)
    "story": "markdown: the crime, what forensics loaded into which variables",
    "suspects": [{"name": "the night guard", "note": "Says they never left the desk."}],
    "variants": ["evidence script 1", "evidence script 2", "evidence script 3"],
    "steps": [{
        "notes": "markdown, optional: formulas, rules, definitions the step needs (see below)",
        "question": "markdown, laid out as Goal / You have / Write / Then / Example (see below)",
        "starter": "runs, but fails the tests",
        "solution": "reference answer",
        "tests": "asserts that recompute the answer from the evidence",
        "tips": ["nudge", "nearly the answer"],
        "reveal": "what this step uncovers in the story",
    }],
    "closing": "the case's ending",
    "fragment": "an X clue (big cases only)",
}
```
Exam: `tier: "exam"`, `quiz: [{q, options, answer, why}]`, `pass_mark`. Capstone: `tier: "capstone"`,
`local` cards and a `checklist` (no steps).

## The case tests Python, not outside knowledge
Anything that is not Python — a formula (temperature, interest, distance), a business rule (late fees,
loan limits), a definition (what an ISBN check digit is, what "overdue" means), a protocol fact (which
HTTP codes are transient) — goes in the step's `notes` ("Field notes" box, always visible above the
question). Never leave it only in the tips, the story, or the trainee's general knowledge. If a step
needs it, a beginner who has never heard of it must be able to solve the step from the page alone.
Tips are for **Python** help only (which construct, which method, how to structure the loop).

## Writing a step question a beginner can follow
Lay every question out the same way, one idea per line (the page renders markdown lists):
```
**Goal:** one sentence: what this step finds out, in story terms.

**You have:** each variable the evidence provides, with its shape and a tiny example
(`calls`, a list of phone numbers as strings, e.g. `["98201", "77450"]`).

**Write** a function `name(params)` / a variable `name`:
- what each parameter is
- exactly what it returns or holds (type, order, rounding)
- each rule or edge case on its own bullet

**Then** what to store or print, with the exact variable name.

**Example:** one or two concrete inputs and outputs, ideally not from the evidence.
```
- Name every variable and function exactly as the tests expect, in backticks.
- Say the type and shape of the answer (a dict from name to count, a sorted list, a float rounded to 1 decimal).
- No hidden requirements: anything the tests check (rounding, order, ties, case, errors raised) is stated.
- Plain words, short sentences. Story flavour goes in `story` and `reveal`, not in the instructions.
- The starter matches the question: same names, and the parts already given are really there.
See `frozen-body` in `days/day1/cases_small.py` for a finished example.

## Rules that make it a real investigation
- 2–3 `variants`; the culprit, numbers and times differ in each. The checker runs the solution on every
  variant and fails the build if the answer is the same on all of them.
- Tests **recompute** the expected answer from the evidence (with `_`-prefixed names), so a typed-in
  name never passes. Failure messages say what was expected *on this evidence*.
- The starter must fail. Questions name the exact variables to store results in.
- Steps build on each other and end with an accusation. Use only syntax from the case's `skills`
  and the skills before them (all of Day 1 counts as known).
- Red herrings belong in the evidence (a suspect who looks guilty until the data is read properly), not in
  trick wording.
- **Story text must be true on every variant.** Suspect notes, reveals, closings and fragments are written
  once but the culprit and numbers change per variant. Phrase them around what was computed ("the mirror
  with most of the stalls"), never around variant 1's specifics.
- **Don't check by searching the source text** when behaviour can be checked (a comment containing
  `with lock` must not pass). Use spies and fakes: a fake lock that counts entries, a subclass that records
  `submit` calls. Text checks are a last resort, for things with no observable behaviour.
- **Browser Python quirk:** no dict literal inside an f-string expression (`f"{fn({'a': 1})}"` is a
  SyntaxError in Brython). Compute into a `_var` first. More quirks in `docs/PLAN.md`.

## Tiers and difficulty
- small: 1–2 steps, one skill. medium: 2–3 steps, 2–4 skills; most are the day's assignment questions,
  keeping their spec but told as a crime. big: 4–6 steps across a whole chapter, ends the chapter
  (`finale`), carries an X `fragment`. Difficulty must rise: later cases need more lines and more ideas.
- XP is computed by the build (tier base + 4 per line the trainee writes). Gate the big cases and the
  exam in the division's `UNLOCKS` (`cases` to close first, `mediums` = how many mediums first) so the top
  of the board is earned. The build prints the total; Day 1 gives ~6,000 XP, and rank thresholds in
  `days/day1/game.py` assume each later day adds roughly 3,000 more.

## Checking
The hook re-checks the day after every save. One file: `python engine/build_game.py --check cases_small --day <day>`.
Then have the `case-auditor` agent review the file (guessability, test strength, difficulty, story) and fix
what it reports. Brython is verified by `/verify-brython`.

"""PostToolUse hook: after Claude edits course content, re-check it straight away.

Edits to days/<day>/*.py run `engine/build_game.py --day <day> --no-write` (about 1 second): it checks
every lesson, practice part and case of that day with CPython and writes nothing. Problems are
sent back to Claude (exit code 2) so they get fixed before moving on. Other files are ignored.
"""
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]   # the playground folder


def main():
    try:
        event = json.load(sys.stdin)
    except ValueError:
        return 0
    path = (event.get("tool_input") or {}).get("file_path") or ""
    m = re.search(r"[\\/]days[\\/](day\d+)[\\/][A-Za-z_][\w]*\.py$", path)
    if not m:
        return 0
    day = m.group(1)
    venv = ROOT / ".venv" / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")
    python = str(venv) if venv.exists() else sys.executable
    try:
        done = subprocess.run([python, "engine/build_game.py", "--day", day, "--no-write"], cwd=ROOT,
                              capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=110)
    except subprocess.TimeoutExpired:
        print(f"Content check for {day} timed out after 110 s (an endless loop in a solution or test?).", file=sys.stderr)
        return 2
    if done.returncode == 0:
        return 0
    lines = [l for l in (done.stdout + done.stderr).splitlines() if l.strip()]
    problems = [l for l in lines if l.startswith("PROBLEM:")] or lines[-25:]
    print(f"Content check failed for {day} (python engine/build_game.py --day {day} --no-write):", file=sys.stderr)
    print("\n".join(problems[:40]), file=sys.stderr)
    if len(problems) > 40:
        print(f"... and {len(problems) - 40} more", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())

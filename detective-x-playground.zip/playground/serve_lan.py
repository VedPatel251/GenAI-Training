"""Host Detective X on your laptop for everyone on the same network.

Usage (from this folder):
    python serve_lan.py              # port 8080
    python serve_lan.py 9000         # another port

Teammates open  http://<your-device-name>:8080  (the script prints the exact addresses).

What it does:
  - turns the built game page site/detective-x.html into a full web page in lan/
    (start.bat / start.sh rebuild it first; after changing content, run the build before restarting),
  - downloads the Python engine (Brython) once into lan/static/, so trainees don't need the CDN,
  - serves everything, plus a small shared leaderboard API at /api/board, saved to lan/board.json,
  - keeps detective accounts (name + password) in lan/accounts.json, so a player can sign in from any
    browser or computer and get their progress back.

Accounts: a new detective picks a name and password. Detectives the trainer creates, and players who
were on the board before accounts existed, start with their name as the password and must change it
at first sign-in. A forgotten password is reset by the trainer (Trainer insights, on this laptop only).
Passwords are stored salted and hashed; this is a trial setup over plain http, not real security.

The laptop running this script sees "Trainer insights" on the leaderboard. Stop the server with Ctrl+C.
"""
import hashlib
import json
import secrets
import socket
import sys
import threading
import time
import urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).parent
SITE = HERE / "site"
OUT = HERE / "lan"
STATIC = OUT / "static"
BOARD_FILE = OUT / "board.json"
ACCOUNTS_FILE = OUT / "accounts.json"
MAX_TOKENS = 10            # signed-in browsers kept per detective
CDN = "https://cdnjs.cloudflare.com/ajax/libs/brython/3.12.4/"
ENGINE_FILES = ["brython.min.js", "brython_stdlib.min.js"]
MAX_BODY = 64 * 1024

INDEX = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>GenAI Training</title>
<style>
:root { --bg:#12151a; --panel:#1b1f26; --fg:#ebe6da; --muted:#9b968a; --accent:#e3a846; --line:#2d333d; color-scheme: dark; }
@media (prefers-color-scheme: light) { :root { --bg:#ece6da; --panel:#fbf8f1; --fg:#211d17; --muted:#6d6556; --accent:#9c6410; --line:#d9d0be; color-scheme: light; } }
body { margin:0; background:var(--bg); color:var(--fg); font-family: system-ui, "Segoe UI", sans-serif; }
main { max-width: 760px; margin: 0 auto; padding: 48px 16px; display:flex; flex-direction:column; gap:18px; }
h1 { margin:0; font-size: 2rem; }
p { margin:0; color: var(--muted); }
a.card { display:block; text-decoration:none; color:var(--fg); background:var(--panel); border:1px solid var(--line); border-radius:14px; padding:20px; }
a.card:hover { border-color: var(--accent); }
a.card b { font-size:1.3rem; display:block; margin-bottom:6px; }
</style></head><body><main>
<h1>GenAI Training</h1>
<p>Everything runs in your browser. The first load downloads the Python engine (about 5 MB) from the trainer's laptop.</p>
__CARDS__
</main></body></html>
"""

_lock = threading.Lock()
_board = {}
_accounts = {}   # lower-case name -> {name, id, salt, hash, must_change, tokens}


# ---------------------------------------------------------------- accounts
def _hash(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt), 100_000).hex()


def _set_password(acc, password, must_change):
    acc["salt"] = secrets.token_hex(16)
    acc["hash"] = _hash(password, acc["salt"])
    acc["must_change"] = must_change
    acc["tokens"] = []          # signs out every browser


def _new_account(name, password=None, rid=None):
    acc = {"name": name, "id": rid or "lan-" + secrets.token_hex(8)}
    _set_password(acc, password if password else name, must_change=not password)
    _accounts[name.lower()] = acc
    return acc


def _save_accounts():
    ACCOUNTS_FILE.write_text(json.dumps(_accounts, indent=1), encoding="utf-8")


def _clean_name(value):
    name = " ".join(str(value or "").split())[:40]
    return name if name else None


def _by_token(token):
    if not token:
        return None
    for acc in _accounts.values():
        if token in acc.get("tokens", []):
            return acc
    return None


def _sign_in(acc):
    token = secrets.token_hex(24)
    acc["tokens"] = (acc.get("tokens", []) + [token])[-MAX_TOKENS:]
    return {"id": acc["id"], "name": acc["name"], "token": token, "must_change": acc.get("must_change", False)}


def _migrate_board():
    """Give every named board row that has no account one, with the name as the first password."""
    owned = {a["id"] for a in _accounts.values()}
    rows = sorted(_board.values(), key=lambda r: -r.get("xp", 0))   # same name twice: the best row wins
    for row in rows:
        name = _clean_name(row.get("name"))
        if row["id"] in owned or not name or name == "Unnamed detective" or name.lower() in _accounts:
            continue
        _new_account(name, rid=row["id"])
        owned.add(row["id"])


def prepare():
    OUT.mkdir(exist_ok=True)
    STATIC.mkdir(exist_ok=True)
    for name in ENGINE_FILES:
        target = STATIC / name
        if not target.exists():
            print(f"Downloading {name} (one time)...")
            urllib.request.urlretrieve(CDN + name, target)
    pages = sorted(SITE.glob("*.html"))
    if not pages:
        print("No pages in site/. Run the builds first (start.bat does this for you).")
    cards = []
    game = SITE / "detective-x.html"
    if game.exists():
        cards.append('<a class="card" href="detective-x.html"><b>Detective X</b>'
                     '<span>Learn Python by solving crimes. Skills, cases, ranks and a shared leaderboard.</span></a>')
    for src in pages:
        body = src.read_text(encoding="utf-8").replace(CDN, "static/")
        page = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
                '<meta name="viewport" content="width=device-width,initial-scale=1"></head><body>'
                + body + "</body></html>")
        (OUT / src.name).write_text(page, encoding="utf-8")
    built = {src.name for src in pages} | {"index.html"}
    for old in OUT.glob("*.html"):          # pages from earlier builds (e.g. the retired day playgrounds)
        if old.name not in built:
            old.unlink()
    (OUT / "index.html").write_text(INDEX.replace("__CARDS__", "\n".join(cards)), encoding="utf-8")
    global _board, _accounts
    if BOARD_FILE.exists():
        try:
            _board = json.loads(BOARD_FILE.read_text(encoding="utf-8"))
        except ValueError:
            _board = {}
    if ACCOUNTS_FILE.exists():
        try:
            _accounts = json.loads(ACCOUNTS_FILE.read_text(encoding="utf-8"))
        except ValueError:
            _accounts = {}
    before = len(_accounts)
    _migrate_board()
    if len(_accounts) != before:
        _save_accounts()
        print(f"Created {len(_accounts) - before} account(s) for players already on the board "
              "(their first password is their detective name).")


def _clean_row(data):
    """Keep only known fields with sane types, so a bad request can't break the board."""
    if not isinstance(data, dict):
        return None
    rid = str(data.get("id", ""))[:80]
    if not rid:
        return None
    cases = data.get("cases") if isinstance(data.get("cases"), dict) else {}
    lessons = data.get("lessons") if isinstance(data.get("lessons"), list) else []
    try:
        xp = max(0, min(int(data.get("xp", 0)), 10_000_000))
        solved = max(0, min(int(data.get("solvedCount", 0)), 10_000))
    except (TypeError, ValueError):
        return None
    return {
        "id": rid,
        "name": str(data.get("name", "Unnamed detective"))[:40],
        "rank": str(data.get("rank", ""))[:40],
        "xp": xp,
        "solvedCount": solved,
        "cases": {str(k)[:60]: int(v) for k, v in list(cases.items())[:500] if isinstance(v, int)},
        "lessons": [str(x)[:60] for x in lessons[:500]],
        "updated": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(OUT), **kwargs)

    def log_message(self, fmt, *args):
        """Quiet console: show leaderboard saves and server errors, skip page loads and 404s."""
        try:
            msg = fmt % args
        except (TypeError, ValueError):
            msg = str(fmt)
        if "POST /api/" in msg or "code 5" in msg:
            super().log_message("%s", msg)

    def _json(self, payload, status=200):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def end_headers(self):
        # Pages must never come from a stale browser cache after the trainer rebuilds and restarts.
        # The 5.5 MB Python engine in static/ may still be cached normally.
        if not self.path.startswith("/static/"):
            self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def _is_host(self):
        return self.client_address[0] in ("127.0.0.1", "::1")

    def do_GET(self):
        if self.path.split("?")[0] == "/favicon.ico":   # browsers ask for a tab icon; we have none
            self.send_response(204)
            self.end_headers()
            return
        if self.path.split("?")[0] == "/api/board":
            with _lock:
                rows = list(_board.values())
            return self._json({"rows": rows, "host": self._is_host()})
        return super().do_GET()

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0 or length > MAX_BODY:
            return None
        try:
            data = json.loads(self.rfile.read(length))
        except ValueError:
            return None
        return data if isinstance(data, dict) else None

    def _rows(self):
        return {"rows": list(_board.values()), "host": self._is_host()}

    def do_POST(self):
        path = self.path.split("?")[0]
        data = self._body()
        if data is None:
            return self._json({"error": "bad request"}, 400)
        with _lock:
            if path == "/api/board":
                acc = _by_token(data.get("token"))
                if not acc:
                    return self._json({"error": "sign in again"}, 401)
                row = _clean_row(dict(data, id=acc["id"], name=acc["name"]))
                if not row:
                    return self._json({"error": "bad data"}, 400)
                _board[row["id"]] = row
                BOARD_FILE.write_text(json.dumps(_board, indent=1), encoding="utf-8")
                return self._json(self._rows())

            if path == "/api/login":
                acc = _accounts.get(" ".join(str(data.get("name", "")).split()).lower())
                if not acc or _hash(str(data.get("password", "")), acc["salt"]) != acc["hash"]:
                    return self._json({"error": "Wrong detective name or password."}, 401)
                result = _sign_in(acc)
                _save_accounts()
                return self._json(result)

            if path == "/api/signup":
                name, password = _clean_name(data.get("name")), str(data.get("password", ""))
                if not name:
                    return self._json({"error": "Pick a detective name."}, 400)
                if len(password) < 4:
                    return self._json({"error": "Use a password of at least 4 characters."}, 400)
                if name.lower() in _accounts:
                    return self._json({"error": "That name is taken. Sign in instead, or pick another name."}, 409)
                acc = _new_account(name, password)
                result = _sign_in(acc)
                _save_accounts()
                return self._json(result)

            if path == "/api/me":
                acc = _by_token(data.get("token"))
                if not acc:
                    return self._json({"error": "sign in again"}, 401)
                return self._json({"id": acc["id"], "name": acc["name"], "must_change": acc.get("must_change", False)})

            if path == "/api/password":
                acc = _by_token(data.get("token"))
                if not acc:
                    return self._json({"error": "sign in again"}, 401)
                if _hash(str(data.get("old", "")), acc["salt"]) != acc["hash"]:
                    return self._json({"error": "Your current password is wrong."}, 403)
                new = str(data.get("new", ""))
                if len(new) < 4:
                    return self._json({"error": "Use a password of at least 4 characters."}, 400)
                if new.lower() == acc["name"].lower():
                    return self._json({"error": "Pick a password that isn't your detective name."}, 400)
                _set_password(acc, new, must_change=False)
                result = _sign_in(acc)            # every other browser is signed out
                _save_accounts()
                return self._json(result)

            # ---- trainer tools: only from the laptop running the server
            if path.startswith("/api/admin/"):
                if not self._is_host():
                    return self._json({"error": "trainer only"}, 403)
                if path == "/api/admin/accounts":
                    owned = {a["id"] for a in _accounts.values()}
                    return self._json({
                        "accounts": sorted(({"name": a["name"], "id": a["id"], "must_change": a.get("must_change", False)}
                                            for a in _accounts.values()), key=lambda a: a["name"].lower()),
                        "orphans": [{"id": r["id"], "name": r.get("name", ""), "xp": r.get("xp", 0)}
                                    for r in _board.values() if r["id"] not in owned],
                    })
                name = _clean_name(data.get("name"))
                password = str(data.get("password") or "") or None
                if path == "/api/admin/create":
                    if not name or name.lower() in _accounts:
                        return self._json({"error": "Missing or taken name."}, 400)
                    acc = _new_account(name, password)
                    acc["must_change"] = True
                    _save_accounts()
                    return self._json({"ok": True})
                if path == "/api/admin/reset":
                    acc = _accounts.get((name or "").lower())
                    if not acc:
                        return self._json({"error": "No such detective."}, 404)
                    _set_password(acc, password or acc["name"], must_change=True)
                    _save_accounts()
                    return self._json({"ok": True})
                if path == "/api/admin/remove-row":
                    rid = str(data.get("id", ""))
                    if rid in {a["id"] for a in _accounts.values()}:
                        return self._json({"error": "That row belongs to an account."}, 400)
                    _board.pop(rid, None)
                    BOARD_FILE.write_text(json.dumps(_board, indent=1), encoding="utf-8")
                    return self._json({"ok": True})
        return self._json({"error": "not found"}, 404)


def addresses(port):
    host = socket.gethostname()
    ips = set()
    try:
        for info in socket.getaddrinfo(host, None, socket.AF_INET):
            ips.add(info[4][0])
    except socket.gaierror:
        pass
    try:   # the address used for the default route, which is usually the Wi-Fi/LAN one
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    ips.discard("127.0.0.1")
    return [f"http://{host}:{port}"] + [f"http://{ip}:{port}" for ip in sorted(ips)]


def port_in_use(port):
    """True if another program already listens on this port (on any local address)."""
    for addr in ("127.0.0.1", "0.0.0.0"):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind((addr, port))
        except OSError:
            return True
        finally:
            s.close()
    return False


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    if port_in_use(port):
        print(f"Port {port} is already used by another program. Try another one, e.g.  python serve_lan.py {port + 1}")
        sys.exit(1)
    prepare()
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print("\nServing Detective X. Teammates on the same network can open:")
    for url in addresses(port):
        print("   ", url)
    print(f"\nOn this laptop: http://localhost:{port}   (shows Trainer insights)")
    print(f"Leaderboard saved to {BOARD_FILE}")
    print("Press Ctrl+C to stop.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Stopped.")


if __name__ == "__main__":
    main()

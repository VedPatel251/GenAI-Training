// Brython regression for Detective X: runs inside the built page, in the browser's Python.
// The CPython build (engine/build_game.py) can pass while Brython fails, so run this after every build.
//
// How: serve the game (python serve_lan.py 8095), open http://localhost:8095/detective-x.html in the
// browser pane, then paste this whole file into the browser's JavaScript tool. Set
// window.CHECK_ONLY = ["lesson-or-case-id", ...] first to check just some ids.
//
// It checks: every lesson demo runs, every challenge/practice solution passes (with the lesson demo
// as prelude when needs_demo is set), every case step's solution passes on EVERY variant, and every
// case starter fails. Result: {lessons, parts, cases, caseRuns, bad: [...]}. "bad" must be empty.
await (async () => {
  const wait = ms => new Promise(r => setTimeout(r, ms));
  for (let i = 0; i < 120 && typeof window.pyRun !== "function"; i++) await wait(500);
  if (typeof window.pyRun !== "function") return { error: "Python engine did not load in 60 s" };
  const only = Array.isArray(window.CHECK_ONLY) ? new Set(window.CHECK_ONLY) : null;
  const want = id => !only || only.has(id);
  const saved = window.pyEmit; window.pyEmit = () => {};
  const bad = []; let parts = 0, caseRuns = 0, lessons = 0, cases = 0;
  const run = (pre, src, tests) => String(window.pyRun(pre || "", src, tests || ""));
  try {
    const L = Array.isArray(LESSONS) ? LESSONS : Object.values(LESSONS);
    for (const l of L) {
      if (!want(l.id)) continue;
      lessons++;
      if (l.code) { const r = run("", l.code, ""); if (r !== "ok") bad.push(`${l.id} demo: ${r.slice(0, 200)}`); }
      const tasks = [l.challenge, ...(l.practice || [])].filter(Boolean);
      tasks.forEach((t, i) => {
        parts++;
        const pre = t.needs_demo ? l.code : "";
        const r = run(pre, t.solution, t.tests);
        if (r !== "ok") bad.push(`${l.id} part ${i + 1}: ${r.slice(0, 200)}`);
        if (run(pre, t.starter, t.tests) === "ok") bad.push(`${l.id} part ${i + 1}: starter already passes`);
      });
    }
    for (const c of GAME.cases) {
      if (!want(c.id) || !c.steps) continue;
      cases++;
      c.steps.forEach((st, i) => {
        c.variants.forEach((v, k) => {
          caseRuns++;
          const r = run(v, st.solution, st.tests);
          if (r !== "ok") bad.push(`${c.id} step ${i + 1} variant ${k + 1}: ${r.slice(0, 200)}`);
        });
        if (run(c.variants[0], st.starter, st.tests) === "ok") bad.push(`${c.id} step ${i + 1}: starter already passes`);
      });
    }
  } finally { window.pyEmit = saved; }
  return { lessons, parts, cases, caseRuns, bad };
})()

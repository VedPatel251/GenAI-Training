"""Create the empty skeleton of a new Detective X division (one training day).

Usage (from the playground folder):
    python engine/new_day.py day2 "Forensics Lab" "Debugging, logging, testing and concurrency"

Creates days/<day>/ with lessons.py, game.py, cases_small.py, cases_medium.py, cases_big.py and
cases_final.py, plus docs/<day>/OUTLINE.md. Every file starts valid and empty, so
    python engine/build_game.py --day <day> --no-write
passes straight away. Nothing existing is overwritten. The day is NOT added to DIVISIONS in
engine/build_game.py: do that when its content is ready to ship.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

LESSONS = '''"""Day {n} lesson content for the Detective X Academy ({division}).

Format of one lesson (every field except `practice`, `mistakes`, `local` and `predict` is required):
  id          url-safe slug, unique across ALL days (prefix it if it could clash, e.g. "d{n}-...")
  part        index into PARTS
  title       short name
  slides      slide numbers in the Day {n} deck it maps to (text, e.g. "8-9")
  idea        1-3 short paragraphs of markdown; **bold** key terms, `code` inline, "- " bullet lists
  code        runnable demo, Python 3.11+, runs in the browser (Brython): no files, network or async
  walkthrough [[code line, plain-English explanation], ...] for every line that teaches something
  mistakes    common beginner mistakes, one sentence each
  local       optional "Run this on your machine" cards: [{{title, note, code, output}}]
              for real libraries the browser can't run (pytest, asyncio, LangChain, FastAPI ...)
  predict     optional "guess first" quiz: {{q, options, answer (index), why}}
  challenge   {{task, starter, solution, tests, hints: [2 hints], needs_demo?: True}}
  practice    more tasks in the same format, so the practice covers EVERYTHING the lesson teaches

Tests are assert statements run after the trainee's code. They can read `__output__` (printed text)
and `__source__` (the trainee's code). The failure message is shown to the trainee as-is.
Check with:  python engine/build.py {day}
"""

DAY = {{
    "number": {n},
    "title": "{division}",
    "tagline": "{tagline}",
}}

PARTS = [
    # "Part title", ...  (one per section of the deck; lessons point here with "part")
]

LESSONS = [
]
'''

GAME = '''"""Detective X: the Day {n} division ({division}).

SKILLS reuse lessons from lessons.py (this package) by id. Course-wide settings (ranks, XP per
tier, X fragments) live in days/day1/game.py; this file only adds the division's own content.
Check with:  python engine/build_game.py --day {day} --no-write
"""

DIVISION = "Day {n} · {division}"

# Skills in teaching order. A case may only use syntax from the skills it lists and earlier ones
# (Day 1 skills are always known).
SKILLS = [
    # {{"id": "...", "title": "...", "badge": "...", "tagline": "...", "lessons": ["lesson-id", ...]}},
]

# Chapters continue the course numbering: Day {n} starts at chapter {first_chapter}.
CHAPTERS = [
    # {{"id": "...", "title": "...", "number": {first_chapter}, "tagline": "...",
    #  "skills": [...], "finale": "big-case-id"}},
]

CASES = []

import importlib as _importlib

for _mod in ("cases_small", "cases_medium", "cases_big", "cases_final"):
    _full = f"{{__package__}}.{{_mod}}"
    try:
        CASES.extend(_importlib.import_module(_full).CASES)
    except ModuleNotFoundError as _e:
        if _e.name != _full:
            raise

# Extra locks on top of skills: "cases" that must be closed first, and how many "mediums"
# (that only use this case's skills) must be closed. Use it for the big cases and the exam.
UNLOCKS = {{
}}
for _c in CASES:
    if _c["id"] in UNLOCKS:
        _c["requires"] = UNLOCKS[_c["id"]]
'''

CASE_FILE = '''"""Detective X Day {n}: {what}.

Case format (see .claude/skills/write-cases/SKILL.md for the full rules):
  id, tier ("small" | "medium" | "big"), title, teaser, skills, story, suspects,
  variants  2-3 evidence scripts; the trainee's code runs on each, answers must differ
  steps     [{{question, starter, solution, tests, tips: [2 tips], reveal}}]
  closing   text shown when the case is closed; optional "fragment" (an X clue, big cases)
Check with:  python engine/build_game.py --check {module} --day {day}
"""

CASES = [
]
'''

FINAL = '''"""Detective X Day {n}: the division exam (tier "exam": quiz + pass_mark) and, if the day
has a deliverable, a field operation (tier "capstone": local cards + checklist).
Check with:  python engine/build_game.py --check cases_final --day {day}
"""

CASES = [
]
'''

OUTLINE = '''# Day {n} outline: {division}

Written by the research step (/research-day {day}). Approve this before any content is written.

## Sources
- Deck: ../extracted/...  (text dump: docs/{day}/sources/)
- Assignments: ...
- Code examples: ...

## Coverage map
Every slide topic and every assignment question must appear here, mapped to a lesson
(browser-runnable, or a "local" card when the real library can't run in the browser).

| Deck topic / slides | Lesson id | Runs in browser? | Skill | Cases that practise it |
|---|---|---|---|---|

## Assignments -> cases
| Q | What it asks | Case id | Tier |
|---|---|---|---|

## Gaps the deck doesn't teach but the assignments need
-

## Skills and chapters
| Chapter | Skill | Lessons |
|---|---|---|

## Story for the division
Setting, recurring characters, the big cases (one per chapter) and how the X thread advances.
'''


def next_chapter():
    sys.path.insert(0, str(ROOT / "engine"))
    import importlib
    total = 0
    for day in sorted(p.name for p in (ROOT / "days").iterdir() if (p / "game.py").exists()):
        total += len(importlib.import_module(f"days.{day}.game").CHAPTERS)
    return total + 1


def write(path, text):
    if path.exists():
        print("exists, kept:", path.relative_to(ROOT))
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    print("created:", path.relative_to(ROOT))


def main():
    if len(sys.argv) < 3 or not re.fullmatch(r"day\d+", sys.argv[1]):
        print(__doc__)
        sys.exit(1)
    day, division = sys.argv[1], sys.argv[2]
    tagline = sys.argv[3] if len(sys.argv) > 3 else ""
    n = int(day[3:])
    fmt = dict(day=day, n=n, division=division, tagline=tagline, first_chapter=next_chapter())
    folder = ROOT / "days" / day
    write(folder / "__init__.py", f'"""Day {n} - {division}: Academy lessons and the Detective X division."""\n')
    write(folder / "lessons.py", LESSONS.format(**fmt))
    write(folder / "game.py", GAME.format(**fmt))
    for module, what in (("cases_small", "small cases (one skill each, 1-2 steps)"),
                         ("cases_medium", "medium cases (2-4 skills, 2-3 steps; most are reskinned assignments)"),
                         ("cases_big", "the big case(s): one murder mystery per chapter, 4-6 steps")):
        write(folder / f"{module}.py", CASE_FILE.format(module=module, what=what, **fmt))
    write(folder / "cases_final.py", FINAL.format(**fmt))
    write(ROOT / "docs" / day / "OUTLINE.md", OUTLINE.format(**fmt))
    print(f"\nNext: python engine/build_game.py --day {day} --no-write")


if __name__ == "__main__":
    main()

"""Check the Academy lessons of one training day with CPython (Detective X shows these lessons).

Usage (from the playground folder):
    python engine/build.py day1                                 # check every lesson
    python engine/build.py day1 --check-practice practice_a     # check one practice file
engine/build_game.py runs the same check before it builds the game, so this is only a faster way
to test lesson content while writing it.

Lesson content lives in days/<day>/lessons.py (see days/day1/lessons.py for the format).
The page runs Python in the browser with Brython, so lessons must not touch files or the network.
"""
import contextlib
import importlib
import io
import sys
from pathlib import Path

HERE = Path(__file__).parent          # engine/
ROOT = HERE.parent                     # the playground folder
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))      # so "days.day1.lessons" can be imported


def _run(src, ns, quiet=True):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(io.StringIO()):
        exec(src, ns)
    ns["__output__"] = buf.getvalue()   # mirrors the page runner: tests can read printed text
    ns["__source__"] = src
    return buf.getvalue()


def check_task(L, C, tag):
    """One practice task: needs hints, its solution must pass, its untouched starter must fail."""
    problems = []
    if not C.get("hints") or len(C["hints"]) < 2:
        problems.append(f"{tag}: needs 2 hints")
    prelude = L["code"] if C.get("needs_demo") else ""
    ns = {"__name__": "__main__"}
    try:
        if prelude:
            _run(prelude, ns)
        _run(C["solution"], ns)
        _run(C["tests"], ns)
    except Exception as e:
        problems.append(f"{tag}: solution failed {type(e).__name__}: {e}")
    ns = {"__name__": "__main__"}
    try:
        if prelude:
            _run(prelude, ns)
        _run(C["starter"], ns)
        _run(C["tests"], ns)
        problems.append(f"{tag}: starter already passes the tests")
    except Exception:
        pass
    return problems


def check(lessons):
    problems = []
    for L in lessons:
        if L.get("code"):
            try:
                _run(L["code"], {"__name__": "__main__"})
            except Exception as e:
                problems.append(f"{L['id']}: demo raised {type(e).__name__}: {e}")
        for q in L.get("quiz", []) + ([L["predict"]] if L.get("predict") else []):
            if not 0 <= q["answer"] < len(q["options"]):
                problems.append(f"{L['id']}: quiz answer index out of range: {q['q'][:40]}")
        if L.get("code") and not L.get("walkthrough"):
            problems.append(f"{L['id']}: demo has no line-by-line walkthrough")
        parts = ([L["challenge"]] if L.get("challenge") else []) + L.get("practice", [])
        for n, C in enumerate(parts, 1):
            problems += check_task(L, C, f"{L['id']} part {n}")
    return problems


def check_day(day):
    mod = importlib.import_module(f"days.{day}.lessons")
    problems = check(mod.LESSONS)
    for p in problems:
        print("PROBLEM:", p)
    if not problems:
        print(f"Checked {len(mod.LESSONS)} lessons with CPython {sys.version.split()[0]}: all good.")
    return problems


def check_practice(day, module):
    """Check one practice file on its own: python engine/build.py day1 --check-practice practice_a"""
    lessons = {l["id"]: l for l in importlib.import_module(f"days.{day}.lessons").LESSONS}
    extra = importlib.import_module(f"days.{day}.{module}").PRACTICE
    problems, count = [], 0
    for lid, tasks in extra.items():
        if lid not in lessons:
            problems.append(f"{lid}: no such lesson")
            continue
        for n, C in enumerate(tasks, 1):
            count += 1
            problems += check_task(lessons[lid], C, f"{lid} extra {n}")
    for p in problems:
        print("PROBLEM:", p)
    print(f"{count} practice tasks checked, {len(problems)} problems.")
    return problems


if __name__ == "__main__":
    if "--check-practice" in sys.argv:
        i = sys.argv.index("--check-practice")
        sys.exit(1 if check_practice(sys.argv[1], sys.argv[i + 1]) else 0)
    sys.exit(1 if check_day(sys.argv[1] if len(sys.argv) > 1 else "day1") else 0)

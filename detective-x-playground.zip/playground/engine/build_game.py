"""Build (and check) the Detective X game page.

Usage (from the playground folder):
    python engine/build_game.py                                  # check everything, then write site/detective-x.html
    python engine/build_game.py --check cases_medium             # check one case file of the newest division
    python engine/build_game.py --check cases_small --day day2   # ... of a given division
    python engine/build_game.py --no-write                       # check everything, write nothing

Checks for every case step:
  - the reference solution passes on EVERY evidence variant,
  - the untouched starter fails,
  - the solution's answer differs between variants (so a hard-coded answer cannot pass),
  - there are exactly 2 informant tips and a reveal.
Plus: every case skill exists, every skill lesson exists, ids are unique across divisions,
and every skill sits in exactly one chapter.

Each training day is a division: days/<day>/lessons.py (Academy lessons) and days/<day>/game.py
(SKILLS, CHAPTERS, UNLOCKS, CASES). Course-wide settings (TITLE, RANKS, XP, XP_BASE, XP_PER_LINE,
FRAGMENTS_TOTAL) come from the first division. Add a day to DIVISIONS once its content builds.
"""
import contextlib
import io
import importlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).parent          # engine/
ROOT = HERE.parent                     # the playground folder
SITE = ROOT / "site"
sys.path.insert(0, str(HERE))          # for "from build import ..."
sys.path.insert(0, str(ROOT))          # for "days.day1...."

DIVISIONS = ["day1"]                   # add "day2", ... as each day's game content is written
if "--day" in sys.argv and sys.argv[sys.argv.index("--day") + 1] not in DIVISIONS:
    DIVISIONS.append(sys.argv[sys.argv.index("--day") + 1])   # check a day before it is listed
DAY = sys.argv[sys.argv.index("--day") + 1] if "--day" in sys.argv else DIVISIONS[-1]

_lessons = {d: importlib.import_module(f"days.{d}.lessons") for d in DIVISIONS}
_games = {d: importlib.import_module(f"days.{d}.game") for d in DIVISIONS}
_course = _games[DIVISIONS[0]]
G = SimpleNamespace(
    TITLE=_course.TITLE, RANKS=_course.RANKS, XP=_course.XP, XP_BASE=_course.XP_BASE,
    XP_PER_LINE=_course.XP_PER_LINE, FRAGMENTS_TOTAL=_course.FRAGMENTS_TOTAL,
    DIVISION=_games[DIVISIONS[-1]].DIVISION,
    SKILLS=[s for d in DIVISIONS for s in _games[d].SKILLS],
    CASES=[c for d in DIVISIONS for c in _games[d].CASES],
    CHAPTERS=[ch for d in DIVISIONS for ch in _games[d].CHAPTERS],
    UNLOCKS={k: v for d in DIVISIONS for k, v in getattr(_games[d], "UNLOCKS", {}).items()},
)
ALL_LESSONS = [l for d in DIVISIONS for l in _lessons[d].LESSONS]
from build import check as check_lessons   # noqa: E402


def check_ids():
    """Lesson, skill, case and chapter ids must be unique across every division."""
    problems = []
    for kind, ids in (("lesson", [l["id"] for l in ALL_LESSONS]), ("skill", [s["id"] for s in G.SKILLS]),
                      ("case", [c["id"] for c in G.CASES]), ("chapter", [c["id"] for c in G.CHAPTERS])):
        for i in sorted({i for i in ids if ids.count(i) > 1}):
            problems.append(f"{kind} id {i!r} is used more than once")
    case_ids = {c["id"] for c in G.CASES}
    for ch in G.CHAPTERS:
        if ch.get("finale") and ch["finale"] not in case_ids:
            problems.append(f"chapter {ch['id']}: finale {ch['finale']!r} is not a case")
    numbers = [ch["number"] for ch in G.CHAPTERS]
    if numbers != list(range(1, len(numbers) + 1)):
        problems.append(f"chapter numbers must run 1, 2, 3 ... across divisions; got {numbers}")
    return problems


def _run(code, ns):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(io.StringIO()):
        exec(code, ns)
    return buf.getvalue()


def run_step(evidence, src, tests):
    """Mirror of the page runner: evidence, then the trainee code, then tests."""
    ns = {"__name__": "__main__"}
    _run(evidence, ns)
    before = set(ns)
    out = _run(src, ns)
    ns["__output__"] = out
    ns["__source__"] = src
    _run(tests, ns)
    answer = {k: repr(v) for k, v in ns.items() if k not in before and not k.startswith("_")}
    return out, answer


def module_name(name):
    """Accept a short case-file name (cases_medium) or a full module path (days.day1.cases_medium)."""
    return name if "." in name else f"days.{DAY}.{name}"


def own_lines(case):
    """Lines of solution code the trainee has to write themselves (not already in the starter)."""
    def lines(code):
        return [l for l in code.splitlines() if l.strip() and not l.strip().startswith("#")]
    total = 0
    for st in case.get("steps", []):
        start = set(lines(st["starter"]))
        total += sum(1 for l in lines(st["solution"]) if l not in start)
    return total


def apply_xp():
    for c in G.CASES:
        bonus = G.XP_PER_LINE * own_lines(c)
        c["xp"] = int(round((G.XP_BASE[c["tier"]] + bonus) / 5.0) * 5)


def check_unlocks():
    problems = []
    ids = {c["id"]: c for c in G.CASES}
    for cid, rule in G.UNLOCKS.items():
        c = ids.get(cid)
        if not c:
            problems.append(f"UNLOCKS: unknown case {cid}")
            continue
        for need in rule.get("cases", []):
            if need not in ids:
                problems.append(f"{cid}: requires unknown case {need}")
        if rule.get("among"):
            for need in rule["among"]:
                if need not in ids or ids[need]["tier"] != "medium":
                    problems.append(f"{cid}: 'among' lists {need}, which is not a medium case")
            pool = [ids[m] for m in rule["among"] if m in ids]
        else:
            pool = [m for m in G.CASES if m["tier"] == "medium" and set(m["skills"]) <= set(c["skills"])]
        if rule.get("mediums", 0) > len(pool):
            problems.append(f"{cid}: requires {rule['mediums']} mediums but only {len(pool)} use its skills")
    return problems


def check_game(only_module=None):
    """Check every case, or only the cases from one module (python engine/build_game.py --check cases_medium)."""
    problems = []
    lesson_ids = {l["id"] for l in ALL_LESSONS}
    skill_ids = {s["id"] for s in G.SKILLS}
    for s in G.SKILLS:
        for lid in s["lessons"]:
            if lid not in lesson_ids:
                problems.append(f"skill {s['id']}: unknown lesson {lid}")
    seen = set()
    cases = G.CASES
    if only_module:
        cases = importlib.import_module(module_name(only_module)).CASES
        known = [c["id"] for c in G.CASES]
        for c in cases:
            if known.count(c["id"]) > 1:
                problems.append(f"{c['id']}: id used by another case")
    for c in cases:
        cid = c["id"]
        if cid in seen:
            problems.append(f"{cid}: duplicate case id")
        seen.add(cid)
        for sk in c["skills"]:
            if sk not in skill_ids:
                problems.append(f"{cid}: unknown skill {sk}")
        if c["tier"] not in G.XP:
            problems.append(f"{cid}: unknown tier {c['tier']}")
        if c["tier"] == "exam":
            q = c.get("quiz") or []
            if not q or not 0 < c.get("pass_mark", 0) <= len(q):
                problems.append(f"{cid}: an exam needs a quiz and a pass_mark between 1 and the number of questions")
            for qq in q:
                if not 0 <= qq["answer"] < len(qq["options"]):
                    problems.append(f"{cid}: answer index out of range in {qq['q'][:40]}")
            continue
        if c["tier"] == "capstone":
            if not c.get("checklist") or not c.get("local"):
                problems.append(f"{cid}: a capstone needs local cards and a checklist")
            continue
        if len(c["variants"]) < 2:
            problems.append(f"{cid}: needs at least 2 evidence variants")
        for i, st in enumerate(c["steps"]):
            tag = f"{cid} step {i + 1}"
            if len(st.get("tips", [])) != 2:
                problems.append(f"{tag}: needs exactly 2 tips")
            if not st.get("reveal"):
                problems.append(f"{tag}: missing reveal")
            signatures = []
            for vi, ev in enumerate(c["variants"]):
                try:
                    out, ans = run_step(ev, st["solution"], st["tests"])
                    signatures.append((out, tuple(sorted(ans.items()))))
                except Exception as e:
                    problems.append(f"{tag}: solution fails on variant {vi + 1}: {type(e).__name__}: {e}")
            if len(set(signatures)) < 2 and len(signatures) == len(c["variants"]):
                problems.append(f"{tag}: the answer is the same on every variant, so a hard-coded answer would pass")
            try:
                run_step(c["variants"][0], st["starter"], st["tests"])
                problems.append(f"{tag}: the starter already passes")
            except Exception:
                pass
    return problems


def build():
    problems = check_lessons(ALL_LESSONS) + check_ids() + check_game() + check_unlocks()
    in_chapters = [sk for ch in G.CHAPTERS for sk in ch["skills"]]
    if sorted(in_chapters) != sorted(s["id"] for s in G.SKILLS) or len(set(in_chapters)) != len(in_chapters):
        problems.append("CHAPTERS must list every skill exactly once")
    for p in problems:
        print("PROBLEM:", p)
    if problems:
        sys.exit(1)
    steps = sum(len(c.get("steps", [])) for c in G.CASES)
    print(f"Checked {len(DIVISIONS)} division(s), {len(G.SKILLS)} skills, {len(G.CASES)} cases ({steps} steps) on every evidence variant: all good.")

    apply_xp()
    total = sum(c["xp"] for c in G.CASES)
    print(f"Case XP: {total} in total; Senior Detective at {dict((n, x) for x, n in G.RANKS)['Senior Detective']}.")
    used = [lid for s in G.SKILLS for lid in s["lessons"]]
    lessons = [l for l in ALL_LESSONS if l["id"] in used]
    game = {
        "title": G.TITLE,
        "division": G.DIVISION,
        "ranks": G.RANKS,
        "xp": G.XP,
        "fragmentsTotal": G.FRAGMENTS_TOTAL,
        "skills": G.SKILLS,
        "chapters": G.CHAPTERS,
        "cases": G.CASES,
    }

    def js(obj):
        return json.dumps(obj, ensure_ascii=False).replace("</", "<\\/")

    if "--no-write" in sys.argv:
        return
    html = (HERE / "game_template.html").read_text(encoding="utf-8")
    html = html.replace("/*__GAME_JSON__*/", js(game)).replace("/*__LESSONS_JSON__*/", js(lessons))
    SITE.mkdir(exist_ok=True)
    out = SITE / "detective-x.html"
    out.write_text(html, encoding="utf-8")
    print(f"Wrote {out} ({len(html) // 1024} KB)")


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--check":
        found = check_game(sys.argv[2])
        for p in found:
            print("PROBLEM:", p)
        mod = importlib.import_module(module_name(sys.argv[2]))
        print(f"{len(mod.CASES)} cases checked, {len(found)} problems.")
        sys.exit(1 if found else 0)
    build()

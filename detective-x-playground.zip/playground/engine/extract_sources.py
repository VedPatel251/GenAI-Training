"""Turn one day's training material into plain text that is easy to read and search.

Usage (from the playground folder):
    python engine/extract_sources.py day2

Reads ../extracted/<day>/ (the folder name may be "day2" or "Day2") and writes docs/<day>/sources/:
  slides.md       every slide of each .pptx, numbered, with speaker notes
  assignments.md  every .docx (assignment sheets), paragraph by paragraph, tables as rows
  code.md         an index of the code examples, then each .py / .md / .txt / .json file in full
Code inside nested .zip files is read in memory, never extracted or run.
Secrets are skipped: .env files, and anything that looks like a key file, are listed by name only.
Standard library only.
"""
import re
import sys
import zipfile
from io import BytesIO
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).parent.parent
SOURCES = ROOT.parent / "extracted"
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
CODE_EXT = {".py", ".md", ".txt", ".json", ".toml", ".cfg", ".ini", ".yaml", ".yml", ".sql", ".html", ".csv"}
SECRET = re.compile(r"(^|/)\.env($|\.)|secret|credential|\.pem$|\.key$|id_rsa", re.I)
SKIP_DIR = re.compile(r"(^|/)(__pycache__|\.venv|venv|node_modules|\.git|\.idea|\.vscode|__MACOSX)(/|$)")
MAX_FILE = 60_000


def slide_text(z, name):
    root = ET.fromstring(z.read(name))
    paras = []
    for p in root.iter(f"{A}p"):
        line = "".join(t.text or "" for t in p.iter(f"{A}t")).strip()
        if line:
            paras.append(line)
    return paras


def pptx(path):
    out = [f"# {path.name}\n"]
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        slides = sorted((n for n in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)),
                        key=lambda n: int(re.search(r"(\d+)", n.rsplit("/", 1)[1]).group(1)))
        for name in slides:
            num = int(re.search(r"(\d+)\.xml", name).group(1))
            out.append(f"\n## Slide {num}\n")
            out += [f"- {line}" for line in slide_text(z, name)]
            notes = f"ppt/notesSlides/notesSlide{num}.xml"
            if notes in names:
                text = [l for l in slide_text(z, notes) if not l.isdigit()]
                if text:
                    out.append("\nNotes: " + " ".join(text))
    return "\n".join(out) + "\n"


def docx(path):
    out = [f"# {path.name}\n"]
    with zipfile.ZipFile(path) as z:
        body = ET.fromstring(z.read("word/document.xml")).find(f"{W}body")
    for el in body:
        if el.tag == f"{W}p":
            text = "".join(t.text or "" for t in el.iter(f"{W}t")).strip()
            if text:
                style = el.find(f"{W}pPr/{W}pStyle")
                level = style.get(f"{W}val", "") if style is not None else ""
                out.append(("\n## " + text) if level.lower().startswith("heading") else text)
        elif el.tag == f"{W}tbl":
            for row in el.iter(f"{W}tr"):
                cells = [" ".join(t.text or "" for t in c.iter(f"{W}t")).strip() for c in row.iter(f"{W}tc")]
                out.append("| " + " | ".join(cells) + " |")
    return "\n".join(out) + "\n"


def code_entries(folder):
    """Yield (display name, inner path, read function) for files on disk and inside zips (read in memory)."""
    for path in sorted(folder.rglob("*")):
        rel = path.relative_to(folder).as_posix()
        if path.is_dir() or SKIP_DIR.search(rel):
            continue
        if path.suffix.lower() == ".zip":
            with zipfile.ZipFile(path) as z:
                for info in z.infolist():
                    inner = info.filename
                    if info.is_dir() or SKIP_DIR.search(inner):
                        continue
                    yield f"{rel} :: {inner}", inner, (lambda z=z, i=info: z.read(i))
        else:
            yield rel, rel, path.read_bytes


def main():
    if len(sys.argv) != 2 or not re.fullmatch(r"day\d+", sys.argv[1].lower()):
        print(__doc__)
        sys.exit(1)
    day = sys.argv[1].lower()
    folder = next((p for p in SOURCES.iterdir() if p.is_dir() and p.name.lower() == day), None) if SOURCES.exists() else None
    if not folder:
        print(f"No folder for {day} in {SOURCES}. Unzip the day's material there first.")
        sys.exit(1)
    out_dir = ROOT / "docs" / day / "sources"
    out_dir.mkdir(parents=True, exist_ok=True)

    decks = sorted(folder.rglob("*.pptx"))
    sheets = sorted(folder.rglob("*.docx"))
    (out_dir / "slides.md").write_text("\n".join(pptx(p) for p in decks) or "No .pptx found.\n", encoding="utf-8")
    (out_dir / "assignments.md").write_text("\n".join(docx(p) for p in sheets) or "No .docx found.\n", encoding="utf-8")

    index, bodies, skipped = [], [], []
    for shown, inner, read in code_entries(folder):
        ext = Path(inner).suffix.lower()
        if SECRET.search(inner):
            skipped.append(shown)
            continue
        if ext not in CODE_EXT:
            continue
        data = read()
        index.append(f"- {shown} ({len(data)} bytes)")
        text = data[:MAX_FILE].decode("utf-8", errors="replace")
        lang = "python" if ext == ".py" else ""
        bodies.append(f"\n## {shown}\n\n```{lang}\n{text}\n```" + ("\n(truncated)" if len(data) > MAX_FILE else ""))
    note = ["\n## Skipped (possible secrets, never copied)"] + [f"- {s}" for s in skipped] if skipped else []
    (out_dir / "code.md").write_text("# Code examples\n\n" + "\n".join(index + note) + "\n" + "\n".join(bodies) + "\n",
                                     encoding="utf-8")
    print(f"From {folder}:")
    print(f"  {len(decks)} deck(s), {len(sheets)} assignment sheet(s), {len(index)} code file(s), {len(skipped)} skipped as secrets")
    print(f"Wrote {out_dir.relative_to(ROOT)}/slides.md, assignments.md, code.md")


if __name__ == "__main__":
    main()

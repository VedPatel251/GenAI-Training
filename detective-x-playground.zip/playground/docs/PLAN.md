# Days 2–8 plan: Detective X only

Status (2026-11-26): **Decision: Detective X only.** The BookVault Playground pages are retired (Day 1's page was
removed). Each day is built only as a Detective X division (Academy skills + cases).

Lesson content is still written in `days/<day>/lessons.py` (plus walkthroughs, hints, mistakes, practice parts),
because the Academy renders those lessons. `engine/build.py` is now only the lesson checker that `engine/build_game.py`
also calls; `start.bat`/`start.sh` build just the game.

## Approach agreed: hybrid, Day 2 first

Each Academy lesson keeps the Day 1 format (idea → runnable code → line by line → auto-checked challenge and practice), plus:

- **Runnable lessons in plain Python** that teach the core idea when the real library can't run in the browser.
- **"Run this locally" cards** (`local` field: `title`, `note`, `code`, `output`) for real library code. Already rendered by `engine/game_template.html`.
- Cases for the division: small (one skill), medium (reskinned assignments), big (murder mysteries), with 2–3 evidence variants each.

Build Day 2's division, review it with the user, then do Days 3–8.

## Standard every day must meet (set by the Day 1 beginner rewrite)

The audience may have never programmed, and the page should teach ~90% without a live session.

- Never use syntax before the lesson that teaches it. If a demo needs something new, explain it in the walkthrough.
- Every demo has a `walkthrough` (line by line). Every challenge has 2 `hints`. `build.py` fails the build otherwise.
- Add `mistakes` for the common beginner errors of each topic.
- Prefer tests that re-run the trainee's code with other inputs (`__source__`) or check printed text (`__output__`), so hard-coded answers fail.
- Test failure messages are plain English: they are shown to the trainee as-is.

## What browser Python (Brython 3.12.4) can and can't do — tested

| Works | Doesn't work |
|---|---|
| `logging` (basicConfig, handlers, custom JSON formatter, `extra=`, `logger.exception`) | `async def` / `await` — Brython turns coroutines into JS Promises, so `asyncio.run`, `gather`, `TaskGroup`, `Semaphore`, `timeout` can't run |
| `unittest.mock` (`MagicMock`, `patch`, `assert_called_once`) | Real parallelism: `threading.Thread` runs, but sequentially, so races can't be shown for real |
| generators incl. `.send()`, `heapq`, `random.seed`, `inspect.signature`, `re`, `json`, `dataclasses` | `multiprocessing`, `ProcessPoolExecutor` |
| `except*` / `ExceptionGroup`, `threading.Lock` as a context manager | pytest itself, httpx, pythonjsonlogger |

More Brython findings (tested 2026-11-26 for Day 2):
- `concurrent.futures` ThreadPoolExecutor hangs the page. Use a mini executor; real pools only on local cards.
- `time.sleep` raises NotImplementedError. Inject `sleep` / clock functions instead.
- `unittest.mock.patch("__main__.fn")` fails (no `__main__` module). `patch.object` works.
- `except*` splits wrongly: `except* ValueError` also receives the KeyError. `ExceptionGroup` itself works.
- `async def` parses (gives a coroutine) but can't be run; use generator-based loops.
- `@dataclass(slots=True)` still creates `__dict__`.
- An f-string whose `{...}` expression contains a dict literal, like `f"{fn({'a': 1})!r}"`, is a SyntaxError. Compute the value into a variable first.
- A nested function's `__qualname__` is just its name (`inner`, not `outer.<locals>.inner`). It can be assigned, so tests set the CPython value.
- Fixed in the runner: `json.JSONDecodeError` has `msg`, `pos`, `lineno`, `colno`. Messages differ from CPython, so never test error text.

Brython bug (not patched): a negative slice longer than the list, like `[1, 2][-3:]`, returns too few items (`[2]` instead of `[1, 2]`). Avoid it in tests and solutions; write `x[max(0, len(x) - 3):]`.

Brython bug (not patched): the f-string debug form prints the value with `str`, not `repr`: `f"{name=}"` gives `name=Ana` instead of `name='Ana'`. Tests that check that output must accept both.

Brython bug (fixed in both templates): `{}.setdefault(2008, [])` stored the key as the string `"2008"`. The template patches `dict.setdefault` at startup.

Gotcha: importing `unittest.mock` prints a Brython warning about asyncio to the output. Filter or silence it in the runner before Day 2 ships.

## Day 2 lesson outline (source: day2 deck, Assignment Day -2.docx, session_examples/)

Part 1 · Debugging & logging
1. Debug the overdue bug (returned loans marked overdue) — challenge: fix `overdue_loans`. Local card: launch.json + conditional breakpoint.
2. Logging levels and basicConfig — challenge: configure a logger so DEBUG shows.
3. Structured JSON logging with a custom Formatter and `extra=` — challenge: add `request_id`/`duration_ms` fields. Local card: python-json-logger.

Part 2 · Testing
4. Plain asserts + a tiny in-page test runner that collects `test_*` functions (mimics pytest output). Local card: real pytest file.
5. Fixtures (simulated with functions; local card with `@pytest.fixture`, yield teardown, conftest).
6. Parametrize — table-driven ISBN cleaning (assignment Q4). Local card: `@pytest.mark.parametrize`.
7. Mocking with `unittest.mock.patch` / `MagicMock` — fake cover API (assignment Q10).
8. Domain exceptions + loan limit (assignment Q6/Q7).

Part 3 · Concurrency
9. I/O-bound vs CPU-bound decision tree — quiz-heavy lesson.
10. Race condition simulated with an interleaving scheduler (read-modify-write lost updates), fixed with a lock. Local card: real threading demo.
11. ThreadPoolExecutor / ProcessPoolExecutor / as_completed — concepts + local cards with expected timings.

Part 4 · Async
12. Event loop built from generators (`yield` = `await`): shows cooperative scheduling and why `time.sleep` freezes the loop.
13. gather / Semaphore / timeout on the mini loop — challenge: cap concurrency at 3.
14. Retry with exponential backoff and injected fake sleep (assignment Q18).
15. FakeLLMProvider + dependency injection (assignment Q19), bridge to Day 3.
Local cards for real asyncio: gather, TaskGroup, Semaphore, timeout, to_thread, httpx capstone.

## Days 3–8 (later, same hybrid format)

| Day | Topic | Runnable idea in the browser |
|---|---|---|
| 3 | LangChain, Ollama, tools, agents | Fake LLM that returns tool calls; trainees write the tool loop / ReAct loop |
| 4 | FastAPI, Pydantic, Uvicorn, Postman | Mini router + validation with dataclasses; local cards for FastAPI/Pydantic |
| 5 | SQLAlchemy, MongoDB, middleware, JWT | Repository pattern in memory, middleware pipeline, JWT with hmac/base64 |
| 6 | Celery, RabbitMQ, webhooks | In-memory queue + worker loop, retries, webhook payloads |
| 7 | LangGraph | Mini graph engine: state, nodes, edges, conditional routing |
| 8 | RAG, embeddings, Qdrant | Toy embeddings + cosine similarity, chunking, hybrid search |

Note: `extracted/Day8/.../.env` may contain API keys — never publish its contents.

## Running and sharing

See `README.md`: `start.bat` / `start.sh` create `.venv`, rebuild Detective X and host it with `serve_lan.py`.

## Files

- `engine/game_template.html` — game page + Python runner (shared by all days)
- `days/dayN/lessons.py` — lesson content per day
- `python engine/build.py dayN` — checks every lesson with CPython
- `python engine/build_game.py` — checks lessons and cases, then writes `site/detective-x.html`
- Local network hosting: `start.bat` / `serve_lan.py` (see README)

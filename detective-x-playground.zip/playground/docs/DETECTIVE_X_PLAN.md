# Detective X: The Python Investigation Bureau — game plan

Status (2026-11-26): **Day 1 division built and published.** 21 skills (incl. Project craft), 45 cases, 85 checked steps; the exam has 13 questions (pass 10). Content: `days/day1/game.py` (skills, chapters, rules + first cases), `days/day1/cases_small.py`, `cases_medium.py`, `cases_big.py`, `cases_project.py`, `cases_final.py`. Build: `python engine/build_game.py` (or `--check <module>` for one file). Next: Day 2 division (Forensics Lab).

## 1. The pitch

You join the Python Investigation Bureau as a cadet. The city is full of crimes, and every case hides its answer in data: guest lists, door logs, phone records, receipts, torn letters, CCTV timestamps. Detectives don't guess. They **write code that proves** who did it.

To crack a case you need the right **skills**. Skills are learned at the **Academy** (one short Python lesson each). New skills unlock new cases. Small cases drill one skill, medium cases combine several, and big murder mysteries span many chapters. Behind several crimes is the same signature, a chalk **"X"**. The final case, **The X Files**, opens only when every skill is learned and every big case is closed.

## 2. How it maps onto what already exists

| Game | Today's playground | Notes |
|---|---|---|
| Academy skill | One or more lessons (idea, example, line by line, mistakes) | Content is reused almost as-is, with a detective framing |
| Small case | A lesson's challenge | Rewritten as a crime with evidence data |
| Medium / big case | New | Multi-step, several skills each |
| Field assignments | Part 5 · Assignments (Q1–Q21) | Official homework, kept to spec (see decision B) |
| Knowledge check | Wrap-up quiz | Becomes the **Detective Exam** for promotion |

The Brython engine, editor, hints, test runner and `build.py` checks are reused. New: a game hub, case screens, evidence viewer and progression.

## 3. Core loop

1. **Case board** (the hub): a cork board of case cards. Each card shows difficulty, required skills and stars earned. Locked cards show which skills they need.
2. Pick a case → **briefing**: a short story, the suspects, and the evidence files.
3. **Missing a skill?** One click goes to the Academy lesson for it, then back to the case.
4. **Investigate**: write Python against the evidence. Each case has 1 step (small), 2–3 steps (medium) or 4–6 chapters (big). Each step asks a precise question ("Who entered the archive between 22:00 and 23:00?").
5. **Submit findings** → the checker runs your code. A correct step reveals a new clue and the next piece of story.
6. **Accusation** (big cases): your code must *compute* the culprit; then the case-closed reveal plays.
7. Earn **XP, stars and badges** → rank up.

## 4. Progression

**Ranks** (by XP): Cadet → Constable → Detective → Senior Detective → Inspector → Chief Inspector. The final case requires Chief Inspector.

**Stars per case**
- ★★★ solved with no hints
- ★★ solved using informant tips (hints)
- ★ solved after "Ask the Chief" (show solution)

**Hints become "informant tips"**: each case has 2 tips; using one costs a star, never progress.

**Badges** for skills learned, for streaks ("Solved 5 cases without tips"), and for each big case closed.

**Unlocking**: a case unlocks when all its required skills are learned (see decision C).

## 5. Anti-guessing: the code must prove it

A name answer could be guessed. So every case ships with **2–3 evidence variants**. The checker re-runs the trainee's code on a hidden variant where the culprit, times and numbers differ. Only code that actually reasons from the data passes. (This reuses the `__source__` re-run technique already in the playground.)

## 6. Skill tree (Day 1) and the cases that use it

Skills come from the 61 existing lessons, grouped into 18 Academy skills. Each row lists example small cases.

| # | Skill (Academy lessons) | Small cases (examples) |
|---|---|---|
| 0 | **Orientation**: how the Bureau works, install Python, VS Code | none (tutorial case "The Coffee Thief" walks through the UI) |
| 1 | **Field notes**: print, comments, variables | *The Ransom Note*: print a reassembled note exactly |
| 2 | **Numbers**: maths, //, %, round | *The Missing Minutes*: convert 2,537 seconds of CCTV gap to mm:ss |
| 3 | **Text**: strings, slicing, methods, f-strings | *The Torn Letter*: slice the hidden word out of a message; *The Typed Confession*: normalise a witness statement |
| 4 | **Logic**: booleans, if/elif/else, truthiness | *Fingerprint Match*: decide match / partial / no match |
| 5 | **Lists** | *The Guest List*: who was invited but never signed the guestbook? |
| 6 | **Loops**: for, while, break/continue, loop-else | *Counting Footsteps*; *The Safe Cracker*: try codes until one opens |
| 7 | **Dictionaries & collections** | *Phone Records*: most-called number with Counter |
| 8 | **Functions**: def, return, args, defaults, scope | *The Alibi Checker*: a reusable function that tests alibis |
| 9 | **Errors**: tracebacks, try/except, raise | *The Corrupted Ledger*: parse a ledger that has bad lines |
| 10 | **Dates & modules**: import, datetime | *The Overdue Witness*: how many days between sightings |
| 11 | **Identity**: tuples, None, `is` vs `==` | *Twins*: same face, different person |
| 12 | **Functional tools**: lambda, sorted(key), map/filter, comprehensions | *Line-up*: sort suspects by alibi strength |
| 13 | **Generators & context managers** | *The Endless Log*: stream a huge log, stop at the first break-in |
| 14 | **Decorators** | *The Wiretap*: a decorator that records every call |
| 15 | **Classes & properties** | *The Suspect File*: a `Suspect` class with a validated age |
| 16 | **Inheritance, ABCs, composition** | *Evidence Types*: polymorphic `describe()` for weapons, documents, footage |
| 17 | **Dunders** | *The Evidence Locker*: `len`, `in`, `[]` on a locker object |
| 18 | **Dataclasses & frozen** | *Case Numbers*: frozen, hashable case IDs |

About **25 small cases** in total (some skills get two).

### Medium cases (2–3 steps, 2–4 skills each), about 8

| Case | Skills | Idea |
|---|---|---|
| The Library Heist | lists, dicts, loops | From checkout logs, find who last held the rare book before it vanished |
| The Forged Signature | text, functions | Compare signature strings; find the one with tell-tale differences |
| The Counterfeit Receipts | numbers, floats/Decimal | Totals that are off by fractions of a rupee |
| The Coded Postcards | text, comprehensions | Decode Caesar-shifted messages and find the meeting place |
| The Double Agent | sets, identity | Two contact lists; who appears in both rival gangs? |
| Timeline Reconstruction | dates, sorting, lambda | Shuffle of timestamped events → order them, find the gap |
| The Leaky Logs | generators, errors | Stream a messy server log, skip corrupt lines, find the intrusion |
| The Informant Network | classes, composition | Model informants and relays; trace who passed the message |

### Big cases (murder mysteries), 3 + final

| Case | Unlocks after | Chapters |
|---|---|---|
| **Murder at the Grand Library** | Skills 1–11 | Guestbook → door-access log → witness statements → alibi cross-check → accusation |
| **The Midnight Express** | Skills 1–14 | Reconstruct a train journey from scattered messages; a pipeline of generators; a decorator that audits the investigation |
| **The Masquerade at the Museum** | Skills 1–18 | Model guests and evidence as classes and dataclasses; dunders make the evidence locker searchable; find the impostor |
| **FINAL: The X Files** | Everything, incl. all three big cases | Every chalk X from earlier cases is a clue. Combine them to unmask X |

Each big case also leaves one **X fragment** (a coordinate, a letter, a date) that the final case needs, so the story ties together.

**The X thread so far.** Each fragment adds one new fact that narrows who X can be; never repeat an earlier fact on its own.

| # | Case | New fact |
|---|---|---|
| 1 | Day 1 intro (`days/day1/game.py`) | The chalk X on shelf 7 was drawn with the **left hand**. |
| 2 | Murder at the Grand Library | X signs with a small **V**. |
| 3 | The Midnight Express | X's timetable marks the **03:10** stop at Vasco Junction. |
| 4 | The Masquerade at the Museum | X's first move was the museum's first acquisition, MX-0001, a "Gift of V." |
| 5 | The Phantom Fines (Day 2) | The bad patch came from the staff-room laptop: X has, or borrows, a **Bureau staff badge**. |
| 6 | The Rigged Verdict (Day 2) | The rigged suite came from a deleted **Bureau Academy trainee** account: X once trained at the Bureau. |
| 7 | The Midnight Ledger (Day 2) | The vault script was typed in person on a terminal set up **left-handed**: confirms fragment 1 and that X was inside the Lab. |

Fragments 8–16 (Days 3–8) should keep narrowing: when V joined, which role, which year, until only one person fits.

## 7. Screens

1. **Bureau HQ (case board)**: cork-board grid of case cards, filters (Open, Solved, Locked), rank and XP bar, the X mystery tracker.
2. **Academy**: the skill tree, each skill showing its lessons and the cases it unlocks. Lessons render exactly like today's playground.
3. **Case file**: briefing and suspects on the left; evidence tabs (logs, CSV, messages) with a read-only viewer; code editor and **Submit findings**; clue cards appear as steps are solved.
4. **Detective profile**: rank, badges, stars, case history.
5. **Case closed** overlay: the story reveal, stars earned, what unlocked next.

Look and feel: a noir case-file style (paper folders, typed reports, rubber stamps, red string on the board) in light and dark themes. Sound is optional and off by default.

## 8. Content format (for building and reviewing)

Same approach as today: content lives in Python files and `build.py` checks it.

```python
CASE = {
    "id": "guest-list",
    "tier": "small",                 # small | medium | big | final
    "title": "The Guest List",
    "skills": ["lists"],
    "story": "...",                  # briefing text
    "suspects": [...],
    "evidence": {                    # shown in the evidence viewer and preloaded as variables
        "invited": [...],
        "signed": [...],
    },
    "variants": [ {...}, {...} ],    # hidden alternative evidence for anti-guessing
    "steps": [
        {"question": "...", "starter": "...", "solution": "...", "tests": "...", "tips": ["...", "..."], "reveal": "..."},
    ],
    "xp": 50,
}
```

`build.py` will verify: every solution passes on **every** variant, every starter fails, each variant has a different answer, every step has 2 tips, and every case's required skills exist.

## 9. Build phases

1. **Vertical slice** (review checkpoint): engine and all five screens, Orientation, 3 skills (Field notes, Text, Lists), 3 small cases, 1 medium case.
2. **Day 1 complete**: all 18 skills, ~25 small, ~8 medium, 3 big cases and the final case, the Detective Exam and the official assignments.
3. **Later days**: each training day becomes a new **Bureau division** with its own skills and cases, for example Day 2 *Forensics Lab* (debugging, logging, testing, concurrency) and Day 3 *AI Informants* (LLM agents and tools).

## 10. Known limits

- Progress is saved in each trainee's browser. Clearing site data resets it (unless decision D adds a shared store).
- Solutions are inside the page source. A determined trainee could read them; this is a learning game, not an exam.
- Input from the keyboard (`input()`) can't be used in the browser page, so cases supply data as evidence instead.

## 11. Decisions (confirmed 2026-11-24)

- **A. Final case spans the whole 8-day course.** Each training day adds a Bureau division. Day 1 ends with the first story arc (*X's first move*); **The X Files** opens only after the last division. Every big case leaves an X fragment that the final case needs.
- **B. The 21 official assignments are reskinned as cases** (same skills and difficulty, new crime stories; see section 12).
- **C. Strict locks.** A case unlocks only when its required skills are learned.
- **D. Shared leaderboard.** Trainees appear on a board (name, rank, XP, cases solved) that the trainer and trainees can see. Needs a shared data store on the published page (artifact runtime capability); per-trainee code and progress still live in their browser.

## 12. Assignments reskinned as cases

| Q | Assignment | Case | Tier |
|---|---|---|---|
| Q1 | Temperature converter | *The Frozen Body*: convert body temperatures to estimate the time of death | small |
| Q2 | Word frequency | *The Anonymous Letters*: word counts fingerprint the writer | small |
| Q3 | Pythonic filter | *The Badge Code*: filter and transform badge numbers into a lock code | small |
| Q4 | ISBN cleaner | *Smudged Serial Numbers*: clean serials of stolen goods, reject fakes | small |
| Q5 | Mutable default trap | *The Shared Notebook*: one detective's notes leak into every case | small |
| Q6 | Catalog loader | *The Smuggler's Manifest*: parse a cargo manifest without `csv` | medium |
| Q7 | min/max without built-ins | *The Shortest Alibi*: find extremes with your own functions | small |
| Q8 | Group by year | *The Cold Case Archive*: group unsolved cases by year | small |
| Q9 | Library v0 | *Evidence Room v0*: add, remove, find evidence | medium |
| Q10 | Properties & validation | *The Suspect File*: validated age and height | small |
| Q11 | Reading time calculator | *Surveillance Hours*: computed property, `from_dict`, static validator | medium |
| Q12 | LibraryItem hierarchy | *Evidence Types*: weapons, documents, footage with polymorphic `describe()` | medium |
| Q13 | Money | *The Counterfeit Notes*: a `Money` value object that refuses mixed currencies | medium |
| Q14 | Native Library | *The Evidence Locker*: `len`, `in`, `[]`, `for`, `print` on a locker | medium |
| Q15 | Reservation system | *Witness Protection*: safehouse check-in/out, overdue stays, history | big-step |
| Q16 | RecentBooks | *Last Known Locations*: keep the N most recent sightings | small |
| Q17 | Polymorphic pricing | *The Bail Calculator*: different bail rules per charge type | medium |
| Q18 | Functional pipeline | *The Forensics Pipeline*: chained transforms with an audit log | medium |
| Q19 | Mini ORM | *The Records Office*: a self-registering record base class | medium |
| Q20 | Catalog search | *The Criminal Database*: multi-filter search, top-N, group-by | medium |
| Q21 | BookVault deliverable | *Undercover at BookVault*: see note below | capstone |

**Q21 and Day 2 continuity.** Day 2's slides and code examples build on the BookVault package from Q21. If Q21 becomes a different project, Day 2 no longer lines up. Plan: keep Q21's BookVault spec unchanged and frame it as the Bureau's undercover job: *"X has been hiding messages in the BookVault library. Build their system from the inside."* This keeps the story and the course compatible.

These reskinned cases replace the generic small/medium examples in section 6 where they cover the same skill, so the total stays at about 25 small and 10 medium cases.

## 13. Leaderboard design (decision D)

- Shown on Bureau HQ: rank, detective name, XP, cases solved, big cases closed.
- On first visit a trainee picks a **detective name** (shown on the board). No email or real name needed.
- The page writes one record per trainee (name, XP, solved case IDs, last active) to the page's shared store whenever a case is solved.
- Trainer view: the same board plus a per-case solve count, to spot cases where everyone gets stuck.
- Limits to accept: trainees can see each other's names and scores; anyone who can open the page can technically write a record, so it is a motivation tool, not an exam record.

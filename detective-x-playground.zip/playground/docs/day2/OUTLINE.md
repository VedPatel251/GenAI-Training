# Day 2 outline: Forensics Lab

Status: approved (2026-11-26)

Day 2 deck: *Concurrency concepts, VS Code debugging, Logging, Pytest testing* (55 slides), assignment
sheet Q1–Q20, 20 session examples. Text dumps: `docs/day2/sources/` (git-ignored).

**Story.** After Day 1 the Bureau opens a **Forensics Lab**. Detectives no longer just read evidence; they
prove things: step through a suspect's code, read the lab's logs, write tests that convict the guilty
function, and untangle crimes where many things happened at once. The X thread: whoever leaves the chalk X
has been tampering with the lab's own tools (a patched check, a rigged test suite, a lost ledger update).
Each big case ends with one X fragment (Day 2 holds fragments 5–7 of 16).

## Coverage map

B = runs in the browser. L = a "run this on your machine" card with the real code and real output.
B+L = the browser teaches the idea in plain Python, and the card shows the real library.

| Slides | Teaching point | Lesson id | Runs | Skill |
|---|---|---|---|---|
| 1–3, 49–52 | Day overview: production Python, what's ahead | `lab-briefing` | B (predict quiz) | lab-bench |
| 4–8 | VS Code: extensions, settings.json, interpreter choice, shortcuts | `vscode-setup` | B+L (find the wrong interpreter from paths; card: settings.json) | lab-bench |
| 9–12, 14 | Why a debugger beats print; Variables, Watch, Call Stack, Debug Console; F5/F10/F11/Shift+F11 | `debugger-basics` | B+L (a `trace` helper prints locals at each step; card: the real panels) | microscope |
| 13–14, 18 | launch.json, conditional breakpoints, logpoints; the overdue bug | `conditional-breakpoints` | B+L (fix `overdue_loans`; condition = an `if` around the trace) | microscope |
| 15–16 | Log levels, basicConfig, named loggers, setLevel, handlers, format; FileHandler (gap) | `logging-levels` | B (handlers write to `StringIO`) + L (FileHandler) | logbook |
| 16–17 | JSON logs, `extra=`, `logger.exception`, stable event names, no secrets | `structured-logging` | B (own JSON `Formatter`) + L (python-json-logger 3.x: `pythonjsonlogger.json`) | logbook |
| 19–22 | Why test; `test_*` names; assert; raises with match; approx | `first-tests` | B+L (an in-page mini runner that prints pytest-style results; card: real pytest) | test-bench |
| 23–24 | Fixtures by name, fresh state, conftest, scopes, yield teardown; tmp_path, capsys (gap) | `fixtures` | B+L (mini runner injects fixtures via `inspect.signature`) | test-bench |
| 25 | parametrize: valid and invalid tables | `parametrize` | B+L (a `parametrize` decorator for the mini runner) | test-bench |
| 26 | Fakes, MagicMock, `patch.object`, `assert_called_once`, `call_args`; injecting clock and env; monkeypatch | `test-doubles` | B (+ L for `patch("module.fn")` and monkeypatch) | decoy-kit |
| 27 | Coverage: the Missing column, "100% is vanity", pyproject settings (gap) | `coverage` | B+L (a mini line tracer lists lines that never ran; card: pytest-cov) | decoy-kit |
| — (Q8) | JSON-lines import that keeps going: line numbers, blank lines, an ImportReport, strict mode | `import-report` | B | decoy-kit |
| — (Q14) | Validating records (required fields, building objects with `**`), streaming with a generator | `validate-and-stream` | B | decoy-kit |
| 28–32 | Concurrency vs parallelism, GIL facts (free-threading supported since 3.14), I/O-bound vs CPU-bound, decision tree | `concurrency-concepts` | B (classify jobs in code + predict quiz) | task-force |
| 33–34 | Threads, start/join, race conditions, Lock; RLock, Semaphore, Event, Queue | `threads-locks` | B+L (a scheduler replays a read-modify-write interleaving and loses updates, then a lock fixes it; card: a real race forced with `time.sleep(0)`) | task-force |
| 35–37 | Processes, ProcessPoolExecutor, the `__main__` guard, pickling (gap), `map` vs `submit` + `as_completed` | `executors` | B+L (a mini executor that finishes in "completion order" from fake durations; cards: real pools with timings) | task-force |
| 38–40, 46 | Why async exists; event loop; cooperative scheduling; async/await; the forgotten await; when not to use async | `event-loop` | B+L (an event loop built from generators, `yield` stands in for `await`; a blocking call freezes every task; card: real asyncio) | switchboard |
| 41–45, 47–48 | gather (return_exceptions), TaskGroup + ExceptionGroup, Semaphore, timeout and cancellation, to_thread, the cheat sheet | `async-patterns` | B+L (same mini loop with gather, a concurrency cap and deadlines; cards: TaskGroup, Semaphore, timeout, to_thread, httpx MockTransport, pytest-asyncio) | switchboard |
| — (Q18) | Retry: transient vs permanent errors, exponential backoff with a cap, jitter, injected sleep | `retry-backoff` | B | field-resilience |
| — (Q19) | Provider interface (ABC), dependency injection, fake providers, validating malformed responses | `provider-injection` | B (sync) + L (async version) | field-resilience |
| 53–54 | Knowledge check | exam | quiz | all |

20 lessons (the JSON-lines import was split into `import-report` and `validate-and-stream` after review), about 50 practice parts.

## Assignments -> cases

Assignment reskins keep the assignment's functions, rules and edge cases. Cases provide a small Day 1
BookVault core (`Book`, `Member`, `Loan`, `Library`, `clean_isbn`, the exception family) as evidence where needed.

| Q | What it asks | Case id | Tier | Chapter |
|---|---|---|---|---|
| 1 | Project layout, settings, interpreter; structured logging | `wrong-interpreter` + `json-trail` (+ capstone checklist) | small + medium | 4 |
| 2 | Debug and fix `overdue_loans` | `overdue-mixup` | medium | 4 |
| 3 | 7+ tests for `Book` | `book-inquest` | medium | 5 |
| 4 | Parametrized `clean_isbn` tests | `forged-isbns` | small | 5 |
| 5 | Fixtures, fresh state per test | `fresh-evidence` | medium | 5 |
| 6 | Domain exception hierarchy | `exception-lineup` | small | 5 |
| 7 | Loan limit + `LoanLimitExceededError` | `loan-limit` | medium | 5 |
| 8 | JSONL loader that keeps going, ImportReport | `smuggled-records` | medium | 5 |
| 9 | CLI tests with capsys, tmp_path | capstone (local) | — | 6 |
| 10 | Fake env, clock and cover API | `fake-clock` | medium | 5 |
| 11 | Concurrent cover import, benchmark | `cover-raid` | medium | 6 |
| 12 | Race lab, fix with Lock | `race-lab` | small | 6 |
| 13 | ProcessPool, `__main__`, pickling | `heavy-lifting` | small | 6 |
| 14 | Streaming import pipeline, strict / non-strict | `paper-trail` | medium | 5 |
| 15 | Concurrent multi-file import, deterministic merge | `merged-manifests` | medium | 6 |
| 16 | Async cover fetcher: Semaphore, timeout, partial failures | `switchboard-jam` | medium | 6 |
| 17 | MockTransport async tests | capstone (local) | — | 6 |
| 18 | Retry with backoff | `retry-storm` | medium | 6 |
| 19 | LLM provider interface, fake provider | `false-informant` | medium | 6 |
| 20 | Production upgrade deliverable | `forensics-upgrade` | capstone | 6 |

Extra small cases so every skill has one: `breakpoint-hunt` (microscope), `silent-alarm` (logbook:
which records a handler level drops), `coverage-gap` (decoy-kit: which lines never ran), `crossed-lines`
(switchboard: a call that never releases the line), `second-attempt` (field-resilience: which failed upload
was refused on purpose, not transient).

`json-trail` has three steps: the logger (formatter given), then the JSON formatter, then the culprit.

**Totals:** 10 small, 13 medium (8 in `cases_medium.py`, 5 in `cases_taskforce.py`), 3 big, 1 exam,
1 capstone (28 cases). The build reports 11,135 case XP across Days 1 and 2 (Day 2 adds about 5,100).

## Gaps the deck doesn't teach but the assignments need
- `logging.FileHandler`; handler level vs logger level (Q1)
- `tmp_path`, `capsys`, monkeypatch `setenv` (Q8, Q9, Q10)
- JSON-lines import with line numbers, strict flag, keeping the raw line (Q8, Q14)
- Retry, backoff, jitter, transient vs permanent errors (Q18; reused on Days 3 and 6)
- Dependency injection and validating malformed LLM output (Q19; reused on Day 3)
- What can be pickled (Q13); pytest-asyncio and httpx MockTransport (Q17, local only)
- Coverage settings in pyproject.toml (Q20)
- "renew" and "member history" in Q20 are never taught: capstone checklist only (trainer note)

## Skills and chapters

| Ch | Chapter | Skill | Title / badge | Lessons |
|---|---|---|---|---|
| 4 | Lab Technician | `lab-bench` | Lab bench / Lab coat | lab-briefing, vscode-setup |
| 4 | | `microscope` | Microscope / Microscope | debugger-basics, conditional-breakpoints |
| 4 | | `logbook` | Lab logbook / Ledger | logging-levels, structured-logging |
| 5 | Forensic Examiner | `test-bench` | Test bench / Test tubes | first-tests, fixtures, parametrize |
| 5 | | `decoy-kit` | Decoy kit / Mannequin | test-doubles, coverage, import-report, validate-and-stream |
| 6 | Task Force | `task-force` | Task force / Walkie-talkie | concurrency-concepts, threads-locks, executors |
| 6 | | `switchboard` | Switchboard / Telephone exchange | event-loop, async-patterns |
| 6 | | `field-resilience` | Field resilience / Grappling hook | retry-backoff, provider-injection |

## Big cases (one per chapter)
- **Ch 4 `phantom-fines`**: patrons are fined for books they returned. Trace the structured JSON log to
  the request and code path that flagged a returned loan, and name the clerk whose patch dropped the
  `returned_on` check.
- **Ch 5 `rigged-verdict`**: a green test suite convicted an innocent function. Write table-driven tests
  with fakes that expose which of the suspect implementations is really wrong (shared state, a real clock,
  a swallowed error).
- **Ch 6 `midnight-ledger`**: the vault ledger lost deposits overnight. Replay the interleaving schedule,
  count the lost updates, find whose write was overwritten, then prove a lock plus a retrying transfer balances the books.

X fragments 5–7 (one new fact each; the full thread is in `docs/DETECTIVE_X_PLAN.md`): X has a Bureau staff
badge (phantom-fines), X once trained at the Bureau Academy (rigged-verdict), X is left-handed and was inside
the Lab (midnight-ledger, service account `svc_vault`).

Exam `forensics-exam`: 12–15 questions covering the knowledge-check topics. Capstone `forensics-upgrade` (Q20, plus Q9 and Q17): local cards and a checklist.

## What the browser's Python can't do (tested 2026-11-26)
- `concurrent.futures` pools hang the page → mini executor in lessons; real pools on local cards.
- `time.sleep` raises NotImplementedError → always inject `sleep`/`clock` (good testing practice anyway).
- `patch("__main__.fn")` fails → teach `patch.object` and injected fakes; `patch("module.fn")` on a local card.
- `except*` matches the wrong exceptions (Brython bug) → ExceptionGroup itself works; `except*` only on local cards.
- `async def` parses but can't be run → generator-based event loop.
- Threads run one after another, so no real race → a replayed interleaving.
- `@dataclass(slots=True)` still has `__dict__` → don't demonstrate slots.
- Works: logging (custom Formatter, `extra=`, `exception`), `unittest.mock` (MagicMock, `patch.object`,
  `call_args`), `inspect.signature`, `contextlib.redirect_stdout`, `os.environ`, `queue`, `threading.Lock`.
- Fixed in the runner today: `json.JSONDecodeError` now has `msg`, `pos`, `lineno`, `colno` like CPython
  (messages still differ, so tests never compare error text).

## Corrections to the source material (taught correctly here; list for trainers)
- Slide 34 / Q12: on Python 3.10+ the `counter += 1` race rarely shows; force a switch with `time.sleep(0)`.
- Slide 35: leaving out the `__main__` guard raises a RuntimeError under spawn, not a fork bomb.
- Slide 30: free-threading is officially supported in 3.14.
- Slide 43: the quoted provider rate limits are tier-dependent; a semaphore limits concurrency, not requests per second.
- Slide 16: `pythonjsonlogger.jsonlogger` is deprecated in 3.x; use `pythonjsonlogger.json`.
- Slide 7 / Q1: on Windows the interpreter is `.venv\Scripts\python.exe`.
- Slide 18: the example test fails for the wrong reason (empty library).
- Slide 37: `result(timeout=5)` inside `as_completed` never times out.
- Slide 42: the `t1.result()` line can't run (the ExceptionGroup is raised first).
- Slide 45: `queries` is undefined. Slide 36: `requests.get` without a timeout.
- Slide 47 / example 06_f: invalid JSON isn't caught, so one bad response cancels the TaskGroup.
- Slide 38 mentions "Day 9".
- Example `clean_isbn` strips letters, so Q4's "invalid" `978abc0132350884` passes; it also drops an ISBN-10 `X`.

## Defaults chosen for ambiguous assignment points
- Q3 vs Q6: `ItemUnavailableError(BookVaultError, ValueError)`, so both questions' tests hold.
- Q7: the assignment's name `LoanLimitExceededError`; `Library(max_active_loans=3)`.
- Q5 / Q7: `Library(name)` with `add_item(item)`.
- Q8: magazine ids start with `MG`, so they don't clash with member `M001`.
- Q10: env var `BOOKVAULT_DATA_PATH` (the assignment's name).
- Q13: pages × 100 (×10,000 takes minutes).
- Q20: coverage target 85% as the assignment says.
- Q2: `today` passed by keyword.

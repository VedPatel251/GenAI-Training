# Day 2 case audit: remaining fixes

**Status 2026-11-27 (second session): all items below are applied.** Every Day 2 case file passes
`build_game.py --check`; the preview build passes `/verify-brython` (70 lessons, 226 parts, 69 cases,
450 runs, nothing bad). Notes: the small rigged-verdict step 4 still names the three kinds of bad value
(the trainee picks the values); fake-clock keeps two `__source__` checks (no `date.today()`, no
`os.environ` edits) because they have no behaviour to observe. Remaining: user play-test, then `/ship-division day2`.

Written 2026-11-27 when the first session was stopped (usage limits). Four `case-auditor` reviews ran on the
Day 2 case files. `cases_small.py` fixes are **done**. The writers of the other three files were stopped
part-way through their fixes, so check what is already done before changing anything.

State at hand-over (`python engine/build_game.py --check <module> --day day2`):
- `cases_small.py`: 10 cases, 0 problems. All audit fixes applied.
- `cases_medium.py`: 8 cases, 0 problems, but the fixes below were **not yet applied** (writer had just started).
- `cases_taskforce.py`: 3 problems: fixes half-applied (writer was fixing a test input that fed invalid JSON).
- `cases_big.py`: 6 problems: fixes half-applied (writer was adding new reference desks to `_RV_TRUTH` in rigged-verdict).
- `cases_final.py`: 0 problems (not audited; exam facts could use one review).

Rules for every fix (also in `.claude/skills/write-cases/SKILL.md`): no dict literal inside an f-string
expression (Brython SyntaxError, compute into `_var` first); every suspect note, reveal, closing and
fragment true on EVERY variant; prefer behaviour checks (spies, fakes) over searching `__source__` / `__output__`.

## cases_medium.py (chapters 4–5)
1. **Cheat:** in book-inquest, fresh-evidence, loan-limit, fake-clock the trainee can redefine `lab_run` /
   `lab_fixtures` / `lab_swap` / `run_tests` and print "N passed, 0 failed" with empty tests. Save private
   copies at the end of each evidence script (`_lab_run = lab_run` …); hidden tests assert
   `lab_run is _lab_run` and use only the `_` copies; replace the `__output__` "passed" check with running
   `_lab_run(name, real) == []` and counting the trainee's `test_` functions.
2. **Cheat:** overdue-mixup step 1 passes by printing "PAUSED" without calling `pause()`: count calls with a
   spy `pause` in the evidence. Add `today=TODAY` to the pause call (Q2 asks to inspect `today`).
3. **False on some variants:** book-inquest suspect notes (Jory, Kemp, Hollis); fresh-evidence notes (Omar,
   Ravi) and closing → "one or more fixtures handed out the same evidence twice, or built the wrong library";
   loan-limit story "three clerks" → four, Wes's note, step-2 reveal → "each guilty limit fails a different
   test"; smuggled-records step-2 reveal → "the other couriers had a stray bad line at most"; fake-clock notes
   (Mara, Odile); paper-trail variant 3: give Wynn a third forgery.
4. **Unstated checks:** json-trail step 1 "exactly these keys, nothing else" + message showing expected vs got;
   fresh-evidence step 1 "each fixture builds a new object every time it runs"; book-inquest step 2 say what
   `b` is in the repr test; fresh-evidence step 2 explain what `test_empty_after_borrow` catches; loan-limit
   step 2 move the `make_library` explanation from the tip into "You have"; for every "most often" answer
   (hoarder, culprit, smuggler, forger) add "`max(d, key=d.get)` gives the key with the biggest value".
5. **Size:** json-trail: step 1 gives `JsonFormatter`, trainee writes `setup_logger`; step 2 = `format`;
   step 3 = culprit. smuggled-records step 1: the two `@property` methods in the starter.
6. **Fidelity:** paper-trail (Q14): trainee writes at least `test_strict_raises` and `test_missing_field`, or
   the story says the lab's checker stands in for the 7 tests; smuggled-records: "on your machine
   `load_items` takes a path; the tests use `tmp_path`"; fake-clock: says it injects env/clock/fetcher instead
   of monkeypatch and points to the lesson's monkeypatch card.

## cases_taskforce.py (chapter 6 mediums)
1. **False on some variants (most important):** cover-raid notes (Rao "used 5 workers", Okafor "slowest report
   by far", Mbeki "most workers"); merged-manifests closing "smuggler's manifest was perfectly tidy";
   switchboard-jam step 3 reveal "every stall came from one mirror", "upgrade log names its keeper", Quist
   "returns a lot of errors", step 2 reveal "finishes in about a second"; retry-storm closing "the client that
   retried the most wasn't the culprit"; false-informant Briar note + closing.
2. **Cheat:** merged-manifests step 1 passes with a plain loop plus a comment. Spy: subclass `MiniExecutor`
   recording each `submit`, put it in the namespace as `MiniExecutor`, assert one submit per path. Same for
   cover-raid step 2.
3. **Clarity:** switchboard-jam step 2 keys in the same order as `isbns`; step 1 notes on why `client` is passed
   in and that `timeout` is in ms; give `CoverResult` fully in the starter. false-informant step 1: notes that
   `True`/`False` count as ints (check `isinstance(c, bool)` first); "take it with `self.replies.pop(0)`";
   `list(informants)[0]`; "(unlike the lesson's demo, the provider catches JSONDecodeError itself)"; consider
   3 steps; mention Q19's research note in the closing. retry-storm: step 1 = `is_transient` + `backoff`,
   step 2 = `fetch_with_retry` + probe with the batch folded in; notes: bare `raise` re-raises. cover-raid
   step 2 example "arrive in the order: the 100 ms one, the 200 ms one, then the 300 ms one".

## cases_big.py (chapter finales)
1. **phantom-fines:** step 3 shortcut `handler_of[phantom[0]["request_id"]]` passes: add a stray phantom fine
   from a second handler in 1–2 variants; step 4's `_FINES_GUILTY` uses `max(phantom_by_handler, key=...)`;
   state the tie rule. Reveals/notes true on all variants (step 3 "only logging its own failures", step 4 "the
   note sounds harmless", Tomas/Wen notes). Split step 5 into 5a `refunds` and 5b `JsonFormatter.format` + log
   lines. Optional: callback to Day 1's capstone ending (a borrower ID that is just "X").
2. **rigged-verdict:** `cleared = True` hard-coded passes, so drop or replace it with something that varies. Story
   "suspended the newest clerk" → "suspended one of the clerks, the `scapegoat`"; step 1 reveal → "some of the
   old tests…". Steps 2–4 dictate every line: let the trainee choose the four due dates from the stated fee rule
   (tests judge rows by behaviour against the mutants) and describe what step 3's test must prove; note how a
   parametrized row label looks (step 5 reads labels).
3. **midnight-ledger:** step 3 notes that `replay_night` uses its own rotation (unlocked total differs from
   step 1, only the locked total must equal `expected_balance`); reveal "same tellers, same deposits". Step 4:
   give `retry` in the starter, keep only the posting loop producing `bounced_by_teller` (red-herring proof).
   Step 5: state the tie rule.
4. **X thread (fragments 5–7):** they repeat "03:10" and "V" without narrowing anything. Each should add one new
   fact that rules suspects out, consistent with Day 1's fragments (`days/day1/cases_big.py`, `game.py`,
   `cases_final.py`): e.g. staff-room laptop (X has staff access), the deleted account's creator role/year,
   something echoing Day 1's left-handedness. Rename the service account `v.vault` → `svc_vault`. Consider writing
   the full X plan (who V is, what each of the 16 fragments adds) in `docs/DETECTIVE_X_PLAN.md` first.

## After the fixes
1. `python engine/build_game.py --day day2 --no-write` passes; the shipped build (`python engine/build_game.py`) still passes.
2. `/verify-brython` on a preview build (`python engine/build_game.py --day day2`), in an isolated copy so the
   real `lan/board.json` / `lan/accounts.json` are untouched (sign-in is required on the LAN now).
3. Update `docs/day2/OUTLINE.md` (10 small cases incl. `crossed-lines`, `second-attempt`; split `import-report`),
   then the user play-tests; then `/ship-division day2`.

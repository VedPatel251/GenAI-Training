#!/usr/bin/env sh
# One-command start for macOS / Linux: creates the virtual environment if needed,
# rebuilds Detective X, then hosts it on your network.
# Usage: sh start.sh        or   sh start.sh 9000   for another port.
set -e
cd "$(dirname "$0")"

if [ ! -x ".venv/bin/python" ]; then
    echo "Creating the virtual environment in .venv ..."
    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements.txt --quiet --disable-pip-version-check
fi

echo "Building Detective X ..."
.venv/bin/python engine/build_game.py

exec .venv/bin/python serve_lan.py "$@"

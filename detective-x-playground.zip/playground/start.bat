@echo off
rem One-click start for Windows: creates the virtual environment if needed,
rem rebuilds Detective X, then hosts it on your network.
rem Usage: double-click start.bat, or run "start.bat 9000" for another port.

cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Creating the virtual environment in .venv ...
    python -m venv .venv || py -m venv .venv
    if not exist ".venv\Scripts\python.exe" (
        echo Could not create .venv. Is Python 3.11+ installed and on PATH?
        pause
        exit /b 1
    )
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt --quiet --disable-pip-version-check
)

echo Building Detective X ...
".venv\Scripts\python.exe" engine\build_game.py || goto :failed

".venv\Scripts\python.exe" serve_lan.py %*
pause
exit /b 0

:failed
echo The build found a problem. Read the messages above, fix it, and run start.bat again.
pause
exit /b 1

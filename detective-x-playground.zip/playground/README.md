# GenAI Training: Detective X

Browser-based Python training for the GenAI course. Python runs **inside the browser**, so trainees install nothing. Day 1 is complete; Days 2–8 will be added to this same project, one folder each.

Each training day is a **division** of the Detective X game. (The earlier BookVault Playground pages were retired; their lessons live on in the game's Academy.)

| Page | What it is |
|---|---|
| **Detective X** (`site/detective-x.html`, one game for the whole course) | Learn Python by solving crimes. The Academy teaches each skill with runnable examples, line-by-line explanations, common mistakes, hints and auto-checked practice; Day 1 runs from "install Python" through dataclasses to building a real project. Then solve crimes by writing code that proves who did it. Each training day adds a division; Day 1 has 21 skills in 3 chapters, 45 cases including 3 murder mysteries, a promotion exam and a field operation (assignment Q21). Ranks, stars and a shared leaderboard run across the whole course. |

---

## Quick start (host it on your laptop for the team)

**Windows:** double-click **`start.bat`** in this folder. Or in a terminal:

```powershell
.\start.bat
```

**macOS / Linux:**

```sh
sh start.sh
```

The script:
1. creates a virtual environment in `.venv` (first run only),
2. rebuilds both pages and checks every lesson and case,
3. starts a server on port **8080** and prints the addresses to share.

```
Serving GenAI Training Day 1. Teammates on the same network can open:
    http://YOUR-PC-NAME:8080
    http://192.168.x.x:8080

On this laptop: http://localhost:8080   (shows Trainer insights)
```

- Teammates open `http://YOUR-PC-NAME:8080` (or the IP address) in their browser.
- You open `http://localhost:8080` to see the leaderboard **plus Trainer insights**: how many trainees solved each case and their average stars.
- Stop the server with **Ctrl + C**. Use another port with `start.bat 9000` (or `sh start.sh 9000`).

### Detective accounts (sign-in)

On your laptop server, every trainee signs in with a **detective name and password**, so they get their progress back from any browser or computer.

- **New trainee:** on the sign-in screen, "I'm new: create a detective", then pick a name and password.
- **You add someone:** Leaderboard → **Detective accounts** → *Add a detective*. Leave the password blank and their starting password is their detective name. They must choose their own at first sign-in.
- **Players from before accounts existed** get an account automatically on the next server start, with their detective name as the starting password.
- **Forgot password:** Leaderboard → Detective accounts → *Reset password* (back to their name, or type one). They must change it at the next sign-in.
- **Change password / sign out:** Profile → Account.
- Solved cases, lessons and XP follow the detective; code typed into editors stays in the browser where it was written.
- *Detective accounts* also lists leaderboard rows with no account (old duplicates), with *Remove row*.

Accounts are kept in `lan/accounts.json` (passwords salted and hashed). The server uses plain http, so this is fine for a training trial, but tell trainees not to reuse a real password. On the claude.ai link no passwords are needed: claude.ai's own sign-in identifies people.

> **First run on Windows:** if Windows asks whether Python may accept network connections, allow it on **Private networks**. If teammates still can't connect, run this once in an **administrator** PowerShell:
>
> ```powershell
> New-NetFirewallRule -DisplayName "GenAI Training 8080" -Direction Inbound -Protocol TCP -LocalPort 8080 -Action Allow -Profile Private,Domain
> ```

---

## Requirements

- **Python 3.11 or newer** (`python --version`; on macOS `python3 --version`).
- Nothing else. All scripts use only Python's standard library. `requirements.txt` exists so the usual `pip install -r requirements.txt` step works, but it installs nothing.
- The first start downloads the in-browser Python engine (Brython, about 5.5 MB) once into `lan/static/`. After that the server works without internet. Without internet, fonts fall back to system fonts.

---

## Manual setup (if you prefer typing the steps)

```powershell
cd playground
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python engine/build_game.py
python serve_lan.py
```

On macOS / Linux use `python3 -m venv .venv` and `source .venv/bin/activate`.

In **VS Code**: open the `playground` folder, press **Ctrl+Shift+P → Python: Select Interpreter**, choose `.venv`, then open `serve_lan.py` and click **▶ Run Python File**.

---

## Using it on claude.ai instead

Detective X is also published as a claude.ai artifact. Share it from the page's **Share** menu and give trainees **Contributor** access, otherwise they can play but won't appear on the leaderboard.

On claude.ai the leaderboard uses claude.ai's own storage; on your laptop it uses `lan/board.json`. The game detects which one to use automatically.

---

## Project layout

```
playground/
├── README.md
├── CLAUDE.md                  project guide for Claude Code (layout, rules, pipeline)
├── .claude/                   Claude Code pipeline: skills, agents, settings, content-check hook
├── start.bat / start.sh       one-command setup + build + host
├── serve_lan.py               hosts Detective X and the laptop leaderboard
├── requirements.txt           (no third-party packages)
│
├── engine/                    shared by every day
│   ├── build.py                   lesson checker (build_game.py runs it too)
│   ├── build_game.py              builds + checks Detective X         → site/detective-x.html
│   ├── new_day.py                 scaffolds a new day's division
│   ├── extract_sources.py         dumps a day's deck/assignments/code to docs/dayN/sources/
│   ├── brython_check.js           runs every lesson and case in the browser's Python
│   └── game_template.html         game design: HQ, Academy, case files, leaderboard
│
├── days/                      course content, one Python package per day
│   └── day1/
│       ├── lessons.py             Day 1 lessons from the deck, plus the assignment questions
│       ├── basics.py              "Start here": install Python, print, variables ... functions
│       ├── beginner.py            line-by-line notes, hints, simpler demos, lesson order
│       ├── practice_a.py, practice_b.py   extra practice parts so every lesson's practice covers what it teaches
│       ├── project.py             "Building a real project": type hints, exceptions, JSON, modules, CLI
│       ├── game.py                Detective X division: skills, chapters, ranks, XP, unlock rules
│       ├── cases_small.py         small cases (one skill each)
│       ├── cases_medium.py        medium cases (mostly reskinned assignments)
│       ├── cases_big.py           the three murder mysteries
│       ├── cases_project.py       Project craft cases (The Dead Drop, The Leaked Dossier)
│       └── cases_final.py         Detective Exam and the BookVault field operation (Q21)
│
├── site/                      built pages (regenerate; don't edit by hand)
│   └── detective-x.html
│
├── docs/
│   ├── PLAN.md                    plan for Days 2–8 and browser-Python limits
│   └── DETECTIVE_X_PLAN.md        the game design
│
└── lan/                       created by serve_lan.py (pages, engine, board.json, accounts.json); not committed
```

**Adding a day:** open this folder in Claude Code and run `/new-division day2`. It walks through:

| Stage | Skill | What happens | You review |
|---|---|---|---|
| 0 | (scaffold) | `python engine/new_day.py day2 "Forensics Lab"` creates `days/day2/` and `docs/day2/OUTLINE.md` | |
| 1 | `/research-day` | extracts `../extracted/day2` and maps every slide and assignment question to lessons, skills and cases | the outline |
| 2 | `/write-lessons` | `lesson-writer` agents write the Academy lessons; `beginner-reviewer` checks them | lessons (preview build) |
| 3 | `/write-cases` | `case-writer` agents write small, medium, big cases and the exam; `case-auditor` checks them | the case board |
| 4 | `/verify-brython` | runs every lesson and case in the browser's Python | |
| 5 | `/ship-division` | adds the day to `DIVISIONS`, builds, publishes, updates docs, commits | what to upload |

While content is being written, a hook re-checks the day after every edit (`.claude/hooks/check_content.py`).
By hand: `python engine/build_game.py --day day2 --no-write` checks a day before it ships.

## Changing content

1. Edit the Python content files in `days/day1/`. Each lesson and case is a plain dictionary; the docstring at the top of each file explains the fields.
2. Rebuild (from the `playground` folder):

   ```powershell
   python engine/build.py day1                         # quick check of the lessons only
   python engine/build_game.py                         # check everything and build Detective X
   python engine/build_game.py --check cases_medium    # check just one case file
   ```

3. Restart `serve_lan.py` (or `start.bat`) so the laptop server picks up the new pages.

**The builds check content before writing anything:**
- Every example runs.
- Every reference solution passes, on **every** evidence version for game cases.
- Every untouched starter fails.
- Every example has line-by-line notes, and every challenge has 2 hints.
- Game answers differ between evidence versions, so a typed-in answer can't pass.
- Unlock rules are possible to meet, and every skill is in exactly one chapter.

If anything fails, the build prints `PROBLEM: ...` and writes nothing.

**Rules for new content** (so beginners can follow):
- Only use Python syntax taught in an earlier lesson or skill; explain anything new in the walkthrough or question.
- Test messages are shown to trainees as-is, so write them in plain English and never reveal another evidence version's answer.
- The in-browser Python (Brython) can't run `input()`, files, threads, `asyncio` or third-party packages. Avoid negative slices longer than the list (e.g. `[1, 2][-3:]`), which Brython gets wrong.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `'python' is not recognized` | Install Python 3.11+ and tick **Add python.exe to PATH**, or use `py` instead of `python`. |
| `Port 8080 is already used by another program` | Start on another port: `start.bat 9000` / `python serve_lan.py 9000`. |
| Teammates can't open the address | Same Wi-Fi/network? Firewall rule above? Try the IP address instead of the PC name. |
| Pill says "Python failed to load" | The page shows a red box with the reason. On the laptop server, delete `lan/static/` and restart so the engine downloads again. |
| Leaderboard empty on the laptop | It fills as trainees solve cases. Scores live in `lan/board.json`; delete it to start a fresh board (with the server stopped). |
| "Create a new detective" again after reopening | Sign in with the detective's name and password instead. Browsers keep separate saves per address (localhost vs PC name vs IP, port 8080 vs 8095), which is why accounts exist. |
| Trainee forgot their password | Leaderboard → Detective accounts → Reset password, on the laptop running the server. |
| Changes don't show up | Rebuild, restart the server, then reload the browser page. |

---

## Privacy

- `lan/board.json` holds trainees' chosen detective names and scores, and `lan/accounts.json` their hashed passwords. Both are excluded by `.gitignore`; don't share them.
- Progress and code drafts are also saved in each trainee's own browser.
- Scores can only be posted by a signed-in detective, but this is a trial setup over plain http: treat the leaderboard as motivation, not an exam record.

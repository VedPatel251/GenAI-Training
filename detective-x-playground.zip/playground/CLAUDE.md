# Detective X: GenAI training as a Python detective game

Browser game that teaches the 8-day GenAI training course. Python runs in the browser (Brython 3.12.4),
so trainees install nothing. Each training day is a **division**: Academy lessons (skills) plus crime
cases solved by writing code. Day 1 is done; Days 2–8 are built with the pipeline below.

**Detective X is the only product.** The old BookVault Playground pages are retired: never recreate
`dayN.html` pages or a playground template. ("BookVault" is still the name of the course's assignment
project, which cases may reference.)

## Layout

- `days/<day>/lessons.py`: the day's Academy lessons (format in its docstring). Day 1 also layers in
  `basics.py`, `beginner.py`, `practice_a.py`, `practice_b.py`, `project.py`; new days write everything inline.
- `days/<day>/game.py`: the division: `DIVISION`, `SKILLS`, `CHAPTERS`, `UNLOCKS`, and `CASES` loaded from
  `cases_small.py`, `cases_medium.py`, `cases_big.py`, `cases_final.py`. Course-wide settings (ranks, XP,
  X fragments) live only in `days/day1/game.py`.
- `engine/build_game.py`: checks everything with CPython and writes `site/detective-x.html`.
  `DIVISIONS` lists the shipped days. `--day dayN --no-write` checks a day that isn't shipped yet.
- `engine/build.py`: lesson-only checker. `engine/game_template.html`: the whole game UI and Python runner.
- `engine/new_day.py`: scaffolds a new division. `engine/extract_sources.py`: dumps a day's deck,
  assignment sheet and code to `docs/<day>/sources/` (git-ignored). `engine/brython_check.js`: the in-browser regression.
- `serve_lan.py` / `start.bat` / `start.sh`: host the game on the LAN with a shared leaderboard (`lan/board.json`) and
  detective sign-in accounts (`lan/accounts.json`, trainer resets passwords from Trainer insights).
- Course material (decks, assignments, examples) is outside the repo in `../extracted/<day>/`.
- `docs/PLAN.md` (Days 2–8 plan + Brython limits), `docs/DETECTIVE_X_PLAN.md` (game design), `docs/<day>/OUTLINE.md`.

## Pipeline for a new day

Run `/new-division dayN`. It drives these skills in order, with a user review between stages:
1. `/research-day`: extract sources and write `docs/dayN/OUTLINE.md` (coverage map). **User approves.**
2. `/write-lessons`: Academy lessons, part by part (agent `lesson-writer`, reviewed by `beginner-reviewer`).
3. `/write-cases`: small, medium, big, exam (agent `case-writer`, reviewed by `case-auditor`).
4. `/verify-brython`: run every lesson and case in the real browser engine.
5. `/ship-division`: add to `DIVISIONS`, build, publish the artifact, update docs, commit.

A PostToolUse hook (`.claude/hooks/check_content.py`) re-checks a day after every edit to `days/<day>/*.py`
and reports problems back. Fix them before moving on.

## Content rules (every day)

- Audience: may never have programmed. The game should teach ~90% without a live session.
- Never use syntax before the lesson/skill that teaches it. Day 1 skills are always known on later days.
- Every demo has a line-by-line `walkthrough`; every challenge, practice part and case step has exactly 2 hints/tips.
- A lesson's practice covers **everything** the lesson teaches (several parts if needed).
- Cases: 2–3 evidence `variants`, the answer differs per variant, tests compute the expected answer
  from the evidence (never hard-code it), the starter must fail. Failure messages are plain English.
- Real libraries the browser can't run (pytest, asyncio, httpx, LangChain, FastAPI, Celery, databases)
  are taught with a browser-runnable plain-Python version of the idea plus a `local` card with real code and expected output.
- Brython quirks are in `docs/PLAN.md` (no async, sequential threads, negative long slices, `f"{x=}"` uses str,
  json errors patched, argparse `SystemExit` has no `.code`). The CPython build can pass while Brython fails:
  always run `/verify-brython` before shipping.

## Commands

```
python engine/build_game.py                         # check all shipped days + write the game
python engine/build_game.py --day day2 --no-write   # check one day (also works before it ships)
python engine/build_game.py --check cases_small --day day2
python engine/build.py day2                         # lessons only
python serve_lan.py 8095                            # local server for Brython checks (8080 is for trainees)
```
Use `.venv/Scripts/python.exe` (Windows) or `.venv/bin/python` if plain `python` lacks 3.11+.

## Guardrails

- **One step at a time.** Never run anything in parallel (several agents, extra sessions, workflows,
  multiple background jobs) unless the user explicitly asks for it for that task. Do one file / one stage,
  finish and check it, then the next. Small fixes: edit directly instead of starting an agent.

- Never read, copy or publish `.env` files or keys from `../extracted/` (Day 8 has one). `extract_sources.py` skips them.
- Never share `lan/board.json` (trainee names and scores) or `lan/accounts.json` (hashed passwords).
- Port 8000 on the trainer's laptop is another project's server: don't stop it. Use 8095 for tests.
- Published game: https://claude.ai/artifact/VWT6wxg76hkS69XQxSSWih (republish with `url`, keep its `db` + `user` capabilities).
- Git: this folder is the repo (pushed to a private GitHub repo by the user, by hand). Commit only when asked or
  at the end of `/ship-division`; end messages with the Co-Authored-By line the session gives.

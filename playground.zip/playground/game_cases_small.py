"""Detective X — small cases for the skills after the vertical slice.

Same format as game_day1.py. Tier "small": 1-2 steps, one main skill each.
Several are the official Day 1 assignments (Q1, Q2, Q3, Q4, Q5, Q7, Q8, Q10, Q16) with a crime story.
"""

CASES = [
    # ------------------------------------------------------------ records
    {
        "id": "phone-records",
        "tier": "small",
        "title": "Phone Records",
        "teaser": "A burner phone, a list of calls, and one number it kept dialling.",
        "skills": ["records"],
        "story": "A burner phone was found in the getaway car. The carrier sent the list of every number it `called`, in order. A number that shows up again and again is the gang's contact.\n\nCount the calls per number with a dictionary.",
        "suspects": [{"name": "the getaway driver", "note": "Says the phone isn't theirs."}],
        "variants": [
            'calls = ["98201", "77450", "98201", "11223", "98201", "77450"]\n',
            'calls = ["55102", "55102", "40011", "40011", "40011", "99870", "55102", "40011"]\n',
            'calls = ["31337", "20480", "20480", "31337", "88001", "20480"]\n',
        ],
        "steps": [
            {
                "question": "Build a dictionary `counts` that maps each number to how many times it was called. Then store the most-called number in `contact`.",
                "starter": "counts = {}\n# count the calls here\n\ncontact = ...\nprint(counts)\nprint(contact)\n",
                "solution": "counts = {}\nfor number in calls:\n    counts[number] = counts.get(number, 0) + 1\n\ncontact = calls[0]\nfor number in counts:\n    if counts[number] > counts[contact]:\n        contact = number\nprint(counts)\nprint(contact)\n",
                "tests": '''_exp = {}
for _n in calls:
    _exp[_n] = _exp.get(_n, 0) + 1
assert counts == _exp, f"counts should be {_exp}, got {counts}"
_best = max(_exp.values())
assert _exp.get(contact) == _best, f"contact should be the number called {_best} times, got {contact!r}"''',
                "tips": [
                    "`counts.get(number, 0)` gives the count so far, or 0 for a new number. Add 1 and store it back.",
                    "For the most-called number, start with `contact = calls[0]`, then loop over `counts` and switch whenever a number has a bigger count.",
                ],
                "reveal": "One number dominates the log. The carrier traces it to a flat above a pawn shop.",
            },
        ],
        "closing": "Case closed. The flat above the pawn shop was the gang's planning room. One dictionary did what a week of stakeouts couldn't.",
    },
    # ------------------------------------------------------------ functions (Q1)
    {
        "id": "frozen-body",
        "tier": "small",
        "title": "The Frozen Body",
        "teaser": "A body in a cold store. When did the victim die?",
        "skills": ["functions", "errors"],
        "story": "A body was found in a restaurant's cold store. The pathologist's thermometer reads in Fahrenheit, but the Bureau's formula needs Celsius.\n\nThe rule of thumb: a body cools about **1.5 °C per hour** from 37 °C. The reading is in `body_temp_f`.\n\n*(This is the official assignment Q1: a temperature converter.)*",
        "suspects": [{"name": "the head chef", "note": "Says they locked up at 11 pm."}, {"name": "the delivery driver", "note": "Had a key to the back door."}],
        "variants": ["body_temp_f = 80.6\n", "body_temp_f = 89.6\n", "body_temp_f = 71.6\n"],
        "steps": [
            {
                "question": "Write `convert(value, from_unit, to_unit)` for the units `\"C\"`, `\"F\"` and `\"K\"`. The same unit returns the value unchanged; any other unit raises `ValueError`. Then print the body temperature in Celsius.",
                "starter": "def convert(value, from_unit, to_unit):\n    ...\n\nprint(convert(body_temp_f, \"F\", \"C\"))\n",
                "solution": 'def convert(value, from_unit, to_unit):\n    units = ["C", "F", "K"]\n    if from_unit not in units or to_unit not in units:\n        raise ValueError("unknown unit")\n    if from_unit == to_unit:\n        return value\n    if from_unit == "C":\n        celsius = value\n    elif from_unit == "F":\n        celsius = (value - 32) * 5 / 9\n    else:\n        celsius = value - 273.15\n    if to_unit == "C":\n        return celsius\n    if to_unit == "F":\n        return celsius * 9 / 5 + 32\n    return celsius + 273.15\n\nprint(convert(body_temp_f, "F", "C"))\n',
                "tests": '''assert convert(0, "C", "F") == 32.0, "convert(0, 'C', 'F') should be 32.0"
assert convert(100, "C", "K") == 373.15, "convert(100, 'C', 'K') should be 373.15"
assert round(convert(32, "F", "C"), 2) == 0.0, "convert(32, 'F', 'C') should be 0.0"
assert convert(21.5, "C", "C") == 21.5, "the same unit should return the value unchanged"
assert round(convert(body_temp_f, "F", "C"), 2) == round((body_temp_f - 32) * 5 / 9, 2), "the body temperature in Celsius is wrong"
try:
    convert(10, "C", "X")
    raise AssertionError("an unknown unit like 'X' should raise ValueError")
except ValueError:
    pass''',
                "tips": [
                    "Convert anything to Celsius first, then from Celsius to the target: F→C is `(value - 32) * 5 / 9`, K→C is `value - 273.15`.",
                    "C→F is `c * 9 / 5 + 32` and C→K is `c + 273.15`. Check the units at the top: `if from_unit not in [\"C\", \"F\", \"K\"] ...: raise ValueError(...)`.",
                ],
                "reveal": "Now the pathologist's reading makes sense in Celsius.",
            },
            {
                "question": "Write `hours_since_death(temp_c)` that returns `(37 - temp_c) / 1.5`, rounded to 1 decimal. Store the result for this body in `hours`.",
                "starter": "def convert(value, from_unit, to_unit):\n    if from_unit == \"F\" and to_unit == \"C\":\n        return (value - 32) * 5 / 9\n    return value\n\ndef hours_since_death(temp_c):\n    ...\n\nhours = ...\nprint(hours, \"hours\")\n",
                "solution": "def convert(value, from_unit, to_unit):\n    if from_unit == \"F\" and to_unit == \"C\":\n        return (value - 32) * 5 / 9\n    return value\n\ndef hours_since_death(temp_c):\n    return round((37 - temp_c) / 1.5, 1)\n\nhours = hours_since_death(convert(body_temp_f, \"F\", \"C\"))\nprint(hours, \"hours\")\n",
                "tests": '''_c = (body_temp_f - 32) * 5 / 9
assert hours_since_death(37) == 0, "at 37 °C no time has passed"
assert hours == round((37 - _c) / 1.5, 1), f"hours should be {round((37 - _c) / 1.5, 1)}, got {hours!r}"''',
                "tips": [
                    "Inside the function: `return round((37 - temp_c) / 1.5, 1)`.",
                    'Call one function inside the other: `hours = hours_since_death(convert(body_temp_f, "F", "C"))`.',
                ],
                "reveal": "Count back that many hours from 7 am: the chef was still in the building.",
            },
        ],
        "closing": "Case closed. Two small functions, called together, broke the chef's alibi.",
    },
    # ------------------------------------------------------------ errors
    {
        "id": "corrupted-ledger",
        "tier": "small",
        "title": "The Corrupted Ledger",
        "teaser": "A smuggler's ledger, half of it smudged. Add up what you can.",
        "skills": ["errors"],
        "story": "Customs seized a smuggler's ledger. The clerk typed each amount into `ledger`, but water damage turned some entries into nonsense like `\"12OO\"` (letter O instead of zero) or `\"??\"`.\n\nThe court will accept the total of the **readable** amounts, plus a count of the damaged ones.",
        "suspects": [{"name": "the smuggler", "note": "Claims the ledger is a shopping list."}],
        "variants": [
            'ledger = ["1200", "350", "12OO", "800", "??", "45"]\n',
            'ledger = ["99", "abc", "1000", "1000", "7 00", "250", "x1"]\n',
            'ledger = ["5000", "2500", "5OOO", "125"]\n',
        ],
        "steps": [
            {
                "question": "Loop over `ledger`. Convert each entry with `int()` inside `try`; add readable amounts to `total` and count the failures in `damaged`.",
                "starter": "total = 0\ndamaged = 0\n# loop with try / except here\n\nprint(\"Total:\", total, \"Damaged:\", damaged)\n",
                "solution": "total = 0\ndamaged = 0\nfor entry in ledger:\n    try:\n        total += int(entry)\n    except ValueError:\n        damaged += 1\n\nprint(\"Total:\", total, \"Damaged:\", damaged)\n",
                "tests": '''_t, _d = 0, 0
for _e in ledger:
    try:
        _t += int(_e)
    except ValueError:
        _d += 1
assert total == _t, f"total should be {_t}, got {total!r}"
assert damaged == _d, f"damaged should be {_d}, got {damaged!r}"''',
                "tips": [
                    "Put `total += int(entry)` inside `try:`. If `int()` fails, Python jumps to `except ValueError:`.",
                    "In the `except ValueError:` block write `damaged += 1`.",
                ],
                "reveal": "The readable amounts alone exceed the import limit by a long way.",
            },
        ],
        "closing": "Case closed. Bad data didn't crash the investigation; it became evidence too.",
    },
    # ------------------------------------------------------------ toolkit
    {
        "id": "overdue-witness",
        "tier": "small",
        "title": "The Overdue Witness",
        "teaser": "A key witness stopped checking in. How long ago?",
        "skills": ["toolkit"],
        "story": "A protected witness must check in at least every **7 days**. Their `last_check_in` and `today` are dates. If the gap is longer than 7 days, the case is escalated.\n\nTip: subtracting two dates gives a `timedelta`; its `.days` is the number of days.",
        "suspects": [{"name": "the witness's handler", "note": "Was on holiday last week."}],
        "variants": [
            "from datetime import date\nlast_check_in = date(2026, 3, 1)\ntoday = date(2026, 3, 12)\n",
            "from datetime import date\nlast_check_in = date(2026, 6, 20)\ntoday = date(2026, 6, 25)\n",
            "from datetime import date\nlast_check_in = date(2026, 12, 28)\ntoday = date(2027, 1, 9)\n",
        ],
        "steps": [
            {
                "question": "Store the number of days since the last check-in in `days_missing`, and `escalate` (True or False) if it is more than 7.",
                "starter": "days_missing = ...\nescalate = ...\nprint(days_missing, escalate)\n",
                "solution": "days_missing = (today - last_check_in).days\nescalate = days_missing > 7\nprint(days_missing, escalate)\n",
                "tests": '''_d = (today - last_check_in).days
assert days_missing == _d, f"days_missing should be {_d}, got {days_missing!r}"
assert escalate is (_d > 7), f"escalate should be {_d > 7} when {_d} days have passed"''',
                "tips": [
                    "`today - last_check_in` gives a timedelta. Add `.days` to get a whole number.",
                    "`escalate = days_missing > 7` stores True or False.",
                ],
                "reveal": "The gap is on the record. The handler has some explaining to do.",
            },
        ],
        "closing": "Case closed. The witness was safe, but the handler had stopped visiting. Dates don't forget.",
    },
    # ------------------------------------------------------------ identity
    {
        "id": "rounding-fraud",
        "tier": "small",
        "title": "The Rounding Fraud",
        "teaser": "A bank teller skims fractions of a rupee. Floats can't see it.",
        "skills": ["identity"],
        "story": "A teller is suspected of skimming. Each transaction in `amounts` is stored as text, exactly as on the receipts. The teller reported `reported_total`.\n\nFloats are slightly wrong with decimals, so the Bureau insists on `Decimal` for money.",
        "suspects": [{"name": "the teller", "note": "\"It's just rounding.\""}],
        "variants": [
            'amounts = ["10.10", "20.20", "0.35", "99.99"]\nreported_total = "130.40"\n',
            'amounts = ["0.10", "0.20", "0.30", "1500.05"]\nreported_total = "1500.50"\n',
            'amounts = ["45.55", "45.55", "45.55"]\nreported_total = "136.60"\n',
        ],
        "steps": [
            {
                "question": "Compute `exact_total` as a `Decimal` sum of `amounts`. Then `skimmed = exact_total - Decimal(reported_total)`, and `honest` is True only if nothing was skimmed.",
                "starter": "from decimal import Decimal\n\nexact_total = ...\nskimmed = ...\nhonest = ...\nprint(exact_total, skimmed, honest)\n",
                "solution": "from decimal import Decimal\n\nexact_total = Decimal(\"0\")\nfor a in amounts:\n    exact_total += Decimal(a)\nskimmed = exact_total - Decimal(reported_total)\nhonest = skimmed == 0\nprint(exact_total, skimmed, honest)\n",
                "tests": '''from decimal import Decimal as _D
_t = sum((_D(a) for a in amounts), _D("0"))
assert exact_total == _t, f"exact_total should be {_t}, got {exact_total!r}"
assert isinstance(exact_total, _D), "exact_total must be a Decimal, not a float"
assert skimmed == _t - _D(reported_total), f"skimmed should be {_t - _D(reported_total)}, got {skimmed!r}"
assert honest is (_t == _D(reported_total)), "honest should be True only when skimmed is 0"''',
                "tips": [
                    "Start with `exact_total = Decimal(\"0\")` and add `Decimal(a)` for each amount. Create Decimals from the **strings**.",
                    "`skimmed = exact_total - Decimal(reported_total)` and `honest = skimmed == 0`.",
                ],
                "reveal": "Exact arithmetic shows exactly how much is missing, to the paisa.",
            },
        ],
        "closing": "Case closed. Tiny amounts, thousands of times a year: the float trap would have hidden it.",
    },
    # ------------------------------------------------------------ forensic text (Q2)
    {
        "id": "anonymous-letters",
        "tier": "small",
        "title": "The Anonymous Letters",
        "teaser": "Threatening letters. Every writer has a favourite word.",
        "skills": ["records", "forensic-text"],
        "story": "Someone is sending threatening letters to the mayor. Linguists say every writer overuses one word. The newest letter is in `letter`, and `favourite_words` maps each suspect to the word they use most in their known emails.\n\n*(This is the official assignment Q2: word frequency.)*",
        "suspects": [{"name": "the rival candidate", "note": ""}, {"name": "the former aide", "note": ""}, {"name": "the journalist", "note": ""}],
        "variants": [
            'letter = "Resign now. Resign before the vote! Everyone knows. Resign."\nfavourite_words = {"Kapoor": "everyone", "Iyer": "resign", "Mendes": "vote"}\n',
            'letter = "The truth will come out. The truth is near. Truth, always truth."\nfavourite_words = {"Kapoor": "truth", "Iyer": "near", "Mendes": "always"}\n',
            'letter = "Money talks. Your money, my silence. Silence costs money? Silence."\nfavourite_words = {"Kapoor": "money", "Iyer": "costs", "Mendes": "silence"}\n',
        ],
        "steps": [
            {
                "question": "Write `word_frequency(text)` that returns a dict of word → count. Lower-case the text and remove the punctuation `.`, `,`, `!` and `?` first.",
                "starter": "def word_frequency(text):\n    ...\n\nprint(word_frequency(letter))\n",
                "solution": 'def word_frequency(text):\n    cleaned = text.lower()\n    for mark in [".", ",", "!", "?"]:\n        cleaned = cleaned.replace(mark, "")\n    counts = {}\n    for word in cleaned.split():\n        counts[word] = counts.get(word, 0) + 1\n    return counts\n\nprint(word_frequency(letter))\n',
                "tests": '''assert word_frequency("The fox. The quick fox. The fox jumps.") == {"the": 3, "fox": 3, "quick": 1, "jumps": 1}, "on 'The fox. The quick fox. The fox jumps.' the counts are wrong"
assert word_frequency("") == {}, "an empty text should give an empty dict"
_c = letter.lower()
for _m in ".,!?":
    _c = _c.replace(_m, "")
_e = {}
for _w in _c.split():
    _e[_w] = _e.get(_w, 0) + 1
assert word_frequency(letter) == _e, "the counts for the letter are wrong"''',
                "tips": [
                    "Lower-case first, then remove each mark with `.replace(mark, \"\")`, then `.split()` into words.",
                    "Count with a dict: `counts[word] = counts.get(word, 0) + 1`.",
                ],
                "reveal": "The letter's vocabulary is on the table.",
            },
            {
                "question": "Find the letter's most frequent word (the first one, if there's a tie) and store the suspect whose favourite word matches it in `writer`.",
                "starter": 'def word_frequency(text):\n    cleaned = text.lower()\n    for mark in [".", ",", "!", "?"]:\n        cleaned = cleaned.replace(mark, "")\n    counts = {}\n    for word in cleaned.split():\n        counts[word] = counts.get(word, 0) + 1\n    return counts\n\nwriter = ...\nprint("Written by", writer)\n',
                "solution": 'def word_frequency(text):\n    cleaned = text.lower()\n    for mark in [".", ",", "!", "?"]:\n        cleaned = cleaned.replace(mark, "")\n    counts = {}\n    for word in cleaned.split():\n        counts[word] = counts.get(word, 0) + 1\n    return counts\n\ncounts = word_frequency(letter)\ntop = None\nfor word in counts:\n    if top is None or counts[word] > counts[top]:\n        top = word\n\nwriter = None\nfor suspect, word in favourite_words.items():\n    if word == top:\n        writer = suspect\nprint("Written by", writer)\n',
                "tests": '''_c = word_frequency(letter)
_top = None
for _w in _c:
    if _top is None or _c[_w] > _c[_top]:
        _top = _w
_exp = [s for s, w in favourite_words.items() if w == _top][0]
assert writer == _exp, f"the writer should be {_exp!r}, got {writer!r}"''',
                "tips": [
                    "Find the top word like the phone-records case: loop over the counts and keep the word with the biggest count.",
                    "Then loop over `favourite_words.items()` and pick the suspect whose word equals the top word.",
                ],
                "reveal": "The favourite word gives the writer away.",
            },
        ],
        "closing": "Case closed. People can disguise their handwriting, but not their habits.",
    },
    # ------------------------------------------------------------ forensic text + errors (Q4)
    {
        "id": "smudged-serials",
        "tier": "small",
        "title": "Smudged Serial Numbers",
        "teaser": "Stolen laptops, scratched serial numbers. Which ones are real?",
        "skills": ["errors", "forensic-text"],
        "story": "A warehouse of stolen laptops. Each has a serial number, but thieves scratched them and added fake ones. A real serial has **exactly 10 or 13 digits** once spaces and hyphens are removed.\n\n*(This is the official assignment Q4: the ISBN cleaner.)*",
        "suspects": [{"name": "the warehouse manager", "note": "Signed for every delivery."}],
        "variants": [
            'serials = ["978-0-13-235088-4", "  0132350882  ", "abc", "12345", "555-555-5555"]\n',
            'serials = ["0201485677", "0-201-48567-X", "1234567890123", "98-76", "  4 4 4 4 4 4 4 4 4 4 "]\n',
            'serials = ["X", "1111111111", "2222-2222-22", "9780132350884", "97801323508841"]\n',
        ],
        "steps": [
            {
                "question": "Write `clean_serial(raw)`: remove spaces and hyphens; return the result if it is exactly 10 or 13 digits, otherwise raise `ValueError`.",
                "starter": "def clean_serial(raw):\n    ...\n\nprint(clean_serial(serials[0]))\n",
                "solution": 'def clean_serial(raw):\n    cleaned = raw.replace("-", "").replace(" ", "")\n    if cleaned.isdigit() and (len(cleaned) == 10 or len(cleaned) == 13):\n        return cleaned\n    raise ValueError("invalid serial: " + raw)\n\nfor s in serials:\n    try:\n        print(clean_serial(s))\n    except ValueError as e:\n        print(e)\n',
                "tests": '''assert clean_serial("978-0-13-235088-4") == "9780132350884", "clean_serial('978-0-13-235088-4') should give '9780132350884'"
assert clean_serial("  0132350882  ") == "0132350882", "spaces around the number must be removed"
for _bad in ("abc", "12345", "", "978-0-13-23508X-4", "97801323508841"):
    try:
        clean_serial(_bad)
        raise AssertionError(f"clean_serial({_bad!r}) should raise ValueError")
    except ValueError:
        pass''',
                "tips": [
                    "`raw.replace(\"-\", \"\").replace(\" \", \"\")` removes hyphens and spaces. `.isdigit()` is True only if every character is a digit.",
                    "Return it if `cleaned.isdigit()` and its length is 10 or 13; otherwise `raise ValueError(...)`.",
                ],
                "reveal": "The rule is written down. Now apply it to the warehouse.",
            },
            {
                "question": "Using `clean_serial`, build `genuine` (the cleaned valid serials, in order) and count the fakes in `fakes`.",
                "starter": 'def clean_serial(raw):\n    cleaned = raw.replace("-", "").replace(" ", "")\n    if cleaned.isdigit() and (len(cleaned) == 10 or len(cleaned) == 13):\n        return cleaned\n    raise ValueError("invalid serial: " + raw)\n\ngenuine = []\nfakes = 0\n# loop here\n\nprint(genuine, fakes)\n',
                "solution": 'def clean_serial(raw):\n    cleaned = raw.replace("-", "").replace(" ", "")\n    if cleaned.isdigit() and (len(cleaned) == 10 or len(cleaned) == 13):\n        return cleaned\n    raise ValueError("invalid serial: " + raw)\n\ngenuine = []\nfakes = 0\nfor s in serials:\n    try:\n        genuine.append(clean_serial(s))\n    except ValueError:\n        fakes += 1\n\nprint(genuine, fakes)\n',
                "tests": '''_g, _f = [], 0
for _s in serials:
    _c = _s.replace("-", "").replace(" ", "")
    if _c.isdigit() and len(_c) in (10, 13):
        _g.append(_c)
    else:
        _f += 1
assert genuine == _g, f"genuine should be {_g}, got {genuine}"
assert fakes == _f, f"fakes should be {_f}, got {fakes!r}"''',
                "tips": [
                    "Loop over `serials`; inside `try:` append `clean_serial(s)` to `genuine`.",
                    "In `except ValueError:` add 1 to `fakes`.",
                ],
                "reveal": "The genuine serials match a shipment reported stolen from the docks.",
            },
        ],
        "closing": "Case closed. A clear rule, written once as a function, sorted real from fake in seconds.",
    },
    # ------------------------------------------------------------ collections (Q8)
    {
        "id": "cold-case-archive",
        "tier": "small",
        "title": "The Cold Case Archive",
        "teaser": "Decades of unsolved cases in one messy box.",
        "skills": ["collections"],
        "story": "The archive's unsolved cases arrived in one unsorted list, `cases`. The Chief wants them grouped **by year** so patterns jump out.\n\n*(This is the official assignment Q8: group by year, once with `defaultdict` and once with `setdefault`.)*",
        "suspects": [{"name": "unknown", "note": "That's the point of a cold case."}],
        "variants": [
            'cases = [{"code": "CC-11", "year": 1998}, {"code": "CC-12", "year": 2003}, {"code": "CC-13", "year": 1998}, {"code": "CC-14", "year": 2011}]\n',
            'cases = [{"code": "K-1", "year": 2015}, {"code": "K-2", "year": 2015}, {"code": "K-3", "year": 2015}, {"code": "K-4", "year": 1987}]\n',
            'cases = [{"code": "Z-9", "year": 2001}, {"code": "Z-8", "year": 2002}, {"code": "Z-7", "year": 2001}, {"code": "Z-6", "year": 2002}, {"code": "Z-5", "year": 2002}]\n',
        ],
        "steps": [
            {
                "question": "Write `by_year(cases)` using `defaultdict(list)` and `by_year_setdefault(cases)` using a plain `{}` with `setdefault`. Both return a plain dict mapping year → list of case codes, in input order. Store the year with the most cases in `worst_year`.",
                "starter": "from collections import defaultdict\n\ndef by_year(cases):\n    ...\n\ndef by_year_setdefault(cases):\n    ...\n\nworst_year = ...\nprint(by_year(cases), worst_year)\n",
                "solution": "from collections import defaultdict\n\ndef by_year(cases):\n    groups = defaultdict(list)\n    for c in cases:\n        groups[c[\"year\"]].append(c[\"code\"])\n    return dict(groups)\n\ndef by_year_setdefault(cases):\n    groups = {}\n    for c in cases:\n        groups.setdefault(c[\"year\"], []).append(c[\"code\"])\n    return groups\n\ngroups = by_year(cases)\nworst_year = None\nfor year in groups:\n    if worst_year is None or len(groups[year]) > len(groups[worst_year]):\n        worst_year = year\nprint(by_year(cases), worst_year)\n",
                "tests": '''_e = {}
for _c in cases:
    _e.setdefault(_c["year"], []).append(_c["code"])
_r = by_year(cases)
assert type(_r) is dict, "by_year should return a plain dict (wrap it with dict(...))"
assert _r == _e, f"by_year gave {_r}, expected {_e}"
assert by_year_setdefault(cases) == _e, "by_year_setdefault gives a different result"
assert by_year([]) == {} and by_year_setdefault([]) == {}, "no cases should give an empty dict"
_most = max(len(v) for v in _e.values())
assert len(_e.get(worst_year, [])) == _most, f"worst_year should be a year with {_most} cases"''',
                "tips": [
                    "`groups = defaultdict(list)` then `groups[c[\"year\"]].append(c[\"code\"])`, and `return dict(groups)`.",
                    "The setdefault version: `groups.setdefault(c[\"year\"], []).append(c[\"code\"])` on a plain `{}`.",
                ],
                "reveal": "One year stands out with far more unsolved cases than any other.",
            },
        ],
        "closing": "Case closed, or rather, reopened: the busiest year leads to a forgotten serial burglar.",
    },
    {
        "id": "double-agent",
        "tier": "small",
        "title": "The Double Agent",
        "teaser": "Two rival gangs. Someone is on both payrolls.",
        "skills": ["collections"],
        "story": "Undercover officers copied the member lists of two rival gangs, `red_dragons` and `blue_vipers`. Anyone on **both** lists is a double agent. Names may repeat within a list.\n\nSets make this fast.",
        "suspects": [{"name": "the double agent", "note": "Selling secrets both ways."}],
        "variants": [
            'red_dragons = ["Arjun", "Leela", "Omar", "Leela", "Sam"]\nblue_vipers = ["Priya", "Omar", "Kiran", "Omar"]\n',
            'red_dragons = ["Neel", "Tara", "Yusuf", "Rhea"]\nblue_vipers = ["Rhea", "Farhan", "Neel", "Maya"]\n',
            'red_dragons = ["Zoya", "Dev", "Ira"]\nblue_vipers = ["Ira", "Ira", "Kabir"]\n',
        ],
        "steps": [
            {
                "question": "Store a **sorted list** of the names on both lists in `double_agents`, and the number of distinct people in either gang in `total_members`.",
                "starter": "double_agents = ...\ntotal_members = ...\nprint(double_agents, total_members)\n",
                "solution": "double_agents = sorted(set(red_dragons) & set(blue_vipers))\ntotal_members = len(set(red_dragons) | set(blue_vipers))\nprint(double_agents, total_members)\n",
                "tests": '''_d = sorted(set(red_dragons) & set(blue_vipers))
assert double_agents == _d, f"double_agents should be {_d}, got {double_agents!r}"
_t = len(set(red_dragons) | set(blue_vipers))
assert total_members == _t, f"total_members should be {_t}, got {total_members!r}"''',
                "tips": [
                    "`set(a) & set(b)` keeps names in both; `set(a) | set(b)` keeps names in either.",
                    "Wrap the intersection in `sorted(...)` to get a list; use `len(...)` on the union.",
                ],
                "reveal": "The double agent's name is on both payrolls in plain sight.",
            },
        ],
        "closing": "Case closed. Two lists, one `&`, and the leak was plugged.",
    },
    # ------------------------------------------------------------ function craft (Q5, Q7)
    {
        "id": "shared-notebook",
        "tier": "small",
        "title": "The Shared Notebook",
        "teaser": "One detective's notes keep appearing in everyone else's case.",
        "skills": ["function-craft"],
        "story": "The Bureau's note-taking helper has a bug: notes from one case show up in every other case's notebook. Here is the helper:\n\n`def add_note(note, notebook=[]): notebook.append(note); return notebook`\n\nThe raw notes are in `case_notes`, a list of `(case, note)` pairs.\n\n*(This is the official assignment Q5: the mutable default trap.)*",
        "suspects": [{"name": "the helper function", "note": "The culprit is a default argument."}],
        "variants": [
            'case_notes = [("C1", "glove"), ("C2", "receipt"), ("C1", "footprint")]\n',
            'case_notes = [("A", "ticket"), ("B", "lighter"), ("C", "map"), ("A", "coin")]\n',
            'case_notes = [("X9", "key"), ("X9", "badge"), ("Y1", "phone")]\n',
        ],
        "steps": [
            {
                "question": "Fix `add_note(note, notebook=None)` so each call without a notebook starts a fresh list. Then build `notebooks`: a dict mapping each case to its own list of notes, using `add_note`.",
                "starter": "def add_note(note, notebook=[]):\n    notebook.append(note)\n    return notebook\n\nnotebooks = {}\nfor case, note in case_notes:\n    if case in notebooks:\n        add_note(note, notebooks[case])\n    else:\n        notebooks[case] = add_note(note)\n\nprint(notebooks)\n",
                "solution": "def add_note(note, notebook=None):\n    if notebook is None:\n        notebook = []\n    notebook.append(note)\n    return notebook\n\nnotebooks = {}\nfor case, note in case_notes:\n    if case in notebooks:\n        add_note(note, notebooks[case])\n    else:\n        notebooks[case] = add_note(note)\n\nprint(notebooks)\n",
                "tests": '''assert add_note("a") == ["a"], "a call without a notebook should return a new list"
assert add_note("b") == ["b"], "the default list is still shared between calls"
_mine = ["x"]
assert add_note("y", _mine) is _mine and _mine == ["x", "y"], "passing a notebook should add to that notebook"
_e = {}
for _c, _n in case_notes:
    _e.setdefault(_c, []).append(_n)
assert notebooks == _e, f"notebooks should be {_e}, got {notebooks}"''',
                "tips": [
                    "Change the default to `notebook=None`.",
                    "Inside: `if notebook is None: notebook = []`, then append and return.",
                ],
                "reveal": "Each case now has its own notebook. The cross-contamination was the code, not a mole.",
            },
        ],
        "closing": "Case closed. The \"mole\" leaking notes between cases was one default argument.",
    },
    {
        "id": "shortest-alibi",
        "tier": "small",
        "title": "The Shortest Alibi",
        "teaser": "Whose alibi leaves the biggest hole? No min() allowed.",
        "skills": ["function-craft"],
        "story": "Each suspect's alibi covers some minutes of the evening, in `alibis` (a list of dicts with `name` and `minutes`). The shortest alibi leaves the most time unaccounted for.\n\nThe Bureau's computers are ancient: no `min`, `max` or `sorted` here.\n\n*(This is the official assignment Q7: min/max without built-ins.)*",
        "suspects": [{"name": "everyone with a short alibi", "note": ""}],
        "variants": [
            'alibis = [{"name": "Asha", "minutes": 120}, {"name": "Ravi", "minutes": 45}, {"name": "Zoya", "minutes": 200}]\n',
            'alibis = [{"name": "Omar", "minutes": 15}, {"name": "Leela", "minutes": 90}, {"name": "Sam", "minutes": 300}, {"name": "Nisha", "minutes": 15}]\n',
            'alibis = [{"name": "Kabir", "minutes": 75}, {"name": "Meera", "minutes": 80}, {"name": "Dev", "minutes": 60}]\n',
        ],
        "steps": [
            {
                "question": "Write `my_min(items, key=None)` and `my_max(items, key=None)` that work like the built-ins (ties keep the first item; an empty input raises `ValueError`). Then store the name with the shortest alibi in `prime_suspect`.",
                "starter": "def my_min(items, key=None):\n    ...\n\ndef my_max(items, key=None):\n    ...\n\nprime_suspect = ...\nprint(prime_suspect)\n",
                "solution": '''def same(x):
    return x

def my_min(items, key=None):
    if key is None:
        key = same
    best = None
    found = False
    for item in items:
        if not found or key(item) < key(best):
            best = item
            found = True
    if not found:
        raise ValueError(\"empty sequence\")
    return best

def my_max(items, key=None):
    if key is None:
        key = same
    best = None
    found = False
    for item in items:
        if not found or key(item) > key(best):
            best = item
            found = True
    if not found:
        raise ValueError(\"empty sequence\")
    return best

def minutes(alibi):
    return alibi[\"minutes\"]

prime_suspect = my_min(alibis, key=minutes)[\"name\"]
print(prime_suspect)
''',
                "tests": '''assert my_min([3, 1, 2]) == 1 and my_max([3, 1, 2]) == 3, "my_min/my_max are wrong on [3, 1, 2]"
assert my_max(["aa", "b", "cc"], key=len) == "aa", "ties should keep the first item"
for _fn in (my_min, my_max):
    try:
        _fn([])
        raise AssertionError(f"{_fn.__name__}([]) should raise ValueError")
    except ValueError:
        pass
_low = alibis[0]
for _a in alibis:
    if _a["minutes"] < _low["minutes"]:
        _low = _a
assert prime_suspect == _low["name"], f"prime_suspect should be {_low['name']!r}, got {prime_suspect!r}"''',
                "tips": [
                    "Keep the best item so far; replace it only when `key(item)` is strictly smaller (min) or larger (max), so ties keep the first.",
                    "`key` is a function: when it is None, use one that returns the item itself. Use a `found` flag; if nothing was found, `raise ValueError(...)`. For the alibis, write `def minutes(alibi): return alibi[\"minutes\"]` and call `my_min(alibis, key=minutes)`.",
                ],
                "reveal": "One alibi is so short it barely covers a cup of tea.",
            },
        ],
        "closing": "Case closed. You rebuilt `min` from scratch and found the hole in the story.",
    },
    # ------------------------------------------------------------ functional (Q3)
    {
        "id": "badge-code",
        "tier": "small",
        "title": "The Badge Code",
        "teaser": "The evidence safe opens with a code hidden in badge numbers.",
        "skills": ["functional"],
        "story": "The evidence safe's code is derived from the on-duty officers' `badges`: take only the **even** badge numbers, **multiply each by 3**, and sort them **from largest to smallest**.\n\n*(This is the official assignment Q3: a one-line list comprehension.)*",
        "suspects": [{"name": "nobody", "note": "Just open the safe."}],
        "variants": [
            "badges = [5, 8, 3, 12, 7, 4, 9, 2]\n",
            "badges = [10, 21, 14, 3, 6]\n",
            "badges = [1, 22, 40, 13, 8, 8]\n",
        ],
        "steps": [
            {
                "question": "In **one** line, build `code` with a list comprehension and `sorted(..., reverse=True)`.",
                "starter": "code = ...\nprint(code)\n",
                "solution": "code = sorted([b * 3 for b in badges if b % 2 == 0], reverse=True)\nprint(code)\n",
                "tests": '''_e = sorted([b * 3 for b in badges if b % 2 == 0], reverse=True)
assert code == _e, f"code should be {_e}, got {code!r}"''',
                "tips": [
                    "Inside the brackets: `b * 3 for b in badges if b % 2 == 0`.",
                    "Wrap it: `sorted([...], reverse=True)`.",
                ],
                "reveal": "Click. The safe swings open.",
            },
        ],
        "closing": "Case closed. One readable line of Python opened the safe.",
    },
    {
        "id": "lineup",
        "tier": "small",
        "title": "The Line-up",
        "teaser": "Order the suspects: weakest alibi first.",
        "skills": ["functional"],
        "story": "Detectives rate each alibi's strength from 1 to 10. For the line-up, the Chief wants suspects ordered by **alibi strength (weakest first)**, then **alphabetically** when strengths tie. The ratings are in `suspects` (a list of dicts).",
        "suspects": [{"name": "the whole line-up", "note": ""}],
        "variants": [
            'suspects = [{"name": "Vikram", "alibi": 7}, {"name": "Asha", "alibi": 3}, {"name": "Dev", "alibi": 3}, {"name": "Meera", "alibi": 9}]\n',
            'suspects = [{"name": "Zara", "alibi": 1}, {"name": "Omar", "alibi": 5}, {"name": "Ana", "alibi": 5}]\n',
            'suspects = [{"name": "Kiran", "alibi": 4}, {"name": "Bilal", "alibi": 8}, {"name": "Chen", "alibi": 2}, {"name": "Ada", "alibi": 2}]\n',
        ],
        "steps": [
            {
                "question": "Use `sorted` with a `key=lambda ...` that returns a tuple. Store the ordered **names** in `order` and the first name in `prime_suspect`.",
                "starter": "ordered = ...\norder = ...\nprime_suspect = ...\nprint(order, prime_suspect)\n",
                "solution": "ordered = sorted(suspects, key=lambda s: (s[\"alibi\"], s[\"name\"]))\norder = [s[\"name\"] for s in ordered]\nprime_suspect = order[0]\nprint(order, prime_suspect)\n",
                "tests": '''_e = [s["name"] for s in sorted(suspects, key=lambda s: (s["alibi"], s["name"]))]
assert order == _e, f"order should be {_e}, got {order!r}"
assert prime_suspect == _e[0], f"prime_suspect should be {_e[0]!r}"''',
                "tips": [
                    "A tuple key sorts by the first item, then the second: `key=lambda s: (s[\"alibi\"], s[\"name\"])`.",
                    "Then `order = [s[\"name\"] for s in ordered]` and `prime_suspect = order[0]`.",
                ],
                "reveal": "The weakest alibi stands at the front of the line.",
            },
        ],
        "closing": "Case closed. `sorted` with a good key turned opinions into an order everyone accepted.",
    },
    # ------------------------------------------------------------ decorators
    {
        "id": "wiretap",
        "tier": "small",
        "title": "The Wiretap",
        "teaser": "Record every call a suspect's phone makes, without changing the phone.",
        "skills": ["decorators"],
        "story": "Internal Affairs suspects an officer is tipping off a gang. You may not change the officer's `send` function, but you may **wrap** it. Every message they will send is in `outgoing` (a list of `(to, text)` pairs).\n\nA decorator can record each call and still let it through.",
        "suspects": [{"name": "the officer", "note": "Very popular on the phone."}],
        "variants": [
            'outgoing = [("Mum", "home late"), ("Viper", "raid at 6"), ("Pizza", "one large")]\n',
            'outgoing = [("Viper", "move the van"), ("Viper", "now"), ("Gym", "cancel")]\n',
            'outgoing = [("Bank", "balance?"), ("Dragon", "cops at pier 9")]\n',
        ],
        "steps": [
            {
                "question": "Write a decorator `tap` that appends `(fn.__name__, args)` to the list `wiretap_log` on every call, then returns the original result. Use `functools.wraps`. Decorate `send`, send every message in `outgoing`, and store the contacts that received a message containing `\"raid\"`, `\"cops\"` or `\"move\"` in `tipped_off`.",
                "starter": "from functools import wraps\n\nwiretap_log = []\n\ndef tap(fn):\n    ...\n\n@tap\ndef send(to, text):\n    return f\"sent to {to}\"\n\nfor to, text in outgoing:\n    send(to, text)\n\ntipped_off = ...\nprint(wiretap_log)\nprint(tipped_off)\n",
                "solution": "from functools import wraps\n\nwiretap_log = []\n\ndef tap(fn):\n    @wraps(fn)\n    def wrapper(*args, **kwargs):\n        wiretap_log.append((fn.__name__, args))\n        return fn(*args, **kwargs)\n    return wrapper\n\n@tap\ndef send(to, text):\n    return f\"sent to {to}\"\n\nfor to, text in outgoing:\n    send(to, text)\n\ntipped_off = []\nfor name, args in wiretap_log:\n    to, text = args\n    if (\"raid\" in text or \"cops\" in text or \"move\" in text) and to not in tipped_off:\n        tipped_off.append(to)\nprint(wiretap_log)\nprint(tipped_off)\n",
                "tests": '''assert send.__name__ == "send", "use @wraps(fn) so send keeps its name"
assert send("X", "y") == "sent to X", "the wrapper must return the original result"
assert wiretap_log[-1] == ("send", ("X", "y")), "each call should log (fn.__name__, args)"
assert wiretap_log[:len(outgoing)] == [("send", m) for m in outgoing], "the log should hold every message from outgoing, in order"
_e = []
for _to, _t in outgoing:
    if ("raid" in _t or "cops" in _t or "move" in _t) and _to not in _e:
        _e.append(_to)
assert tipped_off == _e, f"tipped_off should be {_e}, got {tipped_off!r}"''',
                "tips": [
                    "Inside `tap`, define `wrapper(*args, **kwargs)` decorated with `@wraps(fn)`: append to the log, then `return fn(*args, **kwargs)`.",
                    "Afterwards loop over `wiretap_log`; each entry is `(name, args)` and `args` is `(to, text)`.",
                ],
                "reveal": "The log shows exactly who got the warnings, and when.",
            },
        ],
        "closing": "Case closed. You recorded every call without touching the original function: that's what decorators are for.",
    },
    # ------------------------------------------------------------ streams
    {
        "id": "endless-log",
        "tier": "small",
        "title": "The Endless Log",
        "teaser": "A door log too long to read. Find the first forced entry.",
        "skills": ["streams"],
        "story": "The bank's door sensors write thousands of lines a night into `log`. Somewhere, one line contains `FORCED`. Reading everything into new lists wastes memory, so use a **generator** that hands lines over one at a time.",
        "suspects": [{"name": "the night crew", "note": ""}],
        "variants": [
            'log = [f"{i:04d} side door ok" for i in range(800)]\nlog[317] = "0317 vault door FORCED"\nlog[540] = "0540 roof hatch FORCED"\n',
            'log = [f"{i:04d} lobby ok" for i in range(500)]\nlog[42] = "0042 server room FORCED"\n',
            'log = [f"{i:04d} garage ok" for i in range(1200)]\nlog[999] = "0999 cash room FORCED"\nlog[1001] = "1001 vault FORCED"\n',
        ],
        "steps": [
            {
                "question": "Write a generator `forced_entries(lines)` that **yields** only the lines containing `\"FORCED\"`. Use it to store the first such line in `first_breach`, and count all of them in `breaches`.",
                "starter": "def forced_entries(lines):\n    ...\n\nfirst_breach = ...\nbreaches = ...\nprint(first_breach, breaches)\n",
                "solution": "def forced_entries(lines):\n    for line in lines:\n        if \"FORCED\" in line:\n            yield line\n\nfirst_breach = next(forced_entries(log))\nbreaches = sum(1 for _ in forced_entries(log))\nprint(first_breach, breaches)\n",
                "tests": '''import types as _types
assert isinstance(forced_entries([]), _types.GeneratorType), "forced_entries must be a generator: use yield"
_f = [l for l in log if "FORCED" in l]
assert first_breach == _f[0], f"first_breach should be {_f[0]!r}, got {first_breach!r}"
assert breaches == len(_f), f"breaches should be {len(_f)}, got {breaches!r}"''',
                "tips": [
                    "Inside the generator: `for line in lines:` then `if \"FORCED\" in line: yield line`.",
                    "`next(forced_entries(log))` gets the first one. `sum(1 for _ in forced_entries(log))` counts them.",
                ],
                "reveal": "The first breach happened long before anyone noticed.",
            },
        ],
        "closing": "Case closed. You streamed the log instead of loading it all, the way real log processors work.",
    },
    # ------------------------------------------------------------ classes (Q10)
    {
        "id": "suspect-file",
        "tier": "small",
        "title": "The Suspect File",
        "teaser": "Witness descriptions full of impossible numbers.",
        "skills": ["classes"],
        "story": "Witnesses gave descriptions of the burglar, but some are impossible (a 300 cm tall suspect, an age of -4). The Bureau's `Suspect` record must reject impossible values.\n\nRaw descriptions are in `descriptions`: a list of `(name, age, height_cm)` tuples.\n\n*(This is the official assignment Q10: properties and validation.)*",
        "suspects": [{"name": "the burglar", "note": "Described many different ways."}],
        "variants": [
            'descriptions = [("Witness A", 34, 178), ("Witness B", -4, 170), ("Witness C", 36, 300), ("Witness D", 35, 181)]\n',
            'descriptions = [("Guard", 0, 160), ("Cabbie", 52, 165), ("Kid", 51, 49)]\n',
            'descriptions = [("Neighbour", 29, 175), ("Postman", 30, 176), ("Barber", 28, 174), ("Dog walker", 130, 175)]\n',
        ],
        "steps": [
            {
                "question": "Write `Suspect(name, age, height_cm)` with `@property` setters: `age` must be 1–120 and `height_cm` 50–250, otherwise `ValueError` (also in `__init__`). Then build `credible`: the names whose description is valid, in order.",
                "starter": "class Suspect:\n    def __init__(self, name, age, height_cm):\n        self.name = name\n        self.age = age\n        self.height_cm = height_cm\n\n    # add the properties here\n\ncredible = []\n# try each description here\n\nprint(credible)\n",
                "solution": "class Suspect:\n    def __init__(self, name, age, height_cm):\n        self.name = name\n        self.age = age\n        self.height_cm = height_cm\n\n    @property\n    def age(self):\n        return self._age\n\n    @age.setter\n    def age(self, value):\n        if not 1 <= value <= 120:\n            raise ValueError(f\"impossible age: {value}\")\n        self._age = value\n\n    @property\n    def height_cm(self):\n        return self._height_cm\n\n    @height_cm.setter\n    def height_cm(self, value):\n        if not 50 <= value <= 250:\n            raise ValueError(f\"impossible height: {value}\")\n        self._height_cm = value\n\ncredible = []\nfor name, age, height in descriptions:\n    try:\n        Suspect(name, age, height)\n        credible.append(name)\n    except ValueError:\n        pass\n\nprint(credible)\n",
                "tests": '''_s = Suspect("T", 30, 170)
_s.age = 31
assert _s.age == 31, "setting a valid age should work"
for _attr, _bad in (("age", 0), ("age", 121), ("height_cm", 49), ("height_cm", 251)):
    try:
        setattr(_s, _attr, _bad)
        raise AssertionError(f"setting {_attr} = {_bad} should raise ValueError")
    except ValueError:
        pass
try:
    Suspect("Bad", -1, 170)
    raise AssertionError("__init__ must validate too: Suspect('Bad', -1, 170) should raise")
except ValueError:
    pass
_e = [n for n, a, h in descriptions if 1 <= a <= 120 and 50 <= h <= 250]
assert credible == _e, f"credible should be {_e}, got {credible!r}"''',
                "tips": [
                    "Write a `@property def age(self)` returning `self._age`, and `@age.setter` that checks the range before storing `self._age`. Same for height.",
                    "Because `__init__` does `self.age = age`, the setter runs there too. Build `credible` with try/except around `Suspect(...)`.",
                ],
                "reveal": "With the impossible descriptions thrown out, the rest agree with each other.",
            },
        ],
        "closing": "Case closed. Validation in one place kept bad data out of the whole investigation.",
    },
    # ------------------------------------------------------------ dunders (Q16)
    {
        "id": "last-known-locations",
        "tier": "small",
        "title": "Last Known Locations",
        "teaser": "Track only the most recent sightings of a fugitive.",
        "skills": ["dunders"],
        "story": "A fugitive is on the move. Every sighting is radioed in, in order, in `sightings`. Old sightings are useless: the team only wants the **3 most recent**.\n\n*(This is the official assignment Q16: RecentBooks, as a sightings tracker.)*",
        "suspects": [{"name": "the fugitive", "note": "Never in one place for long."}],
        "variants": [
            'sightings = ["Pier 9", "Old Mill", "Station", "Market", "Bridge"]\n',
            'sightings = ["Airport", "Hotel"]\n',
            'sightings = ["Fort", "Museum", "Harbour", "Temple", "Beach", "Club", "Docks"]\n',
        ],
        "steps": [
            {
                "question": "Build `Tracker(max_size)` with `add(place)`, `oldest()`, `newest()`, and `__len__`, `__iter__`, `__getitem__`, `__contains__`, `__repr__`. Then track `sightings` with `max_size=3` and store `list(tracker)` in `recent`.",
                "starter": "from collections import deque\n\nclass Tracker:\n    ...\n\ntracker = Tracker(max_size=3)\nfor place in sightings:\n    tracker.add(place)\n\nrecent = list(tracker)\nprint(recent, tracker.newest())\n",
                "solution": "from collections import deque\n\nclass Tracker:\n    def __init__(self, max_size):\n        self._items = deque(maxlen=max_size)\n    def add(self, place):\n        self._items.append(place)\n    def oldest(self):\n        return self._items[0]\n    def newest(self):\n        return self._items[-1]\n    def __len__(self):\n        return len(self._items)\n    def __iter__(self):\n        return iter(self._items)\n    def __getitem__(self, i):\n        return self._items[i]\n    def __contains__(self, place):\n        return place in self._items\n    def __repr__(self):\n        return f\"Tracker({list(self._items)})\"\n\ntracker = Tracker(max_size=3)\nfor place in sightings:\n    tracker.add(place)\n\nrecent = list(tracker)\nprint(recent, tracker.newest())\n",
                "tests": '''_e = sightings[max(0, len(sightings) - 3):]   # (avoids a Brython bug with short negative slices)
assert recent == _e, f"recent should be {_e}, got {recent!r}"
assert len(tracker) == len(_e) and tracker[0] == _e[0] and tracker[-1] == _e[-1], "len and [] should work"
assert tracker.oldest() == _e[0] and tracker.newest() == _e[-1], "oldest/newest are wrong"
assert _e[-1] in tracker, "in should work"
if len(sightings) > 3:
    assert sightings[0] not in tracker, "the oldest sightings should be dropped"
assert "Tracker" in repr(tracker), "write a __repr__ that mentions Tracker"''',
                "tips": [
                    "Store the places in `deque(maxlen=max_size)`: it drops the oldest automatically.",
                    "Each dunder forwards to the deque, e.g. `def __len__(self): return len(self._items)`; `oldest` is `self._items[0]`.",
                ],
                "reveal": "The last three sightings form a straight line towards the harbour.",
            },
        ],
        "closing": "Case closed. The team was waiting at the harbour.",
    },
    # ------------------------------------------------------------ dataclasses
    {
        "id": "case-numbers",
        "tier": "small",
        "title": "Case Numbers",
        "teaser": "Duplicate case numbers are wrecking the filing system.",
        "skills": ["dataclasses"],
        "story": "Every case number looks like `PIB-` + a 4-digit year + `-` + a 3-digit number, e.g. `PIB-2026-041`. The intake desk typed the raw numbers into `intake`, with duplicates and typos.\n\nA **frozen** dataclass makes case numbers safe to put in a set.",
        "suspects": [{"name": "the intake desk", "note": "Overworked."}],
        "variants": [
            'intake = ["PIB-2026-041", "PIB-2026-041", "PIB-2025-007", "PIB-26-1", "PIB-2026-099"]\n',
            'intake = ["PIB-2024-001", "PIB-2024-001", "PIB-2024-001", "pib-2024-002"]\n',
            'intake = ["PIB-2023-123", "PIB-2023-124", "XYZ", "PIB-2023-123", "PIB-2023-12A"]\n',
        ],
        "steps": [
            {
                "question": "Write a frozen dataclass `CaseNumber` with `value: str`. In `__post_init__`, raise `ValueError` unless the value matches the format exactly. Then build the **set** `unique_cases` of valid case numbers and count the rejected entries in `rejected`.",
                "starter": "from dataclasses import dataclass\n\n@dataclass(frozen=True)\nclass CaseNumber:\n    ...\n\nunique_cases = set()\nrejected = 0\n# process intake here\n\nprint(len(unique_cases), rejected)\n",
                "solution": "from dataclasses import dataclass\n\n@dataclass(frozen=True)\nclass CaseNumber:\n    value: str\n\n    def __post_init__(self):\n        parts = self.value.split(\"-\")\n        ok = (len(parts) == 3 and parts[0] == \"PIB\" and len(parts[1]) == 4 and parts[1].isdigit()\n              and len(parts[2]) == 3 and parts[2].isdigit())\n        if not ok:\n            raise ValueError(f\"bad case number: {self.value!r}\")\n\nunique_cases = set()\nrejected = 0\nfor raw in intake:\n    try:\n        unique_cases.add(CaseNumber(raw))\n    except ValueError:\n        rejected += 1\n\nprint(len(unique_cases), rejected)\n",
                "tests": '''from dataclasses import FrozenInstanceError as _FIE
_c = CaseNumber("PIB-2026-041")
try:
    _c.value = "x"
    raise AssertionError("CaseNumber must be frozen")
except _FIE:
    pass
assert CaseNumber("PIB-2026-041") == _c and len({_c, CaseNumber("PIB-2026-041")}) == 1, "equal case numbers should collapse in a set"
def _ok(v):
    p = v.split("-")
    return len(p) == 3 and p[0] == "PIB" and len(p[1]) == 4 and p[1].isdigit() and len(p[2]) == 3 and p[2].isdigit()
for _bad in ("PIB-26-1", "pib-2024-002", "XYZ", "PIB-2023-12A"):
    try:
        CaseNumber(_bad)
        raise AssertionError(f"CaseNumber({_bad!r}) should raise ValueError")
    except ValueError:
        pass
_valid = {v for v in intake if _ok(v)}
assert {c.value for c in unique_cases} == _valid, f"unique_cases should hold {sorted(_valid)}"
assert rejected == sum(1 for v in intake if not _ok(v)), "rejected count is wrong"''',
                "tips": [
                    "`self.value.split(\"-\")` should give 3 parts: `\"PIB\"`, 4 digits, 3 digits. Use `len(...)` and `.isdigit()`.",
                    "Loop over `intake`: inside `try`, `unique_cases.add(CaseNumber(raw))`; in `except ValueError`, add 1 to `rejected`.",
                ],
                "reveal": "The duplicates collapse, and the typos are caught at the door.",
            },
        ],
        "closing": "Case closed. Immutable, validated, hashable: the filing system is clean again.",
    },
]

# BookVault Playground — plan for Days 2–8

Status (2026-11-24): Day 1 is live. Day 2 is paused mid-research while Day 1 issues get fixed.

## Approach agreed: hybrid, Day 2 first

Each day keeps the Day 1 format (idea → guess first → runnable code → auto-checked challenge), plus:

- **Runnable lessons in plain Python** that teach the core idea when the real library can't run in the browser.
- **"Run this locally" cards** for real library code (copy button + expected output). Not built yet:
  add an optional `local` field to lessons (`title`, `note`, `code`, `output`) and render it in `template.html`.

Build Day 2, review it with the user, then do Days 3–8.

## Standard every day must meet (set by the Day 1 beginner rewrite)

The audience may have never programmed, and the page should teach ~90% without a live session.

- Never use syntax before the lesson that teaches it. If a demo needs something new, explain it in the walkthrough.
- Every demo has a `walkthrough` (line by line). Every challenge has 2 `hints`. `build.py` fails the build otherwise.
- Add `mistakes` for the common beginner errors of each topic.
- Prefer tests that re-run the trainee's code with other inputs (`__source__`) or check printed text (`__output__`), so hard-coded answers fail.
- Test failure messages are plain English: they are shown to the trainee as-is.

## What browser Python (Brython 3.12.4) can and can't do — tested

| Works | Doesn't work |
|---|---|
| `logging` (basicConfig, handlers, custom JSON formatter, `extra=`, `logger.exception`) | `async def` / `await` — Brython turns coroutines into JS Promises, so `asyncio.run`, `gather`, `TaskGroup`, `Semaphore`, `timeout` can't run |
| `unittest.mock` (`MagicMock`, `patch`, `assert_called_once`) | Real parallelism: `threading.Thread` runs, but sequentially, so races can't be shown for real |
| generators incl. `.send()`, `heapq`, `random.seed`, `inspect.signature`, `re`, `json`, `dataclasses` | `multiprocessing`, `ProcessPoolExecutor` |
| `except*` / `ExceptionGroup`, `threading.Lock` as a context manager | pytest itself, httpx, pythonjsonlogger |

Brython bug (not patched): a negative slice longer than the list, like `[1, 2][-3:]`, returns too few items (`[2]` instead of `[1, 2]`). Avoid it in tests and solutions; write `x[max(0, len(x) - 3):]`.

Brython bug (fixed in `template.html`): `{}.setdefault(2008, [])` stored the key as the string `"2008"`. The template patches `dict.setdefault` at startup.

Gotcha: importing `unittest.mock` prints a Brython warning about asyncio to the output. Filter or silence it in the runner before Day 2 ships.

## Day 2 lesson outline (source: day2 deck, Assignment Day -2.docx, session_examples/)

Part 1 · Debugging & logging
1. Debug the overdue bug (returned loans marked overdue) — challenge: fix `overdue_loans`. Local card: launch.json + conditional breakpoint.
2. Logging levels and basicConfig — challenge: configure a logger so DEBUG shows.
3. Structured JSON logging with a custom Formatter and `extra=` — challenge: add `request_id`/`duration_ms` fields. Local card: python-json-logger.

Part 2 · Testing
4. Plain asserts + a tiny in-page test runner that collects `test_*` functions (mimics pytest output). Local card: real pytest file.
5. Fixtures (simulated with functions; local card with `@pytest.fixture`, yield teardown, conftest).
6. Parametrize — table-driven ISBN cleaning (assignment Q4). Local card: `@pytest.mark.parametrize`.
7. Mocking with `unittest.mock.patch` / `MagicMock` — fake cover API (assignment Q10).
8. Domain exceptions + loan limit (assignment Q6/Q7).

Part 3 · Concurrency
9. I/O-bound vs CPU-bound decision tree — quiz-heavy lesson.
10. Race condition simulated with an interleaving scheduler (read-modify-write lost updates), fixed with a lock. Local card: real threading demo.
11. ThreadPoolExecutor / ProcessPoolExecutor / as_completed — concepts + local cards with expected timings.

Part 4 · Async
12. Event loop built from generators (`yield` = `await`): shows cooperative scheduling and why `time.sleep` freezes the loop.
13. gather / Semaphore / timeout on the mini loop — challenge: cap concurrency at 3.
14. Retry with exponential backoff and injected fake sleep (assignment Q18).
15. FakeLLMProvider + dependency injection (assignment Q19), bridge to Day 3.
Local cards for real asyncio: gather, TaskGroup, Semaphore, timeout, to_thread, httpx capstone.

## Days 3–8 (later, same hybrid format)

| Day | Topic | Runnable idea in the browser |
|---|---|---|
| 3 | LangChain, Ollama, tools, agents | Fake LLM that returns tool calls; trainees write the tool loop / ReAct loop |
| 4 | FastAPI, Pydantic, Uvicorn, Postman | Mini router + validation with dataclasses; local cards for FastAPI/Pydantic |
| 5 | SQLAlchemy, MongoDB, middleware, JWT | Repository pattern in memory, middleware pipeline, JWT with hmac/base64 |
| 6 | Celery, RabbitMQ, webhooks | In-memory queue + worker loop, retries, webhook payloads |
| 7 | LangGraph | Mini graph engine: state, nodes, edges, conditional routing |
| 8 | RAG, embeddings, Qdrant | Toy embeddings + cosine similarity, chunking, hybrid search |

Note: `extracted/Day8/.../.env` may contain API keys — never publish its contents.

## Files

- `template.html` — page shell + Python runner (shared by all days)
- `dayN_lessons.py` — lesson content per day
- `build.py dayN` — checks every lesson with CPython, then writes `dayN.html`
- Brython local test copy: scratchpad `bvtest/` served on port 8765

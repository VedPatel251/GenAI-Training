"""Part 1 · Start here — Python from zero, for people who have never programmed.

Every lesson only uses things taught in the lessons before it.
Tests can read `__output__`: everything the trainee's code printed.
"""

BASICS = [
    # ------------------------------------------------------------------
    {
        "id": "welcome",
        "title": "Welcome: how to use this page",
        "idea": "A **program** is a list of instructions a computer follows, one after another. **Python** is a language for writing those instructions. It reads almost like English, which is why it is a great first language and why most AI tools are built with it.\n\nThis page lets you write and run real Python without installing anything. Every lesson works the same way:\n1. Read the short explanation.\n2. Look at the example code in the dark box, then press **▶ Run**. The result appears in the **Output** box below it.\n3. Change the code and run it again. You cannot break anything; **Reset** brings the original back.\n4. Read **Line by line**, which explains every line of the example.\n5. Solve the **Your turn** challenge and press **✓ Check**. Stuck? Press **Show a hint**.\n\nYour progress and your code are saved in this browser. Go through the lessons in order: each one only uses what the earlier lessons taught.",
        "code": '''print("Hello, BookVault!")
print("I am learning Python.")
''',
        "walkthrough": [
            ['print("Hello, BookVault!")', "`print` shows something in the Output box. The text you want to show goes inside the round brackets `( )`, wrapped in quote marks."],
            ['print("I am learning Python.")', "Python runs your lines **from top to bottom**, so this line is printed second."],
        ],
        "challenge": {
            "task": "Change the code so it prints exactly `Hello, my name is ` followed by your name, for example `Hello, my name is Asha`.",
            "hints": [
                "Keep the quote marks and the brackets. Only change the text between the quotes.",
                'For example: `print("Hello, my name is Asha")`',
            ],
            "starter": '''print("Hello, BookVault!")
''',
            "solution": '''print("Hello, my name is Asha")
''',
            "tests": '''assert __output__.startswith("Hello, my name is "), "your output should start with: Hello, my name is "
assert len(__output__.strip()) > len("Hello, my name is"), "add your name after 'Hello, my name is'"''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "install-python",
        "title": "Install Python on your computer",
        "idea": "This page runs Python inside your browser, which is perfect for learning. For real projects (and from Day 2 onwards) you need Python installed on your own computer. It is free and takes about 5 minutes.\n\n**Windows**\n1. Open python.org/downloads and click the yellow **Download Python 3.x** button.\n2. Run the installer. On the first screen, **tick \"Add python.exe to PATH\"** at the bottom. This is the step most people miss.\n3. Click **Install Now** and wait for it to finish.\n4. Open **Command Prompt** (press the Windows key, type `cmd`, press Enter).\n5. Type `python --version` and press Enter. You should see `Python 3.12.x` or newer.\n\n**macOS**\n1. Open python.org/downloads, download the macOS installer and run it.\n2. Open **Terminal** (press Cmd+Space, type `Terminal`, press Enter).\n3. Type `python3 --version` and press Enter. On a Mac the command is `python3`, not `python`.\n\n**Linux**: Python is usually already installed. Check with `python3 --version`; if it is missing, install it with your package manager (for example `sudo apt install python3`).\n\nYou need Python **3.11 or newer** for this training.",
        "predict": {
            "q": "You installed Python on Windows, but typing `python --version` says *'python' is not recognized*. What is the most likely cause?",
            "options": [
                "Python only works on macOS",
                "\"Add python.exe to PATH\" was not ticked during install",
                "You need to restart the internet",
                "The version is too new",
            ],
            "answer": 1,
            "why": "PATH is the list of folders Windows searches for commands. Re-run the installer, choose **Modify**, and tick the PATH option (or try the `py` command, which the installer always adds).",
        },
        "local": [{
            "title": "Check your installation",
            "note": "Type this in Command Prompt (Windows) or Terminal (macOS/Linux). On macOS and Linux use `python3` and `pip3`.",
            "code": '''python --version
pip --version''',
            "output": '''Python 3.12.4
pip 24.0 from C:\\Users\\you\\AppData\\Local\\Programs\\Python\\Python312\\Lib\\site-packages\\pip (python 3.12)''',
        }],
        "mistakes": [
            "Forgetting to tick **Add python.exe to PATH** on Windows. Fix it by re-running the installer and choosing Modify.",
            "Typing `python` on a Mac. Use `python3`.",
            "Typing `python --version` *inside* Python (after `>>>`). Type it in the normal terminal instead; type `exit()` to leave Python.",
        ],
    },
    # ------------------------------------------------------------------
    {
        "id": "first-program",
        "title": "Your first program in VS Code",
        "idea": "You write Python in a text file ending in `.py` and run it with the `python` command. A code editor makes this easier. We use **Visual Studio Code** (VS Code), which is free.\n\n**Set up VS Code**\n1. Download VS Code from code.visualstudio.com and install it.\n2. Open VS Code, click the **Extensions** icon on the left (four squares), search for **Python** (by Microsoft) and click **Install**.\n3. Make a new folder on your computer, for example `bookvault`. In VS Code choose **File → Open Folder…** and pick it.\n\n**Write and run a program**\n1. Choose **File → New File**, name it `hello.py`.\n2. Type the code from the card below and save (Ctrl+S, or Cmd+S on a Mac).\n3. Click the **▶ Run** button at the top right of the editor. The output appears in the **Terminal** panel at the bottom.\n4. Or open **Terminal → New Terminal** and type `python hello.py` (`python3 hello.py` on a Mac).\n\n**The interactive prompt.** Typing just `python` in a terminal starts an interactive session with a `>>>` prompt. Each line runs as soon as you press Enter, which is handy for quick experiments. Type `exit()` to leave it.",
        "predict": {
            "q": "Which file name will Python run as a program?",
            "options": ["hello.txt", "hello.py", "hello.docx", "hello"],
            "answer": 1,
            "why": "Python files end in `.py`. The ending tells VS Code to treat the file as Python code.",
        },
        "local": [
            {
                "title": "hello.py",
                "code": '''print("Hello from my own computer!")
print("Python is installed and working.")''',
                "output": '''Hello from my own computer!
Python is installed and working.''',
            },
            {
                "title": "The interactive prompt",
                "note": "Start it by typing `python` (or `python3`) in a terminal. Type the lines after `>>>`. Type `exit()` to quit.",
                "code": '''>>> 2 + 3
5
>>> print("hi")
hi
>>> exit()''',
            },
        ],
        "mistakes": [
            "Running a file you have not saved. VS Code runs the saved version, so press Ctrl+S first.",
            "Running `python hello.py` from the wrong folder. The terminal must be in the folder that contains the file; VS Code's built-in terminal opens in your project folder.",
        ],
    },
    # ------------------------------------------------------------------
    {
        "id": "print-comments",
        "title": "print() and comments",
        "idea": "`print()` is how a program shows you results. Text must be inside quote marks; numbers do not need them. You can print several things at once by separating them with commas: Python puts a space between them.\n\nA line starting with `#` is a **comment**. Python ignores it completely. Comments are notes for humans, explaining *why* the code does something.",
        "code": '''# This is a comment. Python skips it.
print("Welcome to BookVault")
print(42)
print("Pages:", 464)
print("Clean Code", "by", "Robert Martin")
print()                      # an empty line
print("Done")                # a comment can also go at the end of a line
''',
        "walkthrough": [
            ["# This is a comment. Python skips it.", "Anything after `#` is ignored by Python. Use comments to explain your code."],
            ['print("Welcome to BookVault")', "Text (called a **string**) goes inside quotes. Single `'...'` or double `\"...\"` quotes both work."],
            ["print(42)", "Numbers are printed without quotes."],
            ['print("Pages:", 464)', "A comma separates the things to print. Python adds one space between them."],
            ["print()", "With nothing inside the brackets, `print` prints an empty line."],
        ],
        "mistakes": [
            "Forgetting the quotes: `print(Hello)` makes Python look for something *named* Hello and fail with `NameError`.",
            "Mixing quotes: `print(\"Hello')` starts with `\"` and ends with `'`, which is a `SyntaxError`.",
            "Capital letters: `Print(...)` does not work. Python is case-sensitive, and it is `print`.",
        ],
        "challenge": {
            "task": "Print this library card, exactly, on three lines:\n`Title: Clean Code`\n`Author: Robert Martin`\n`Pages: 464`",
            "hints": [
                "You need three `print(...)` lines, one for each line of the card.",
                'The first line is `print("Title: Clean Code")`. Copy the pattern for the other two.',
            ],
            "starter": '''# write your three print lines below
''',
            "solution": '''print("Title: Clean Code")
print("Author: Robert Martin")
print("Pages: 464")
''',
            "tests": '''lines = __output__.strip().split("\\n")
assert len(lines) == 3, f"expected 3 lines of output, got {len(lines)}"
assert lines[0] == "Title: Clean Code", f"line 1 is {lines[0]!r}"
assert lines[1] == "Author: Robert Martin", f"line 2 is {lines[1]!r}"
assert lines[2] == "Pages: 464", f"line 3 is {lines[2]!r}"''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "variables",
        "title": "Variables: giving values a name",
        "idea": "A **variable** is a name that points to a value, like a label on a box. You create one with `=`: the name on the left, the value on the right. After that you can use the name anywhere instead of the value.\n\nIn Python `=` means **\"store this value under this name\"**, not \"is equal to\". You can store a new value under the same name later; the old one is replaced.\n\n**Naming rules**: letters, digits and `_` only; no spaces; cannot start with a digit; case matters (`title` and `Title` are different). Python style is lowercase words joined by underscores, called **snake_case**: `book_title`, `pages_read`.",
        "code": '''title = "Clean Code"
author = "Robert Martin"
pages = 464

print(title)
print(title, "has", pages, "pages")

pages_read = 100
pages_left = pages - pages_read
print("Pages left:", pages_left)

pages_read = 250            # replace the old value
print("Now read:", pages_read)
''',
        "walkthrough": [
            ['title = "Clean Code"', "Create a variable called `title` and store the text `Clean Code` in it."],
            ["pages = 464", "Variables can hold numbers too."],
            ['print(title, "has", pages, "pages")', "Use the variable names without quotes. Python replaces each name with its value."],
            ["pages_left = pages - pages_read", "The right side is worked out first (464 − 100), then the result is stored in `pages_left`."],
            ["pages_read = 250", "Assigning again replaces the old value. `pages_read` is now 250."],
        ],
        "mistakes": [
            "`print(\"title\")` prints the word *title*. `print(title)` prints the value stored in the variable.",
            "Using a variable before creating it gives `NameError: name '...' is not defined`. Check the spelling and the order of your lines.",
            "Spaces in names: `book title = ...` is an error. Use `book_title`.",
        ],
        "challenge": {
            "task": "Create three variables: `title` set to `\"Refactoring\"`, `author` set to `\"Martin Fowler\"` and `pages` set to `448`. Then print `Refactoring by Martin Fowler` using the variables (not by typing the words again).",
            "hints": [
                'Create each variable on its own line, for example `title = "Refactoring"`.',
                'Print with commas between the parts: `print(title, "by", author)`.',
            ],
            "starter": '''# create the three variables here

# then print the sentence using them
''',
            "solution": '''title = "Refactoring"
author = "Martin Fowler"
pages = 448

print(title, "by", author)
''',
            "tests": '''assert title == "Refactoring", f"title is {title!r}"
assert author == "Martin Fowler", f"author is {author!r}"
assert pages == 448, "pages should be the number 448 (no quotes)"
assert __output__.strip() == "Refactoring by Martin Fowler", f"you printed {__output__.strip()!r}"''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "numbers",
        "title": "Numbers and maths",
        "idea": "Python has two kinds of numbers:\n- **int** (integer): whole numbers like `464`, `0`, `-7`.\n- **float**: numbers with a decimal point like `4.7` or `2.5`.\n\nThe maths operators:\n- `+` add, `-` subtract, `*` multiply, `/` divide (always gives a float)\n- `//` divide and drop the remainder, `%` the remainder only\n- `**` power, so `2 ** 3` is 8\n\nPython follows normal maths order (multiply and divide before add and subtract). Use brackets to make the order clear. `type(x)` tells you what kind of value `x` is, and `round(x, 2)` rounds to 2 decimal places.",
        "code": '''pages = 464
pages_per_day = 30

print(pages + 36)
print(pages / pages_per_day)       # / always gives a decimal
print(pages // pages_per_day)      # whole days
print(pages % pages_per_day)       # pages left over
print(2 ** 10)

price = 499.0
discount = 0.15
final = price - price * discount
print(final)
print(round(final, 2))

print(type(pages), type(price))
print(2 + 3 * 4, (2 + 3) * 4)
''',
        "walkthrough": [
            ["print(pages / pages_per_day)", "464 ÷ 30 = 15.466… `/` always produces a float, even for whole numbers."],
            ["print(pages // pages_per_day)", "`//` keeps only the whole part: 15 full days of reading."],
            ["print(pages % pages_per_day)", "`%` gives the remainder: after 15 days of 30 pages, 14 pages are left."],
            ["final = price - price * discount", "Multiplication happens first (499 × 0.15 = 74.85), then the subtraction."],
            ["print(type(pages), type(price))", "`type()` shows the kind of value: `int` for 464, `float` for 499.0."],
            ["print(2 + 3 * 4, (2 + 3) * 4)", "Without brackets 3 × 4 happens first (14). Brackets change the order (20)."],
        ],
        "mistakes": [
            "Writing `5 x 3`. Python uses `*` for multiplication.",
            "Expecting `7 / 2` to be `3`. It is `3.5`; use `7 // 2` for a whole number.",
            "Using a comma in big numbers: `1,000` is *not* one thousand. Write `1000` or `1_000`.",
        ],
        "challenge": {
            "task": "A book is 5 days late and the fine is ₹2.5 per day, plus a fixed ₹10 handling charge. Store the days in `days_late`, the daily fine in `fine_per_day`, and calculate `total_fine`. Print it.",
            "hints": [
                "Create `days_late = 5` and `fine_per_day = 2.5` first.",
                "The total is days × fine per day, plus 10: `total_fine = days_late * fine_per_day + 10`.",
            ],
            "starter": '''days_late = 5
fine_per_day = 2.5

total_fine = ...   # replace ... with the calculation
print(total_fine)
''',
            "solution": '''days_late = 5
fine_per_day = 2.5

total_fine = days_late * fine_per_day + 10
print(total_fine)
''',
            "tests": '''assert total_fine == 22.5, f"total_fine is {total_fine!r}, expected 22.5"
assert __output__.strip() == "22.5", "print the total"''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "strings-basics",
        "title": "Text (strings)",
        "idea": "Text values are called **strings** (type `str`). Things you can do with them:\n- Join with `+`: `\"Clean\" + \" Code\"` gives `\"Clean Code\"`.\n- Count characters with `len(text)`.\n- Call **methods** with a dot: `text.upper()`, `text.lower()`, `text.strip()` (removes spaces at both ends), `text.replace(\"a\", \"b\")`.\n\nA number inside quotes is text, not a number: `\"5\" + \"5\"` is `\"55\"`. Convert with `int(\"5\")` (text → whole number), `float(\"4.5\")` and `str(464)` (number → text).\n\n**f-strings** are the easiest way to put values into text: write `f` before the quote and put variable names inside `{ }`.",
        "code": '''title = "Clean Code"
author = "Robert Martin"

print(title + " by " + author)
print(len(title))
print(title.upper())
print(title.lower())
print("   extra spaces   ".strip())
print(title.replace("Clean", "Messy"))

pages_text = "464"              # text, not a number
pages = int(pages_text)          # now a number
print(pages + 1)
print("Pages: " + str(pages))

print(f"{title} by {author} has {pages} pages")
''',
        "walkthrough": [
            ['print(title + " by " + author)', "`+` glues strings together. Notice the spaces inside `\" by \"`: `+` does not add spaces for you."],
            ["print(len(title))", "`len()` counts characters, including spaces: `Clean Code` has 10."],
            ["print(title.upper())", "A **method** is an action that belongs to a value. Write the value, a dot, the method name and `()`. `upper()` returns a new, upper-case copy."],
            ["pages = int(pages_text)", "`int()` converts the text `\"464\"` into the number 464, so you can do maths with it."],
            ['print("Pages: " + str(pages))', "You cannot `+` text and a number. `str()` turns the number into text first."],
            ['print(f"{title} by {author} has {pages} pages")', "An **f-string**: the `f` before the quote lets you put variables inside `{ }`. Numbers are converted automatically."],
        ],
        "mistakes": [
            '`"Pages: " + 464` fails with `TypeError: can only concatenate str (not "int") to str`. Use `str(464)` or an f-string.',
            "Forgetting the `f` in an f-string: `\"{title}\"` prints the braces literally.",
            "Forgetting the brackets on a method: `title.upper` (no `()`) does not call it.",
        ],
        "challenge": {
            "task": "Given `title = \"  the pragmatic programmer \"`, create `clean_title` that has the spaces removed from both ends and is in UPPER CASE. Then print the f-string `Book: ` followed by the clean title.",
            "hints": [
                "You can chain methods: `title.strip().upper()` does strip first, then upper.",
                'Print with `print(f"Book: {clean_title}")`.',
            ],
            "starter": '''title = "  the pragmatic programmer "

clean_title = ...
print(...)
''',
            "solution": '''title = "  the pragmatic programmer "

clean_title = title.strip().upper()
print(f"Book: {clean_title}")
''',
            "tests": '''assert clean_title == "THE PRAGMATIC PROGRAMMER", f"clean_title is {clean_title!r}"
assert __output__.strip() == "Book: THE PRAGMATIC PROGRAMMER", f"you printed {__output__.strip()!r}"''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "booleans",
        "title": "True, False and comparisons",
        "idea": "A **boolean** (type `bool`) is either `True` or `False` (capital T and F). You get booleans by comparing values:\n- `==` equal, `!=` not equal\n- `<` less than, `>` greater than, `<=`, `>=`\n\nCombine them with `and` (both must be true), `or` (at least one true) and `not` (flips True and False).\n\nRemember: one `=` **stores** a value; two `==` **compares** values.",
        "code": '''pages = 464
available = True

print(pages > 300)
print(pages == 464)
print(pages != 464)
print("clean" == "Clean")        # case matters

is_long = pages > 400
print("Is long?", is_long)

member_active = True
fines_due = 0
can_borrow = available and member_active and fines_due == 0
print("Can borrow?", can_borrow)
print(not available)
print(pages < 100 or available)
''',
        "walkthrough": [
            ["print(pages > 300)", "A comparison produces `True` or `False`. 464 is greater than 300, so `True`."],
            ['print("clean" == "Clean")', "Strings must match exactly, including capitals, so this is `False`."],
            ["is_long = pages > 400", "You can store the result of a comparison in a variable."],
            ["can_borrow = available and member_active and fines_due == 0", "`and` is `True` only if **every** part is `True`."],
            ["print(not available)", "`not` flips the value: `not True` is `False`."],
            ["print(pages < 100 or available)", "`or` is `True` if **at least one** part is `True`. `pages < 100` is False but `available` is True."],
        ],
        "mistakes": [
            "Writing `true` or `false` in lower case. Python needs `True` and `False`.",
            "Using `=` to compare: `if pages = 464:` is an error. Use `==`.",
        ],
        "challenge": {
            "task": "A member may borrow if they are `active` **and** have fewer than 3 loans. Using the variables given, create `can_borrow` with a single expression.",
            "hints": [
                "Fewer than 3 is written `loans < 3`.",
                "Join the two conditions with `and`: `can_borrow = active and loans < 3`.",
            ],
            "starter": '''active = True
loans = 2

can_borrow = ...
print(can_borrow)
''',
            "solution": '''active = True
loans = 2

can_borrow = active and loans < 3
print(can_borrow)
''',
            "tests": '''import io, contextlib
assert can_borrow is True, f"with active=True and loans=2, can_borrow should be True, got {can_borrow!r}"
for a, n, expected in ((True, 3, False), (False, 0, False), (True, 0, True), (False, 5, False)):
    code = __source__.replace("active = True", f"active = {a}", 1).replace("loans = 2", f"loans = {n}", 1)
    trial = {}
    with contextlib.redirect_stdout(io.StringIO()):
        exec(code, trial)
    assert trial.get("can_borrow") is expected, f"with active={a} and loans={n}, can_borrow should be {expected}, got {trial.get('can_borrow')!r}"''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "if-else",
        "title": "Decisions: if, elif, else",
        "idea": "`if` runs a block of code only when a condition is `True`.\n\n**Indentation matters in Python.** The line with `if` ends with a colon `:`, and the lines that belong to it are indented by 4 spaces (press Tab in this editor). When the indentation stops, the `if` block is over.\n\n- `elif` (\"else if\") checks another condition when the earlier ones were False.\n- `else` runs when nothing above matched.\n\nPython checks the conditions from top to bottom and runs **only the first** block that matches.",
        "code": '''pages = 464

if pages > 400:
    print("This is a long book.")
    print("Plan a few weeks.")

print("This line always runs.")

days_late = 3
if days_late == 0:
    status = "on time"
elif days_late <= 7:
    status = "a little late"
else:
    status = "very late"
print("Status:", status)

available = False
if available:
    print("You can borrow it now.")
else:
    print("Join the waiting list.")
''',
        "walkthrough": [
            ["if pages > 400:", "The condition comes after `if`, and the line ends with a colon `:`."],
            ['    print("This is a long book.")', "Indented 4 spaces, so it belongs to the `if`. It only runs when `pages > 400` is True."],
            ['print("This line always runs.")', "Not indented, so it is outside the `if` and always runs."],
            ["elif days_late <= 7:", "Only checked if the first condition was False. 3 ≤ 7, so `status` becomes `\"a little late\"`."],
            ["else:", "Catches everything that did not match above. It has no condition."],
            ["if available:", "A boolean variable can be the condition directly; no need to write `== True`."],
        ],
        "mistakes": [
            "Forgetting the colon: `if pages > 400` without `:` is a `SyntaxError`.",
            "Inconsistent indentation gives `IndentationError`. Always use 4 spaces.",
            "Writing `else if`. Python's keyword is `elif`.",
        ],
        "challenge": {
            "task": "Set `category` based on `pages`: under 200 → `\"short\"`, 200 to 499 → `\"medium\"`, 500 or more → `\"long\"`. Test your code by changing `pages`.",
            "hints": [
                "Start with `if pages < 200:` and indent `category = \"short\"` under it.",
                "Then `elif pages < 500:` for medium, and `else:` for long.",
            ],
            "starter": '''pages = 464

# set category here

print(category)
''',
            "solution": '''pages = 464

if pages < 200:
    category = "short"
elif pages < 500:
    category = "medium"
else:
    category = "long"

print(category)
''',
            "tests": '''import io, contextlib
assert category == "medium", f"with pages = 464, category should be 'medium', got {category!r}"
for p, expected in ((150, "short"), (199, "short"), (200, "medium"), (499, "medium"), (500, "long"), (900, "long")):
    trial = {}
    with contextlib.redirect_stdout(io.StringIO()):
        exec(__source__.replace("pages = 464", f"pages = {p}", 1), trial)
    assert trial.get("category") == expected, f"with pages = {p}, category should be {expected!r}, got {trial.get('category')!r}"''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "lists-basics",
        "title": "Lists: many values in one variable",
        "idea": "A **list** holds several values in order, inside square brackets: `[\"Clean Code\", \"Refactoring\"]`.\n- Get one item by its position, called the **index**. Counting starts at **0**: `books[0]` is the first item, and `books[-1]` is the last.\n- `len(books)` is how many items there are.\n- `books.append(x)` adds `x` to the end.\n- `x in books` is `True` if `x` is in the list.\n- `books[1] = \"New\"` replaces an item.\n- `books[0:2]` (a **slice**) gives the items from index 0 up to, but not including, 2.",
        "code": '''books = ["Clean Code", "Refactoring", "Fluent Python"]

print(books)
print(books[0])          # first item
print(books[2])          # third item
print(books[-1])         # last item
print(len(books))

books.append("Atomic Habits")
print(books)

print("Refactoring" in books)
print("Dune" in books)

books[1] = "Refactoring (2nd edition)"
print(books[0:2])

pages = [464, 448, 1014]
print(sum(pages), max(pages), min(pages))
''',
        "walkthrough": [
            ['books = ["Clean Code", "Refactoring", "Fluent Python"]', "Square brackets make a list. Items are separated by commas."],
            ["print(books[0])", "Index 0 is the **first** item. This trips up every beginner at least once."],
            ["print(books[-1])", "Negative indexes count from the end: `-1` is the last item."],
            ['books.append("Atomic Habits")', "`append` adds one item to the end. The list is changed in place."],
            ['print("Refactoring" in books)', "`in` checks whether a value is in the list and gives True or False."],
            ["print(books[0:2])", "A slice `[start:stop]` includes `start` but stops *before* `stop`: items 0 and 1."],
            ["print(sum(pages), max(pages), min(pages))", "Built-in helpers for lists of numbers: total, largest and smallest."],
        ],
        "mistakes": [
            "`books[3]` on a 3-item list gives `IndexError: list index out of range`. The last index is `len(books) - 1`.",
            "Writing `books.append = \"x\"` instead of calling it: `books.append(\"x\")`.",
        ],
        "challenge": {
            "task": "Start from the list given. Add `\"Deep Work\"` to the end, then store the **first** book in `first_book` and the number of books in `count`.",
            "hints": [
                'Use `books.append("Deep Work")`.',
                "The first item is `books[0]`, and the count is `len(books)`.",
            ],
            "starter": '''books = ["Clean Code", "Refactoring"]

# add "Deep Work", then set first_book and count

print(books, first_book, count)
''',
            "solution": '''books = ["Clean Code", "Refactoring"]

books.append("Deep Work")
first_book = books[0]
count = len(books)

print(books, first_book, count)
''',
            "tests": '''assert books == ["Clean Code", "Refactoring", "Deep Work"], f"books is {books}"
assert first_book == "Clean Code", f"first_book is {first_book!r}"
assert count == 3, f"count is {count!r}"''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "for-loops",
        "title": "Repeating with for loops",
        "idea": "A `for` loop runs the same block of code once for each item in a list. Like `if`, the line ends with `:` and the repeated lines are indented.\n\n`range(n)` gives the numbers `0, 1, …, n-1`, which is handy for repeating something n times. `range(1, 6)` gives 1 to 5.\n\nA common pattern is the **accumulator**: start a variable at 0 before the loop and add to it inside the loop.",
        "code": '''books = ["Clean Code", "Refactoring", "Fluent Python"]

for book in books:
    print("Reading:", book)

print("Finished the list")

for number in range(3):
    print("Lap", number)

pages = [464, 448, 1014, 180]
total = 0
for p in pages:
    total = total + p
print("Total pages:", total)

long_books = 0
for p in pages:
    if p > 400:
        long_books = long_books + 1
print("Long books:", long_books)
''',
        "walkthrough": [
            ["for book in books:", "Each time round, `book` holds the next item from `books`. The name `book` is your choice."],
            ['    print("Reading:", book)', "Indented, so it repeats: once per book."],
            ["for number in range(3):", "`range(3)` gives 0, 1, 2: three laps, starting from 0."],
            ["total = 0", "The accumulator starts at 0 **before** the loop."],
            ["    total = total + p", "Each lap adds the current page count to the running total."],
            ["    if p > 400:", "You can put an `if` inside a loop; it is indented one more level."],
        ],
        "mistakes": [
            "Putting `total = 0` *inside* the loop resets it every lap.",
            "Forgetting to indent the body: the loop would have nothing to repeat (`IndentationError`).",
            "Expecting `range(3)` to include 3. It stops just before.",
        ],
        "challenge": {
            "task": "Use a `for` loop to count how many books in `pages` have **more than 300** pages. Store the answer in `count`. Do not use `len` on a filtered list; practise the loop.",
            "hints": [
                "Start with `count = 0` before the loop.",
                "Inside `for p in pages:`, write `if p > 300:` and then `count = count + 1` indented under it.",
            ],
            "starter": '''pages = [464, 120, 448, 290, 1014, 301]

count = 0
# your loop here

print(count)
''',
            "solution": '''pages = [464, 120, 448, 290, 1014, 301]

count = 0
for p in pages:
    if p > 300:
        count = count + 1

print(count)
''',
            "tests": '''assert count == 4, f"count is {count!r}, expected 4 (464, 448, 1014 and 301)"''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "while-loops",
        "title": "Repeating with while loops",
        "idea": "A `while` loop repeats **as long as** its condition is True. Use it when you don't know in advance how many times to repeat, such as retrying until something works.\n\nSomething inside the loop must eventually make the condition False, or the loop runs forever. `break` stops a loop immediately. `+=` is a shortcut: `count += 1` means `count = count + 1`.",
        "code": '''copies = 3
while copies > 0:
    print("Lending a copy. Copies left before:", copies)
    copies -= 1
print("No copies left")

savings = 0
weeks = 0
while savings < 1000:
    savings += 300
    weeks += 1
print("Weeks needed:", weeks, "savings:", savings)

attempt = 0
while True:
    attempt += 1
    print("Attempt", attempt)
    if attempt == 3:
        print("Success!")
        break
''',
        "walkthrough": [
            ["while copies > 0:", "Checks the condition before every lap. When `copies` reaches 0, the loop stops."],
            ["    copies -= 1", "`-=` subtracts: same as `copies = copies - 1`. Without it the loop would never end."],
            ["while savings < 1000:", "We don't know how many weeks it takes, so `while` fits better than `for`."],
            ["while True:", "A loop that would run forever…"],
            ["        break", "…except that `break` exits the loop as soon as it runs."],
        ],
        "mistakes": [
            "An **infinite loop**: forgetting to change the variable in the condition. On this page the tab may freeze; reload the page to recover.",
        ],
        "challenge": {
            "task": "A reader reads 40 pages per day. Use a `while` loop to find how many `days` it takes to finish a 464-page book. Keep track of `pages_read`.",
            "hints": [
                "Start with `days = 0` and `pages_read = 0`.",
                "Loop `while pages_read < 464:` and inside add 40 to `pages_read` and 1 to `days`.",
            ],
            "starter": '''book_pages = 464
per_day = 40

days = 0
pages_read = 0
# your while loop here

print(days)
''',
            "solution": '''book_pages = 464
per_day = 40

days = 0
pages_read = 0
while pages_read < book_pages:
    pages_read += per_day
    days += 1

print(days)
''',
            "tests": '''assert days == 12, f"days is {days!r}, expected 12"
assert pages_read >= 464, "keep reading until pages_read reaches the book length"''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "dicts-basics",
        "title": "Dictionaries: values with labels",
        "idea": "A **dictionary** (`dict`) stores pairs of **key → value**, inside curly braces: `{\"title\": \"Clean Code\", \"pages\": 464}`. Instead of a position, you look up a value by its key, like a word in a real dictionary.\n- `book[\"title\"]` gets a value. A missing key gives `KeyError`.\n- `book.get(\"isbn\")` gets a value but returns `None` (nothing) if the key is missing.\n- `book[\"year\"] = 2008` adds a new key or changes an existing one.\n- `for key, value in book.items():` loops over every pair.\n\nA list of dictionaries is a simple way to store a table of records.",
        "code": '''book = {
    "title": "Clean Code",
    "author": "Robert Martin",
    "pages": 464,
}

print(book["title"])
print(book.get("isbn"))
print(book.get("isbn", "no ISBN yet"))

book["year"] = 2008          # add a new key
book["pages"] = 431          # change a value
print(book)
print(len(book), "fields")

for key, value in book.items():
    print(key, "->", value)

catalog = [
    {"title": "Clean Code", "pages": 464},
    {"title": "Refactoring", "pages": 448},
]
for b in catalog:
    print(b["title"], "has", b["pages"], "pages")
''',
        "walkthrough": [
            ['book = {', "Curly braces start a dictionary. You can spread it over several lines for readability."],
            ['    "title": "Clean Code",', "Each entry is `key: value`. Keys are usually strings."],
            ['print(book["title"])', "Look up a value by its key with square brackets."],
            ['print(book.get("isbn", "no ISBN yet"))', "`get` is the safe version: the second value is used when the key is missing."],
            ['book["year"] = 2008', "Assigning to a new key adds it; assigning to an existing key replaces the value."],
            ["for key, value in book.items():", "`.items()` gives each pair, and the loop puts them into `key` and `value`."],
        ],
        "mistakes": [
            "Using a position: `book[0]` does not work on a dictionary. Use the key: `book[\"title\"]`.",
            "Forgetting the quotes around a string key: `book[title]` looks for a *variable* named title.",
        ],
        "challenge": {
            "task": "Create a dictionary `member` with keys `\"name\"` (`\"Asha\"`), `\"member_id\"` (`\"M001\"`) and `\"loans\"` (`0`). Then increase `loans` by 1 and add a new key `\"active\"` set to `True`.",
            "hints": [
                'Start with `member = {"name": "Asha", "member_id": "M001", "loans": 0}`.',
                'Then `member["loans"] = member["loans"] + 1` and `member["active"] = True`.',
            ],
            "starter": '''member = ...

# update loans and add "active"

print(member)
''',
            "solution": '''member = {"name": "Asha", "member_id": "M001", "loans": 0}

member["loans"] = member["loans"] + 1
member["active"] = True

print(member)
''',
            "tests": '''assert isinstance(member, dict), "member should be a dictionary: use { }"
assert member.get("name") == "Asha" and member.get("member_id") == "M001", member
assert member.get("loans") == 1, f"loans should be 1 after increasing, got {member.get('loans')!r}"
assert member.get("active") is True, "add the key 'active' with the value True"''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "functions-basics",
        "title": "Functions: reusable blocks of code",
        "idea": "A **function** is a named block of code you can run whenever you need it. You already used built-in ones: `print`, `len`, `round`. Now you write your own.\n- `def` starts the definition, followed by the name, brackets and a colon. The body is indented.\n- Values passed in go into **parameters**, the names in the brackets.\n- `return` sends a result back to whoever called the function. A function without `return` gives back `None`.\n- A parameter can have a **default** value, used when the caller leaves it out.\n\nDefining a function does not run it. It runs when you **call** it: `name(...)`.",
        "code": '''def greet(name):
    print(f"Welcome to BookVault, {name}!")

greet("Asha")
greet("Ravi")

def reading_days(pages, per_day=40):
    days = pages / per_day
    return round(days)

print(reading_days(464))
print(reading_days(464, 20))

result = reading_days(300)
print("Result stored:", result)

def is_long(pages):
    return pages > 400

if is_long(464):
    print("Long book!")
''',
        "walkthrough": [
            ["def greet(name):", "Defines a function called `greet` with one parameter, `name`. Nothing runs yet."],
            ['greet("Asha")', "Calls the function: `name` becomes `\"Asha\"` and the indented body runs."],
            ["def reading_days(pages, per_day=40):", "`per_day=40` is a default: if the caller gives only `pages`, `per_day` is 40."],
            ["    return round(days)", "`return` hands the answer back. The function stops here."],
            ["result = reading_days(300)", "The returned value can be stored in a variable and used later."],
            ["    return pages > 400", "A function can return True or False, which makes it handy inside `if`."],
        ],
        "mistakes": [
            "Printing instead of returning: `print` only shows a value, `return` gives it back so other code can use it.",
            "Calling a function before its `def` line has run gives `NameError`.",
            "Forgetting the brackets: `greet` (no `()`) refers to the function but does not run it.",
        ],
        "challenge": {
            "task": "Write a function `late_fee(days_late)` that **returns** the fee: ₹0 if the book is not late (0 days or fewer), otherwise ₹10 plus ₹2 per day late.",
            "hints": [
                "Start with `def late_fee(days_late):` and indent the body.",
                "Inside: `if days_late <= 0:` → `return 0`, otherwise `return 10 + 2 * days_late`.",
            ],
            "starter": '''# define late_fee here

print(late_fee(0))    # 0
print(late_fee(5))    # 20
''',
            "solution": '''def late_fee(days_late):
    if days_late <= 0:
        return 0
    return 10 + 2 * days_late

print(late_fee(0))
print(late_fee(5))
''',
            "tests": '''assert late_fee(0) == 0, f"late_fee(0) returned {late_fee(0)!r}"
assert late_fee(-2) == 0, "a book returned early has no fee"
assert late_fee(5) == 20, f"late_fee(5) returned {late_fee(5)!r}, expected 20"
assert late_fee(1) == 12''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "errors-basics",
        "title": "Reading errors, and try/except",
        "idea": "Errors are normal; every programmer sees them all day. When Python cannot run a line, it stops and prints an **error message** (a *traceback*). Read it **from the bottom up**: the last line names the error type and the reason, and the line above it shows where it happened.\n\nThe errors you will meet most:\n- `SyntaxError`: the code is not valid Python (missing `:`, bracket or quote).\n- `IndentationError`: spaces at the start of a line are wrong.\n- `NameError`: a name is misspelled or used before it was created.\n- `TypeError`: wrong kind of value, like `\"5\" + 5`.\n- `ValueError`: right type, bad value, like `int(\"abc\")`.\n- `KeyError` / `IndexError`: a missing dictionary key or list position.\n\n`try` / `except` lets your program handle an error instead of crashing. `raise` creates an error on purpose when input is invalid.",
        "code": '''text = "abc"
try:
    number = int(text)
    print("Converted:", number)
except ValueError:
    print("That is not a whole number:", text)

books = ["Clean Code"]
try:
    print(books[5])
except IndexError as error:
    print("Problem:", error)

def set_pages(pages):
    if pages <= 0:
        raise ValueError("pages must be positive")
    return pages

try:
    set_pages(-10)
except ValueError as error:
    print("Rejected:", error)

print("The program keeps running.")
''',
        "walkthrough": [
            ["try:", "Python tries the indented block."],
            ["    number = int(text)", "`int(\"abc\")` fails with a `ValueError`, so the rest of the `try` block is skipped…"],
            ["except ValueError:", "…and this block runs instead. The program does not crash."],
            ["except IndexError as error:", "`as error` stores the error so you can print its message."],
            ['        raise ValueError("pages must be positive")', "`raise` creates an error on purpose to reject bad input."],
        ],
        "mistakes": [
            "Reading only the top of the traceback. The useful part is the **last** line.",
            "Wrapping everything in `try` with a bare `except:`. It hides real bugs. Catch the specific error you expect.",
        ],
        "challenge": {
            "task": "Write `safe_int(text)` that returns the text converted to an int, or `None` if it cannot be converted. Use `try` / `except ValueError`.",
            "hints": [
                "Inside `try:` write `return int(text)`.",
                "Under `except ValueError:` write `return None`.",
            ],
            "starter": '''def safe_int(text):
    ...  # your code here

print(safe_int("42"))
print(safe_int("forty-two"))
''',
            "solution": '''def safe_int(text):
    try:
        return int(text)
    except ValueError:
        return None

print(safe_int("42"))
print(safe_int("forty-two"))
''',
            "tests": '''assert safe_int("42") == 42, f"safe_int('42') returned {safe_int('42')!r}"
assert safe_int(" 7 ") == 7, "int() already ignores surrounding spaces"
assert safe_int("forty-two") is None, "return None when the text is not a number"
assert safe_int("4.5") is None''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "modules-basics",
        "title": "Using modules: import",
        "idea": "Python comes with a large **standard library**: ready-made code grouped into **modules**. You load a module with `import`.\n- `import math` then `math.sqrt(16)`: use the module name, a dot and the function.\n- `from datetime import date` then `date(2026, 1, 1)`: import one thing directly.\n\nUseful modules for beginners: `math` (maths), `random` (random choices), `datetime` (dates), `json` (data files). Later you will install extra packages with `pip`.",
        "code": '''import math
import random
from datetime import date, timedelta

print(math.sqrt(16))
print(math.ceil(464 / 40))        # round UP: 12 days

books = ["Clean Code", "Refactoring", "Fluent Python"]
print("Random pick:", random.choice(books))

borrowed = date(2026, 3, 1)
due = borrowed + timedelta(days=14)
print("Borrowed:", borrowed)
print("Due back:", due)
print("Late?", date(2026, 3, 20) > due)
''',
        "walkthrough": [
            ["import math", "Loads the `math` module. Imports usually go at the top of the file."],
            ["print(math.ceil(464 / 40))", "`ceil` rounds **up**: 11.6 days becomes 12, because you can't read part of a day's quota and stop."],
            ["print(\"Random pick:\", random.choice(books))", "`random.choice` picks one item at random. Run the code a few times."],
            ["from datetime import date, timedelta", "Imports two names directly, so you can write `date(...)` instead of `datetime.date(...)`."],
            ["due = borrowed + timedelta(days=14)", "A `timedelta` is a length of time. Adding it to a date gives a new date."],
        ],
        "mistakes": [
            "Naming your own file `math.py` or `random.py`. Python then imports *your* file instead of the real module.",
            "Using a module before importing it gives `NameError: name 'math' is not defined`.",
        ],
        "challenge": {
            "task": "A loan started on 1 March 2026 and lasts 21 days. Using `datetime`, store the start in `borrowed` and the due date in `due`.",
            "hints": [
                "`from datetime import date, timedelta` is already at the top.",
                "`borrowed = date(2026, 3, 1)` and `due = borrowed + timedelta(days=21)`.",
            ],
            "starter": '''from datetime import date, timedelta

borrowed = ...
due = ...
print(due)
''',
            "solution": '''from datetime import date, timedelta

borrowed = date(2026, 3, 1)
due = borrowed + timedelta(days=21)
print(due)
''',
            "tests": '''assert borrowed == date(2026, 3, 1), f"borrowed is {borrowed!r}"
assert due == date(2026, 3, 22), f"due is {due!r}, expected 2026-03-22"''',
        },
    },
    # ------------------------------------------------------------------
    {
        "id": "tuples-none",
        "title": "Tuples, None and multiple assignment",
        "idea": "Three small things you will see in almost every Python program:\n- A **tuple** is like a list that cannot be changed, written with round brackets: `(\"Clean Code\", 464)`. Use it for a fixed group of values.\n- `None` means \"no value\". It is what a function returns when it has no `return`, and what `dict.get` gives for a missing key. Test for it with `is None`.\n- **Multiple assignment** (also called **unpacking**) stores several values at once: `title, pages = \"Clean Code\", 464`. The values on the right are matched to the names on the left in order.",
        "code": '''book = ("Clean Code", 464)       # a tuple
print(book[0], book[1])

title, pages = book              # unpack into two variables
print(title)
print(pages)

name, age, city = "Asha", 28, "Pune"
print(name, age, city)

isbn = None                      # no ISBN yet
if isbn is None:
    print("ISBN missing")

def find_book(title):
    if title == "Clean Code":
        return "Shelf A3"
    # no return here, so Python returns None

print(find_book("Clean Code"))
print(find_book("Dune"))
''',
        "walkthrough": [
            ['book = ("Clean Code", 464)', "Round brackets make a tuple. You read it like a list, but you cannot change, add or remove items."],
            ["title, pages = book", "Unpacking: the first value goes into `title`, the second into `pages`. The counts must match."],
            ['name, age, city = "Asha", 28, "Pune"', "The same idea without a tuple variable: three names, three values."],
            ["if isbn is None:", "`is None` is the correct way to check for \"no value\"."],
            ['print(find_book("Dune"))', "The function reaches its end without `return`, so the result is `None`."],
        ],
        "mistakes": [
            "Unpacking with the wrong count: `a, b = 1, 2, 3` gives `ValueError: too many values to unpack`.",
            "Trying to change a tuple: `book[0] = \"x\"` gives `TypeError`.",
        ],
        "challenge": {
            "task": "Swap the two variables `first` and `second` in **one line** using multiple assignment, so `first` becomes `\"Refactoring\"` and `second` becomes `\"Clean Code\"`.",
            "hints": [
                "Put the new order on the right: `first, second = ...`",
                "`first, second = second, first`",
            ],
            "starter": '''first = "Clean Code"
second = "Refactoring"

# swap them in one line

print(first, "|", second)
''',
            "solution": '''first = "Clean Code"
second = "Refactoring"

first, second = second, first

print(first, "|", second)
''',
            "tests": '''assert first == "Refactoring" and second == "Clean Code", f"first={first!r}, second={second!r}"''',
        },
    },
]

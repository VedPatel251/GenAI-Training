"""Build (and check) the Detective X game page.

Usage:
    python build_game.py            # check everything with CPython, then write detective_x.html

Checks for every case step:
  - the reference solution passes on EVERY evidence variant,
  - the untouched starter fails,
  - the solution's answer differs between variants (so a hard-coded answer cannot pass),
  - there are exactly 2 informant tips and a reveal.
Plus: every case skill exists, every skill lesson exists in day1_lessons.
"""
import contextlib
import io
import importlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

import day1_lessons            # noqa: E402  (applies the beginner layer)
import game_day1 as G          # noqa: E402
from build import check as check_lessons   # noqa: E402


def _run(code, ns):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(io.StringIO()):
        exec(code, ns)
    return buf.getvalue()


def run_step(evidence, src, tests):
    """Mirror of the page runner: evidence, then the trainee code, then tests."""
    ns = {"__name__": "__main__"}
    _run(evidence, ns)
    before = set(ns)
    out = _run(src, ns)
    ns["__output__"] = out
    ns["__source__"] = src
    _run(tests, ns)
    answer = {k: repr(v) for k, v in ns.items() if k not in before and not k.startswith("_")}
    return out, answer


def check_game(only_module=None):
    """Check every case, or only the cases from one module (python build_game.py --check game_cases_medium)."""
    problems = []
    lesson_ids = {l["id"] for l in day1_lessons.LESSONS}
    skill_ids = {s["id"] for s in G.SKILLS}
    for s in G.SKILLS:
        for lid in s["lessons"]:
            if lid not in lesson_ids:
                problems.append(f"skill {s['id']}: unknown lesson {lid}")
    seen = set()
    cases = G.CASES
    if only_module:
        cases = importlib.import_module(only_module).CASES
        known = [c["id"] for c in G.CASES]
        for c in cases:
            if known.count(c["id"]) > 1:
                problems.append(f"{c['id']}: id used by another case")
    for c in cases:
        cid = c["id"]
        if cid in seen:
            problems.append(f"{cid}: duplicate case id")
        seen.add(cid)
        for sk in c["skills"]:
            if sk not in skill_ids:
                problems.append(f"{cid}: unknown skill {sk}")
        if c["tier"] not in G.XP:
            problems.append(f"{cid}: unknown tier {c['tier']}")
        if c["tier"] == "exam":
            q = c.get("quiz") or []
            if not q or not 0 < c.get("pass_mark", 0) <= len(q):
                problems.append(f"{cid}: an exam needs a quiz and a pass_mark between 1 and the number of questions")
            for qq in q:
                if not 0 <= qq["answer"] < len(qq["options"]):
                    problems.append(f"{cid}: answer index out of range in {qq['q'][:40]}")
            continue
        if c["tier"] == "capstone":
            if not c.get("checklist") or not c.get("local"):
                problems.append(f"{cid}: a capstone needs local cards and a checklist")
            continue
        if len(c["variants"]) < 2:
            problems.append(f"{cid}: needs at least 2 evidence variants")
        for i, st in enumerate(c["steps"]):
            tag = f"{cid} step {i + 1}"
            if len(st.get("tips", [])) != 2:
                problems.append(f"{tag}: needs exactly 2 tips")
            if not st.get("reveal"):
                problems.append(f"{tag}: missing reveal")
            signatures = []
            for vi, ev in enumerate(c["variants"]):
                try:
                    out, ans = run_step(ev, st["solution"], st["tests"])
                    signatures.append((out, tuple(sorted(ans.items()))))
                except Exception as e:
                    problems.append(f"{tag}: solution fails on variant {vi + 1}: {type(e).__name__}: {e}")
            if len(set(signatures)) < 2 and len(signatures) == len(c["variants"]):
                problems.append(f"{tag}: the answer is the same on every variant, so a hard-coded answer would pass")
            try:
                run_step(c["variants"][0], st["starter"], st["tests"])
                problems.append(f"{tag}: the starter already passes")
            except Exception:
                pass
    return problems


def build():
    problems = check_lessons(day1_lessons.LESSONS) + check_game()
    for p in problems:
        print("PROBLEM:", p)
    if problems:
        sys.exit(1)
    steps = sum(len(c.get("steps", [])) for c in G.CASES)
    print(f"Checked {len(G.SKILLS)} skills, {len(G.CASES)} cases ({steps} steps) on every evidence variant: all good.")

    used = [lid for s in G.SKILLS for lid in s["lessons"]]
    lessons = [l for l in day1_lessons.LESSONS if l["id"] in used]
    game = {
        "title": G.TITLE,
        "division": G.DIVISION,
        "ranks": G.RANKS,
        "xp": G.XP,
        "fragmentsTotal": G.FRAGMENTS_TOTAL,
        "skills": G.SKILLS,
        "cases": G.CASES,
    }

    def js(obj):
        return json.dumps(obj, ensure_ascii=False).replace("</", "<\\/")

    html = (HERE / "game_template.html").read_text(encoding="utf-8")
    html = html.replace("/*__GAME_JSON__*/", js(game)).replace("/*__LESSONS_JSON__*/", js(lessons))
    out = HERE / "detective_x.html"
    out.write_text(html, encoding="utf-8")
    print(f"Wrote {out} ({len(html) // 1024} KB)")


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--check":
        found = check_game(sys.argv[2])
        for p in found:
            print("PROBLEM:", p)
        mod = importlib.import_module(sys.argv[2])
        print(f"{len(mod.CASES)} cases checked, {len(found)} problems.")
        sys.exit(1 if found else 0)
    build()

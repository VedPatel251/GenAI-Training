"""Host Detective X and the Day 1 playground on your laptop for everyone on the same network.

Usage (from this folder):
    python serve_lan.py              # port 8080
    python serve_lan.py 9000         # another port

Teammates open  http://<your-device-name>:8080  (the script prints the exact addresses).

What it does:
  - builds full web pages from detective_x.html and day1.html into lan/ (run build_game.py / build.py first
    after changing content),
  - downloads the Python engine (Brython) once into lan/static/, so trainees don't need the CDN,
  - serves everything, plus a small shared leaderboard API at /api/board, saved to lan/board.json.

The laptop running this script sees "Trainer insights" on the leaderboard. Anyone on the network can
post a score, so treat the board as motivation, not an exam record. Stop the server with Ctrl+C.
"""
import json
import socket
import sys
import threading
import time
import urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).parent
OUT = HERE / "lan"
STATIC = OUT / "static"
BOARD_FILE = OUT / "board.json"
CDN = "https://cdnjs.cloudflare.com/ajax/libs/brython/3.12.4/"
ENGINE_FILES = ["brython.min.js", "brython_stdlib.min.js"]
PAGES = {"detective-x.html": "detective_x.html", "playground.html": "day1.html"}
MAX_BODY = 64 * 1024

INDEX = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>GenAI Training · Day 1</title>
<style>
:root { --bg:#12151a; --panel:#1b1f26; --fg:#ebe6da; --muted:#9b968a; --accent:#e3a846; --line:#2d333d; color-scheme: dark; }
@media (prefers-color-scheme: light) { :root { --bg:#ece6da; --panel:#fbf8f1; --fg:#211d17; --muted:#6d6556; --accent:#9c6410; --line:#d9d0be; color-scheme: light; } }
body { margin:0; background:var(--bg); color:var(--fg); font-family: system-ui, "Segoe UI", sans-serif; }
main { max-width: 760px; margin: 0 auto; padding: 48px 16px; display:flex; flex-direction:column; gap:18px; }
h1 { margin:0; font-size: 2rem; }
p { margin:0; color: var(--muted); }
a.card { display:block; text-decoration:none; color:var(--fg); background:var(--panel); border:1px solid var(--line); border-radius:14px; padding:20px; }
a.card:hover { border-color: var(--accent); }
a.card b { font-size:1.3rem; display:block; margin-bottom:6px; }
</style></head><body><main>
<h1>GenAI Training · Day 1</h1>
<p>Everything runs in your browser. The first load downloads the Python engine (about 5 MB) from the trainer's laptop.</p>
<a class="card" href="detective-x.html"><b>Detective X</b><span>Learn Python by solving crimes. Skills, cases, ranks and a shared leaderboard.</span></a>
<a class="card" href="playground.html"><b>BookVault Playground</b><span>All Day 1 lessons in order, with runnable examples and challenges.</span></a>
</main></body></html>
"""

_lock = threading.Lock()
_board = {}


def prepare():
    OUT.mkdir(exist_ok=True)
    STATIC.mkdir(exist_ok=True)
    for name in ENGINE_FILES:
        target = STATIC / name
        if not target.exists():
            print(f"Downloading {name} (one time)...")
            urllib.request.urlretrieve(CDN + name, target)
    for out_name, src_name in PAGES.items():
        src = HERE / src_name
        if not src.exists():
            print(f"Skipping {out_name}: {src_name} not found (run the build first).")
            continue
        body = src.read_text(encoding="utf-8").replace(CDN, "static/")
        page = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
                '<meta name="viewport" content="width=device-width,initial-scale=1"></head><body>'
                + body + "</body></html>")
        (OUT / out_name).write_text(page, encoding="utf-8")
    (OUT / "index.html").write_text(INDEX, encoding="utf-8")
    global _board
    if BOARD_FILE.exists():
        try:
            _board = json.loads(BOARD_FILE.read_text(encoding="utf-8"))
        except ValueError:
            _board = {}


def _clean_row(data):
    """Keep only known fields with sane types, so a bad request can't break the board."""
    if not isinstance(data, dict):
        return None
    rid = str(data.get("id", ""))[:80]
    if not rid:
        return None
    cases = data.get("cases") if isinstance(data.get("cases"), dict) else {}
    lessons = data.get("lessons") if isinstance(data.get("lessons"), list) else []
    try:
        xp = max(0, min(int(data.get("xp", 0)), 10_000_000))
        solved = max(0, min(int(data.get("solvedCount", 0)), 10_000))
    except (TypeError, ValueError):
        return None
    return {
        "id": rid,
        "name": str(data.get("name", "Unnamed detective"))[:40],
        "rank": str(data.get("rank", ""))[:40],
        "xp": xp,
        "solvedCount": solved,
        "cases": {str(k)[:60]: int(v) for k, v in list(cases.items())[:500] if isinstance(v, int)},
        "lessons": [str(x)[:60] for x in lessons[:500]],
        "updated": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(OUT), **kwargs)

    def log_message(self, fmt, *args):
        """Quiet console: show leaderboard saves and server errors, skip page loads and 404s."""
        try:
            msg = fmt % args
        except (TypeError, ValueError):
            msg = str(fmt)
        if "POST /api/" in msg or "code 5" in msg:
            super().log_message("%s", msg)

    def _json(self, payload, status=200):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _is_host(self):
        return self.client_address[0] in ("127.0.0.1", "::1")

    def do_GET(self):
        if self.path.split("?")[0] == "/favicon.ico":   # browsers ask for a tab icon; we have none
            self.send_response(204)
            self.end_headers()
            return
        if self.path.split("?")[0] == "/api/board":
            with _lock:
                rows = list(_board.values())
            return self._json({"rows": rows, "host": self._is_host()})
        return super().do_GET()

    def do_POST(self):
        if self.path.split("?")[0] != "/api/board":
            return self._json({"error": "not found"}, 404)
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0 or length > MAX_BODY:
            return self._json({"error": "bad size"}, 400)
        try:
            row = _clean_row(json.loads(self.rfile.read(length)))
        except ValueError:
            row = None
        if not row:
            return self._json({"error": "bad data"}, 400)
        with _lock:
            _board[row["id"]] = row
            BOARD_FILE.write_text(json.dumps(_board, indent=1), encoding="utf-8")
            rows = list(_board.values())
        return self._json({"rows": rows, "host": self._is_host()})


def addresses(port):
    host = socket.gethostname()
    ips = set()
    try:
        for info in socket.getaddrinfo(host, None, socket.AF_INET):
            ips.add(info[4][0])
    except socket.gaierror:
        pass
    try:   # the address used for the default route, which is usually the Wi-Fi/LAN one
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    ips.discard("127.0.0.1")
    return [f"http://{host}:{port}"] + [f"http://{ip}:{port}" for ip in sorted(ips)]


def port_in_use(port):
    """True if another program already listens on this port (on any local address)."""
    for addr in ("127.0.0.1", "0.0.0.0"):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind((addr, port))
        except OSError:
            return True
        finally:
            s.close()
    return False


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    if port_in_use(port):
        print(f"Port {port} is already used by another program. Try another one, e.g.  python serve_lan.py {port + 1}")
        sys.exit(1)
    prepare()
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print("\nServing GenAI Training Day 1. Teammates on the same network can open:")
    for url in addresses(port):
        print("   ", url)
    print(f"\nOn this laptop: http://localhost:{port}   (shows Trainer insights)")
    print(f"Leaderboard saved to {BOARD_FILE}")
    print("Press Ctrl+C to stop.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Stopped.")


if __name__ == "__main__":
    main()

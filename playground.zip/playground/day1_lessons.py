"""Day 1 lesson content for the BookVault Playground.

Each lesson has:
  id        - url-safe slug (used as #hash link)
  part      - index into PARTS
  title     - lesson name
  slides    - slide numbers in the Day 1 deck it maps to
  idea      - 1-3 short paragraphs (plain text, `code` allowed)
  predict   - optional "guess first" quiz: q, options, answer (index), why
  code      - runnable demo (Python 3.11+, no file/network access)
  challenge - optional: task, starter, solution, tests (assert statements)
"""

DAY = {
    "number": 1,
    "title": "Python Foundations",
    "tagline": "Run every Day 1 example in your browser, guess before you run, then solve the challenge.",
}

PARTS = [
    "Language Essentials",
    "Functions & Pythonic Tools",
    "Object Modeling",
    "Dunders & Dataclasses",
    "Assignments",
    "Wrap-up",
]

LESSONS = [
    # ------------------------------------------------------------------ PART 1
    {
        "id": "dynamic-typing",
        "part": 0,
        "title": "Names point to objects",
        "slides": "8-9",
        "idea": "A variable is just a name. The object it points to carries the type, so the same name can hold an int, then a str, then a list.\n\nThat flexibility is why tests (Day 2) and type hints matter later.",
        "code": '''x = 42
print(type(x), x)
x = "hello"
print(type(x), x)
x = [1, 2, 3]
print(type(x), x)

# BookVault values and their types
pages, rating, available, isbn = 464, 4.7, True, None
for value in (pages, rating, available, isbn):
    print(f"{value!r:>6} -> {type(value).__name__}")
''',
        "challenge": {
            "task": "Build `kinds`: a list of the type *names* of each value in `values`.",
            "starter": '''values = [464, "Clean Code", ["python"], None]

kinds = ...  # your code here
print(kinds)
''',
            "solution": '''values = [464, "Clean Code", ["python"], None]

kinds = [type(v).__name__ for v in values]
print(kinds)
''',
            "tests": '''assert kinds == ["int", "str", "list", "NoneType"], f"got {kinds}"''',
        },
    },
    {
        "id": "float-trap",
        "part": 0,
        "title": "The float trap",
        "slides": "9",
        "idea": "Floats are binary approximations, so tiny rounding errors appear. Never compare floats with `==` and never store money in a float.\n\nUse `decimal.Decimal` for money and `math.isclose` for measurements.",
        "predict": {
            "q": "What does `print(0.1 + 0.2 == 0.3)` print?",
            "options": ["True", "False", "SyntaxError"],
            "answer": 1,
            "why": "0.1 + 0.2 is actually 0.30000000000000004, so the comparison is False.",
        },
        "code": '''print(0.1 + 0.2)            # 0.30000000000000004
print(0.1 + 0.2 == 0.3)     # False!

from decimal import Decimal
print(Decimal("0.1") + Decimal("0.2"))   # exactly 0.3

import math
print(math.isclose(0.1 + 0.2, 0.3))      # True
''',
        "challenge": {
            "task": "Add up the late fees exactly. `total` must equal `Decimal(\"25.10\")`.",
            "starter": '''from decimal import Decimal

fees = ["19.99", "5.01", "0.10"]
total = ...  # your code here
print(total)
''',
            "solution": '''from decimal import Decimal

fees = ["19.99", "5.01", "0.10"]
total = sum(Decimal(f) for f in fees)
print(total)
''',
            "tests": '''assert total == Decimal("25.10"), f"got {total!r}"''',
        },
    },
    {
        "id": "truthiness",
        "part": 0,
        "title": "Truthiness",
        "slides": "10, 14",
        "idea": "Empty things are falsy: `0`, `\"\"`, `[]`, `{}`, `None`. Everything else is truthy, including `\" \"` and `[0]`.\n\nPythonic code writes `if items:` instead of `if len(items) > 0:`. Later your `Library` class will be falsy when it has no books.",
        "predict": {
            "q": "Which of these is truthy?",
            "options": ['bool("")', 'bool([0])', "bool(0)", "bool({})"],
            "answer": 1,
            "why": "[0] is a list with one item. It is non-empty, so it is truthy. The value inside does not matter.",
        },
        "code": '''test_values = [0, 1, -1, "", " ", "False", [], [0], {}, {0: 0}, None]
for v in test_values:
    print(f"{v!r:>8}  ->  {bool(v)}")

# Ternary expression
shelf = []
print("Shelf has books" if shelf else "Shelf is empty")
''',
        "challenge": {
            "task": "Write `first_or_default(items, default)` that returns the first item, or `default` when `items` is empty. Use truthiness, not `len()`.",
            "starter": '''def first_or_default(items, default):
    ...  # your code here

print(first_or_default(["Clean Code", "Refactoring"], "none"))
print(first_or_default([], "none"))
''',
            "solution": '''def first_or_default(items, default):
    return items[0] if items else default

print(first_or_default(["Clean Code", "Refactoring"], "none"))
print(first_or_default([], "none"))
''',
            "tests": '''assert first_or_default(["a", "b"], "x") == "a"
assert first_or_default([], "x") == "x"
assert first_or_default([0], "x") == 0, "a list holding 0 is still non-empty"''',
        },
    },
    {
        "id": "strings",
        "part": 0,
        "title": "Strings are sequences",
        "slides": "11",
        "idea": "Strings index from 0, negative indexes count from the end, and `start:stop:step` slices cheaply.\n\nStrings are immutable: every method returns a new string. BookVault search starts by normalizing both the query and the title.",
        "code": '''title = "The Pragmatic Programmer"
print(title[0])
print(title[-1])
print(title[4:13])
print(title[::-1])
print(title[::2])              # every other char
print(title.split())
print("-".join(["a", "b", "c"]))
print("  hi  ".strip())
print(title.lower().replace("the ", ""))
''',
        "challenge": {
            "task": "Write `normalize(title)`: strip spaces, lowercase it, and drop a leading `\"the \"` if there is one.",
            "starter": '''def normalize(title):
    ...  # your code here

print(normalize("  The Pragmatic Programmer "))
''',
            "solution": '''def normalize(title):
    t = title.strip().lower()
    return t[4:] if t.startswith("the ") else t

print(normalize("  The Pragmatic Programmer "))
''',
            "tests": '''assert normalize("  The Pragmatic Programmer ") == "pragmatic programmer"
assert normalize("Clean Code") == "clean code"
assert normalize("Theory of Fun") == "theory of fun", "only drop 'the ' as a whole word"''',
        },
    },
    {
        "id": "f-strings",
        "part": 0,
        "title": "f-strings, every form",
        "slides": "12",
        "idea": "f-strings are the one way to format text. A format spec after `:` controls decimals, alignment, thousands separators and percentages.\n\n`f\"{name=}\"` prints both the expression and its value, which is handy for quick debugging.",
        "code": '''name = "Dave"
year = 1999
price = 49.95
big = 1_234_567

print(f"{name} in {year}")
print(f"${price:.2f}")
print(f"{big:,}")              # 1,234,567
print(f"[{price:>10.2f}]")     # right-aligned, 10 wide
print(f"[{price:<10.2f}]")     # left-aligned
print(f"[{price:^10.2f}]")     # centered
print(f"{0.875:.1%}")          # 87.5%
print(f"{255:b} {255:x}")      # binary, hex

# Debug form
print(f"{name=}, {year=}, {price=:.2f}")
''',
        "challenge": {
            "task": "Write `receipt_line(title, price)` that pads the title to 14 characters, then adds the price with 2 decimals: `\"Clean Code    $49.95\"`.",
            "starter": '''def receipt_line(title, price):
    ...  # your code here

print(receipt_line("Clean Code", 49.95))
print(receipt_line("Refactoring", 7.5))
''',
            "solution": '''def receipt_line(title, price):
    return f"{title:<14}${price:.2f}"

print(receipt_line("Clean Code", 49.95))
print(receipt_line("Refactoring", 7.5))
''',
            "tests": '''assert receipt_line("Clean Code", 49.95) == "Clean Code    $49.95", repr(receipt_line("Clean Code", 49.95))
assert receipt_line("Refactoring", 7.5) == "Refactoring   $7.50"''',
        },
    },
    {
        "id": "containers",
        "part": 0,
        "title": "Lists, tuples, sets",
        "slides": "13",
        "idea": "Lists are ordered and mutable, tuples are ordered and fixed, sets hold unique items with O(1) lookup.\n\nIf you keep calling `x in big_list`, build a set once. And watch out: `.copy()` is shallow, so nested lists are still shared.",
        "predict": {
            "q": "`nested = [[1, 2]]`, `shallow = nested.copy()`, then `nested[0].append(99)`. What is `shallow`?",
            "options": ["[[1, 2]]", "[[1, 2, 99]]", "[[1, 2], 99]"],
            "answer": 1,
            "why": "A shallow copy makes a new outer list, but the inner list is the same object. Use copy.deepcopy to copy the inner lists too.",
        },
        "code": '''import copy, time

# List basics
catalog = ["The Pragmatic Programmer", "Clean Code", "Refactoring"]
catalog.append("Designing Data-Intensive Applications")
catalog.insert(0, "SICP")
catalog.remove("Refactoring")
print(catalog, len(catalog))
print(catalog[:2], sorted(catalog, key=len)[0])

# Why sets: membership in a list scans every item
big_list = list(range(200_000))
big_set = set(big_list)
t0 = time.perf_counter(); 199_999 in big_list; t_list = time.perf_counter() - t0
t0 = time.perf_counter(); 199_999 in big_set; t_set = time.perf_counter() - t0
print(f"list lookup {t_list*1000:.2f} ms vs set lookup {t_set*1000:.3f} ms")

# Shallow vs deep copy, a famous bug
nested = [[1, 2], [3, 4]]
shallow = nested.copy()
deep = copy.deepcopy(nested)
nested[0].append(99)
print("shallow:", shallow)   # leaked!
print("deep:   ", deep)      # safe

# Tuple unpacking
first, *middle, last = [1, 2, 3, 4, 5]
print(first, middle, last)
a, b = 1, 2
a, b = b, a                  # swap, no temp variable
print(a, b)

# Set algebra
fiction = {"Dune", "1984", "Brave New World"}
classics = {"1984", "Pride and Prejudice", "Moby Dick"}
print(fiction & classics)    # in both
print(fiction - classics)    # only fiction
''',
        "challenge": {
            "task": "Write `in_both(a, b)` that returns a **sorted list** of ISBNs present in both catalogs. Use sets.",
            "starter": '''def in_both(a, b):
    ...  # your code here

central = ["111", "222", "333", "222"]
branch = ["333", "444", "111"]
print(in_both(central, branch))
''',
            "solution": '''def in_both(a, b):
    return sorted(set(a) & set(b))

central = ["111", "222", "333", "222"]
branch = ["333", "444", "111"]
print(in_both(central, branch))
''',
            "tests": '''assert in_both(["111", "222", "333", "222"], ["333", "444", "111"]) == ["111", "333"]
assert in_both([], ["1"]) == []''',
        },
    },
    {
        "id": "dicts",
        "part": 0,
        "title": "Dicts and collections",
        "slides": "13",
        "idea": "Dicts map keys to values with O(1) lookup. Use `.get()` for safe access, `setdefault` for get-or-create and `|` to merge.\n\nThe `collections` module adds `Counter`, `defaultdict`, `deque` and `namedtuple`, which cover most counting and grouping jobs.",
        "assignment": "Q8",
        "code": '''from collections import Counter, defaultdict, deque, namedtuple

book = {"title": "Clean Code", "author": "Martin", "year": 2008}
print(book.get("isbn", "no isbn"))

defaults = {"available": True, "loans": 0}
print(defaults | {"loans": 3})          # merge (3.9+)

words = "the quick brown fox jumps over the lazy dog the".split()
c = Counter(words)
print(c.most_common(2))
print(c["missing"])                     # 0, no KeyError

groups = defaultdict(list)
for word in words:
    groups[word[0]].append(word)
print(dict(groups))

recent = deque(maxlen=3)                # keeps the last 3
for i in range(5):
    recent.append(i)
print(recent)

Point = namedtuple("Point", ["x", "y"])  # a tuple with named fields
p = Point(10, 20)
print(p, p.x, p.y)
''',
        "challenge": {
            "task": "Write `group_by_year(books)` that returns `{year: [titles]}` using `defaultdict` (return a plain `dict`). Then write `group_by_year_setdefault(books)` that does the same with `setdefault` and no `defaultdict`. Which reads better?",
            "starter": '''from collections import defaultdict

books = [
    {"title": "Clean Code", "year": 2008},
    {"title": "Refactoring", "year": 2018},
    {"title": "Clean Architecture", "year": 2018},
]

def group_by_year(books):
    ...  # defaultdict version

def group_by_year_setdefault(books):
    ...  # setdefault version

print(group_by_year(books))
print(group_by_year_setdefault(books))
''',
            "solution": '''from collections import defaultdict

books = [
    {"title": "Clean Code", "year": 2008},
    {"title": "Refactoring", "year": 2018},
    {"title": "Clean Architecture", "year": 2018},
]

def group_by_year(books):
    groups = defaultdict(list)
    for b in books:
        groups[b["year"]].append(b["title"])
    return dict(groups)

def group_by_year_setdefault(books):
    groups = {}
    for b in books:
        groups.setdefault(b["year"], []).append(b["title"])
    return groups

print(group_by_year(books))
print(group_by_year_setdefault(books))
''',
            "tests": '''expected = {2008: ["Clean Code"], 2018: ["Refactoring", "Clean Architecture"]}
result = group_by_year(books)
assert type(result) is dict, "group_by_year: return a plain dict"
assert result == expected, f"group_by_year got {result}"
result2 = group_by_year_setdefault(books)
assert type(result2) is dict and result2 == expected, f"group_by_year_setdefault got {result2}"
assert group_by_year([]) == {} and group_by_year_setdefault([]) == {}''',
        },
    },
    {
        "id": "control-flow",
        "part": 0,
        "title": "Loop-else and match/case",
        "slides": "15-16",
        "idea": "A `for` loop's `else` runs only when the loop finished without `break`, which suits search loops.\n\n`match/case` matches on the *shape* of data. Later it dispatches CLI commands, JSON records and LLM tool calls.",
        "code": '''target = "Refactoring"
for book in ["Clean Code", "The Pragmatic Programmer"]:
    if book == target:
        print("Found!")
        break
else:
    print(f"{target!r} not in catalog")

def describe_item(item):
    match item:
        case {"type": "book", "pages": pages} if pages > 500:
            return f"thick book ({pages}p)"
        case {"type": "book", "pages": pages}:
            return f"book ({pages}p)"
        case {"type": "magazine", "issue": issue}:
            return f"magazine #{issue}"
        case _:
            return "unknown"

print(describe_item({"type": "book", "pages": 600}))
print(describe_item({"type": "book", "pages": 200}))
print(describe_item({"type": "magazine", "issue": 42}))
print(describe_item({"type": "audiobook"}))
''',
        "challenge": {
            "task": "Write the BookVault CLI router with `match` on `cmd.split()`: `list` → `\"listing\"`, `search <q>` → `\"searching <q>\"`, `borrow <ids...>` → `\"borrowing <n> items\"`, anything else → `\"unknown\"`.",
            "starter": '''def route(cmd):
    match cmd.split():
        case _:
            return "unknown"

for c in ["list", "search clean", "borrow B001 M001", "dance"]:
    print(c, "->", route(c))
''',
            "solution": '''def route(cmd):
    match cmd.split():
        case ["list"]:
            return "listing"
        case ["search", query]:
            return f"searching {query}"
        case ["borrow", *ids] if ids:
            return f"borrowing {len(ids)} items"
        case _:
            return "unknown"

for c in ["list", "search clean", "borrow B001 M001", "dance"]:
    print(c, "->", route(c))
''',
            "tests": '''assert route("list") == "listing"
assert route("search clean") == "searching clean"
assert route("borrow B001 M001") == "borrowing 2 items"
assert route("dance") == "unknown"''',
        },
    },
    # ------------------------------------------------------------------ PART 2
    {
        "id": "arguments",
        "part": 1,
        "title": "Function signatures",
        "slides": "18-19",
        "idea": "A signature is a contract: positional, default, `*args` (a tuple) and `**kwargs` (a dict).\n\nPut `/` after parameters that must be positional and `*` before ones that must be named. Booleans should always be keyword-only: `search(\"x\", True)` is unreadable.",
        "code": '''def add_book(title, author, year=2024, *tags, **metadata):
    print(f"{title=} {author=} {year=}")
    print(f"{tags=}")
    print(f"{metadata=}")

add_book("Clean Code", "Martin", 2008,
         "programming", "classic",
         isbn="978-0132350884", pages=464)

def search(query, /, limit=10, *, exact=False):
    return f"q={query}, limit={limit}, exact={exact}"

print(search("python", limit=20, exact=True))
for bad in ('search(query="python")', 'search("python", 5, True)'):
    try:
        eval(bad)
    except TypeError as e:
        print("TypeError:", e)
''',
        "challenge": {
            "task": "Write `make_book(title, author, *tags, **extra)` that returns a dict with `title`, `author`, `tags` (as a list) plus every extra keyword.",
            "starter": '''def make_book(title, author, *tags, **extra):
    ...  # your code here

print(make_book("Clean Code", "Martin", "classic", "python", pages=464))
''',
            "solution": '''def make_book(title, author, *tags, **extra):
    return {"title": title, "author": author, "tags": list(tags), **extra}

print(make_book("Clean Code", "Martin", "classic", "python", pages=464))
''',
            "tests": '''b = make_book("Clean Code", "Martin", "classic", "python", pages=464)
assert b == {"title": "Clean Code", "author": "Martin", "tags": ["classic", "python"], "pages": 464}, b
assert make_book("A", "B")["tags"] == []''',
        },
    },
    {
        "id": "mutable-default",
        "part": 1,
        "title": "The mutable default trap",
        "assignment": "Q5",
        "slides": "33",
        "idea": "Default values are created **once**, when `def` runs, not on every call. A default `[]` is therefore shared by every call that uses it.\n\nUse `None` as the default and create the list inside the function.",
        "predict": {
            "q": "`def add(x, items=[]): items.append(x); return items`. What does the second call `add(\"b\")` return?",
            "options": ['["b"]', '["a", "b"]', "None"],
            "answer": 1,
            "why": "Both calls use the same default list, so the first call's \"a\" is still in it.",
        },
        "code": '''def add_tag_bad(tag, tags=[]):     # shared list across calls!
    tags.append(tag)
    return tags

print(add_tag_bad("classic"))      # ['classic']
print(add_tag_bad("python"))       # ['classic', 'python']  leak!

def add_tag_good(tag, tags=None):
    if tags is None:
        tags = []
    tags.append(tag)
    return tags

print(add_tag_good("classic"))     # ['classic']
print(add_tag_good("python"))      # ['python']
''',
        "challenge": {
            "task": "Fix `add_item` so every call without a basket starts with a fresh one.",
            "starter": '''def add_item(item, basket=[]):
    basket.append(item)
    return basket

print(add_item("apple"))
print(add_item("milk"))
''',
            "solution": '''def add_item(item, basket=None):
    if basket is None:
        basket = []
    basket.append(item)
    return basket

print(add_item("apple"))
print(add_item("milk"))
''',
            "tests": '''assert add_item("apple") == ["apple"]
assert add_item("milk") == ["milk"], "the default list is still shared"
mine = ["bread"]
assert add_item("egg", mine) is mine and mine == ["bread", "egg"]''',
        },
    },
    {
        "id": "scope",
        "part": 1,
        "title": "Scope (LEGB) and closures",
        "slides": "20",
        "idea": "Python looks up names in order: Local, Enclosing, Global, Built-in.\n\nAssigning to a name *anywhere* in a function makes it local for the *whole* function, which causes `UnboundLocalError`. Use `nonlocal` to change a variable from an enclosing function.",
        "predict": {
            "q": "`total = 0` at module level, then `def add(x): total = total + x`. What happens on `add(5)`?",
            "options": ["total becomes 5", "UnboundLocalError", "NameError"],
            "answer": 1,
            "why": "The assignment makes `total` local to `add`, so reading it on the right-hand side fails before it has a value.",
        },
        "code": '''total = 0
def add_bad(x):
    total = total + x          # UnboundLocalError
try:
    add_bad(5)
except UnboundLocalError as e:
    print("Caught:", e)

def make_counter():
    count = 0
    def inc():
        nonlocal count
        count += 1
        return count
    return inc

counter = make_counter()
print(counter(), counter(), counter())   # 1 2 3
''',
        "challenge": {
            "task": "Write `make_ticket_dispenser(start)` that returns a function. Each call returns the next ticket number, beginning at `start`.",
            "starter": '''def make_ticket_dispenser(start):
    ...  # your code here

next_ticket = make_ticket_dispenser(100)
print(next_ticket(), next_ticket(), next_ticket())
''',
            "solution": '''def make_ticket_dispenser(start):
    current = start - 1
    def next_ticket():
        nonlocal current
        current += 1
        return current
    return next_ticket

next_ticket = make_ticket_dispenser(100)
print(next_ticket(), next_ticket(), next_ticket())
''',
            "tests": '''t = make_ticket_dispenser(100)
assert [t(), t(), t()] == [100, 101, 102]
other = make_ticket_dispenser(1)
assert other() == 1 and t() == 103, "each dispenser keeps its own count"''',
        },
    },
    {
        "id": "context-managers",
        "part": 1,
        "title": "Context managers",
        "slides": "22",
        "idea": "`with` guarantees cleanup: files close, locks release and transactions commit or roll back, even when an error happens.\n\n`@contextmanager` turns a generator into a context manager. Code before `yield` is setup and code after it is teardown.",
        "code": '''from contextlib import contextmanager

@contextmanager
def transaction(db_name):
    print(f"BEGIN on {db_name}")
    try:
        yield db_name
        print("COMMIT")
    except Exception:
        print("ROLLBACK")
        raise

with transaction("bookvault") as db:
    print(f"Writing safely to {db}")

print("---")
try:
    with transaction("bookvault"):
        print("Borrowing B001...")
        raise ValueError("B001 is already on loan")
except ValueError as e:
    print("Error reached caller:", e)
''',
        "challenge": {
            "task": "Write `@contextmanager opened(log)` that appends `\"open\"` on entry and `\"close\"` on exit, **even if the block raises**.",
            "starter": '''from contextlib import contextmanager

@contextmanager
def opened(log):
    ...  # your code here
    yield

log = []
with opened(log):
    log.append("work")
print(log)
''',
            "solution": '''from contextlib import contextmanager

@contextmanager
def opened(log):
    log.append("open")
    try:
        yield
    finally:
        log.append("close")

log = []
with opened(log):
    log.append("work")
print(log)
''',
            "tests": '''log = []
with opened(log):
    log.append("work")
assert log == ["open", "work", "close"], log
log = []
try:
    with opened(log):
        raise RuntimeError("boom")
except RuntimeError:
    pass
assert log == ["open", "close"], f"close must run even on error: {log}"''',
        },
    },
    {
        "id": "first-class",
        "part": 1,
        "title": "Functions are values",
        "slides": "21, 25",
        "idea": "Functions can be stored, passed, returned and composed. That one idea powers `sorted(key=...)`, `partial`, decorators and pipelines.\n\n`sorted(key=...)` with a tuple key sorts by several fields at once. Negate a number to sort it descending.",
        "code": '''from functools import partial

def shout(s): return s.upper() + "!"
def whisper(s): return s.lower() + "..."
styles = {"loud": shout, "quiet": whisper}
print(styles["loud"]("Hello"), styles["quiet"]("Hello"))

def make_multiplier(factor):
    def multiply(x):
        return x * factor
    return multiply
double = make_multiplier(2)
print(double(10))

books = [
    {"title": "B", "year": 2020, "rating": 4.2},
    {"title": "A", "year": 2018, "rating": 4.8},
    {"title": "C", "year": 2020, "rating": 4.5},
]
for b in sorted(books, key=lambda b: (b["year"], -b["rating"])):
    print(b)

from operator import itemgetter        # faster than a lambda for plain keys
print([b["title"] for b in sorted(books, key=itemgetter("rating"), reverse=True)])

def power(base, exp): return base ** exp
square = partial(power, exp=2)
print(square(5))
''',
        "challenge": {
            "task": "Write `newest_first(books)`: sort by `year` descending, then `title` A→Z for ties. Return the list of titles.",
            "starter": '''books = [
    {"title": "Refactoring", "year": 2018},
    {"title": "Clean Code", "year": 2008},
    {"title": "Accelerate", "year": 2018},
]

def newest_first(books):
    ...  # your code here

print(newest_first(books))
''',
            "solution": '''books = [
    {"title": "Refactoring", "year": 2018},
    {"title": "Clean Code", "year": 2008},
    {"title": "Accelerate", "year": 2018},
]

def newest_first(books):
    ordered = sorted(books, key=lambda b: (-b["year"], b["title"]))
    return [b["title"] for b in ordered]

print(newest_first(books))
''',
            "tests": '''assert newest_first(books) == ["Accelerate", "Refactoring", "Clean Code"], newest_first(books)''',
        },
    },
    {
        "id": "comprehensions",
        "part": 1,
        "title": "The four comprehensions",
        "assignment": "Q3",
        "slides": "27",
        "idea": "List, set and dict comprehensions build a collection right away. A generator expression `( ... )` produces values lazily, one at a time.\n\nA generator can only be consumed **once**.",
        "predict": {
            "q": "`gen = (x for x in range(3))`, then `list(gen)` twice. What does the second `list(gen)` give?",
            "options": ["[0, 1, 2]", "[]", "StopIteration error"],
            "answer": 1,
            "why": "The first list() consumed the generator. Once it is exhausted it yields nothing more.",
        },
        "code": '''squares = [x**2 for x in range(10) if x % 2 == 0]   # list
square_map = {x: x**2 for x in range(5)}             # dict
unique = {w.upper() for w in ["clean", "code", "clean"]}  # set
print(squares, square_map, unique, sep="\\n")

gen = (x**2 for x in range(5))                        # generator
print(gen)
print(list(gen))
print(list(gen))    # exhausted!

print(sum(x**2 for x in range(1_000)))   # no list built

matrix = [[1, 2, 3], [4, 5, 6]]
print([n for row in matrix for n in row])
''',
        "challenge": {
            "task": "In **one** list comprehension: keep only even numbers, multiply each by 3, and sort the result descending.",
            "starter": '''nums = [5, 8, 3, 12, 7, 4, 9, 2]
result = ...  # one line
print(result)
''',
            "solution": '''nums = [5, 8, 3, 12, 7, 4, 9, 2]
result = sorted([n * 3 for n in nums if n % 2 == 0], reverse=True)
print(result)
''',
            "tests": '''assert result == [36, 24, 12, 6], result''',
        },
    },
    {
        "id": "decorators",
        "part": 1,
        "title": "Decorators",
        "slides": "23-24",
        "idea": "`@trace` above a function is shorthand for `fn = trace(fn)`. The decorator returns a wrapper that adds behavior around the original call.\n\nAlways use `functools.wraps` so the wrapped function keeps its name and docstring. Keep each decorator to one job: timing, logging, retries or validation.",
        "code": '''from functools import wraps
from time import perf_counter

def trace(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        print(f"calling {fn.__name__}{args}")
        return fn(*args, **kwargs)
    return wrapper

def timed(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        start = perf_counter()
        try:
            return fn(*args, **kwargs)
        finally:
            ms = (perf_counter() - start) * 1000
            print(f"{fn.__name__} took {ms:.1f}ms")
    return wrapper

@timed
@trace
def search_books(query):
    books = ["Clean Code", "Refactoring", "The Pragmatic Programmer"]
    return [b for b in books if query.lower() in b.lower()]

print(search_books("clean"))
print(search_books.__name__)   # still 'search_books' thanks to @wraps
''',
        "challenge": {
            "task": "Write a `count_calls` decorator. The wrapped function gets a `.calls` attribute that counts how many times it ran. Keep its name with `@wraps`.",
            "starter": '''from functools import wraps

def count_calls(fn):
    ...  # your code here

@count_calls
def greet(name):
    return f"Hi {name}"

greet("Ada"); greet("Linus")
print(greet.calls, greet.__name__)
''',
            "solution": '''from functools import wraps

def count_calls(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        wrapper.calls += 1
        return fn(*args, **kwargs)
    wrapper.calls = 0
    return wrapper

@count_calls
def greet(name):
    return f"Hi {name}"

greet("Ada"); greet("Linus")
print(greet.calls, greet.__name__)
''',
            "tests": '''@count_calls
def ping():
    return "pong"
assert ping.calls == 0
assert ping() == "pong", "the wrapper must return the original result"
ping()
assert ping.calls == 2, ping.calls
assert ping.__name__ == "ping", "use functools.wraps"''',
        },
    },
    {
        "id": "generators",
        "part": 1,
        "title": "Generators and pipelines",
        "slides": "28-29",
        "idea": "`yield` pauses the function and hands back one value. Nothing runs until someone iterates.\n\nChain generators into a read → filter → transform → consume pipeline and only one record is in memory at a time. RAG ingestion and ML data loaders work this way.",
        "code": '''import io, json

# Pretend this is a huge catalog.jsonl file
catalog_file = io.StringIO(
    '{"type": "book", "title": "Clean Code"}\\n'
    '{"type": "magazine", "title": "National Geographic"}\\n'
    '{"type": "book", "title": "Refactoring"}\\n'
)

def read_jsonl(f):
    for line in f:
        print("  read one line")
        yield json.loads(line)

def only_books(records):
    for r in records:
        if r["type"] == "book":
            yield r

def titles(records):
    for r in records:
        yield r["title"]

pipeline = titles(only_books(read_jsonl(catalog_file)))
print("nothing has run yet:", pipeline)
for title in pipeline:
    print(title)
''',
        "challenge": {
            "task": "Write a generator `chunks(items, size)` that yields lists of up to `size` items. Useful for batching API calls.",
            "starter": '''def chunks(items, size):
    ...  # your code here

print(list(chunks(["B1", "B2", "B3", "B4", "B5"], 2)))
''',
            "solution": '''def chunks(items, size):
    batch = []
    for item in items:
        batch.append(item)
        if len(batch) == size:
            yield batch
            batch = []
    if batch:
        yield batch

print(list(chunks(["B1", "B2", "B3", "B4", "B5"], 2)))
''',
            "tests": '''import types
assert isinstance(chunks([1], 1), types.GeneratorType), "use yield"
assert list(chunks(range(5), 2)) == [[0, 1], [2, 3], [4]]
assert list(chunks([], 3)) == []''',
        },
    },
    # ------------------------------------------------------------------ PART 3
    {
        "id": "classes",
        "part": 2,
        "title": "Classes: state + behavior",
        "slides": "31-33",
        "idea": "A class keeps data and the behavior that changes it in one place. A `Book` knows whether it is available and how to borrow itself.\n\nClass attributes are shared by every instance. A mutable class attribute such as `tags = []` leaks between objects, so create it in `__init__` instead.",
        "predict": {
            "q": "`class Book: tags = []`. `b1.tags.append(\"classic\")`. What is `b2.tags`?",
            "options": ["[]", '["classic"]', "AttributeError"],
            "answer": 1,
            "why": "`tags` lives on the class, so every instance shares the same list.",
        },
        "code": '''class Book:
    library_name = "BookVault"          # class attribute (shared)

    def __init__(self, title, author):
        self.title = title              # instance attributes
        self.author = author
        self.available = True
        self.tags = []                  # per instance, safe

    def borrow(self):
        if not self.available:
            raise ValueError(f"{self.title} is already borrowed")
        self.available = False
        print(f"Borrowed: {self.title}")

b = Book("Clean Code", "Martin")
b.borrow()
try:
    b.borrow()
except ValueError as e:
    print("Caught:", e)

class BookBad:
    tags = []                           # shared!
b1, b2 = BookBad(), BookBad()
b1.tags.append("classic")
print("b2.tags =", b2.tags)
''',
        "challenge": {
            "task": "Write a `Member` class with `name` and a per-member `loans` list. `borrow(title)` adds the title, but raises `ValueError` once a member already has 3 loans.",
            "starter": '''class Member:
    ...  # your code here

ada = Member("Ada")
for t in ["A", "B", "C"]:
    ada.borrow(t)
print(ada.name, ada.loans)
''',
            "solution": '''class Member:
    MAX_LOANS = 3

    def __init__(self, name):
        self.name = name
        self.loans = []

    def borrow(self, title):
        if len(self.loans) >= self.MAX_LOANS:
            raise ValueError(f"{self.name} already has {self.MAX_LOANS} loans")
        self.loans.append(title)

ada = Member("Ada")
for t in ["A", "B", "C"]:
    ada.borrow(t)
print(ada.name, ada.loans)
''',
            "tests": '''a, b = Member("Ada"), Member("Linus")
a.borrow("Clean Code")
assert a.loans == ["Clean Code"] and b.loans == [], "loans must not be shared"
a.borrow("B"); a.borrow("C")
try:
    a.borrow("D")
    raise AssertionError("4th loan should raise ValueError")
except ValueError:
    pass''',
        },
    },
    {
        "id": "properties",
        "part": 2,
        "title": "Properties, classmethods, staticmethods",
        "assignment": "Q10",
        "slides": "34",
        "idea": "`@property` lets `book.pages` still look like a plain field while a setter validates it. You can add the check later without changing any caller.\n\n`@classmethod` receives the class (good for alternate constructors like `from_dict`). `@staticmethod` receives neither, so it suits pure helpers like `validate_isbn`.",
        "code": '''class Book:
    _next_id = 0                        # class attribute shared by all books

    def __init__(self, title, pages):
        self.title = title
        self.pages = pages              # goes through the setter
        self.id = Book._next_id
        Book._next_id += 1

    @classmethod
    def reset_ids(cls):                 # works on the class, not one book
        cls._next_id = 0

    @property
    def pages(self):
        return self._pages

    @pages.setter
    def pages(self, value):
        if value < 0:
            raise ValueError("Pages cannot be negative")
        self._pages = value

    @property
    def reading_time_hours(self):
        return round(self._pages / 50, 1)

    @classmethod
    def from_dict(cls, data):
        return cls(data["title"], data["pages"])

    @staticmethod
    def validate_isbn(isbn):
        return len(isbn.replace("-", "")) in (10, 13)

b = Book.from_dict({"title": "Clean Code", "pages": 464})
print(b.pages, b.reading_time_hours)
b2 = Book("Refactoring", 448)
print("ids:", b.id, b2.id)
Book.reset_ids()
print("after reset:", Book("SICP", 657).id)
print(Book.validate_isbn("978-0132350884"))
try:
    b.pages = -10
except ValueError as e:
    print("Caught:", e)
''',
        "challenge": {
            "task": "Refactor `Book` so `pages` (must be > 0) and `rating` (must be 0.0–5.0) are validated with `@property` setters. Invalid values raise `ValueError`, including in `__init__`.",
            "starter": '''class Book:
    def __init__(self, title, pages, rating):
        self.title = title
        self.pages = pages       # must be > 0
        self.rating = rating     # must be 0.0 <= rating <= 5.0

    # add the properties + setters here

b = Book("Clean Code", 464, 4.5)
print(b.pages, b.rating)
''',
            "solution": '''class Book:
    def __init__(self, title, pages, rating):
        self.title = title
        self.pages = pages
        self.rating = rating

    @property
    def pages(self):
        return self._pages

    @pages.setter
    def pages(self, value):
        if value <= 0:
            raise ValueError(f"pages must be > 0, got {value}")
        self._pages = value

    @property
    def rating(self):
        return self._rating

    @rating.setter
    def rating(self, value):
        if not 0.0 <= value <= 5.0:
            raise ValueError(f"rating must be 0-5, got {value}")
        self._rating = value

b = Book("Clean Code", 464, 4.5)
print(b.pages, b.rating)
''',
            "tests": '''b = Book("Clean Code", 464, 4.5)
b.rating = 5.0
b.pages = 300
assert (b.pages, b.rating) == (300, 5.0)
for attr, bad in (("rating", -1), ("rating", 5.1), ("pages", 0), ("pages", -5)):
    try:
        setattr(b, attr, bad)
        raise AssertionError(f"{attr}={bad} should raise ValueError")
    except ValueError:
        pass
for args in ((0, 4.0), (100, 9)):
    try:
        Book("Bad", *args)
        raise AssertionError(f"Book('Bad', {args[0]}, {args[1]}) should raise: __init__ must validate too")
    except ValueError:
        pass''',
        },
    },
    {
        "id": "inheritance-abc",
        "part": 2,
        "assignment": "Q17",
        "title": "Inheritance and ABCs",
        "slides": "35-36",
        "idea": "An abstract base class is a contract: subclasses must implement the abstract methods, and you cannot create the base class itself.\n\nThe payoff is polymorphism. One function handles every item type, with no `if isinstance` chains.",
        "code": '''from abc import ABC, abstractmethod

class LibraryItem(ABC):
    def __init__(self, title, item_id):
        self.title = title
        self.item_id = item_id

    @abstractmethod
    def describe(self) -> str: ...

class Book(LibraryItem):
    def __init__(self, title, item_id, author):
        super().__init__(title, item_id)
        self.author = author
    def describe(self):
        return f"{self.title} ({self.item_id}) by {self.author}"

class Magazine(LibraryItem):
    def __init__(self, title, item_id, issue):
        super().__init__(title, item_id)
        self.issue = issue
    def describe(self):
        return f"{self.title} ({self.item_id}) issue #{self.issue}"

try:
    LibraryItem("X", "Y")
except TypeError as e:
    print("Caught:", e)

for item in [Book("Clean Code", "B001", "Martin"), Magazine("Nat Geo", "M001", 247)]:
    print(item.describe())     # same call, different behavior
''',
        "challenge": {
            "task": "Polymorphic pricing. Add `loan_fee()` to each class: Book ₹50 flat, AudioBook ₹30 + ₹0.10 per minute, Magazine free, RareBook (a subclass of Book) ₹200 + a flat ₹500 damage deposit. `calculate_total(items)` sums the fees with **no** `isinstance` checks.",
            "starter": '''from abc import ABC, abstractmethod

class LibraryItem(ABC):
    @abstractmethod
    def loan_fee(self) -> float: ...

class Book(LibraryItem):
    pass

class AudioBook(LibraryItem):
    def __init__(self, duration_min):
        self.duration_min = duration_min

class Magazine(LibraryItem):
    pass

class RareBook(Book):
    pass

def calculate_total(items):
    ...

print(calculate_total([Book(), Magazine(), AudioBook(100), RareBook()]))
''',
            "solution": '''from abc import ABC, abstractmethod

class LibraryItem(ABC):
    @abstractmethod
    def loan_fee(self) -> float: ...

class Book(LibraryItem):
    def loan_fee(self):
        return 50

class AudioBook(LibraryItem):
    def __init__(self, duration_min):
        self.duration_min = duration_min
    def loan_fee(self):
        return 30 + 0.10 * self.duration_min

class Magazine(LibraryItem):
    def loan_fee(self):
        return 0

class RareBook(Book):
    DEPOSIT = 500
    def loan_fee(self):
        return 200 + self.DEPOSIT

def calculate_total(items):
    return sum(item.loan_fee() for item in items)

print(calculate_total([Book(), Magazine(), AudioBook(100), RareBook()]))
''',
            "tests": '''import math
assert Book().loan_fee() == 50, "Book: flat 50"
assert math.isclose(AudioBook(320).loan_fee(), 62.0), "AudioBook: 30 + 0.10 per minute"
assert Magazine().loan_fee() == 0, "Magazine: free"
assert RareBook().loan_fee() == 700, "RareBook: 200 + 500 deposit"
assert isinstance(RareBook(), Book), "RareBook must subclass Book"
assert math.isclose(calculate_total([Book(), Magazine(), AudioBook(100), RareBook()]), 790.0)
assert calculate_total([]) == 0''',
        },
    },
    {
        "id": "composition",
        "part": 2,
        "title": "Composition over inheritance",
        "slides": "37",
        "idea": "Instead of inheriting from `Loggable, Cacheable, Searchable`, a `Library` *receives* a logger and a cache. That is dependency injection.\n\nYou can swap any part, for example a fake logger in tests. An AI agent is built the same way from a model, tools, memory and a retriever.",
        "code": '''class Logger:
    def __init__(self, prefix):
        self.prefix = prefix
    def log(self, msg):
        print(f"[{self.prefix}] {msg}")

class InMemoryCache:
    def __init__(self):
        self._store = {}
    def get(self, key):
        return self._store.get(key)
    def set(self, key, value):
        self._store[key] = value

class Library:
    def __init__(self, logger, cache):
        self.logger = logger
        self.cache = cache
        self._items = {}

    def add(self, isbn, title):
        self.logger.log(f"adding {title}")
        self._items[isbn] = title

    def find(self, isbn):
        if (hit := self.cache.get(isbn)) is not None:
            self.logger.log(f"cache hit {isbn}")
            return hit
        self.logger.log(f"cache miss {isbn}")
        title = self._items.get(isbn)
        self.cache.set(isbn, title)
        return title

lib = Library(Logger("LIB"), InMemoryCache())
lib.add("978-0132350884", "Clean Code")
lib.find("978-0132350884")
lib.find("978-0132350884")
''',
        "challenge": {
            "task": "Write a `RecordingLogger` that stores messages in a `.messages` list instead of printing, and inject it into the `Library` above. No change to `Library` needed.",
            "starter": '''# The Library, Logger and InMemoryCache from the demo are already defined.
# (Run the demo once first if you edited it.)

class RecordingLogger:
    ...  # your code here

rec = RecordingLogger()
lib = Library(rec, InMemoryCache())
lib.add("111", "Clean Code")
lib.find("111")
print(rec.messages)
''',
            "solution": '''class RecordingLogger:
    def __init__(self):
        self.messages = []
    def log(self, msg):
        self.messages.append(msg)

rec = RecordingLogger()
lib = Library(rec, InMemoryCache())
lib.add("111", "Clean Code")
lib.find("111")
print(rec.messages)
''',
            "tests": '''rec = RecordingLogger()
lib = Library(rec, InMemoryCache())
lib.add("111", "Clean Code")
lib.find("111"); lib.find("111")
assert rec.messages == ["adding Clean Code", "cache miss 111", "cache hit 111"], rec.messages''',
            "needs_demo": True,
        },
    },
    # ------------------------------------------------------------------ PART 4
    {
        "id": "dunders",
        "part": 3,
        "title": "Dunders: make it feel native",
        "assignment": "Q16",
        "slides": "39-40, 43",
        "idea": "Python syntax calls dunder methods: `len(x)` calls `x.__len__()`, `y in x` calls `x.__contains__(y)` and `x[k]` calls `x.__getitem__(k)`.\n\nImplement them and your `Library` works with `len`, `in`, `for`, `[]` and `print` like a built-in. `__call__` makes an object usable as a function.",
        "code": '''class Library:
    def __init__(self, name):
        self.name = name
        self._books = {}                     # isbn -> title

    def add(self, isbn, title):
        self._books[isbn] = title

    def __repr__(self):
        return f"Library(name={self.name!r}, n={len(self)})"
    def __str__(self):
        return f"{self.name}: {len(self)} books"
    def __len__(self):
        return len(self._books)
    def __bool__(self):
        return bool(self._books)
    def __contains__(self, isbn):
        return isbn in self._books
    def __iter__(self):
        return iter(self._books.values())
    def __getitem__(self, key):
        if isinstance(key, (int, slice)):    # lib[0], lib[:2]
            return list(self._books.values())[key]
        return self._books[key]              # lib["978-..."]
    def __eq__(self, other):
        if not isinstance(other, Library):
            return NotImplemented
        return self._books == other._books
    __hash__ = None                          # mutable, so not hashable
    def __call__(self, query):
        return [t for t in self if query.lower() in t.lower()]

lib = Library("Central")
print(bool(lib))
lib.add("978-0132350884", "Clean Code")
lib.add("978-0201485677", "Refactoring")
print(repr(lib)); print(lib)
print(len(lib), "978-0132350884" in lib)
print(lib["978-0201485677"], lib[0], lib[:1])
for title in lib:
    print("  -", title)
print(lib("clean"))
''',
        "challenge": {
            "task": "Build `RecentBooks(max_size)`: it acts like a list but keeps only the N most recently added books, dropping the oldest. Support `len`, iteration, `[index]`, `in` and `repr`, plus `oldest()` and `newest()`. Tip: `collections.deque(maxlen=...)` does most of the work, but write the public API yourself.",
            "starter": '''from collections import deque

class RecentBooks:
    ...  # your code here

recent = RecentBooks(max_size=3)
for title in ["A", "B", "C", "D", "E"]:
    recent.add(title)
print(list(recent))    # ['C', 'D', 'E']
print(recent.oldest()) # 'C'
print(recent.newest()) # 'E'
''',
            "solution": '''from collections import deque

class RecentBooks:
    def __init__(self, max_size):
        self._items = deque(maxlen=max_size)
    def add(self, title):
        self._items.append(title)
    def oldest(self):
        return self._items[0]
    def newest(self):
        return self._items[-1]
    def __len__(self):
        return len(self._items)
    def __contains__(self, title):
        return title in self._items
    def __iter__(self):
        return iter(self._items)
    def __getitem__(self, index):
        return self._items[index]
    def __repr__(self):
        return f"RecentBooks(max_size={self._items.maxlen}, items={list(self._items)})"

recent = RecentBooks(max_size=3)
for title in ["A", "B", "C", "D", "E"]:
    recent.add(title)
print(list(recent))
print(recent.oldest())
print(recent.newest())
''',
            "tests": '''r = RecentBooks(max_size=3)
for t in "ABCDE":
    r.add(t)
assert list(r) == ["C", "D", "E"], list(r)
assert len(r) == 3
assert "E" in r and "A" not in r
assert r[0] == "C" and r[-1] == "E"
assert r.oldest() == "C" and r.newest() == "E"
assert "RecentBooks" in repr(r), "write a developer-friendly __repr__"''',
        },
    },
    {
        "id": "eq-hash",
        "part": 3,
        "assignment": "Q13",
        "title": "repr vs str, eq + hash",
        "slides": "41-42",
        "idea": "`__repr__` is for developers (debuggers, logs, containers) and `__str__` is for users. Always write `__repr__`.\n\nThe contract: if `a == b` then `hash(a) == hash(b)`. Define `__eq__` without `__hash__` and Python makes your object unhashable, so it cannot go in a set or be a dict key.",
        "predict": {
            "q": "A class defines `__eq__` but not `__hash__`. What happens with `{Book(\"A\")}`?",
            "options": ["A set with one book", "TypeError: unhashable type", "It uses id() for the hash"],
            "answer": 1,
            "why": "Defining __eq__ sets __hash__ to None, so instances cannot go into sets.",
        },
        "code": '''class Book:
    def __init__(self, title, isbn):
        self.title, self.isbn = title, isbn
    def __repr__(self):
        return f"Book(title={self.title!r}, isbn={self.isbn!r})"
    def __str__(self):
        return f"{self.title}"
    def __eq__(self, other):
        if not isinstance(other, Book):
            return NotImplemented
        return self.isbn == other.isbn
    def __hash__(self):
        return hash(self.isbn)

b = Book("Clean Code", "978-0132350884")
print(str(b)); print(repr(b)); print([b])
print(len({b, Book("Clean Code (2nd)", "978-0132350884")}))   # 1, same ISBN

class BookBad:
    def __init__(self, isbn): self.isbn = isbn
    def __eq__(self, other): return self.isbn == other.isbn
try:
    {BookBad("A")}
except TypeError as e:
    print("BookBad:", e)
''',
        "challenge": {
            "task": "Build the `Money(amount: Decimal, currency: str)` value object: `__repr__` (`Money(15.75, USD)`) and `__str__`, `__eq__` + `__hash__` on amount **and** currency, `+` and `-`, the four comparisons `< <= > >=`, and `__bool__` (True when amount > 0). Mixing currencies in `+ - < <= > >=` raises `ValueError`.",
            "starter": '''from decimal import Decimal

class Money:
    ...  # your code here

a = Money(Decimal("10.50"), "USD")
b = Money(Decimal("5.25"),  "USD")
c = Money(Decimal("5.00"),  "EUR")
print(a + b)        # Money(15.75, USD)
print(a == Money(Decimal("10.50"), "USD"))  # True
print({a, b, Money(Decimal("10.50"), "USD")})  # set of 2 unique
try:
    a + c
except ValueError as e:
    print(e)
''',
            "solution": '''from decimal import Decimal

class Money:
    def __init__(self, amount, currency):
        self.amount, self.currency = amount, currency

    def __repr__(self):
        return f"Money({self.amount}, {self.currency})"
    def __str__(self):
        return f"{self.amount} {self.currency}"

    def __eq__(self, other):
        if not isinstance(other, Money):
            return NotImplemented
        return (self.amount, self.currency) == (other.amount, other.currency)
    def __hash__(self):
        return hash((self.amount, self.currency))

    def _check(self, other):
        if self.currency != other.currency:
            raise ValueError(f"currency mismatch: {self.currency} vs {other.currency}")

    def __add__(self, other):
        self._check(other)
        return Money(self.amount + other.amount, self.currency)
    def __sub__(self, other):
        self._check(other)
        return Money(self.amount - other.amount, self.currency)

    def __lt__(self, other):
        self._check(other); return self.amount < other.amount
    def __le__(self, other):
        self._check(other); return self.amount <= other.amount
    def __gt__(self, other):
        self._check(other); return self.amount > other.amount
    def __ge__(self, other):
        self._check(other); return self.amount >= other.amount

    def __bool__(self):
        return self.amount > 0

a = Money(Decimal("10.50"), "USD")
b = Money(Decimal("5.25"),  "USD")
c = Money(Decimal("5.00"),  "EUR")
print(a + b)
print(a == Money(Decimal("10.50"), "USD"))
print({a, b, Money(Decimal("10.50"), "USD")})
try:
    a + c
except ValueError as e:
    print(e)
''',
            "tests": '''a = Money(Decimal("10.50"), "USD")
b = Money(Decimal("5.25"), "USD")
c = Money(Decimal("5.00"), "EUR")
assert repr(a + b) == "Money(15.75, USD)", repr(a + b)
assert a - b == Money(Decimal("5.25"), "USD")
assert a == Money(Decimal("10.50"), "USD") and a != Money(Decimal("10.50"), "EUR")
assert len({a, b, Money(Decimal("10.50"), "USD")}) == 2
assert b < a and b <= a and a > b and a >= b and a >= Money(Decimal("10.50"), "USD")
assert bool(a) and not Money(Decimal("0"), "USD")
for op in ("a + c", "a - c", "a < c", "a <= c", "a > c", "a >= c"):
    try:
        eval(op)
        raise AssertionError(f"{op} should raise ValueError (different currencies)")
    except ValueError:
        pass''',
        },
    },
    {
        "id": "dataclasses",
        "part": 3,
        "title": "@dataclass and __post_init__",
        "slides": "44, 46",
        "idea": "`@dataclass` writes `__init__`, `__repr__` and `__eq__` for you from type-annotated fields. Use `field(default_factory=list)` for mutable defaults.\n\n`__post_init__` runs right after the generated `__init__`. Use it to validate and normalize, so impossible objects never exist.",
        "code": '''from dataclasses import dataclass, field

@dataclass
class Book:
    title: str
    pages: int
    isbn: str
    tags: list[str] = field(default_factory=list)
    available: bool = True

    def __post_init__(self):
        self.title = self.title.strip()
        self.isbn = self.isbn.replace("-", "")
        if self.pages < 0:
            raise ValueError(f"Invalid pages: {self.pages}")

b1 = Book("  Clean Code  ", 464, "978-0-13-235088-4")
b2 = Book("Clean Code", 464, "9780132350884")
print(b1)
print(b1 == b2)            # True, generated __eq__
try:
    Book("Oops", -1, "x")
except ValueError as e:
    print("Caught:", e)

# Computed field: not an __init__ argument, hidden from repr
@dataclass
class Ebook:
    title: str
    pages: int
    _reading_time: float = field(init=False, repr=False)

    def __post_init__(self):
        self._reading_time = self.pages / 50

    @property
    def reading_time_hours(self):
        return self._reading_time

e = Ebook("Clean Code", 464)
print(e, e.reading_time_hours)
''',
        "challenge": {
            "task": "Write a `Loan` dataclass: `item_id`, `member_id`, `borrowed_on: date`, `days: int = 14`. Add a `due_on` property, and reject `days <= 0` in `__post_init__`.",
            "starter": '''from dataclasses import dataclass
from datetime import date, timedelta

@dataclass
class Loan:
    ...  # your code here

loan = Loan("B001", "M01", date(2026, 1, 1))
print(loan, loan.due_on)
''',
            "solution": '''from dataclasses import dataclass
from datetime import date, timedelta

@dataclass
class Loan:
    item_id: str
    member_id: str
    borrowed_on: date
    days: int = 14

    def __post_init__(self):
        if self.days <= 0:
            raise ValueError("days must be positive")

    @property
    def due_on(self):
        return self.borrowed_on + timedelta(days=self.days)

loan = Loan("B001", "M01", date(2026, 1, 1))
print(loan, loan.due_on)
''',
            "tests": '''loan = Loan("B001", "M01", date(2026, 1, 1))
assert loan.due_on == date(2026, 1, 15), loan.due_on
assert Loan("B1", "M1", date(2026, 1, 1), days=7).due_on == date(2026, 1, 8)
assert loan == Loan("B001", "M01", date(2026, 1, 1)), "dataclass gives you __eq__"
try:
    Loan("B1", "M1", date(2026, 1, 1), days=0)
    raise AssertionError("days=0 should raise ValueError")
except ValueError:
    pass''',
        },
    },
    {
        "id": "frozen",
        "part": 3,
        "title": "Frozen value objects",
        "slides": "45",
        "idea": "`@dataclass(frozen=True)` blocks assignment after creation and makes instances hashable. Equality and hashing stay stable forever.\n\nRule of thumb: if changing it would make it a *different* thing (an ID, an ISBN, a coordinate), freeze it.",
        "code": '''from dataclasses import dataclass, FrozenInstanceError

@dataclass(frozen=True)
class ISBN:
    value: str
    region: str = "US"

isbn = ISBN("9780132350884")
print(isbn, hash(isbn) == hash(ISBN("9780132350884")))
print({ISBN("a"), ISBN("a"), ISBN("b")})      # dedups in a set

try:
    isbn.value = "x"
except FrozenInstanceError as e:
    print("Caught:", type(e).__name__, "-", e)
''',
        "challenge": {
            "task": "Write a frozen `MemberId` dataclass with `value: str`. In `__post_init__`, raise `ValueError` unless the value looks like `\"M\"` followed by digits (e.g. `\"M042\"`).",
            "starter": '''from dataclasses import dataclass, FrozenInstanceError

@dataclass(frozen=True)
class MemberId:
    ...  # your code here

print(MemberId("M042"))
''',
            "solution": '''from dataclasses import dataclass, FrozenInstanceError

@dataclass(frozen=True)
class MemberId:
    value: str

    def __post_init__(self):
        if not (self.value.startswith("M") and self.value[1:].isdigit()):
            raise ValueError(f"bad member id: {self.value!r}")

print(MemberId("M042"))
''',
            "tests": '''m = MemberId("M042")
assert m == MemberId("M042") and len({m, MemberId("M042")}) == 1
try:
    m.value = "M999"
    raise AssertionError("MemberId must be frozen")
except FrozenInstanceError:
    pass
for bad in ("042", "M", "Mx1"):
    try:
        MemberId(bad)
        raise AssertionError(f"{bad!r} should be rejected")
    except ValueError:
        pass''',
        },
    },
]


# ======================================================================
# Lessons added to cover the rest of the Day 1 deck. Each is inserted
# right after the lesson named in the first tuple item.
# ======================================================================

def _insert_after(after_id, lesson):
    idx = next(i for i, l in enumerate(LESSONS) if l["id"] == after_id)
    LESSONS.insert(idx + 1, lesson)


def _insert_before(before_id, lesson):
    idx = next(i for i, l in enumerate(LESSONS) if l["id"] == before_id)
    LESSONS.insert(idx, lesson)


_insert_before("dynamic-typing", {
    "id": "python-setup",
    "part": 0,
    "title": "Python, CPython and venvs",
    "slides": "3-5",
    "idea": "Python reads close to pseudocode, ships 200+ standard-library modules, and is the default language for GenAI tools (OpenAI, Anthropic, Hugging Face, LangChain).\n\n**CPython** is the standard interpreter: your code becomes bytecode, which runs as objects in memory. Python 3.11+ is the baseline for this training.\n\nA **virtual environment** (`.venv/`) gives each project its own interpreter and packages, like `node_modules/` for Python. Project A can pin `requests==2.28` while project B uses `2.31`. Every BookVault milestone lives in its own venv.\n\nThis page runs **Brython**, a Python interpreter written in JavaScript, so you can practise without installing anything. Run the code to see which implementation you are on.",
    "predict": {
        "q": "Which is the closest equivalent of a Python `.venv/` folder?",
        "options": ["A Git branch", "`node_modules/` in a JavaScript project", "A Docker image", "The system PATH"],
        "answer": 1,
        "why": "Both hold one project's own dependencies, isolated from every other project on the machine.",
    },
    "code": '''import sys

print(type(42))
print("Implementation:", sys.implementation.name)   # 'cpython' on your laptop
print("Version:", sys.version.split()[0])

# Python should read like the idea
catalog = ["Python Crash Course", "Clean Code", "Fluent Python"]
books = [b for b in catalog if "python" in b.lower()]
for book in books:
    print(book)
''',
    "local": [{
        "title": "Create a project venv with uv",
        "note": "Run these in a terminal inside your project folder. Use the Windows line or the macOS/Linux line to activate.",
        "code": '''uv venv                          # create .venv/
.venv\\Scripts\\activate           # Windows
source .venv/bin/activate        # macOS / Linux
uv pip install requests
python --version
python -c "import sys; print(sys.implementation.name, sys.prefix)"''',
        "output": '''Python 3.11.x
cpython C:\\path\\to\\bookvault\\.venv''',
    }],
})

_insert_after("dynamic-typing", {
    "id": "is-vs-eq",
    "part": 0,
    "title": "is vs ==",
    "slides": "8",
    "idea": "`==` asks *do these have equal values?* It calls `__eq__`. `is` asks *are these the very same object?* It compares identity, like `id(a) == id(b)`.\n\nUse `is` only for singletons: `x is None`, `x is True`, sentinels. Use `==` for everything else, including numbers and strings. Small ints and short strings may *happen* to be the same object, which is an implementation detail you must never rely on.",
    "predict": {
        "q": "`a = [1, 2]` and `b = [1, 2]`. What do `a == b` and `a is b` give?",
        "options": ["True, True", "True, False", "False, False", "False, True"],
        "answer": 1,
        "why": "The lists hold equal values, but they are two separate objects in memory.",
    },
    "code": '''a = [1, 2]
b = [1, 2]
c = a                      # another name for the same object

print(a == b, a is b)      # True False
print(a == c, a is c)      # True True
print(id(a) == id(c))

c.append(3)                # changing c changes a: same object
print(a)

isbn = None
if isbn is None:           # the right way to test for None
    print("no ISBN yet")
''',
    "challenge": {
        "task": "Write `count_missing(values)` that counts how many values are `None`. Values like `0`, `\"\"` and `[]` are *not* missing, so truthiness is the wrong test here.",
        "starter": '''def count_missing(values):
    ...  # your code here

print(count_missing([None, 0, "", None, [], "Clean Code"]))   # 2
''',
        "solution": '''def count_missing(values):
    return sum(1 for v in values if v is None)

print(count_missing([None, 0, "", None, [], "Clean Code"]))
''',
        "tests": '''assert count_missing([None, 0, "", None, [], "Clean Code"]) == 2, count_missing([None, 0, "", None, [], "Clean Code"])
assert count_missing([]) == 0
assert count_missing([0, False, ""]) == 0, "0, False and empty string are values, not missing"''',
    },
})

_insert_before("control-flow", {
    "id": "loops",
    "part": 0,
    "title": "Loops: for, while, break, continue",
    "slides": "14, 16",
    "idea": "Use `for` when you have an iterable, and `while` for open-ended conditions such as retries. `break` exits the loop early and `continue` skips to the next item.\n\n`enumerate()` gives you an index without a counter variable, and `zip()` walks two lists side by side.",
    "code": '''rows = [
    {"title": "Clean Code"},
    {"title": ""},                 # bad row
    {"title": "Refactoring"},
    {"title": "STOP"},             # end marker
    {"title": "Never reached"},
]

for i, row in enumerate(rows, start=1):
    if not row["title"]:
        print(f"row {i}: skipped (empty)")
        continue
    if row["title"] == "STOP":
        print(f"row {i}: stop marker")
        break
    print(f"row {i}: {row['title']}")

attempt = 0
while attempt < 3:                 # open-ended: retry until it works
    attempt += 1
    ok = attempt == 2
    print(f"attempt {attempt}: {'ok' if ok else 'failed'}")
    if ok:
        break

for title, year in zip(["Clean Code", "Refactoring"], [2008, 2018]):
    print(title, year)
''',
    "challenge": {
        "task": "Write `collect_titles(rows, limit)`: walk the rows, skip any row without a title (`continue`), and stop as soon as you have `limit` titles (`break`).",
        "starter": '''def collect_titles(rows, limit):
    ...  # your code here

rows = [{"title": "A"}, {}, {"title": ""}, {"title": "B"}, {"title": "C"}]
print(collect_titles(rows, 2))   # ['A', 'B']
''',
        "solution": '''def collect_titles(rows, limit):
    titles = []
    for row in rows:
        title = row.get("title")
        if not title:
            continue
        titles.append(title)
        if len(titles) == limit:
            break
    return titles

rows = [{"title": "A"}, {}, {"title": ""}, {"title": "B"}, {"title": "C"}]
print(collect_titles(rows, 2))
''',
        "tests": '''rows = [{"title": "A"}, {}, {"title": ""}, {"title": "B"}, {"title": "C"}]
assert collect_titles(rows, 2) == ["A", "B"], collect_titles(rows, 2)
assert collect_titles(rows, 10) == ["A", "B", "C"]
assert collect_titles([], 3) == []''',
    },
})

_insert_after("first-class", {
    "id": "map-filter-reduce",
    "part": 1,
    "title": "map, filter, reduce",
    "slides": "25-26",
    "idea": "`map(fn, items)` transforms every item and `filter(fn, items)` keeps the ones where `fn` is truthy. Both are lazy. In everyday code a comprehension usually reads better.\n\n`functools.reduce` folds a list into one value. It is rare: prefer `sum`, `max`, `any` and `all` when they fit, and keep `reduce` for folds with no built-in.",
    "code": '''from functools import reduce
from operator import mul

prices = [12.99, 24.50, 8.75, 99.00]

with_tax = list(map(lambda p: round(p * 1.18, 2), prices))
expensive = list(filter(lambda p: p > 20, prices))
print(with_tax)
print(expensive)

# The same with comprehensions (usually preferred)
print([round(p * 1.18, 2) for p in prices])
print([p for p in prices if p > 20])

total = reduce(lambda acc, p: acc + p, prices, 0)
print(round(total, 2), "== sum():", round(sum(prices), 2))
print("5! =", reduce(mul, range(1, 6)))      # no built-in for this fold
''',
    "challenge": {
        "task": "Write `compose(*funcs)` using `reduce`: it returns one function that applies `funcs` left to right. `compose(str.strip, str.lower)(\"  HI \")` gives `\"hi\"`.",
        "starter": '''from functools import reduce

def compose(*funcs):
    ...  # your code here

clean = compose(str.strip, str.lower, str.title)
print(clean("  the pragmatic PROGRAMMER "))
''',
        "solution": '''from functools import reduce

def compose(*funcs):
    return lambda value: reduce(lambda acc, f: f(acc), funcs, value)

clean = compose(str.strip, str.lower, str.title)
print(clean("  the pragmatic PROGRAMMER "))
''',
        "tests": '''assert compose(str.strip, str.lower)("  HI ") == "hi"
assert compose(str.strip, str.lower, str.title)("  the pragmatic PROGRAMMER ") == "The Pragmatic Programmer"
assert compose()("same") == "same", "no functions: return the value unchanged"
assert compose(lambda x: x + 1, lambda x: x * 10)(1) == 20, "apply left to right"''',
    },
})

# ---------------------------------------------------------------- PART 5
ASSIGNMENTS = [
    {
        "id": "a-temperature",
        "assignment": "Q1",
        "title": "Temperature converter",
        "idea": "Easy warm-up, 15–25 min.\n\nWrite `convert(value, from_unit, to_unit)` that converts between Celsius, Fahrenheit and Kelvin.\n- Units are `\"C\"`, `\"F\"` and `\"K\"`.\n- The same unit returns the value unchanged.\n- An unknown unit raises `ValueError`.",
        "challenge": {
            "task": "Make the three asserts from the assignment pass, plus the unit checks.",
            "starter": '''def convert(value: float, from_unit: str, to_unit: str) -> float:
    ...  # your code here

print(convert(0, "C", "F"))      # 32.0
print(convert(100, "C", "K"))    # 373.15
''',
            "solution": '''def convert(value: float, from_unit: str, to_unit: str) -> float:
    units = {"C", "F", "K"}
    if from_unit not in units or to_unit not in units:
        raise ValueError(f"unknown unit: {from_unit!r} or {to_unit!r}")
    if from_unit == to_unit:
        return value
    celsius = {"C": value, "F": (value - 32) * 5 / 9, "K": value - 273.15}[from_unit]
    return {"C": celsius, "F": celsius * 9 / 5 + 32, "K": celsius + 273.15}[to_unit]

print(convert(0, "C", "F"))
print(convert(100, "C", "K"))
''',
            "tests": '''assert convert(0, "C", "F") == 32.0
assert convert(100, "C", "K") == 373.15
assert round(convert(32, "F", "C"), 2) == 0.0
assert round(convert(373.15, "K", "F"), 2) == 212.0
assert convert(21.5, "C", "C") == 21.5, "same unit returns the value"
try:
    convert(10, "C", "X")
    raise AssertionError("unknown unit should raise ValueError")
except ValueError:
    pass''',
        },
    },
    {
        "id": "a-word-frequency",
        "assignment": "Q2",
        "title": "Word frequency",
        "idea": "Easy warm-up, 15–25 min.\n\nGiven a string, return a dict of word → count. Lowercase the words and strip punctuation with `str.translate` or `re`.\n\nBonus: `top_words(text, n)` returns the top N words using `collections.Counter`.",
        "challenge": {
            "task": "Implement `word_frequency(text)` and the bonus `top_words(text, n)`.",
            "starter": '''import string
from collections import Counter

def word_frequency(text):
    ...  # your code here

def top_words(text, n):
    ...  # bonus

text = "The fox. The quick fox. The fox jumps."
print(word_frequency(text))   # {'the': 3, 'fox': 3, 'quick': 1, 'jumps': 1}
print(top_words(text, 2))
''',
            "solution": '''import string
from collections import Counter

def word_frequency(text):
    cleaned = text.lower().translate(str.maketrans("", "", string.punctuation))
    counts = {}
    for word in cleaned.split():
        counts[word] = counts.get(word, 0) + 1
    return counts

def top_words(text, n):
    return Counter(word_frequency(text)).most_common(n)

text = "The fox. The quick fox. The fox jumps."
print(word_frequency(text))
print(top_words(text, 2))
''',
            "tests": '''text = "The fox. The quick fox. The fox jumps."
assert word_frequency(text) == {"the": 3, "fox": 3, "quick": 1, "jumps": 1}, word_frequency(text)
assert word_frequency("Hello, hello!") == {"hello": 2}
assert word_frequency("") == {}
assert top_words(text, 2) == [("the", 3), ("fox", 3)], top_words(text, 2)''',
        },
    },
    {
        "id": "a-isbn-cleaner",
        "assignment": "Q4",
        "title": "ISBN cleaner",
        "idea": "Easy warm-up, 15–25 min.\n\nWrite `clean_isbn(raw)` that:\n- strips spaces and hyphens,\n- returns the result if it is exactly 10 or 13 digits,\n- raises `ValueError` otherwise.",
        "challenge": {
            "task": "Make all the examples from the assignment behave correctly.",
            "starter": '''def clean_isbn(raw: str) -> str:
    ...  # your code here

print(clean_isbn("978-0-13-235088-4"))   # "9780132350884"
print(clean_isbn("  0132350882  "))      # "0132350882"
''',
            "solution": '''def clean_isbn(raw: str) -> str:
    cleaned = raw.replace("-", "").replace(" ", "")
    if cleaned.isdigit() and len(cleaned) in (10, 13):
        return cleaned
    raise ValueError(f"invalid ISBN: {raw!r}")

print(clean_isbn("978-0-13-235088-4"))
print(clean_isbn("  0132350882  "))
''',
            "tests": '''assert clean_isbn("978-0-13-235088-4") == "9780132350884"
assert clean_isbn("  0132350882  ") == "0132350882"
for bad in ("abc", "12345", "", "978-0-13-23508X-4", "97801323508841"):
    try:
        clean_isbn(bad)
        raise AssertionError(f"clean_isbn({bad!r}) should raise ValueError")
    except ValueError:
        pass''',
        },
    },
    {
        "id": "a-catalog-loader",
        "assignment": "Q6",
        "title": "Catalog loader",
        "idea": "Medium, 30–60 min.\n\nParse a CSV-like string into a list of dicts **without** the `csv` module. Use `str.split`, `str.strip` and slicing. Handle:\n- leading and trailing whitespace,\n- type conversion (`year` and `pages` → `int`),\n- an empty trailing line.\n\nBonus (not checked): support quoted fields that contain commas, like `\"Smith, John\"`.",
        "challenge": {
            "task": "Write `load_catalog(text)` that returns one dict per data row.",
            "starter": '''CSV = """
title,author,year,pages
Clean Code,Robert Martin,2008,464
  Refactoring , Martin Fowler ,2018,448
The Pragmatic Programmer,Dave Thomas,1999,320

"""

def load_catalog(text):
    ...  # your code here

for row in load_catalog(CSV):
    print(row)
''',
            "solution": '''CSV = """
title,author,year,pages
Clean Code,Robert Martin,2008,464
  Refactoring , Martin Fowler ,2018,448
The Pragmatic Programmer,Dave Thomas,1999,320

"""

def load_catalog(text):
    lines = [line.strip() for line in text.strip().split("\\n") if line.strip()]
    header = [h.strip() for h in lines[0].split(",")]
    rows = []
    for line in lines[1:]:
        values = [v.strip() for v in line.split(",")]
        row = dict(zip(header, values))
        for key in ("year", "pages"):
            row[key] = int(row[key])
        rows.append(row)
    return rows

for row in load_catalog(CSV):
    print(row)
''',
            "tests": '''rows = load_catalog(CSV)
assert len(rows) == 3, f"expected 3 rows, got {len(rows)}"
assert rows[0] == {"title": "Clean Code", "author": "Robert Martin", "year": 2008, "pages": 464}, rows[0]
assert rows[1]["title"] == "Refactoring" and rows[1]["author"] == "Martin Fowler", "strip whitespace around values"
assert isinstance(rows[2]["year"], int) and rows[2]["pages"] == 320''',
        },
    },
    {
        "id": "a-min-max",
        "assignment": "Q7",
        "title": "min/max without built-ins",
        "idea": "Medium, 30–60 min.\n\nWrite your own `my_min(items, key=None)` and `my_max(items, key=None)` that mimic the built-ins, including the `key` parameter. You may not use `min`, `max` or `sorted`. An empty input raises `ValueError`.",
        "challenge": {
            "task": "Implement `my_min` and `my_max`. Ties keep the first item, like the built-ins.",
            "starter": '''def my_min(items, key=None):
    ...  # your code here

def my_max(items, key=None):
    ...  # your code here

books = [{"title": "A", "year": 2020}, {"title": "B", "year": 2015}]
print(my_min(books, key=lambda b: b["year"]))   # {'title': 'B', 'year': 2015}
''',
            "solution": '''def _pick(items, key, better):
    key = key or (lambda x: x)
    it = iter(items)
    try:
        best = next(it)
    except StopIteration:
        raise ValueError("arg is an empty sequence")
    best_key = key(best)
    for item in it:
        k = key(item)
        if better(k, best_key):
            best, best_key = item, k
    return best

def my_min(items, key=None):
    return _pick(items, key, lambda a, b: a < b)

def my_max(items, key=None):
    return _pick(items, key, lambda a, b: a > b)

books = [{"title": "A", "year": 2020}, {"title": "B", "year": 2015}]
print(my_min(books, key=lambda b: b["year"]))
''',
            "tests": '''books = [{"title": "A", "year": 2020}, {"title": "B", "year": 2015}]
assert my_min(books, key=lambda b: b["year"]) == {"title": "B", "year": 2015}
assert my_max(books, key=lambda b: b["year"]) == {"title": "A", "year": 2020}
assert my_min([3, 1, 2]) == 1 and my_max([3, 1, 2]) == 3
assert my_max(["aa", "b", "cc"], key=len) == "aa", "ties keep the first item"
assert my_min(x for x in [5, 4]) == 4, "should work with any iterable"
for fn in (my_min, my_max):
    try:
        fn([])
        raise AssertionError(f"{fn.__name__}([]) should raise ValueError")
    except ValueError:
        pass''',
        },
    },
    {
        "id": "a-library-v0",
        "assignment": "Q9",
        "title": "The Library v0",
        "idea": "Medium, 30–60 min.\n\nBuild a simple `Library` class with no dunders yet:\n- `__init__(self, name)`\n- `add(self, book)` where `book` is a dict with `title`, `author`, `isbn`\n- `remove(self, isbn)`\n- `find(self, query)` returns the books whose title contains `query`, ignoring case\n- `count(self)` returns the number of books",
        "challenge": {
            "task": "Implement the class, then make the `main()` demo add 5 books, search twice, remove one and print stats.",
            "starter": '''class Library:
    ...  # your code here

def main():
    lib = Library("Central")
    for title, author, isbn in [
        ("Clean Code", "Martin", "111"), ("Clean Architecture", "Martin", "222"),
        ("Refactoring", "Fowler", "333"), ("Fluent Python", "Ramalho", "444"),
        ("The Pragmatic Programmer", "Thomas", "555"),
    ]:
        lib.add({"title": title, "author": author, "isbn": isbn})
    print([b["title"] for b in lib.find("clean")])
    print([b["title"] for b in lib.find("PYTHON")])
    lib.remove("333")
    print(lib.name, "has", lib.count(), "books")

main()
''',
            "solution": '''class Library:
    def __init__(self, name):
        self.name = name
        self.books = []

    def add(self, book):
        self.books.append(book)

    def remove(self, isbn):
        self.books = [b for b in self.books if b["isbn"] != isbn]

    def find(self, query):
        q = query.lower()
        return [b for b in self.books if q in b["title"].lower()]

    def count(self):
        return len(self.books)

def main():
    lib = Library("Central")
    for title, author, isbn in [
        ("Clean Code", "Martin", "111"), ("Clean Architecture", "Martin", "222"),
        ("Refactoring", "Fowler", "333"), ("Fluent Python", "Ramalho", "444"),
        ("The Pragmatic Programmer", "Thomas", "555"),
    ]:
        lib.add({"title": title, "author": author, "isbn": isbn})
    print([b["title"] for b in lib.find("clean")])
    print([b["title"] for b in lib.find("PYTHON")])
    lib.remove("333")
    print(lib.name, "has", lib.count(), "books")

main()
''',
            "tests": '''lib = Library("Test")
assert lib.name == "Test" and lib.count() == 0
lib.add({"title": "Clean Code", "author": "Martin", "isbn": "111"})
lib.add({"title": "Refactoring", "author": "Fowler", "isbn": "333"})
assert lib.count() == 2
assert [b["isbn"] for b in lib.find("CLEAN")] == ["111"], "find ignores case"
assert lib.find("nothing") == []
lib.remove("111")
assert lib.count() == 1 and lib.find("clean") == []''',
        },
    },
    {
        "id": "a-reading-time",
        "assignment": "Q11",
        "title": "Reading time calculator",
        "idea": "Medium, 30–60 min. Extends the `Book` from Q10.\n- Add a computed property `reading_time_hours`: 50 pages/hour for books under 300 pages, 40 pages/hour otherwise.\n- Add a class method `from_dict(cls, data)` that builds a `Book` from a dict.\n- Add a static method `is_valid_rating(rating)` that returns `True`/`False` and never raises.",
        "challenge": {
            "task": "Add the property, the class method and the static method.",
            "starter": '''class Book:
    def __init__(self, title, pages, rating):
        self.title = title
        self.pages = pages
        self.rating = rating

    # reading_time_hours, from_dict, is_valid_rating

b = Book.from_dict({"title": "Clean Code", "pages": 464, "rating": 4.5})
print(b.reading_time_hours)              # 11.6
print(Book.is_valid_rating(7))           # False
''',
            "solution": '''class Book:
    def __init__(self, title, pages, rating):
        self.title = title
        self.pages = pages
        self.rating = rating

    @property
    def reading_time_hours(self):
        pages_per_hour = 50 if self.pages < 300 else 40
        return self.pages / pages_per_hour

    @classmethod
    def from_dict(cls, data):
        return cls(data["title"], data["pages"], data["rating"])

    @staticmethod
    def is_valid_rating(rating):
        try:
            return 0.0 <= float(rating) <= 5.0
        except (TypeError, ValueError):
            return False

b = Book.from_dict({"title": "Clean Code", "pages": 464, "rating": 4.5})
print(b.reading_time_hours)
print(Book.is_valid_rating(7))
''',
            "tests": '''assert Book("Short", 200, 4).reading_time_hours == 4.0, "under 300 pages: 50 pages/hour"
assert Book("Long", 400, 4).reading_time_hours == 10.0, "300+ pages: 40 pages/hour"
assert Book("Edge", 300, 4).reading_time_hours == 7.5
b = Book.from_dict({"title": "Clean Code", "pages": 464, "rating": 4.5})
assert isinstance(b, Book) and b.title == "Clean Code" and b.pages == 464
assert Book.is_valid_rating(4.5) and Book.is_valid_rating(0)
assert not Book.is_valid_rating(7) and not Book.is_valid_rating(-1)
assert Book.is_valid_rating("abc") is False and Book.is_valid_rating(None) is False, "must not raise"''',
        },
    },
    {
        "id": "a-hierarchy",
        "assignment": "Q12",
        "title": "The LibraryItem hierarchy",
        "idea": "Medium, 30–60 min.\n- `LibraryItem` (abstract via `ABC`) has `title`, `item_id` and `available` (starts `True`), plus abstract `category() -> str` and `describe() -> str`.\n- `Book` adds `author` and `pages`.\n- `AudioBook` adds `narrator` and `duration_min`.\n- `Magazine` adds `issue` (int).\n\nEach `category()` returns the class name. `print_all(items)` prints each `.describe()`: one function, three behaviours.",
        "challenge": {
            "task": "Build the hierarchy and `print_all`. `print_all` should also return the list of lines it printed.",
            "starter": '''from abc import ABC, abstractmethod

class LibraryItem(ABC):
    ...  # your code here

def print_all(items):
    ...

items = [
    Book("Clean Code", "B001", "Robert Martin", 464),
    AudioBook("Atomic Habits", "A001", "James Clear", 320),
    Magazine("National Geographic", "M001", 247),
]
print_all(items)
''',
            "solution": '''from abc import ABC, abstractmethod

class LibraryItem(ABC):
    def __init__(self, title, item_id):
        self.title = title
        self.item_id = item_id
        self.available = True

    def category(self) -> str:
        return type(self).__name__

    @abstractmethod
    def describe(self) -> str: ...

class Book(LibraryItem):
    def __init__(self, title, item_id, author, pages):
        super().__init__(title, item_id)
        self.author, self.pages = author, pages
    def describe(self):
        return f"[{self.category()}] {self.title} by {self.author}, {self.pages} pages"

class AudioBook(LibraryItem):
    def __init__(self, title, item_id, narrator, duration_min):
        super().__init__(title, item_id)
        self.narrator, self.duration_min = narrator, duration_min
    def describe(self):
        return f"[{self.category()}] {self.title}, narrated by {self.narrator}, {self.duration_min} min"

class Magazine(LibraryItem):
    def __init__(self, title, item_id, issue):
        super().__init__(title, item_id)
        self.issue = int(issue)
    def describe(self):
        return f"[{self.category()}] {self.title}, issue #{self.issue}"

def print_all(items):
    lines = [item.describe() for item in items]
    for line in lines:
        print(line)
    return lines

items = [
    Book("Clean Code", "B001", "Robert Martin", 464),
    AudioBook("Atomic Habits", "A001", "James Clear", 320),
    Magazine("National Geographic", "M001", 247),
]
print_all(items)
''',
            "tests": '''try:
    LibraryItem("X", "X1")
    raise AssertionError("LibraryItem must be abstract (inherit from ABC)")
except TypeError:
    pass
b = Book("Clean Code", "B001", "Robert Martin", 464)
a = AudioBook("Atomic Habits", "A001", "James Clear", 320)
m = Magazine("National Geographic", "M001", 247)
assert [x.category() for x in (b, a, m)] == ["Book", "AudioBook", "Magazine"]
assert all(x.available is True for x in (b, a, m)), "available starts True"
assert "Robert Martin" in b.describe() and "James Clear" in a.describe() and "247" in m.describe()
lines = print_all([b, a, m])
assert lines == [b.describe(), a.describe(), m.describe()], "print_all returns the lines it printed"''',
        },
    },
    {
        "id": "a-native-library",
        "assignment": "Q14",
        "title": "Make Library \"native\"",
        "idea": "Medium, 30–60 min. Take the `Library` from Q9 and add dunders:\n- `__len__` → number of books, `__bool__` → non-empty\n- `__contains__` → accepts a book dict **or** an ISBN string\n- `__iter__` → iterate over books\n- `__getitem__` → by index, slice **or** ISBN string\n- `__repr__` for developers, `__str__` for users\n- `__call__(query)` → shortcut for `find(query)`",
        "challenge": {
            "task": "Add every dunder. The Q9 methods are already written for you.",
            "starter": '''class Library:
    def __init__(self, name):
        self.name = name
        self.books = []

    def add(self, book):
        self.books.append(book)

    def remove(self, isbn):
        self.books = [b for b in self.books if b["isbn"] != isbn]

    def find(self, query):
        q = query.lower()
        return [b for b in self.books if q in b["title"].lower()]

    # add the dunders here

lib = Library("Central")
lib.add({"title": "Clean Code", "author": "Martin", "isbn": "111"})
lib.add({"title": "Refactoring", "author": "Fowler", "isbn": "333"})
print(len(lib), "111" in lib, lib["333"]["title"], lib("clean"))
''',
            "solution": '''class Library:
    def __init__(self, name):
        self.name = name
        self.books = []

    def add(self, book):
        self.books.append(book)

    def remove(self, isbn):
        self.books = [b for b in self.books if b["isbn"] != isbn]

    def find(self, query):
        q = query.lower()
        return [b for b in self.books if q in b["title"].lower()]

    def __len__(self):
        return len(self.books)

    def __bool__(self):
        return bool(self.books)

    def __contains__(self, item):
        if isinstance(item, str):
            return any(b["isbn"] == item for b in self.books)
        return item in self.books

    def __iter__(self):
        return iter(self.books)

    def __getitem__(self, key):
        if isinstance(key, (int, slice)):
            return self.books[key]
        for b in self.books:
            if b["isbn"] == key:
                return b
        raise KeyError(key)

    def __repr__(self):
        return f"Library(name={self.name!r}, books={len(self)})"

    def __str__(self):
        return f"{self.name}: {len(self)} books"

    def __call__(self, query):
        return self.find(query)

lib = Library("Central")
lib.add({"title": "Clean Code", "author": "Martin", "isbn": "111"})
lib.add({"title": "Refactoring", "author": "Fowler", "isbn": "333"})
print(len(lib), "111" in lib, lib["333"]["title"], lib("clean"))
''',
            "tests": '''lib = Library("Central")
assert len(lib) == 0 and not lib, "empty library is falsy"
cc = {"title": "Clean Code", "author": "Martin", "isbn": "111"}
lib.add(cc)
lib.add({"title": "Refactoring", "author": "Fowler", "isbn": "333"})
assert len(lib) == 2 and bool(lib)
assert "111" in lib and cc in lib and "999" not in lib, "__contains__ takes an ISBN or a book dict"
assert [b["isbn"] for b in lib] == ["111", "333"], "__iter__"
assert lib[0] is cc and lib[-1]["isbn"] == "333" and [b["isbn"] for b in lib[:1]] == ["111"], "index and slice"
assert lib["333"]["title"] == "Refactoring", "lookup by ISBN"
try:
    lib["999"]
    raise AssertionError("unknown ISBN should raise KeyError")
except KeyError:
    pass
assert "Library" in repr(lib) and "Central" in str(lib)
assert lib("clean") == [cc], "__call__ is find()"''',
        },
    },
    {
        "id": "a-reservations",
        "assignment": "Q15",
        "title": "The reservation system",
        "idea": "Hard, 1–2 hrs. Extend BookVault with loans:\n- `Member` dataclass: `member_id`, `name`, `email`, `joined_on: date`.\n- `Loan` dataclass: `item_id`, `member_id`, `borrowed_on`, `due_on`, `returned_on: date | None`.\n- `borrow(item_id, member_id, on, days=14)` creates a `Loan` and marks the item unavailable.\n- `return_item(item_id, on)` closes the loan and frees the item.\n- `overdue_loans(today)` returns open loans past `due_on`.\n- `member_history(member_id)` returns all of a member's loans, oldest first.\n\nRaise meaningful errors. The `on` date parameter replaces `date.today()` so the tests are deterministic.",
        "challenge": {
            "task": "Implement the four `Library` methods. The dataclasses and exceptions are set up for you.",
            "starter": '''from dataclasses import dataclass, field
from datetime import date, timedelta

class BookVaultError(Exception): ...
class ItemNotFoundError(BookVaultError): ...
class ItemUnavailableError(BookVaultError): ...
class UnknownMemberError(BookVaultError): ...

@dataclass(frozen=True)
class Member:
    member_id: str
    name: str
    email: str
    joined_on: date

@dataclass
class Loan:
    item_id: str
    member_id: str
    borrowed_on: date
    due_on: date
    returned_on: date | None = None

class Library:
    def __init__(self):
        self.available = {}      # item_id -> bool
        self.members = {}        # member_id -> Member
        self.loans = []

    def add_item(self, item_id):
        self.available[item_id] = True

    def add_member(self, member):
        self.members[member.member_id] = member

    def borrow(self, item_id, member_id, on, days=14):
        ...

    def return_item(self, item_id, on):
        ...

    def overdue_loans(self, today):
        ...

    def member_history(self, member_id):
        ...

lib = Library()
lib.add_item("B001")
lib.add_member(Member("M1", "Asha", "asha@example.com", date(2026, 1, 1)))
print(lib.borrow("B001", "M1", on=date(2026, 3, 1)))
''',
            "solution": '''from dataclasses import dataclass, field
from datetime import date, timedelta

class BookVaultError(Exception): ...
class ItemNotFoundError(BookVaultError): ...
class ItemUnavailableError(BookVaultError): ...
class UnknownMemberError(BookVaultError): ...

@dataclass(frozen=True)
class Member:
    member_id: str
    name: str
    email: str
    joined_on: date

@dataclass
class Loan:
    item_id: str
    member_id: str
    borrowed_on: date
    due_on: date
    returned_on: date | None = None

class Library:
    def __init__(self):
        self.available = {}
        self.members = {}
        self.loans = []

    def add_item(self, item_id):
        self.available[item_id] = True

    def add_member(self, member):
        self.members[member.member_id] = member

    def borrow(self, item_id, member_id, on, days=14):
        if item_id not in self.available:
            raise ItemNotFoundError(item_id)
        if member_id not in self.members:
            raise UnknownMemberError(member_id)
        if not self.available[item_id]:
            raise ItemUnavailableError(f"{item_id} is already on loan")
        loan = Loan(item_id, member_id, on, on + timedelta(days=days))
        self.loans.append(loan)
        self.available[item_id] = False
        return loan

    def return_item(self, item_id, on):
        for loan in self.loans:
            if loan.item_id == item_id and loan.returned_on is None:
                loan.returned_on = on
                self.available[item_id] = True
                return loan
        raise ItemNotFoundError(f"no open loan for {item_id}")

    def overdue_loans(self, today):
        return [l for l in self.loans if l.returned_on is None and l.due_on < today]

    def member_history(self, member_id):
        if member_id not in self.members:
            raise UnknownMemberError(member_id)
        return sorted((l for l in self.loans if l.member_id == member_id), key=lambda l: l.borrowed_on)

lib = Library()
lib.add_item("B001")
lib.add_member(Member("M1", "Asha", "asha@example.com", date(2026, 1, 1)))
print(lib.borrow("B001", "M1", on=date(2026, 3, 1)))
''',
            "tests": '''lib = Library()
for item in ("B1", "B2", "B3"):
    lib.add_item(item)
lib.add_member(Member("M1", "Asha", "asha@example.com", date(2026, 1, 1)))
lib.add_member(Member("M2", "Ravi", "ravi@example.com", date(2026, 1, 2)))
loan = lib.borrow("B1", "M1", on=date(2026, 3, 1))
assert isinstance(loan, Loan) and loan.due_on == date(2026, 3, 15), "default loan is 14 days"
assert lib.available["B1"] is False, "borrowing marks the item unavailable"
for args, err in ((("B1", "M2"), ItemUnavailableError), (("B9", "M1"), ItemNotFoundError), (("B2", "M9"), UnknownMemberError)):
    try:
        lib.borrow(*args, on=date(2026, 3, 2))
        raise AssertionError(f"borrow{args} should raise {err.__name__}")
    except err:
        pass
lib.borrow("B2", "M1", on=date(2026, 2, 1), days=7)
lib.borrow("B3", "M2", on=date(2026, 3, 10))
lib.return_item("B1", on=date(2026, 3, 20))
assert lib.available["B1"] is True, "returning frees the item"
overdue = lib.overdue_loans(date(2026, 4, 1))
assert sorted(l.item_id for l in overdue) == ["B2", "B3"], f"returned loans are never overdue: {overdue}"
assert [l.item_id for l in lib.member_history("M1")] == ["B2", "B1"], "history is oldest first"
try:
    Member("M3", "X", "x@example.com", date(2026, 1, 1)).member_id = "M4"
    raise AssertionError("Member should be frozen")
except Exception as e:
    assert type(e).__name__ == "FrozenInstanceError", e''',
        },
    },
    {
        "id": "a-pipeline",
        "assignment": "Q18",
        "title": "Functional pipeline",
        "idea": "Hard, 1–2 hrs.\n- `pipeline(funcs)` returns a function that applies `funcs` left to right.\n- `pipeline_filter(funcs, predicate)` returns a function that takes a list and runs each element through the stages, **skipping** an element as soon as `predicate(intermediate_result)` is false.\n- `pipeline_with_logging(funcs, log_fn)` calls `log_fn(stage_name, before, after)` after each step.\n\nThen use the logging version to debug a chain that processes book titles.",
        "challenge": {
            "task": "Implement the three builders.",
            "starter": '''def pipeline(funcs):
    ...

def pipeline_filter(funcs, predicate):
    ...

def pipeline_with_logging(funcs, log_fn):
    ...

pipe = pipeline([str.strip, str.lower, lambda s: s.replace(" ", "_")])
print(pipe("  Hello World  "))   # 'hello_world'
''',
            "solution": '''def pipeline(funcs):
    def run(value):
        for f in funcs:
            value = f(value)
        return value
    return run

def pipeline_filter(funcs, predicate):
    def run(items):
        results = []
        for value in items:
            for f in funcs:
                value = f(value)
                if not predicate(value):
                    break
            else:
                results.append(value)
        return results
    return run

def pipeline_with_logging(funcs, log_fn):
    def run(value):
        for f in funcs:
            before = value
            value = f(value)
            log_fn(getattr(f, "__name__", repr(f)), before, value)
        return value
    return run

pipe = pipeline([str.strip, str.lower, lambda s: s.replace(" ", "_")])
print(pipe("  Hello World  "))

slugify = pipeline_with_logging(
    [str.strip, str.lower, lambda s: s.replace(" ", "-")],
    lambda stage, before, after: print(f"{stage:>10}: {before!r} -> {after!r}"),
)
slugify("  The Pragmatic Programmer ")
''',
            "tests": '''pipe = pipeline([str.strip, str.lower, lambda s: s.replace(" ", "_")])
assert pipe("  Hello World  ") == "hello_world"
assert pipeline([])("same") == "same"
keep_short = pipeline_filter([str.strip, str.upper], lambda s: len(s) <= 5)
assert keep_short(["  abc ", " toolong ", "hi"]) == ["ABC", "HI"], keep_short(["  abc ", " toolong ", "hi"])
log = []
run = pipeline_with_logging([str.strip, str.lower], lambda *entry: log.append(entry))
assert run("  HI ") == "hi"
assert log == [("strip", "  HI ", "HI"), ("lower", "HI", "hi")], log''',
        },
    },
    {
        "id": "a-mini-orm",
        "assignment": "Q19",
        "title": "Mini ORM (no database)",
        "idea": "Hard, 1–2 hrs. Build a base class `Record` so subclasses declare `fields` and get:\n- keyword construction validated against `fields` (unknown or missing → `TypeError`),\n- `to_dict()` and `from_dict()`,\n- a class-level registry: `all()` returns every instance created, and `filter(**kw)` returns matches.\n\nUse class attributes, `__init_subclass__` (to give **each** subclass its own registry) and class methods.",
        "challenge": {
            "task": "Implement `Record`. Each subclass must keep its own registry.",
            "starter": '''class Record:
    fields = ()
    ...  # your code here

class Book(Record):
    fields = ("title", "author", "isbn", "pages")

b = Book(title="Clean Code", author="Martin", isbn="978-0132350884", pages=464)
print(b.title, b.to_dict())
print(len(Book.all()))
''',
            "solution": '''class Record:
    fields = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        cls._registry = []

    def __init__(self, **kwargs):
        unknown = set(kwargs) - set(self.fields)
        missing = set(self.fields) - set(kwargs)
        if unknown or missing:
            raise TypeError(f"unknown fields {sorted(unknown)}, missing fields {sorted(missing)}")
        for name in self.fields:
            setattr(self, name, kwargs[name])
        type(self)._registry.append(self)

    def to_dict(self):
        return {name: getattr(self, name) for name in self.fields}

    @classmethod
    def from_dict(cls, data):
        return cls(**data)

    @classmethod
    def all(cls):
        return list(cls._registry)

    @classmethod
    def filter(cls, **criteria):
        return [r for r in cls._registry if all(getattr(r, k) == v for k, v in criteria.items())]

    def __repr__(self):
        args = ", ".join(f"{k}={v!r}" for k, v in self.to_dict().items())
        return f"{type(self).__name__}({args})"

class Book(Record):
    fields = ("title", "author", "isbn", "pages")

b = Book(title="Clean Code", author="Martin", isbn="978-0132350884", pages=464)
print(b.title, b.to_dict())
print(len(Book.all()))
''',
            "tests": '''class Novel(Record):
    fields = ("title", "author")

class Member(Record):
    fields = ("name",)

n1 = Novel(title="Dune", author="Herbert")
n2 = Novel.from_dict({"title": "Emma", "author": "Austen"})
Member(name="Asha")
assert n1.title == "Dune" and n2.to_dict() == {"title": "Emma", "author": "Austen"}
assert Novel.all() == [n1, n2], "from_dict instances are registered too"
assert len(Member.all()) == 1, "each subclass needs its own registry (__init_subclass__)"
assert Novel.filter(author="Austen") == [n2] and Novel.filter(author="Nobody") == []
for bad in ({"title": "X"}, {"title": "X", "author": "Y", "year": 1}):
    try:
        Novel(**bad)
        raise AssertionError(f"Novel(**{bad}) should raise TypeError")
    except TypeError:
        pass''',
        },
    },
    {
        "id": "a-catalog-search",
        "assignment": "Q20",
        "title": "Catalog search engine",
        "idea": "Hard, 1–2 hrs. Design a `Catalog`:\n- `add(item)`\n- `search(query=None, *, author=None, min_year=None, max_year=None, category=None)`: any combination of filters, written with comprehensions (no `for` loop in the search body)\n- `top_rated(n=10)`\n- `group_by(attr)` → `dict[value, list[item]]`\n- `__iter__`, and `__getitem__` by `item_id`\n\nThe assignment asks for 20 items; 8 are provided here to keep the page short.",
        "challenge": {
            "task": "Implement `Catalog`. Query matching on the title ignores case.",
            "starter": '''from dataclasses import dataclass

@dataclass
class Item:
    item_id: str
    title: str
    author: str
    year: int
    rating: float
    category: str

ITEMS = [
    Item("B1", "Clean Code", "Robert Martin", 2008, 4.4, "book"),
    Item("B2", "Clean Architecture", "Robert Martin", 2017, 4.2, "book"),
    Item("B3", "Refactoring", "Martin Fowler", 2018, 4.5, "book"),
    Item("B4", "Fluent Python", "Luciano Ramalho", 2022, 4.8, "book"),
    Item("A1", "Atomic Habits", "James Clear", 2018, 4.7, "audiobook"),
    Item("A2", "Deep Work", "Cal Newport", 2016, 4.3, "audiobook"),
    Item("M1", "National Geographic", "Various", 2024, 4.0, "magazine"),
    Item("M2", "Python Weekly", "Various", 2025, 3.9, "magazine"),
]

class Catalog:
    ...  # your code here

cat = Catalog()
for item in ITEMS:
    cat.add(item)
print([i.title for i in cat.search("clean", author="Robert Martin")])
''',
            "solution": '''from dataclasses import dataclass

@dataclass
class Item:
    item_id: str
    title: str
    author: str
    year: int
    rating: float
    category: str

ITEMS = [
    Item("B1", "Clean Code", "Robert Martin", 2008, 4.4, "book"),
    Item("B2", "Clean Architecture", "Robert Martin", 2017, 4.2, "book"),
    Item("B3", "Refactoring", "Martin Fowler", 2018, 4.5, "book"),
    Item("B4", "Fluent Python", "Luciano Ramalho", 2022, 4.8, "book"),
    Item("A1", "Atomic Habits", "James Clear", 2018, 4.7, "audiobook"),
    Item("A2", "Deep Work", "Cal Newport", 2016, 4.3, "audiobook"),
    Item("M1", "National Geographic", "Various", 2024, 4.0, "magazine"),
    Item("M2", "Python Weekly", "Various", 2025, 3.9, "magazine"),
]

class Catalog:
    def __init__(self):
        self._items = {}

    def add(self, item):
        self._items[item.item_id] = item

    def search(self, query=None, *, author=None, min_year=None, max_year=None, category=None):
        q = query.lower() if query else None
        return [
            i for i in self._items.values()
            if (q is None or q in i.title.lower())
            and (author is None or i.author == author)
            and (min_year is None or i.year >= min_year)
            and (max_year is None or i.year <= max_year)
            and (category is None or i.category == category)
        ]

    def top_rated(self, n=10):
        return sorted(self._items.values(), key=lambda i: i.rating, reverse=True)[:n]

    def group_by(self, attr):
        groups = {}
        for i in self._items.values():
            groups.setdefault(getattr(i, attr), []).append(i)
        return groups

    def __iter__(self):
        return iter(self._items.values())

    def __getitem__(self, item_id):
        return self._items[item_id]

cat = Catalog()
for item in ITEMS:
    cat.add(item)
print([i.title for i in cat.search("clean", author="Robert Martin")])
''',
            "tests": '''cat = Catalog()
for item in ITEMS:
    cat.add(item)
ids = lambda items: [i.item_id for i in items]
assert ids(cat.search("CLEAN")) == ["B1", "B2"], ids(cat.search("CLEAN"))
assert ids(cat.search(author="Robert Martin", min_year=2010)) == ["B2"]
assert ids(cat.search(min_year=2018, max_year=2018)) == ["B3", "A1"]
assert ids(cat.search(category="magazine")) == ["M1", "M2"]
assert ids(cat.search("python", category="book")) == ["B4"]
assert len(cat.search()) == 8, "no filters returns everything"
assert ids(cat.top_rated(3)) == ["B4", "A1", "B3"]
groups = cat.group_by("category")
assert sorted(groups) == ["audiobook", "book", "magazine"] and ids(groups["audiobook"]) == ["A1", "A2"]
assert len(list(cat)) == 8 and cat["B3"].title == "Refactoring"''',
        },
    },
]

for _a in ASSIGNMENTS:
    _a["part"] = 4
    LESSONS.append(_a)

# ---------------------------------------------------------------- PART 6
LESSONS.append({
    "id": "deliverable",
    "part": 5,
    "assignment": "Q21",
    "title": "BookVault Day 1 deliverable",
    "slides": "50",
    "idea": "Stretch, 2–3 hrs. This is your Day 1 capstone, and Day 2 builds on it, so keep it clean.\n- `items.py`: `LibraryItem` ABC + `Book`, `AudioBook`, `Magazine`, using dataclasses where they fit.\n- `members.py`: `Member` (frozen dataclass) and `Loan`.\n- `library.py`: `Library` with `__len__`, `__iter__`, `__contains__`, `__getitem__`, `__repr__`, `__str__`, `__call__`.\n- `exceptions.py`: `BookVaultError` + `ItemNotFoundError`, `ItemUnavailableError`, `UnknownMemberError` (at least 4 types).\n- `cli.py`: loads `books.json` and supports list, search, borrow, return, overdue via `argparse` or `match/case`.\n\nNo pytest yet: use plain asserts and `main()` demos. Formal tests start on Day 2. The lessons on this page cover every building block; this one runs on your own machine.",
    "local": [
        {
            "title": "Project layout",
            "note": "Create this structure, then install the package in editable mode inside your venv with `uv pip install -e .`.",
            "code": '''bookvault/
├── pyproject.toml
├── src/bookvault/
│   ├── __init__.py
│   ├── items.py
│   ├── members.py
│   ├── library.py
│   ├── exceptions.py
│   └── cli.py
└── data/books.json''',
        },
        {
            "title": "data/books.json",
            "code": '''[
  {"type": "book", "title": "Clean Code", "item_id": "B001",
   "author": "Robert Martin", "pages": 464},
  {"type": "audiobook", "title": "Atomic Habits", "item_id": "A001",
   "narrator": "James Clear", "duration_min": 320},
  {"type": "magazine", "title": "National Geographic", "item_id": "M001",
   "issue": 247}
]''',
        },
        {
            "title": "CLI dispatch with match/case",
            "note": "A starting point for `cli.py`. Fill in each branch with calls to your `Library`.",
            "code": '''import sys

def main(argv=None):
    args = (argv if argv is not None else sys.argv[1:])
    match args:
        case ["list"]:
            ...
        case ["search", query]:
            ...
        case ["borrow", *item_ids] if item_ids:
            ...
        case ["return", item_id]:
            ...
        case ["overdue"]:
            ...
        case _:
            print("usage: list | search <q> | borrow <ids...> | return <id> | overdue")
            return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())''',
        },
        {
            "title": "Must run",
            "note": "Your exact wording can differ. What matters is that each command works and errors are clear.",
            "code": '''python -m bookvault.cli list
python -m bookvault.cli search "clean"
python -m bookvault.cli borrow B001 M001''',
            "output": '''B001  Book       Clean Code — by Robert Martin
A001  AudioBook  Atomic Habits — narrated by James Clear
M001  Magazine   National Geographic — issue #247

Found 1: Clean Code — by Robert Martin

Borrowed B001, due 2026-06-08
Borrowed M001, due 2026-06-08''',
        },
    ],
})

LESSONS.append({
    "id": "recap",
    "part": 5,
    "title": "Recap and the bridge to GenAI",
    "slides": "47-49",
    "idea": "**What you can now do**\n- Choose the right data structure: list, tuple, dict, set, generator.\n- Write idiomatic Python: truthiness, slicing, f-strings, comprehensions.\n- Build class hierarchies with ABCs: polymorphism instead of `if/elif` type checks.\n- Use decorators and generators: wrap behaviour, stream data lazily.\n- Make objects feel native with dunders, and cut boilerplate with dataclasses.\n\n**What breaks tomorrow (Day 2)**\n- Library class → debug it without `print()`.\n- Validation rules → protect them with pytest.\n- Dataclasses + dunders → refactor safely with coverage.\n- Generator pipeline → load big catalogs without RAM spikes.\n- BookVault catalog → fetch covers concurrently.\n\n**Everything today → GenAI**\n- Dataclasses → structured tool inputs, config objects, document chunks.\n- Generators → streaming documents, batch ingestion, lazy token processing.\n- Decorators → retries, tracing, caching, auth and telemetry around model calls.\n- ABCs → provider interfaces: `OpenAIProvider`, `LocalLLMProvider`, `EmbeddingProvider`.\n- Dunders → clean objects in logs, tests, collections and pipelines.\n- Composition → agents built from model + tools + memory + retriever.\n\n**Self-assessment: can you say yes to all of these?**\n- I can explain why `is` is not `==`, and when to use each.\n- I can predict the output of a comprehension without running it.\n- I know why `def f(x, items=[])` is a bug.\n- I can implement `__eq__` and `__hash__` correctly together.\n- I can choose between inheritance and composition for a new feature.\n- I can explain when `dataclass(frozen=True)` is preferable.\n- My Library class passes `print`, `len`, `for`, `in` and `[]` tests.\n- My BookVault deliverable has zero `# TODO` comments left.",
})

LESSONS.append({
    "id": "knowledge-check",
    "part": 5,
    "title": "Knowledge check",
    "slides": "52-53",
    "idea": "The nine questions from the end of the deck, as multiple choice. Answer all of them to see your score.",
    "quiz": [
        {
            "q": "When would you prefer an Abstract Base Class over simple duck typing in BookVault?",
            "options": [
                "Never; duck typing is always better in Python",
                "When several item types must all provide the same methods and you want a missing one to fail at creation time",
                "Only when the class has no attributes",
                "When you need the class to be faster",
            ],
            "answer": 1,
            "why": "An ABC is an enforced contract: a subclass that forgets `describe()` cannot be instantiated, so the bug shows up immediately instead of deep inside a loop.",
        },
        {
            "q": "How do dunders like `__len__` and `__getitem__` improve a custom object?",
            "options": [
                "They make the object run faster",
                "They let built-in syntax like `len(lib)` and `lib[\"B001\"]` work on it, so it feels native",
                "They hide the object's attributes",
                "They are required for every class",
            ],
            "answer": 1,
            "why": "Python syntax calls dunders: `len(x)` calls `x.__len__()`. Implementing them lets your object fit the language.",
        },
        {
            "q": "When does a generator give a big advantage over a list?",
            "options": [
                "When you need random access by index",
                "When you must loop over the data many times",
                "When processing huge or streaming data one item at a time, so memory stays flat",
                "When the data has fewer than 10 items",
            ],
            "answer": 2,
            "why": "Generators produce values lazily, one at a time. Big files, paginated APIs and log streams never need to fit in RAM.",
        },
        {
            "q": "What is the main benefit of `@dataclass` for value objects?",
            "options": [
                "It writes `__init__`, `__repr__` and `__eq__` for you from the type-annotated fields",
                "It validates types at runtime automatically",
                "It makes attributes private",
                "It stores objects in a database",
            ],
            "answer": 0,
            "why": "Dataclasses remove boilerplate. They do **not** check types: use `__post_init__` (or Pydantic later) for validation.",
        },
        {
            "q": "Why is composition often preferred over deep inheritance?",
            "options": [
                "Inheritance doesn't work with ABCs",
                "Composed parts can be swapped independently, for example a fake logger in tests",
                "Composition uses less memory",
                "Python only allows one level of inheritance",
            ],
            "answer": 1,
            "why": "A `Library` that receives a logger and a cache can have either replaced without rewriting it. That is dependency injection.",
        },
        {
            "q": "How do decorators help keep core library logic single-responsibility?",
            "options": [
                "They make functions run in parallel",
                "They move cross-cutting concerns such as timing, logging and retries out of the business logic",
                "They replace classes",
                "They check types automatically",
            ],
            "answer": 1,
            "why": "`search_books` stays about searching. `@timed` or `@retry` add their own concern around it.",
        },
        {
            "q": "Which method is intended for end users?",
            "options": ["`__repr__`", "`__str__`", "`__format__`", "`__init__`"],
            "answer": 1,
            "why": "`__str__` is for users (`print`). `__repr__` is for developers (debuggers, logs, containers). Always write `__repr__`.",
        },
        {
            "q": "How does `@property` enable safer attribute access without breaking callers?",
            "options": [
                "It makes the attribute read-only forever",
                "Callers still write `book.pages`, but a setter can now validate every assignment",
                "It renames the attribute",
                "It caches the value",
            ],
            "answer": 1,
            "why": "You can start with a public attribute and add validation later; no caller has to change.",
        },
        {
            "q": "Which BookVault method is best as a `@staticmethod` rather than a `@classmethod`?",
            "options": [
                "`Book.from_dict(data)`, which builds a new Book",
                "`Book.reset_ids()`, which changes a class-level counter",
                "`Book.validate_isbn(isbn)`, a pure check that needs neither the class nor an instance",
                "`Book.borrow()`, which changes one book",
            ],
            "answer": 2,
            "why": "A static method uses no `self` or `cls`. Alternate constructors and class-state changes need `cls`, so they are class methods.",
        },
    ],
})

# ======================================================================
# Beginner layer: "Start here" part, line-by-line notes, hints, ordering.
# ======================================================================
from day1_beginner import apply as _apply_beginner_layer

_apply_beginner_layer(LESSONS, PARTS)
DAY["tagline"] = "New to programming? Start here and go in order. No installation needed to begin: every example runs in your browser."

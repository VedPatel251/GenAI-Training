"""Detective X — vertical slice content (Day 1 division).

SKILLS reuse lessons from day1_lessons.py by id.
Each case step runs with one evidence variant preloaded. The checker runs the
trainee's code against EVERY variant, so only code that reasons from the
evidence passes. Tests compute the expected answer from the evidence itself.
"""

TITLE = "Detective X"
DIVISION = "Day 1 · Street Division"

# Spread over the whole 8-day course: finishing Day 1 (~6,000 XP) reaches Senior Detective.
RANKS = [
    (0, "Cadet"),
    (400, "Constable"),
    (1500, "Detective"),
    (4000, "Senior Detective"),
    (9000, "Inspector"),
    (18000, "Chief Inspector"),
    (30000, "Commissioner"),
]

XP = {"lesson": 10, "skill": 30, "tutorial": 20, "small": 50, "medium": 120, "big": 300, "exam": 200, "capstone": 250}

FRAGMENTS_TOTAL = 16   # X fragments across the whole course (Day 1 holds 4); the final case needs them all

# Skills in teaching order. Each skill's lessons come from day1_lessons.py, and a case may only
# use syntax from the skills it lists (and the skills before them).
SKILLS = [
    {"id": "orientation", "title": "Orientation", "badge": "Bureau ID card",
     "tagline": "How the Bureau works, and how to set up Python on your own machine.",
     "lessons": ["welcome", "install-python", "first-program"]},
    {"id": "field-notes", "title": "Field notes", "badge": "Notebook",
     "tagline": "print, comments, variables and numbers: writing down what you find.",
     "lessons": ["print-comments", "variables", "numbers"]},
    {"id": "text", "title": "Reading text", "badge": "Magnifying glass",
     "tagline": "Strings: cleaning up statements, notes and messages.",
     "lessons": ["strings-basics"]},
    {"id": "logic", "title": "Deduction", "badge": "Scales of justice",
     "tagline": "True, False, comparisons and if / elif / else: drawing conclusions.",
     "lessons": ["booleans", "if-else"]},
    {"id": "lists", "title": "Lists and loops", "badge": "Case binder",
     "tagline": "Keep many records in order and check every one of them with for and while.",
     "lessons": ["lists-basics", "for-loops", "while-loops"]},
    {"id": "records", "title": "Records", "badge": "Index cards",
     "tagline": "Dictionaries: look things up by name instead of by position.",
     "lessons": ["dicts-basics"]},
    {"id": "functions", "title": "Procedures", "badge": "Rubber stamp",
     "tagline": "Functions: write a procedure once, run it on every case.",
     "lessons": ["functions-basics"]},
    {"id": "errors", "title": "Damage control", "badge": "First-aid kit",
     "tagline": "Read error messages and survive bad data with try / except.",
     "lessons": ["errors-basics"]},
    {"id": "toolkit", "title": "Field kit", "badge": "Toolbox",
     "tagline": "Modules, dates, tuples, None and virtual environments.",
     "lessons": ["modules-basics", "tuples-none", "python-setup"]},
    {"id": "identity", "title": "Identity checks", "badge": "ID scanner",
     "tagline": "Types, is vs ==, the float trap and truthiness.",
     "lessons": ["dynamic-typing", "is-vs-eq", "float-trap", "truthiness"]},
    {"id": "forensic-text", "title": "Forensic text", "badge": "Typewriter",
     "tagline": "Slicing, split and join, and f-string formatting for reports.",
     "lessons": ["strings", "f-strings"]},
    {"id": "collections", "title": "Evidence collections", "badge": "Evidence bags",
     "tagline": "Sets, copies, Counter, defaultdict, loop tricks and match / case.",
     "lessons": ["containers", "dicts", "loops", "control-flow"]},
    {"id": "function-craft", "title": "Procedure craft", "badge": "Signet ring",
     "tagline": "Argument types, the mutable default trap, scope and closures.",
     "lessons": ["arguments", "mutable-default", "scope"]},
    {"id": "functional", "title": "Functional tools", "badge": "Lens kit",
     "tagline": "Functions as values, lambda, sorted(key=), map / filter / reduce, comprehensions.",
     "lessons": ["first-class", "map-filter-reduce", "comprehensions"]},
    {"id": "decorators", "title": "Wiretaps", "badge": "Headphones",
     "tagline": "Decorators: wrap a function to log, time or count it.",
     "lessons": ["decorators"]},
    {"id": "streams", "title": "Surveillance streams", "badge": "Reel-to-reel",
     "tagline": "Generators and context managers: process data one piece at a time.",
     "lessons": ["generators", "context-managers"]},
    {"id": "classes", "title": "Case files", "badge": "Filing cabinet",
     "tagline": "Classes, objects, properties, class and static methods.",
     "lessons": ["classes", "properties"]},
    {"id": "inheritance", "title": "Chain of command", "badge": "Org chart",
     "tagline": "Inheritance, abstract base classes and composition.",
     "lessons": ["inheritance-abc", "composition"]},
    {"id": "dunders", "title": "Native evidence", "badge": "Master key",
     "tagline": "Dunder methods: make your objects work with len, in, [], print and ==.",
     "lessons": ["dunders", "eq-hash"]},
    {"id": "dataclasses", "title": "Standard forms", "badge": "Carbon copy",
     "tagline": "Dataclasses, __post_init__ validation and frozen value objects.",
     "lessons": ["dataclasses", "frozen"]},
]

CASES = [
    # ------------------------------------------------------------------ tutorial
    {
        "id": "coffee-thief",
        "tier": "tutorial",
        "title": "The Coffee Thief",
        "teaser": "Someone keeps raiding the Bureau's coffee. Your first case.",
        "skills": ["orientation"],
        "story": "Welcome to the Bureau, Cadet. Your first case is small but personal: every night, someone steals the good coffee from the 3rd-floor kitchen.\n\nThe hallway camera reads ID badges. Forensics has already loaded its record into a **variable** called `camera_name`. A variable is a labelled box that holds a value; you will learn all about them in the Field notes skill.\n\nAt the Bureau we never type an answer we *think* is right. We write code that reads the evidence, so the same code works on every case file.",
        "suspects": [
            {"name": "the night janitor", "note": "Has keys to every floor."},
            {"name": "the intern", "note": "Drinks four cups a day."},
            {"name": "the Chief", "note": "Claims to only drink tea."},
        ],
        "variants": [
            'camera_name = "Inspector Rao"\ncups_missing = 3\n',
            'camera_name = "Officer Mehta"\ncups_missing = 5\n',
            'camera_name = "Clerk Fernandes"\ncups_missing = 2\n',
        ],
        "steps": [
            {
                "question": "Print a line that says `Thief:` followed by the name from the camera. Use the variable `camera_name`, not the name itself.",
                "starter": 'print("Thief:", ...)\n',
                "solution": 'print("Thief:", camera_name)\n',
                "tests": '''expected = "Thief: " + camera_name
assert __output__.strip() == expected, f"expected the line {expected!r}, you printed {__output__.strip()!r}"''',
                "tips": [
                    "Replace the `...` with the variable name `camera_name`. No quotes around it: quotes would print the word itself.",
                    'The whole line is `print("Thief:", camera_name)`.',
                ],
                "reveal": "The camera never lies. Caught red-handed with a thermos. The coffee is safe, and you have learned the Bureau's first rule: **read the evidence with code**.",
            },
        ],
        "closing": "Case closed. The Chief is impressed, and slightly embarrassed that the culprit was on their own staff. Your badge is ready. Real cases are waiting on the board.",
    },
    # ------------------------------------------------------------------ small
    {
        "id": "ransom-note",
        "tier": "small",
        "title": "The Ransom Note",
        "teaser": "Three scraps of paper, one kidnapper, one demand.",
        "skills": ["field-notes"],
        "story": "A shipping heir has vanished, and this morning a ransom note arrived, torn into three scraps. The lab has typed each scrap into a variable. They have also worked out the order from the tear marks: **scrap 2, then scrap 3, then scrap 1**.\n\nThe note also says how the money must be delivered. Read it carefully.",
        "suspects": [
            {"name": "the chauffeur", "note": "Last to see the heir."},
            {"name": "the business rival", "note": "Lost a contract to the family last month."},
        ],
        "variants": [
            'scrap_1 = "AT MIDNIGHT"\nscrap_2 = "BRING THE MONEY"\nscrap_3 = "TO PIER 9"\nbills = 400\nbill_value = 500\nenvelopes = 3\n',
            'scrap_1 = "BEFORE DAWN"\nscrap_2 = "LEAVE THE CASE"\nscrap_3 = "UNDER THE CLOCK TOWER"\nbills = 250\nbill_value = 2000\nenvelopes = 4\n',
            'scrap_1 = "ON FRIDAY"\nscrap_2 = "DROP THE BAG"\nscrap_3 = "AT THE OLD MILL"\nbills = 900\nbill_value = 100\nenvelopes = 7\n',
        ],
        "steps": [
            {
                "question": "Print the full note on **one line**, with the scraps in the right order (2, 3, 1).",
                "starter": "# print the scraps in the right order\n",
                "solution": "print(scrap_2, scrap_3, scrap_1)\n",
                "tests": '''expected = f"{scrap_2} {scrap_3} {scrap_1}"
assert __output__.strip() == expected, f"the note should read {expected!r}, you printed {__output__.strip()!r}"''',
                "tips": [
                    "`print` can take several values separated by commas, and puts a space between them.",
                    "`print(scrap_2, scrap_3, scrap_1)`",
                ],
                "reveal": "The demand is clear. Now the money: the kidnapper wants it in used bills.",
            },
            {
                "question": "The note demands `bills` bills of `bill_value` rupees each, split equally into `envelopes` envelopes. Calculate `ransom_total`, and `per_envelope` as a **whole** number of rupees (drop any remainder).",
                "starter": "ransom_total = ...\nper_envelope = ...\n\nprint(ransom_total, per_envelope)\n",
                "solution": "ransom_total = bills * bill_value\nper_envelope = ransom_total // envelopes\n\nprint(ransom_total, per_envelope)\n",
                "tests": '''assert ransom_total == bills * bill_value, f"ransom_total should be bills x bill_value = {bills * bill_value}, got {ransom_total!r}"
assert per_envelope == (bills * bill_value) // envelopes, f"per_envelope should be {(bills * bill_value) // envelopes} (whole rupees), got {per_envelope!r}"''',
                "tips": [
                    "Total = number of bills times the value of one bill: `bills * bill_value`.",
                    "`//` divides and drops the remainder: `per_envelope = ransom_total // envelopes`.",
                ],
                "reveal": "The amounts match a withdrawal the business rival made yesterday, to the rupee.",
            },
        ],
        "closing": "Case closed. The heir was found safe at the pier, and the rival's bank records did the rest. Precise arithmetic catches careless criminals.",
    },
    {
        "id": "missing-minutes",
        "tier": "small",
        "title": "The Missing Minutes",
        "teaser": "The vault camera went dark. For how long, exactly?",
        "skills": ["field-notes"],
        "story": "Last night the camera covering the bank vault went dark. The security system only logs the gap in **seconds**, in a variable called `gap_seconds`.\n\nThe night guard says they were gone for \"a few minutes\". The jury will want minutes and seconds.",
        "suspects": [
            {"name": "the night guard", "note": "Says the outage was short."},
            {"name": "the electrician", "note": "Was rewiring the floor above."},
        ],
        "variants": [
            "gap_seconds = 2537\n",
            "gap_seconds = 754\n",
            "gap_seconds = 3600\n",
        ],
        "steps": [
            {
                "question": "Split `gap_seconds` into whole `minutes` and the leftover `seconds`. Then print them like `42 min 17 s`.",
                "starter": "minutes = ...\nseconds = ...\n\nprint(minutes, \"min\", seconds, \"s\")\n",
                "solution": "minutes = gap_seconds // 60\nseconds = gap_seconds % 60\n\nprint(minutes, \"min\", seconds, \"s\")\n",
                "tests": '''assert minutes == gap_seconds // 60, f"minutes should be {gap_seconds // 60}, got {minutes!r}"
assert seconds == gap_seconds % 60, f"seconds should be {gap_seconds % 60}, got {seconds!r}"
assert __output__.strip() == f"{gap_seconds // 60} min {gap_seconds % 60} s", "print them as: <minutes> min <seconds> s"''',
                "tips": [
                    "There are 60 seconds in a minute. `//` gives whole minutes and `%` gives what is left over.",
                    "`minutes = gap_seconds // 60` and `seconds = gap_seconds % 60`.",
                ],
                "reveal": "Not \"a few minutes\". More than enough time to empty a safe-deposit box. The guard's story falls apart.",
            },
        ],
        "closing": "Case closed. Faced with the exact numbers, the night guard admitted to leaving the door propped open for an accomplice.",
    },
    {
        "id": "typed-confession",
        "tier": "small",
        "title": "The Typed Confession",
        "teaser": "A messy statement that has to go in the official report.",
        "skills": ["text"],
        "story": "A witness typed their statement on a broken typewriter: stray spaces, random CAPITALS. The court only accepts clean statements in the official format.\n\nThe statement is in `statement` and the witness's name is in `witness`.",
        "suspects": [
            {"name": "the witness", "note": "Nervous, but cooperative."},
        ],
        "variants": [
            'statement = "   i was AT the DOCKS until NINE   "\nwitness = "harbour master"\n',
            'statement = "  The VAN was BLUE and had no plates "\nwitness = "flower seller"\n',
            'statement = "    nobody LEFT the Theatre before the encore  "\nwitness = "usher"\n',
        ],
        "steps": [
            {
                "question": "Make `clean`: the statement with the spaces removed from both ends and everything in lower case.",
                "starter": "clean = ...\nprint(clean)\n",
                "solution": "clean = statement.strip().lower()\nprint(clean)\n",
                "tests": '''assert clean == statement.strip().lower(), f"clean should be {statement.strip().lower()!r}, got {clean!r}"''',
                "tips": [
                    "Two methods: `.strip()` removes outer spaces and `.lower()` lowercases.",
                    "Chain them: `statement.strip().lower()`.",
                ],
                "reveal": "Readable at last. Now put it in the court's format.",
            },
            {
                "question": "Build `report` with an f-string, exactly like `Statement of HARBOUR MASTER: i was at the docks until nine`: the witness's name in UPPER CASE, then the clean statement. Also store `length`, the number of characters in the clean statement.",
                "starter": "clean = statement.strip().lower()\n\nreport = ...\nlength = ...\nprint(report)\nprint(length)\n",
                "solution": 'clean = statement.strip().lower()\n\nreport = f"Statement of {witness.upper()}: {clean}"\nlength = len(clean)\nprint(report)\nprint(length)\n',
                "tests": '''_clean = statement.strip().lower()
_expected = f"Statement of {witness.upper()}: {_clean}"
assert report == _expected, f"report should be {_expected!r}, got {report!r}"
assert length == len(_clean), f"length should be {len(_clean)}, got {length!r}"''',
                "tips": [
                    "Inside an f-string you can call methods: `{witness.upper()}`.",
                    '`report = f"Statement of {witness.upper()}: {clean}"` and `length = len(clean)`.',
                ],
                "reveal": "Filed. The clean statement puts the witness somewhere they couldn't have seen the crime from.",
            },
        ],
        "closing": "Case closed. Clean evidence holds up in court; messy evidence gets thrown out.",
    },
    {
        "id": "fingerprint-match",
        "tier": "small",
        "title": "Fingerprint Match",
        "teaser": "The lab needs a verdict on a print from the crime scene.",
        "skills": ["logic"],
        "story": "A print was lifted from a broken window. The lab compared it with the suspect's and counted the `matching_points`. They also noted whether the print is `smudged`.\n\nBureau rules:\n- A smudged print must be **retaken**, whatever the score.\n- 12 or more points: **match**.\n- 8 to 11 points: **partial**.\n- Fewer than 8: **no match**.",
        "suspects": [
            {"name": "the window cleaner", "note": "Has a reason to touch every window."},
        ],
        "variants": [
            "matching_points = 9\nsmudged = False\n",
            "matching_points = 14\nsmudged = False\n",
            "matching_points = 5\nsmudged = False\n",
            "matching_points = 13\nsmudged = True\n",
            "matching_points = 12\nsmudged = False\n",
            "matching_points = 8\nsmudged = False\n",
        ],
        "steps": [
            {
                "question": "Set `verdict` to `\"retake\"`, `\"match\"`, `\"partial\"` or `\"no match\"` following the Bureau rules. Check the smudge first.",
                "starter": "# set verdict here\n\nprint(verdict)\n",
                "solution": 'if smudged:\n    verdict = "retake"\nelif matching_points >= 12:\n    verdict = "match"\nelif matching_points >= 8:\n    verdict = "partial"\nelse:\n    verdict = "no match"\n\nprint(verdict)\n',
                "tests": '''if smudged:
    _exp = "retake"
elif matching_points >= 12:
    _exp = "match"
elif matching_points >= 8:
    _exp = "partial"
else:
    _exp = "no match"
assert verdict == _exp, f"with matching_points = {matching_points} and smudged = {smudged}, the verdict should be {_exp!r}, got {verdict!r}"''',
                "tips": [
                    "Start with `if smudged:` because it wins over any score.",
                    "Then `elif matching_points >= 12:`, `elif matching_points >= 8:` and `else:`.",
                ],
                "reveal": "The verdict is in the file. The window cleaner's lawyer is already calling.",
            },
        ],
        "closing": "Case closed. Clear rules, applied the same way every time: that is how a deduction holds up.",
    },
    {
        "id": "guest-list",
        "tier": "small",
        "title": "The Guest List",
        "teaser": "A gala, a stolen necklace, and two lists that don't agree.",
        "skills": ["lists"],
        "story": "At last night's gala a diamond necklace disappeared. The host has the list of `invited` guests, and the doorman has the `signed` guestbook of everyone who actually came in.\n\nWhoever was invited but never signed in was not where they were supposed to be. And the doorman swears that **exactly one** person got in without an invitation.",
        "suspects": [
            {"name": "the guests who never signed", "note": "Where were they?"},
            {"name": "the gatecrasher", "note": "Not on any list."},
        ],
        "variants": [
            'invited = ["Asha", "Ravi", "Meera", "Kabir", "Zoya", "Vikram"]\nsigned = ["Ravi", "Zoya", "Asha", "Dev", "Vikram"]\n',
            'invited = ["Leela", "Arjun", "Nisha", "Omar", "Priya"]\nsigned = ["Omar", "Sam", "Leela", "Priya"]\n',
            'invited = ["Tara", "Ishaan", "Rhea", "Yusuf", "Anika", "Neel", "Maya"]\nsigned = ["Neel", "Tara", "Maya", "Rhea", "Farhan"]\n',
        ],
        "steps": [
            {
                "question": "Build the list `missing`: every invited guest who is **not** in `signed`, in the same order as `invited`. Use a `for` loop.",
                "starter": "missing = []\n# loop over invited here\n\nprint(missing)\n",
                "solution": "missing = []\nfor guest in invited:\n    if guest not in signed:\n        missing.append(guest)\n\nprint(missing)\n",
                "tests": '''_exp = [g for g in invited if g not in signed]
assert missing == _exp, f"missing should be {_exp}, got {missing}"''',
                "tips": [
                    "`not in` is the opposite of `in`: `guest not in signed` is True when the guest never signed.",
                    "Inside `for guest in invited:` write `if guest not in signed:` and then `missing.append(guest)`.",
                ],
                "reveal": "Two names. Two people with no alibi for the hour the necklace vanished.",
            },
            {
                "question": "Now find `gatecrasher`: the one name in `signed` that is **not** in `invited`.",
                "starter": "gatecrasher = None\n# loop over signed here\n\nprint(gatecrasher)\n",
                "solution": "gatecrasher = None\nfor name in signed:\n    if name not in invited:\n        gatecrasher = name\n\nprint(gatecrasher)\n",
                "tests": '''_exp = [n for n in signed if n not in invited][0]
assert gatecrasher == _exp, f"gatecrasher should be {_exp!r}, got {gatecrasher!r}"''',
                "tips": [
                    "The same pattern as before, but loop over `signed` and check `not in invited`.",
                    "When you find the name, store it: `gatecrasher = name`.",
                ],
                "reveal": "The gatecrasher was carrying a jeweller's loupe. Interesting.",
            },
        ],
        "closing": "Case closed. The gatecrasher and one of the missing guests were working together. Comparing two lists, one name at a time, cracked it.",
    },
    # ------------------------------------------------------------------ medium
    {
        "id": "library-heist",
        "tier": "medium",
        "title": "The Library Heist",
        "teaser": "A priceless folio is gone. The checkout log knows who took it.",
        "skills": ["field-notes", "text", "logic", "lists"],
        "story": "The Grand Library's rarest book, **Folio 1623**, has been replaced with a fake. The checkout system records every movement in four lists of the same length. Line `i` of the log is: `times[i]`, `names[i]`, `actions[i]` (`\"out\"` or `\"in\"`) and `items[i]`.\n\nTimes are written `\"HH:MM\"`, so the log is already in time order.\n\nThe head librarian adds one detail that matters: *\"A return only counts if the same person who took the book out brings it back. Anyone else 'returning' it is handing in a forgery.\"*",
        "suspects": [
            {"name": "the archivist", "note": "Handles the folio for restoration."},
            {"name": "the visiting scholar", "note": "Requested the folio three times this month."},
            {"name": "the volunteer", "note": "New, eager, and always near the rare-books desk."},
        ],
        "variants": [
            'times = ["18:02", "18:15", "18:40", "19:05", "19:30", "20:10", "20:45"]\n'
            'names = ["Archivist Iyer", "Scholar Novak", "Scholar Novak", "Volunteer Das", "Archivist Iyer", "Volunteer Das", "Scholar Novak"]\n'
            'actions = ["out", "out", "in", "out", "in", "out", "in"]\n'
            'items = ["Atlas", "Folio 1623", "Folio 1623", "Folio 1623", "Atlas", "Map Box", "Folio 1623"]\n',

            'times = ["17:50", "18:20", "18:55", "19:10", "19:45", "20:30"]\n'
            'names = ["Scholar Novak", "Archivist Iyer", "Scholar Novak", "Archivist Iyer", "Volunteer Das", "Archivist Iyer"]\n'
            'actions = ["out", "out", "in", "in", "out", "out"]\n'
            'items = ["Folio 1623", "Atlas", "Folio 1623", "Atlas", "Map Box", "Folio 1623"]\n',

            'times = ["18:00", "18:30", "19:00", "19:20", "19:55", "20:15", "20:50", "21:05"]\n'
            'names = ["Volunteer Das", "Volunteer Das", "Scholar Novak", "Archivist Iyer", "Archivist Iyer", "Volunteer Das", "Volunteer Das", "Archivist Iyer"]\n'
            'actions = ["out", "in", "out", "out", "in", "in", "out", "in"]\n'
            'items = ["Folio 1623", "Folio 1623", "Folio 1623", "Atlas", "Atlas", "Folio 1623", "Map Box", "Map Box"]\n',
        ],
        "steps": [
            {
                "question": "**Follow the book.** Build `folio_people`: the names on every log line about `\"Folio 1623\"`, in log order, each person listed **once**.",
                "starter": "folio_people = []\nfor i in range(len(items)):\n    # look at items[i] and names[i] here\n    ...\n\nprint(folio_people)\n",
                "solution": 'folio_people = []\nfor i in range(len(items)):\n    if items[i] == "Folio 1623":\n        if names[i] not in folio_people:\n            folio_people.append(names[i])\n\nprint(folio_people)\n',
                "tests": '''_exp = []
for _i in range(len(items)):
    if items[_i] == "Folio 1623" and names[_i] not in _exp:
        _exp.append(names[_i])
assert folio_people == _exp, f"folio_people should be {_exp}, got {folio_people}"''',
                "tips": [
                    "`range(len(items))` gives every line number `i`, so `items[i]` and `names[i]` belong to the same log line.",
                    'Inside the loop: `if items[i] == "Folio 1623":` and then, only if `names[i] not in folio_people`, append it.',
                ],
                "reveal": "Everyone on that list touched the folio yesterday. One of them walked out with the real one.",
            },
            {
                "question": "**Last sighting.** Store in `last_seen` the time of the **last** log line about the folio.",
                "starter": "last_seen = None\n# loop over the log here\n\nprint(last_seen)\n",
                "solution": 'last_seen = None\nfor i in range(len(items)):\n    if items[i] == "Folio 1623":\n        last_seen = times[i]\n\nprint(last_seen)\n',
                "tests": '''_exp = [times[_i] for _i in range(len(items)) if items[_i] == "Folio 1623"][-1]
assert last_seen == _exp, f"last_seen should be {_exp!r}, got {last_seen!r}"''',
                "tips": [
                    "Loop over every line. Each time the item is the folio, overwrite `last_seen` with that line's time.",
                    "After the loop, `last_seen` holds the time from the last matching line, because later lines overwrite earlier ones.",
                ],
                "reveal": "After that time, the folio never shows up in the log again.",
            },
            {
                "question": "**Accuse.** Track who is holding the real folio. Start with `holder = None`. On each folio line: an `\"out\"` makes that person the holder; an `\"in\"` clears the holder **only if** it is the same person. When the loop ends, `holder` is the thief. Store it in `culprit`.",
                "starter": "holder = None\nfor i in range(len(items)):\n    if items[i] == \"Folio 1623\":\n        ...\n\nculprit = holder\nprint(\"The thief is\", culprit)\n",
                "solution": 'holder = None\nfor i in range(len(items)):\n    if items[i] == "Folio 1623":\n        if actions[i] == "out":\n            holder = names[i]\n        elif actions[i] == "in" and names[i] == holder:\n            holder = None\n\nculprit = holder\nprint("The thief is", culprit)\n',
                "tests": '''_h = None
for _i in range(len(items)):
    if items[_i] == "Folio 1623":
        if actions[_i] == "out":
            _h = names[_i]
        elif actions[_i] == "in" and names[_i] == _h:
            _h = None
assert culprit == _h, f"on this log the thief is {_h!r}, but your code says {culprit!r}. Remember: a return by someone else doesn't count."''',
                "tips": [
                    'Inside the folio check: `if actions[i] == "out": holder = names[i]`.',
                    'Then `elif actions[i] == "in" and names[i] == holder: holder = None`. A forged return by someone else leaves `holder` unchanged.',
                ],
                "reveal": "The log doesn't lie: the folio went out and never came back with the person who took it. And on the empty shelf, someone has drawn a small chalk **X**.",
            },
        ],
        "closing": "Case closed. The real Folio 1623 was found in the thief's locker. But the chalk X on the shelf bothers the Chief: *\"I've seen that mark before. Open a file. Call it X.\"*",
        "fragment": "A chalk X on shelf 7, drawn with the left hand.",
    },
]

# ----------------------------------------------------------------------
# More cases live in their own files so they can be written and checked
# separately. Each module exports CASES (a list in the same format).
# ----------------------------------------------------------------------
import importlib as _importlib

for _mod in ("game_cases_small", "game_cases_medium", "game_cases_big", "game_cases_final"):
    try:
        CASES.extend(_importlib.import_module(_mod).CASES)
    except ModuleNotFoundError as _e:
        if _e.name != _mod:
            raise

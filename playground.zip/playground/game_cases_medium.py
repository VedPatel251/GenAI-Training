"""Detective X: medium cases (Day 1 division).

Eleven reskinned official assignments (Q6, Q9, Q11-Q15, Q17-Q20) plus two
original cases. Same format as game_day1.py: every step runs on every evidence
variant, and the tests compute the expected answer from the evidence itself.

Check with:  python build_game.py --check game_cases_medium
"""


def _caesar(text, shift):
    """Shift every lower-case letter forward by `shift` (used to build the postcard evidence)."""
    abc = "abcdefghijklmnopqrstuvwxyz"
    return "".join(abc[(abc.index(c) + shift) % 26] if c in abc else c for c in text)


def _postcards(cards):
    """Build the evidence code for coded-postcards from plain-text cards."""
    lines = ['ALPHABET = "abcdefghijklmnopqrstuvwxyz"\n', "postcards = [\n"]
    for town, shift, plain in cards:
        lines.append(f'    {{"from": {town!r}, "shift": {shift}, "text": {_caesar(plain, shift)!r}}},\n')
    lines.append("]\n")
    return "".join(lines)


# Shared test helper: parse the cargo manifest the way the trainee should.
_MANIFEST_PARSE = r'''_lines = [_l.strip() for _l in manifest.strip().split("\n") if _l.strip()]
_head = [_h.strip() for _h in _lines[0].split(",")]
_exp_rows = []
for _l in _lines[1:]:
    _vals = [_v.strip() for _v in _l.split(",")]
    _row = dict(zip(_head, _vals))
    _row["declared_kg"] = int(_row["declared_kg"])
    _row["weighed_kg"] = int(_row["weighed_kg"])
    _exp_rows.append(_row)
'''

_LOAD_MANIFEST = r'''def load_manifest(text):
    lines = []
    for line in text.strip().split("\n"):
        if line.strip() != "":
            lines.append(line.strip())
    header = lines[0].split(",")
    for i in range(len(header)):
        header[i] = header[i].strip()
    rows = []
    for line in lines[1:]:
        values = line.split(",")
        row = {}
        for i in range(len(header)):
            row[header[i]] = values[i].strip()
        row["declared_kg"] = int(row["declared_kg"])
        row["weighed_kg"] = int(row["weighed_kg"])
        rows.append(row)
    return rows
'''

_EVIDENCE_ROOM = r'''class EvidenceRoom:
    def __init__(self, name):
        self.name = name
        self.items = []

    def add(self, item):
        self.items.append(item)

    def remove(self, tag):
        self.items = [i for i in self.items if i["tag"] != tag]

    def find(self, query):
        q = query.lower()
        return [i for i in self.items if q in i["description"].lower()]

    def count(self):
        return len(self.items)
'''

_STAKEOUT = r'''class Stakeout:
    def __init__(self, officer, location, minutes, night):
        self.officer = officer
        self.location = location
        self.minutes = minutes
        self.night = night

    @property
    def hours(self):
        rate = 1.5 if self.night else 1.0
        return round(self.minutes / 60 * rate, 2)

    @classmethod
    def from_dict(cls, data):
        return cls(data["officer"], data["location"], int(data["minutes"]), data["night"])

    @staticmethod
    def is_valid_shift(data):
        try:
            return 1 <= int(data["minutes"]) <= 720
        except (KeyError, TypeError, ValueError):
            return False
'''

_EVIDENCE_TYPES = r'''from abc import ABC, abstractmethod

class Evidence(ABC):
    def __init__(self, title, tag):
        self.title = title
        self.tag = tag
        self.logged = True

    @abstractmethod
    def category(self) -> str: ...

    @abstractmethod
    def describe(self) -> str: ...

class Weapon(Evidence):
    def __init__(self, title, tag, material):
        super().__init__(title, tag)
        self.material = material
    def category(self):
        return "Weapon"
    def describe(self):
        return f"[{self.category()}] {self.tag} {self.title}, made of {self.material}"

class Document(Evidence):
    def __init__(self, title, tag, pages):
        super().__init__(title, tag)
        self.pages = pages
    def category(self):
        return "Document"
    def describe(self):
        return f"[{self.category()}] {self.tag} {self.title}, {self.pages} pages"

class Footage(Evidence):
    def __init__(self, title, tag, minutes):
        super().__init__(title, tag)
        self.minutes = minutes
    def category(self):
        return "Footage"
    def describe(self):
        return f"[{self.category()}] {self.tag} {self.title}, {self.minutes} min"
'''

_MONEY = r'''from decimal import Decimal

class Money:
    def __init__(self, amount, currency):
        self.amount = amount
        self.currency = currency

    def __repr__(self):
        return f"Money({self.amount}, {self.currency})"

    def __str__(self):
        return f"{self.amount} {self.currency}"

    def __eq__(self, other):
        if not isinstance(other, Money):
            return NotImplemented
        return (self.amount, self.currency) == (other.amount, other.currency)

    def __hash__(self):
        return hash((self.amount, self.currency))

    def _check(self, other):
        if self.currency != other.currency:
            raise ValueError(f"cannot mix {self.currency} and {other.currency}")

    def __add__(self, other):
        self._check(other)
        return Money(self.amount + other.amount, self.currency)

    def __sub__(self, other):
        self._check(other)
        return Money(self.amount - other.amount, self.currency)

    def __lt__(self, other):
        self._check(other)
        return self.amount < other.amount

    def __le__(self, other):
        self._check(other)
        return self.amount <= other.amount

    def __gt__(self, other):
        self._check(other)
        return self.amount > other.amount

    def __ge__(self, other):
        self._check(other)
        return self.amount >= other.amount

    def __bool__(self):
        return self.amount > 0
'''

_LOCKER_BASE = r'''class Locker:
    def __init__(self, name):
        self.name = name
        self.items = []

    def add(self, item):
        self.items.append(item)

    def find(self, query):
        q = query.lower()
        return [i for i in self.items if q in i["description"].lower()]
'''

_LOCKER_DUNDERS = r'''
    def __len__(self):
        return len(self.items)

    def __bool__(self):
        return len(self.items) > 0

    def __contains__(self, item):
        if isinstance(item, str):
            return any(i["tag"] == item for i in self.items)
        return item in self.items

    def __iter__(self):
        return iter(self.items)

    def __getitem__(self, key):
        if isinstance(key, (int, slice)):
            return self.items[key]
        for i in self.items:
            if i["tag"] == key:
                return i
        raise KeyError(key)

    def __repr__(self):
        return f"Locker(name={self.name!r}, items={len(self.items)})"

    def __str__(self):
        return f"{self.name}: {len(self.items)} items"

    def __call__(self, query):
        return self.find(query)
'''

_BAIL = r'''from abc import ABC, abstractmethod

class Charge(ABC):
    def __init__(self, amount):
        self.amount = amount

    @abstractmethod
    def bail(self): ...

class Theft(Charge):
    def bail(self):
        return 5000

class Fraud(Charge):
    def bail(self):
        return 10000 + self.amount // 10

class Vandalism(Charge):
    def bail(self):
        if self.amount < 5000:
            return 0
        return 2000

class ArmedRobbery(Theft):
    DEPOSIT = 25000
    def bail(self):
        return super().bail() + self.DEPOSIT

def calculate_total(charges):
    return sum(charge.bail() for charge in charges)

KINDS = {"Theft": Theft, "Fraud": Fraud, "Vandalism": Vandalism, "ArmedRobbery": ArmedRobbery}
'''

_DROP_FILLERS = r'''def drop_fillers(text):
    return " ".join([w for w in text.split() if w not in ("um", "uh")])
'''

_PIPELINE = r'''def pipeline(funcs):
    def run(value):
        for f in funcs:
            value = f(value)
        return value
    return run
'''

_PIPELINE_FILTER = r'''def pipeline_filter(funcs, predicate):
    def run(items):
        results = []
        for value in items:
            for f in funcs:
                value = f(value)
                if not predicate(value):
                    break
            else:
                results.append(value)
        return results
    return run
'''

_RECORD = r'''class Record:
    fields = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        cls._registry = []

    def __init__(self, **kwargs):
        unknown = set(kwargs) - set(self.fields)
        missing = set(self.fields) - set(kwargs)
        if unknown or missing:
            raise TypeError(f"unknown fields {sorted(unknown)}, missing fields {sorted(missing)}")
        for name in self.fields:
            setattr(self, name, kwargs[name])
        type(self)._registry.append(self)

    def to_dict(self):
        return {name: getattr(self, name) for name in self.fields}

    @classmethod
    def from_dict(cls, data):
        return cls(**data)

    @classmethod
    def all(cls):
        return list(cls._registry)

    @classmethod
    def filter(cls, **criteria):
        return [r for r in cls._registry if all(getattr(r, k) == v for k, v in criteria.items())]
'''

_RECORD_SUBCLASSES = r'''class Suspect(Record):
    fields = ("name", "gang", "city")

class Vehicle(Record):
    fields = ("plate", "colour", "make", "owner")
'''

_CRIMINAL = r'''from dataclasses import dataclass

@dataclass
class Criminal:
    crim_id: str
    name: str
    gang: str
    year: int       # year of first arrest
    bounty: int     # reward in rupees
    status: str     # "at large" or "in custody"

CRIMINALS = [Criminal(*row) for row in criminal_rows]
'''

_CRIMINAL_DB = r'''class CriminalDB:
    def __init__(self):
        self._records = {}

    def add(self, criminal):
        self._records[criminal.crim_id] = criminal

    def search(self, query=None, *, gang=None, min_year=None, max_year=None, status=None):
        q = query.lower() if query else None
        return [
            c for c in self._records.values()
            if (q is None or q in c.name.lower())
            and (gang is None or c.gang == gang)
            and (min_year is None or c.year >= min_year)
            and (max_year is None or c.year <= max_year)
            and (status is None or c.status == status)
        ]

    def top_wanted(self, n=3):
        return sorted(self._records.values(), key=lambda c: c.bounty, reverse=True)[:n]

    def group_by(self, attr):
        groups = {}
        for c in self._records.values():
            groups.setdefault(getattr(c, attr), []).append(c)
        return groups

    def __iter__(self):
        return iter(self._records.values())

    def __getitem__(self, crim_id):
        return self._records[crim_id]
'''

_CRIMINAL_TEST_DB = r'''_crims = [Criminal(*_r) for _r in criminal_rows]
_db = CriminalDB()
for _c in _crims:
    _db.add(_c)
def _ids(found):
    return [c.crim_id for c in found]
def _expect(query=None, gang=None, min_year=None, max_year=None, status=None):
    return [c.crim_id for c in _crims
            if (query is None or query.lower() in c.name.lower())
            and (gang is None or c.gang == gang)
            and (min_year is None or c.year >= min_year)
            and (max_year is None or c.year <= max_year)
            and (status is None or c.status == status)]
'''

_WITNESS_SETUP = r'''from dataclasses import dataclass
from datetime import date, timedelta

class ProgramError(Exception): ...
class UnknownSafehouseError(ProgramError): ...
class UnknownWitnessError(ProgramError): ...
class SafehouseOccupiedError(ProgramError): ...
class NoOpenStayError(ProgramError): ...

@dataclass(frozen=True)
class Witness:
    witness_id: str
    name: str

@dataclass
class Stay:
    safehouse_id: str
    witness_id: str
    checked_in: date
    due_out: date
    checked_out: "date | None" = None

class Program:
    def __init__(self):
        self.free = {}        # safehouse_id -> True when nobody is staying there
        self.witnesses = {}   # witness_id -> Witness
        self.stays = []       # every Stay, in the order they were created

    def add_safehouse(self, safehouse_id):
        self.free[safehouse_id] = True

    def add_witness(self, witness):
        self.witnesses[witness.witness_id] = witness
'''

_WITNESS_CHECK = r'''
    def check_in(self, safehouse_id, witness_id, on, nights=7):
        if safehouse_id not in self.free:
            raise UnknownSafehouseError(safehouse_id)
        if witness_id not in self.witnesses:
            raise UnknownWitnessError(witness_id)
        if not self.free[safehouse_id]:
            raise SafehouseOccupiedError(f"{safehouse_id} is occupied")
        stay = Stay(safehouse_id, witness_id, on, on + timedelta(days=nights))
        self.stays.append(stay)
        self.free[safehouse_id] = False
        return stay

    def check_out(self, safehouse_id, on):
        if safehouse_id not in self.free:
            raise UnknownSafehouseError(safehouse_id)
        for stay in self.stays:
            if stay.safehouse_id == safehouse_id and stay.checked_out is None:
                stay.checked_out = on
                self.free[safehouse_id] = True
                return stay
        raise NoOpenStayError(f"nobody is staying at {safehouse_id}")
'''

_WITNESS_REPLAY = r'''program = Program()
for house in safehouses:
    program.add_safehouse(house)
for witness_id, name in witnesses:
    program.add_witness(Witness(witness_id, name))
'''

_WITNESS_TEST_PROGRAM = r'''from datetime import timedelta as _td
_p = Program()
for _h in safehouses:
    _p.add_safehouse(_h)
for _wid, _nm in witnesses:
    _p.add_witness(Witness(_wid, _nm))
_h0, _h1 = safehouses[0], safehouses[1]
_w0, _w1 = witnesses[0][0], witnesses[1][0]
_day = events[0]["on"]
'''

_DECODE = r'''def decode(text, shift):
    table = {ALPHABET[i]: ALPHABET[(i - shift) % 26] for i in range(26)}
    return "".join([table.get(ch, ch) for ch in text])
'''

_DECODE_TEST = r'''_abc = "abcdefghijklmnopqrstuvwxyz"
def _plain(text, shift):
    return "".join(_abc[(_abc.index(c) - shift) % 26] if c in _abc else c for c in text)
_msgs = [_plain(_c["text"], _c["shift"]) for _c in postcards]
'''

_TO_TIME = r'''from datetime import datetime

def to_time(stamp):
    day, clock = stamp.split(" ")
    year, month, date_num = day.split("-")
    hour, minute = clock.split(":")
    return datetime(int(year), int(month), int(date_num), int(hour), int(minute))
'''

_TIMELINE_TEST = r'''from datetime import datetime as _dt
def _t(s):
    return _dt(int(s[0:4]), int(s[5:7]), int(s[8:10]), int(s[11:13]), int(s[14:16]))
_ord = sorted(events, key=lambda e: _t(e[0]))
'''


CASES = [
    # ================================================================== 1 (Q6)
    {
        "id": "smugglers-manifest",
        "tier": "medium",
        "title": "The Smuggler's Manifest",
        "teaser": "A cargo ship, a typed manifest, and one crate that weighs too much.",
        "skills": ["text", "lists", "records", "functions", "forensic-text"],
        "story": "The cargo ship **Sea Sparrow** docked at midnight. Customs suspects one crate is hiding something, but the captain's manifest is a mess: a single block of text, typed in a hurry, with stray spaces everywhere.\n\nThe manifest is in the variable `manifest`. The first line is the **header** (the column names). Every other line is one crate, with values separated by commas. The scales team has already weighed every crate: compare `declared_kg` (what the captain wrote) with `weighed_kg` (what the scales say).\n\nRule of the docks: no `csv` module on this job. Use `split`, `strip` and a loop.",
        "suspects": [
            {"name": "the captain", "note": "Typed the manifest himself."},
            {"name": "the loading crew", "note": "Packed the crates at the last port."},
            {"name": "the shipping agent", "note": "Paid in cash, asked for no receipt."},
        ],
        "variants": [
            'manifest = """\n crate, contents ,origin,declared_kg ,weighed_kg\nC-101,Tea leaves,Kolkata,120,120\n C-102 , Cashew nuts ,Kochi, 80,80\nC-103,Silk scarves,Varanasi,45,62\nC-104,  Brass lamps,Moradabad,150 ,150\nC-105,Coffee beans,Chikmagalur,95,95\n\n"""\n',
            'manifest = """\ncrate ,contents,origin, declared_kg,weighed_kg\nS-710,Rubber sheets,Kottayam,200,200\nS-711,Marble tiles,Makrana,300,300\n S-712, Saffron ,Srinagar,12,12\nS-713,Carpets,Bhadohi , 90,90\nS-714,Mango pulp,Ratnagiri,140,171\nS-715,Jute bags,Kolkata,60,60\n\n"""\n',
            'manifest = """\n  crate,contents , origin,declared_kg,weighed_kg  \nN-01,Olive oil,Piraeus,110,138\nN-02,Leather jackets, Istanbul,70,70\n N-03 , Dates ,Muscat,85, 85\nN-04,Glass beads,Murano,25,25\n\n"""\n',
        ],
        "steps": [
            {
                "question": "Write `load_manifest(text)`. It returns a **list of dicts**, one dict per crate, using the header words as keys.\n\n- Skip blank lines.\n- Strip the spaces around every header word and every value.\n- Convert `declared_kg` and `weighed_kg` to `int`.\n\nThen store `crates = load_manifest(manifest)`.",
                "starter": r'''def load_manifest(text):
    rows = []
    # 1. split the text into lines and keep only the non-blank ones
    # 2. the first line is the header: split it at the commas
    # 3. every other line becomes a dict: header word -> value
    return rows

crates = load_manifest(manifest)
print(len(crates), "crates on board")
for crate in crates:
    print(crate)
''',
                "solution": _LOAD_MANIFEST + r'''
crates = load_manifest(manifest)
print(len(crates), "crates on board")
for crate in crates:
    print(crate)
''',
                "tests": _MANIFEST_PARSE + r'''_got = load_manifest(manifest)
assert isinstance(_got, list), f"load_manifest should return a list, but it returned {type(_got).__name__}"
assert len(_got) == len(_exp_rows), f"the manifest lists {len(_exp_rows)} crates (blank lines don't count), but your list has {len(_got)}"
assert isinstance(_got[0], dict), "each crate should be a dict, like {'crate': 'C-101', ...}"
assert sorted(_got[0].keys()) == sorted(_head), f"the keys should be the header words without spaces: {_head}, got {list(_got[0].keys())}"
assert isinstance(_got[0]["declared_kg"], int) and isinstance(_got[0]["weighed_kg"], int), "convert declared_kg and weighed_kg to whole numbers with int()"
for _i in range(len(_exp_rows)):
    assert _got[_i] == _exp_rows[_i], f"crate {_i + 1} should be {_exp_rows[_i]}, got {_got[_i]}"
assert crates == _exp_rows, "store the result: crates = load_manifest(manifest)"''',
                "tips": [
                    "`text.strip().split(\"\\n\")` gives the lines. Keep a line only if `line.strip() != \"\"`. The first kept line is the header; `lines[1:]` are the crates.",
                    "For each crate line: `values = line.split(\",\")`, then `for i in range(len(header)): row[header[i]] = values[i].strip()`. Finally `row[\"declared_kg\"] = int(row[\"declared_kg\"])`, and the same for `weighed_kg`.",
                ],
                "reveal": "The manifest is finally readable: every crate, every number, in neat records. Now the scales can talk.",
            },
            {
                "question": "Find the contraband. Store in `contraband` the `crate` code of the one crate whose `weighed_kg` is different from its `declared_kg`, and in `extra_kg` the difference (`weighed_kg - declared_kg`).\n\nThen build `alert`, exactly like `ALERT: C-103 (Silk scarves from Varanasi) is 17 kg off`, and print it.",
                "starter": _LOAD_MANIFEST + r'''
crates = load_manifest(manifest)

contraband = None
extra_kg = 0
# loop over crates here

alert = ...
print(alert)
''',
                "solution": _LOAD_MANIFEST + r'''
crates = load_manifest(manifest)

contraband = None
extra_kg = 0
for crate in crates:
    if crate["weighed_kg"] != crate["declared_kg"]:
        contraband = crate["crate"]
        extra_kg = crate["weighed_kg"] - crate["declared_kg"]
        contents = crate["contents"]
        origin = crate["origin"]

alert = f"ALERT: {contraband} ({contents} from {origin}) is {extra_kg} kg off"
print(alert)
''',
                "tests": _MANIFEST_PARSE + r'''_bad = [_r for _r in _exp_rows if _r["declared_kg"] != _r["weighed_kg"]][0]
_extra = _bad["weighed_kg"] - _bad["declared_kg"]
assert contraband == _bad["crate"], f"on this manifest the odd crate is {_bad['crate']!r}, your code says {contraband!r}"
assert extra_kg == _extra, f"extra_kg should be {_extra}, got {extra_kg!r}"
_alert = f"ALERT: {_bad['crate']} ({_bad['contents']} from {_bad['origin']}) is {_extra} kg off"
assert alert == _alert, f"alert should be {_alert!r}, got {alert!r}"
assert _alert in __output__, "print the alert"''',
                "tips": [
                    "Loop with `for crate in crates:` and test `crate[\"weighed_kg\"] != crate[\"declared_kg\"]`. Inside that `if`, remember the crate's code, contents and origin.",
                    'Inside the `if`: `contraband = crate["crate"]` and `extra_kg = crate["weighed_kg"] - crate["declared_kg"]`. After the loop: `alert = f"ALERT: {contraband} ({contents} from {origin}) is {extra_kg} kg off"`.',
                ],
                "reveal": "Customs pried the crate open. Under a layer of legitimate goods: a false bottom packed with stolen antique coins.",
            },
        ],
        "closing": "Case closed. The shipping agent had paid the crew to add one heavy surprise to one crate. A readable manifest and an honest scale were all it took.",
    },
    # ================================================================== 2 (Q9)
    {
        "id": "evidence-room",
        "tier": "medium",
        "title": "Evidence Room v0",
        "teaser": "The Bureau's evidence room runs on paper slips. Time to build it a system.",
        "skills": ["lists", "records", "classes"],
        "story": "The evidence room in the basement has run on paper slips for thirty years. Last week a slip went missing and a whole case nearly collapsed. The Chief wants a proper system, and she wants it written as a **class**.\n\nEach item of evidence is a dict with a `tag`, a `description` and the `case` it belongs to. The current room's name is in `room_name` and its items are in the list `evidence`.\n\nToday's paperwork: the item with tag `released` goes back to its owner, and the prosecutor is asking about everything that matches the word in `query`.",
        "suspects": [
            {"name": "the old clerk", "note": "Knows every slip by heart. Retiring next month."},
            {"name": "the defence lawyer", "note": "Would love a piece of evidence to disappear."},
        ],
        "variants": [
            'room_name = "Room 12B"\nevidence = [\n    {"tag": "E-01", "description": "Muddy boot print", "case": "Harbour Fire"},\n    {"tag": "E-02", "description": "Leather glove, left hand", "case": "Museum Break-in"},\n    {"tag": "E-03", "description": "Burnt matchbox", "case": "Harbour Fire"},\n    {"tag": "E-04", "description": "Wool glove with paint", "case": "Museum Break-in"},\n    {"tag": "E-05", "description": "Broken phone", "case": "Taxi Robbery"},\n    {"tag": "E-06", "description": "Museum floor plan", "case": "Museum Break-in"},\n    {"tag": "E-07", "description": "Petrol can", "case": "Harbour Fire"},\n]\nreleased = "E-04"\nquery = "GLOVE"\n',
            'room_name = "Vault 3"\nevidence = [\n    {"tag": "K-11", "description": "Brass key on a red ribbon", "case": "Bank Job"},\n    {"tag": "K-12", "description": "Phone with cracked screen", "case": "Market Pickpocket"},\n    {"tag": "K-13", "description": "Spare car key", "case": "Bank Job"},\n    {"tag": "K-14", "description": "Keyring with 3 keys", "case": "Market Pickpocket"},\n    {"tag": "K-15", "description": "Stolen wallet", "case": "Market Pickpocket"},\n    {"tag": "K-16", "description": "Bank teller\'s badge", "case": "Bank Job"},\n]\nreleased = "K-16"\nquery = "key"\n',
            'room_name = "Locker Room A"\nevidence = [\n    {"tag": "P-1", "description": "Train ticket to Chennai", "case": "Express Swindle"},\n    {"tag": "P-2", "description": "Fake passport", "case": "Airport Smuggling"},\n    {"tag": "P-3", "description": "Second train ticket", "case": "Express Swindle"},\n    {"tag": "P-4", "description": "Passport photo strip", "case": "Airport Smuggling"},\n    {"tag": "P-5", "description": "Customs form", "case": "Airport Smuggling"},\n    {"tag": "P-6", "description": "Ticket stub, platform 4", "case": "Express Swindle"},\n    {"tag": "P-7", "description": "Luggage tag", "case": "Airport Smuggling"},\n]\nreleased = "P-1"\nquery = "Ticket"\n',
        ],
        "steps": [
            {
                "question": "Write the class `EvidenceRoom`:\n\n- `__init__(self, name)` stores the name and starts an **empty list** of items.\n- `add(self, item)` adds an item dict.\n- `remove(self, tag)` removes the item with that tag.\n- `find(self, query)` returns the items whose `description` contains `query`, **ignoring upper/lower case**.\n- `count(self)` returns the number of items.",
                "starter": r'''class EvidenceRoom:
    ...  # your code here

room = EvidenceRoom(room_name)
for item in evidence:
    room.add(item)
print(room.name, "holds", room.count(), "items")
''',
                "solution": _EVIDENCE_ROOM + r'''
room = EvidenceRoom(room_name)
for item in evidence:
    room.add(item)
print(room.name, "holds", room.count(), "items")
print("matching", query, ":", [i["tag"] for i in room.find(query)])
''',
                "tests": r'''_r = EvidenceRoom(room_name)
assert _r.name == room_name, f"room.name should be {room_name!r}, got {_r.name!r}"
assert _r.count() == 0, f"a new room should be empty, but count() gave {_r.count()!r}"
for _it in evidence:
    _r.add(_it)
assert _r.count() == len(evidence), f"after adding {len(evidence)} items, count() should be {len(evidence)}, got {_r.count()!r}"
_exp = [_it for _it in evidence if query.lower() in _it["description"].lower()]
_got = _r.find(query)
assert _got == _exp, f"find({query!r}) should return the items tagged {[e['tag'] for e in _exp]}, got {_got!r}"
assert _r.find(query.swapcase()) == _exp, "find should ignore upper/lower case: lowercase both the query and the description"
assert _r.find("zz-nothing-zz") == [], "find should return an empty list when nothing matches"
_r.remove(released)
assert _r.count() == len(evidence) - 1, f"after remove({released!r}) the room should hold {len(evidence) - 1} items, got {_r.count()!r}"
assert all(_it["tag"] != released for _it in _r.find("")), f"after remove({released!r}) that item must be gone"
_r2 = EvidenceRoom("Spare room")
assert _r2.count() == 0, "each room needs its own list: create it in __init__ with self.items = []"''',
                "tips": [
                    "In `__init__`: `self.name = name` and `self.items = []`. `add` is `self.items.append(item)` and `count` is `len(self.items)`.",
                    'For `remove`, rebuild the list: `self.items = [i for i in self.items if i["tag"] != tag]`. For `find`: `q = query.lower()` then `return [i for i in self.items if q in i["description"].lower()]`.',
                ],
                "reveal": "The evidence room has a system at last. The old clerk tries it once, frowns, then smiles.",
            },
            {
                "question": "Use the class. Build a room from `evidence`, then:\n\n1. Remove the `released` item.\n2. Store in `matches` the **tags** of the items that match `query`.\n3. Store in `left` how many items remain.\n4. Store in `busiest` the name of the case with the most items still in the room.",
                "starter": _EVIDENCE_ROOM + r'''
room = EvidenceRoom(room_name)
for item in evidence:
    room.add(item)

# 1. release the item
matches = []      # 2. tags matching query
left = 0          # 3. items left
busiest = None    # 4. case with the most items

print(matches, left, busiest)
''',
                "solution": _EVIDENCE_ROOM + r'''
room = EvidenceRoom(room_name)
for item in evidence:
    room.add(item)

room.remove(released)
matches = [item["tag"] for item in room.find(query)]
left = room.count()

per_case = {}
for item in room.items:
    per_case[item["case"]] = per_case.get(item["case"], 0) + 1
busiest = max(per_case, key=lambda case: per_case[case])

print(matches, left, busiest)
''',
                "tests": r'''_kept = [_it for _it in evidence if _it["tag"] != released]
_exp = [_it["tag"] for _it in _kept if query.lower() in _it["description"].lower()]
assert matches == _exp, f"after releasing {released!r}, the tags matching {query!r} are {_exp}, got {matches!r}"
assert left == len(_kept), f"left should be {len(_kept)}, got {left!r}"
_counts = {}
for _it in _kept:
    _counts[_it["case"]] = _counts.get(_it["case"], 0) + 1
_best = max(_counts, key=lambda c: _counts[c])
assert busiest == _best, f"the busiest case still in the room is {_best!r} ({_counts[_best]} items), got {busiest!r}"''',
                "tips": [
                    "`room.remove(released)` first. Then `room.find(query)` gives item dicts: take the `\"tag\"` of each one.",
                    'Count items per case in a dict: `per_case[item["case"]] = per_case.get(item["case"], 0) + 1` for each `item in room.items`. Then `busiest = max(per_case, key=lambda case: per_case[case])`.',
                ],
                "reveal": "The prosecutor gets a clean list, the owner gets their item back, and the busiest case gets a second shelf.",
            },
        ],
        "closing": "Case closed. The evidence room is digital, and nothing goes missing quietly any more. The defence lawyer looks disappointed.",
    },
    # ================================================================== 3 (Q11)
    {
        "id": "surveillance-hours",
        "tier": "medium",
        "title": "Surveillance Hours",
        "teaser": "Overtime claims from a long stakeout. Some of them don't add up.",
        "skills": ["errors", "classes"],
        "story": "A three-week stakeout is over and the overtime claims have arrived. Accounts sends them back with one note: *\"Half of these are nonsense.\"*\n\nThe claims are in `shift_log`, a list of dicts with `officer`, `location`, `minutes` and `night` (True or False). Some minutes were typed as text, some are missing, some are impossible.\n\nBureau rules:\n- A shift is **valid** if `int(minutes)` works and gives a number from **1 to 720** (12 hours).\n- Credited hours are `minutes / 60`, times **1.5** for a night shift, rounded to 2 decimals.",
        "suspects": [
            {"name": "the officer with the biggest claim", "note": "Says they barely slept."},
            {"name": "the accounts clerk", "note": "Has rejected every claim this year."},
        ],
        "variants": [
            'shift_log = [\n    {"officer": "Sgt. Kapoor", "location": "Dock 4", "minutes": 240, "night": True},\n    {"officer": "Det. Okafor", "location": "Hotel lobby", "minutes": 180, "night": False},\n    {"officer": "Det. Okafor", "location": "Dock 4", "minutes": "??", "night": True},\n    {"officer": "Insp. Lindqvist", "location": "Rooftop", "minutes": "300", "night": True},\n    {"officer": "Sgt. Kapoor", "location": "Bus stand", "minutes": 900, "night": False},\n    {"officer": "Det. Okafor", "location": "Cafe", "minutes": 120, "night": True},\n    {"officer": "Insp. Lindqvist", "location": "Rooftop", "night": False},\n]\n',
            'shift_log = [\n    {"officer": "Det. Banerjee", "location": "Jewellery shop", "minutes": 200, "night": False},\n    {"officer": "Det. Banerjee", "location": "Jewellery shop", "minutes": 160, "night": True},\n    {"officer": "Sgt. Haddad", "location": "Parking lot", "minutes": 360, "night": False},\n    {"officer": "Sgt. Haddad", "location": "Parking lot", "minutes": -30, "night": True},\n    {"officer": "Officer Tanaka", "location": "Pier", "minutes": "abc", "night": False},\n    {"officer": "Officer Tanaka", "location": "Pier", "minutes": "220", "night": False},\n]\n',
            'shift_log = [\n    {"officer": "Insp. Moreau", "location": "Casino", "minutes": 720, "night": True},\n    {"officer": "Det. Sharma", "location": "Casino", "minutes": 721, "night": True},\n    {"officer": "Det. Sharma", "location": "Station", "minutes": 400, "night": True},\n    {"officer": "Det. Sharma", "location": "Station", "minutes": 300, "night": False},\n    {"officer": "Insp. Moreau", "location": "Bridge", "minutes": None, "night": False},\n    {"officer": "Det. Sharma", "location": "Mall", "minutes": "90", "night": False},\n]\n',
        ],
        "steps": [
            {
                "question": "Complete the `Stakeout` class:\n\n- A **property** `hours`: `minutes / 60`, times 1.5 if `night` is True, rounded to 2 decimals.\n- A **class method** `from_dict(cls, data)` that builds a `Stakeout` from one dict of `shift_log`, converting `minutes` with `int()`.\n- A **static method** `is_valid_shift(data)` that returns True or False following the Bureau rules. It must **never raise**, whatever it is given (even `None`).",
                "starter": r'''class Stakeout:
    def __init__(self, officer, location, minutes, night):
        self.officer = officer
        self.location = location
        self.minutes = minutes
        self.night = night

    # hours (property), from_dict (classmethod), is_valid_shift (staticmethod)

for data in shift_log:
    if Stakeout.is_valid_shift(data):
        s = Stakeout.from_dict(data)
        print(s.officer, s.location, s.hours)
    else:
        print("REJECTED:", data)
''',
                "solution": _STAKEOUT + r'''
for data in shift_log:
    if Stakeout.is_valid_shift(data):
        s = Stakeout.from_dict(data)
        print(s.officer, s.location, s.hours)
    else:
        print("REJECTED:", data)
''',
                "tests": r'''def _valid(d):
    try:
        return 1 <= int(d["minutes"]) <= 720
    except (KeyError, TypeError, ValueError):
        return False
assert isinstance(getattr(Stakeout, "hours", None), property), "hours should be a @property, so you read it as s.hours with no brackets"
for _d in shift_log:
    try:
        _res = Stakeout.is_valid_shift(_d)
    except Exception as _e:
        raise AssertionError(f"is_valid_shift({_d}) must never raise, but it raised {type(_e).__name__}")
    assert _res is _valid(_d), f"is_valid_shift({_d}) should be {_valid(_d)}, got {_res!r}"
for _bad in (None, "abc", {}, {"minutes": None}, {"minutes": 0}):
    try:
        _res = Stakeout.is_valid_shift(_bad)
    except Exception as _e:
        raise AssertionError(f"is_valid_shift({_bad!r}) must never raise, but it raised {type(_e).__name__}")
    assert _res is False, f"is_valid_shift({_bad!r}) should be False, got {_res!r}"
for _d in shift_log:
    if _valid(_d):
        _s = Stakeout.from_dict(_d)
        assert isinstance(_s, Stakeout), "from_dict should return a Stakeout (use cls(...))"
        assert _s.officer == _d["officer"] and _s.location == _d["location"], "from_dict should copy officer and location"
        assert _s.minutes == int(_d["minutes"]), f"from_dict should convert minutes with int(): expected {int(_d['minutes'])}, got {_s.minutes!r}"
        _exp = round(int(_d["minutes"]) / 60 * (1.5 if _d["night"] else 1.0), 2)
        assert abs(_s.hours - _exp) < 0.006, f"{_d['minutes']} minutes with night={_d['night']} should give {_exp} hours, got {_s.hours!r}"''',
                "tips": [
                    "`hours`: `rate = 1.5 if self.night else 1.0`, then `return round(self.minutes / 60 * rate, 2)`. `from_dict`: `return cls(data[\"officer\"], data[\"location\"], int(data[\"minutes\"]), data[\"night\"])`.",
                    "`is_valid_shift`: put `return 1 <= int(data[\"minutes\"]) <= 720` inside `try:`, and `except (KeyError, TypeError, ValueError): return False`.",
                ],
                "reveal": "The impossible claims bounce off the validator. What is left is honest work, and one officer did a lot of it.",
            },
            {
                "question": "Total the **valid** shifts. Store in `totals` a dict: officer → total credited hours (rounded to 2 decimals), in `skipped` the number of invalid claims, and in `top_officer` the officer with the most hours.",
                "starter": _STAKEOUT + r'''
totals = {}
skipped = 0
# loop over shift_log here

top_officer = ...
print(totals, skipped, top_officer)
''',
                "solution": _STAKEOUT + r'''
totals = {}
skipped = 0
for data in shift_log:
    if not Stakeout.is_valid_shift(data):
        skipped += 1
        continue
    s = Stakeout.from_dict(data)
    totals[s.officer] = round(totals.get(s.officer, 0) + s.hours, 2)

top_officer = max(totals, key=lambda name: totals[name])
print(totals, skipped, top_officer)
''',
                "tests": r'''def _valid(d):
    try:
        return 1 <= int(d["minutes"]) <= 720
    except (KeyError, TypeError, ValueError):
        return False
_tot = {}
_skip = 0
for _d in shift_log:
    if not _valid(_d):
        _skip += 1
        continue
    _h = round(int(_d["minutes"]) / 60 * (1.5 if _d["night"] else 1.0), 2)
    _tot[_d["officer"]] = _tot.get(_d["officer"], 0) + _h
assert skipped == _skip, f"there are {_skip} invalid claims, skipped is {skipped!r}"
assert isinstance(totals, dict) and sorted(totals) == sorted(_tot), f"totals should have one entry per officer with a valid shift: {sorted(_tot)}, got {totals!r}"
for _name in _tot:
    assert abs(totals[_name] - _tot[_name]) < 0.02, f"{_name} should have {round(_tot[_name], 2)} hours, got {totals[_name]!r}"
_top = max(_tot, key=lambda n: _tot[n])
assert top_officer == _top, f"the officer with the most hours is {_top!r}, got {top_officer!r}"''',
                "tips": [
                    "Inside the loop: if the shift is not valid, add 1 to `skipped` and `continue`. Otherwise `s = Stakeout.from_dict(data)`.",
                    "`totals[s.officer] = round(totals.get(s.officer, 0) + s.hours, 2)`. After the loop, `top_officer = max(totals, key=lambda name: totals[name])`.",
                ],
                "reveal": "Accounts approves the valid claims without a word. The top officer gets a thank-you note and a long weekend.",
            },
        ],
        "closing": "Case closed. Clean rules in one class: a property for the maths, a class method to load, a static method that never panics.",
    },
    # ================================================================== 4 (Q12)
    {
        "id": "evidence-types",
        "tier": "medium",
        "title": "Evidence Types",
        "teaser": "Weapons, documents and footage: one report, three kinds of exhibit.",
        "skills": ["functional", "classes", "inheritance"],
        "story": "The court wants one printed list of every exhibit in the **Gallery Theft** trial. But a candlestick, a torn will and an hour of camera footage are described in very different ways.\n\nThe exhibits are in `exhibits`, a list of tuples: `(kind, title, tag, extra)`. The `extra` value depends on the kind:\n- `Weapon`: what it is made of\n- `Document`: number of pages\n- `Footage`: length in minutes\n\nThe Bureau's answer: one abstract base class, three subclasses, and one function that treats them all the same way.",
        "suspects": [
            {"name": "the gallery owner", "note": "Insured the paintings last month."},
            {"name": "the night watchman", "note": "Claims the camera was off."},
        ],
        "variants": [
            'exhibits = [\n    ("Weapon", "Brass candlestick", "W-1", "brass"),\n    ("Document", "Torn will", "D-1", 3),\n    ("Footage", "Lobby camera", "F-1", 42),\n    ("Document", "Train ticket", "D-2", 1),\n]\n',
            'exhibits = [\n    ("Footage", "Car park camera", "F-7", 95),\n    ("Weapon", "Cricket bat", "W-3", "willow"),\n    ("Weapon", "Rope", "W-4", "jute"),\n    ("Document", "Insurance policy", "D-9", 12),\n]\n',
            'exhibits = [\n    ("Document", "Gallery floor plan", "D-5", 2),\n    ("Footage", "Rooftop drone clip", "F-2", 6),\n    ("Weapon", "Umbrella", "W-8", "steel"),\n    ("Footage", "Staff door camera", "F-3", 120),\n    ("Document", "Love letter", "D-6", 4),\n]\n',
        ],
        "steps": [
            {
                "question": "Build the hierarchy:\n\n- `Evidence(ABC)` with `__init__(self, title, tag)` that stores both and sets `logged = True`, plus **abstract** methods `category()` and `describe()`.\n- `Weapon(title, tag, material)`, `Document(title, tag, pages)` and `Footage(title, tag, minutes)`. Each `category()` returns the class name, and `describe()` returns exactly:\n  - `[Weapon] W-1 Brass candlestick, made of brass`\n  - `[Document] D-1 Torn will, 3 pages`\n  - `[Footage] F-1 Lobby camera, 42 min`",
                "starter": r'''from abc import ABC, abstractmethod

class Evidence(ABC):
    def __init__(self, title, tag):
        ...
    # abstract category() and describe()

class Weapon(Evidence):
    ...

class Document(Evidence):
    ...

class Footage(Evidence):
    ...

kinds = {"Weapon": Weapon, "Document": Document, "Footage": Footage}
for kind, title, tag, extra in exhibits:
    print(kinds[kind](title, tag, extra).describe())
''',
                "solution": _EVIDENCE_TYPES + r'''
kinds = {"Weapon": Weapon, "Document": Document, "Footage": Footage}
for kind, title, tag, extra in exhibits:
    print(kinds[kind](title, tag, extra).describe())
''',
                "tests": r'''try:
    Evidence("x", "y")
    raise AssertionError("Evidence must be abstract: inherit from ABC and mark category() and describe() with @abstractmethod")
except TypeError:
    pass
for _cls in ("Weapon", "Document", "Footage"):
    assert issubclass(globals()[_cls], Evidence), f"{_cls} should inherit from Evidence"
_kinds = {"Weapon": Weapon, "Document": Document, "Footage": Footage}
for _kind, _title, _tag, _extra in exhibits:
    _obj = _kinds[_kind](_title, _tag, _extra)
    assert _obj.title == _title and _obj.tag == _tag, f"{_kind}: store title and tag (call super().__init__(title, tag))"
    assert _obj.logged is True, f"{_kind}: logged should start as True"
    assert _obj.category() == _kind, f"{_kind}.category() should return {_kind!r}, got {_obj.category()!r}"
    _exp = {
        "Weapon": f"[Weapon] {_tag} {_title}, made of {_extra}",
        "Document": f"[Document] {_tag} {_title}, {_extra} pages",
        "Footage": f"[Footage] {_tag} {_title}, {_extra} min",
    }[_kind]
    assert _obj.describe() == _exp, f"describe() should return {_exp!r}, got {_obj.describe()!r}"''',
                "tips": [
                    "`Evidence.__init__` sets `self.title`, `self.tag` and `self.logged = True`. Mark both methods with `@abstractmethod` and give them `...` as the body.",
                    'Each subclass: `def __init__(self, title, tag, material): super().__init__(title, tag); self.material = material`, `def category(self): return "Weapon"`, and `def describe(self): return f"[{self.category()}] {self.tag} {self.title}, made of {self.material}"`.',
                ],
                "reveal": "Three very different exhibits, one shared contract. And nobody can file a vague \"Evidence\" with no kind at all.",
            },
            {
                "question": "Write `print_all(items)`: it prints each item's `describe()` on its own line and **returns the list of lines** it printed. Then build `items` (one object per row of `exhibits`, in order) and store `lines = print_all(items)`.",
                "starter": _EVIDENCE_TYPES + r'''
def print_all(items):
    ...

items = []
# build one object per row of exhibits

lines = print_all(items)
''',
                "solution": _EVIDENCE_TYPES + r'''
def print_all(items):
    lines = [item.describe() for item in items]
    for line in lines:
        print(line)
    return lines

kinds = {"Weapon": Weapon, "Document": Document, "Footage": Footage}
items = [kinds[kind](title, tag, extra) for kind, title, tag, extra in exhibits]

lines = print_all(items)
''',
                "tests": r'''assert len(items) == len(exhibits), f"items should hold {len(exhibits)} objects, one per exhibit, got {len(items)}"
assert [_i.tag for _i in items] == [_e[2] for _e in exhibits], "build items in the same order as exhibits"
assert [_i.category() for _i in items] == [_e[0] for _e in exhibits], "each row's kind decides the class: Weapon, Document or Footage"
_exp = [_i.describe() for _i in items]
assert lines == _exp, f"print_all should return the list of lines {_exp}, got {lines!r}"
for _line in _exp:
    assert _line in __output__, f"print_all should print {_line!r}"
assert print_all([]) == [], "print_all([]) should return an empty list"''',
                "tips": [
                    "`print_all`: `lines = [item.describe() for item in items]`, print each line, then `return lines`. One call, three behaviours: that is polymorphism.",
                    'A dict maps the kind to the class: `kinds = {"Weapon": Weapon, "Document": Document, "Footage": Footage}`. Then `items = [kinds[kind](title, tag, extra) for kind, title, tag, extra in exhibits]`.',
                ],
                "reveal": "The court clerk reads the list aloud. When she gets to the footage, the night watchman goes very quiet.",
            },
        ],
        "closing": "Case closed. The lobby camera was never off: the footage shows the watchman carrying out a painting \"for cleaning\".",
    },
    # ================================================================== 5 (Q13)
    {
        "id": "counterfeit-notes",
        "tier": "medium",
        "title": "The Counterfeit Notes",
        "teaser": "A suitcase of cash in three currencies. One note was never printed by any bank.",
        "skills": ["identity", "classes", "dunders"],
        "story": "Police stopped a courier at the airport with a suitcase full of cash in three currencies. Every note was logged in `notes` as `(serial, amount, currency)`, with the amount written as text so no rupee or cent gets lost.\n\nMoney is never a float at the Bureau. You will build a `Money` value object on top of `Decimal` that refuses to mix currencies, because adding rupees to dollars is how mistakes, and crimes, hide.\n\nThe central bank also sent `denominations`: the note values that really exist in each currency.",
        "suspects": [
            {"name": "the courier", "note": "Says he was just carrying a suitcase for a friend."},
            {"name": "the 'friend'", "note": "Runs a printing shop."},
        ],
        "variants": [
            'notes = [\n    ("A1201", "500", "INR"),\n    ("A1202", "200", "INR"),\n    ("B7730", "20", "USD"),\n    ("A1203", "500", "INR"),\n    ("B7731", "25", "USD"),\n    ("C0410", "50", "EUR"),\n    ("B7732", "100", "USD"),\n]\ndenominations = {\n    "INR": ["10", "20", "50", "100", "200", "500"],\n    "USD": ["1", "5", "10", "20", "50", "100"],\n    "EUR": ["5", "10", "20", "50", "100", "200"],\n}\n',
            'notes = [\n    ("Q-88", "50", "USD"),\n    ("Q-89", "10", "USD"),\n    ("R-01", "300", "INR"),\n    ("S-17", "20", "EUR"),\n    ("R-02", "100", "INR"),\n    ("S-18", "200", "EUR"),\n    ("Q-90", "50", "USD"),\n]\ndenominations = {\n    "INR": ["10", "20", "50", "100", "200", "500"],\n    "USD": ["1", "5", "10", "20", "50", "100"],\n    "EUR": ["5", "10", "20", "50", "100", "200"],\n}\n',
            'notes = [\n    ("EU-5", "100", "EUR"),\n    ("EU-6", "10", "EUR"),\n    ("IN-1", "2000", "INR"),\n    ("US-3", "5", "USD"),\n    ("EU-7", "15", "EUR"),\n    ("IN-2", "50", "INR"),\n]\ndenominations = {\n    "INR": ["10", "20", "50", "100", "200", "500", "2000"],\n    "USD": ["1", "5", "10", "20", "50", "100"],\n    "EUR": ["5", "10", "20", "50", "100", "200"],\n}\n',
        ],
        "steps": [
            {
                "question": "Build `Money(amount, currency)`, where `amount` is a `Decimal`:\n\n- `__repr__` gives `Money(15.75, USD)`; `__str__` gives `15.75 USD`.\n- `__eq__` and `__hash__` use amount **and** currency.\n- `+` and `-` return a new `Money`.\n- `<`, `<=`, `>`, `>=` compare amounts.\n- `__bool__` is True when the amount is above 0.\n- Mixing currencies in `+ - < <= > >=` raises `ValueError`.",
                "starter": r'''from decimal import Decimal

class Money:
    ...  # your code here

serial, amount, currency = notes[0]
first = Money(Decimal(amount), currency)
print(repr(first), first + first)
''',
                "solution": _MONEY + r'''
serial, amount, currency = notes[0]
first = Money(Decimal(amount), currency)
print(repr(first), first + first)
''',
                "tests": r'''from decimal import Decimal as _D
_by = {}
for _s, _a, _c in notes:
    if _D(_a) not in _by.setdefault(_c, []):
        _by[_c].append(_D(_a))
_cur = [_c for _c in _by if len(_by[_c]) >= 2][0]
_other = [_c for _c in _by if _c != _cur][0]
_small, _big = min(_by[_cur][:2]), max(_by[_cur][:2])
_m_small, _m_big = Money(_small, _cur), Money(_big, _cur)
_m_other = Money(_big, _other)
assert repr(_m_big) == f"Money({_big}, {_cur})", f"repr should look like Money({_big}, {_cur}), got {repr(_m_big)}"
assert str(_m_big) == f"{_big} {_cur}", f"str should look like '{_big} {_cur}', got {str(_m_big)!r}"
assert repr(_m_big + _m_small) == f"Money({_big + _small}, {_cur})", f"{_big} + {_small} {_cur} should be Money({_big + _small}, {_cur}), got {_m_big + _m_small!r}"
assert _m_big - _m_small == Money(_big - _small, _cur), f"{_big} - {_small} {_cur} should be Money({_big - _small}, {_cur})"
assert _m_big == Money(_big, _cur), "two Money objects with the same amount and currency should be equal"
assert _m_big != _m_other, "same amount in a different currency is not equal"
assert len({_m_big, Money(_big, _cur), _m_small}) == 2, "equal Money objects need equal hashes, so a set keeps only one of them"
assert _m_small < _m_big and _m_small <= _m_big and _m_big > _m_small and _m_big >= _m_small and _m_big >= Money(_big, _cur), "check the four comparisons < <= > >="
assert bool(_m_big) and not Money(_D("0"), _cur), "Money is True when the amount is above 0, False at 0"
for _name, _op in (("+", lambda: _m_big + _m_other), ("-", lambda: _m_big - _m_other), ("<", lambda: _m_big < _m_other),
                   ("<=", lambda: _m_big <= _m_other), (">", lambda: _m_big > _m_other), (">=", lambda: _m_big >= _m_other)):
    try:
        _op()
        raise AssertionError(f"{_cur} {_name} {_other} should raise ValueError: never mix currencies")
    except ValueError:
        pass''',
                "tips": [
                    "Write a helper `_check(self, other)` that raises `ValueError` when `self.currency != other.currency`, and call it first in `__add__`, `__sub__`, `__lt__`, `__le__`, `__gt__` and `__ge__`.",
                    '`__repr__` returns `f"Money({self.amount}, {self.currency})"`, `__eq__` compares `(self.amount, self.currency) == (other.amount, other.currency)`, `__hash__` returns `hash((self.amount, self.currency))` and `__bool__` returns `self.amount > 0`.',
                ],
                "reveal": "Rupees refuse to be added to dollars. The `Money` class is ready to count the suitcase.",
            },
            {
                "question": "Count the suitcase. Build `totals`: a dict from currency to a `Money` total of every note in that currency. Start each currency at `Money(Decimal(\"0\"), currency)` and add with `+`. Print each total.",
                "starter": _MONEY + r'''
totals = {}
# loop over notes here

for currency in totals:
    print(totals[currency])
''',
                "solution": _MONEY + r'''
totals = {}
for serial, amount, currency in notes:
    if currency not in totals:
        totals[currency] = Money(Decimal("0"), currency)
    totals[currency] = totals[currency] + Money(Decimal(amount), currency)

for currency in totals:
    print(totals[currency])
''',
                "tests": r'''from decimal import Decimal as _D
_exp = {}
for _s, _a, _c in notes:
    _exp[_c] = _exp.get(_c, _D("0")) + _D(_a)
assert isinstance(totals, dict) and sorted(totals) == sorted(_exp), f"totals should have one entry per currency: {sorted(_exp)}, got {totals!r}"
for _c in _exp:
    assert isinstance(totals[_c], Money), f"totals[{_c!r}] should be a Money object, got {totals[_c]!r}"
    assert totals[_c].amount == _exp[_c] and totals[_c].currency == _c, f"the {_c} total should be {_exp[_c]} {_c}, got {totals[_c]!r}"''',
                "tips": [
                    "Loop with `for serial, amount, currency in notes:`. If the currency is not in `totals` yet, start it at `Money(Decimal(\"0\"), currency)`.",
                    "`totals[currency] = totals[currency] + Money(Decimal(amount), currency)`. Your `__add__` does the rest.",
                ],
                "reveal": "The totals are exact to the last paisa and cent. Now: is every one of those notes real?",
            },
            {
                "question": "Spot the fake. Build `valid_notes`, a **set** of `Money` objects for every value in `denominations`. Then store in `fake` the serial number of the one note whose `Money` value is **not** in that set.",
                "starter": _MONEY + r'''
valid_notes = set()
# fill valid_notes from denominations

fake = None
# check every note

print("Fake note:", fake)
''',
                "solution": _MONEY + r'''
valid_notes = set()
for currency in denominations:
    for value in denominations[currency]:
        valid_notes.add(Money(Decimal(value), currency))

fake = None
for serial, amount, currency in notes:
    if Money(Decimal(amount), currency) not in valid_notes:
        fake = serial

print("Fake note:", fake)
''',
                "tests": r'''from decimal import Decimal as _D
_valid = {(_D(_v), _c) for _c in denominations for _v in denominations[_c]}
_fakes = [_s for _s, _a, _c in notes if (_D(_a), _c) not in _valid]
assert isinstance(valid_notes, set) and len(valid_notes) == len(_valid), f"valid_notes should be a set of {len(_valid)} Money objects, got {len(valid_notes)} items"
assert all(isinstance(_m, Money) for _m in valid_notes), "every item of valid_notes should be a Money object"
assert fake == _fakes[0], f"the fake note in this suitcase is {_fakes[0]!r}, your code says {fake!r}"''',
                "tips": [
                    "Two loops: `for currency in denominations:` and inside it `for value in denominations[currency]:`, then `valid_notes.add(Money(Decimal(value), currency))`.",
                    "`in` on a set uses your `__hash__` and `__eq__`: `if Money(Decimal(amount), currency) not in valid_notes: fake = serial`.",
                ],
                "reveal": "No bank has ever printed that note. The ink is still slightly wet.",
            },
        ],
        "closing": "Case closed. The 'friend' with the printing shop had been testing a new design. A value object that knows its own currency caught it in one line.",
    },
    # ================================================================== 6 (Q14)
    {
        "id": "evidence-locker",
        "tier": "medium",
        "title": "The Evidence Locker",
        "teaser": "Make the locker behave like a real Python container: len, in, [], for and print.",
        "skills": ["classes", "dunders"],
        "story": "The Bureau's lockers have a simple `Locker` class with `add` and `find`. Detectives complain that it feels clumsy: they want to write `len(locker)`, `\"L-02\" in locker`, `locker[\"L-02\"]` and `for item in locker`, the way they would with a list.\n\nThe locker's name is in `locker_name`, its items (dicts with `tag` and `description`) are in `locker_items`. The audit team also sent a `checklist` of tags that should be inside, and the prosecutor wants everything matching `query`.",
        "suspects": [
            {"name": "the locker attendant", "note": "Has the only key."},
            {"name": "the visiting auditor", "note": "Was alone with the locker for ten minutes."},
        ],
        "variants": [
            'locker_name = "Locker 7"\nlocker_items = [\n    {"tag": "L-01", "description": "Red silk scarf"},\n    {"tag": "L-02", "description": "Pawn shop receipt"},\n    {"tag": "L-03", "description": "Silver ring"},\n    {"tag": "L-04", "description": "Bus ticket, route 42"},\n    {"tag": "L-05", "description": "Second pawn receipt"},\n]\nchecklist = ["L-02", "L-06", "L-03", "L-09"]\nquery = "receipt"\n',
            'locker_name = "Locker 21"\nlocker_items = [\n    {"tag": "X-10", "description": "Laptop charger"},\n    {"tag": "X-11", "description": "USB stick, blue"},\n    {"tag": "X-12", "description": "Hotel key card"},\n    {"tag": "X-13", "description": "USB stick, black"},\n]\nchecklist = ["X-10", "X-11", "X-14"]\nquery = "USB"\n',
            'locker_name = "Cold Store 2"\nlocker_items = [\n    {"tag": "C-1", "description": "Frozen fish crate"},\n    {"tag": "C-2", "description": "Ice pick"},\n    {"tag": "C-3", "description": "Crate label, smudged"},\n    {"tag": "C-4", "description": "Thermometer"},\n    {"tag": "C-5", "description": "Glove with fish scales"},\n    {"tag": "C-6", "description": "Delivery note"},\n]\nchecklist = ["C-7", "C-2", "C-8", "C-6", "C-1"]\nquery = "Fish"\n',
        ],
        "steps": [
            {
                "question": "Add these dunder methods to `Locker`:\n\n- `__len__` (number of items) and `__bool__` (True when not empty)\n- `__contains__`: accepts an item dict **or** a tag string\n- `__iter__`: loops over the items\n- `__getitem__`: an index, a slice, or a tag string (raise `KeyError` for an unknown tag)\n- `__repr__` for developers (must contain `Locker`), `__str__` for users, like `Locker 7: 5 items`\n- `__call__(query)`: a shortcut for `find(query)`",
                "starter": _LOCKER_BASE + r'''
    # add the dunders here

locker = Locker(locker_name)
for item in locker_items:
    locker.add(item)
print(locker, len(locker))
''',
                "solution": _LOCKER_BASE + _LOCKER_DUNDERS + r'''
locker = Locker(locker_name)
for item in locker_items:
    locker.add(item)
print(locker, len(locker))
''',
                "tests": r'''_lk = Locker(locker_name)
assert len(_lk) == 0, "an empty locker should have len() 0"
assert not _lk, "an empty locker should count as False"
for _it in locker_items:
    _lk.add(_it)
assert len(_lk) == len(locker_items), f"len(locker) should be {len(locker_items)}, got {len(_lk)}"
assert bool(_lk) is True, "a locker with items should count as True"
_first, _last = locker_items[0], locker_items[-1]
assert _first in _lk, "`item in locker` should work with an item dict"
assert _first["tag"] in _lk, f"`{_first['tag']!r} in locker` should be True: in should also accept a tag string"
assert "NO-SUCH-TAG" not in _lk, "an unknown tag should not be in the locker"
assert [_i["tag"] for _i in _lk] == [_i["tag"] for _i in locker_items], "`for item in locker` should give every item, in order"
assert _lk[0] is _first and _lk[-1] is _last, "locker[0] and locker[-1] should work like a list"
assert _lk[1:3] == locker_items[1:3], "locker[1:3] should return a slice of the items"
assert _lk[_last["tag"]] is _last, f"locker[{_last['tag']!r}] should return the item with that tag"
try:
    _lk["NO-SUCH-TAG"]
    raise AssertionError("locker['NO-SUCH-TAG'] should raise KeyError")
except KeyError:
    pass
assert "Locker" in repr(_lk), f"repr(locker) should mention Locker, got {repr(_lk)!r}"
assert str(_lk) == f"{locker_name}: {len(locker_items)} items", f"str(locker) should be {locker_name + ': ' + str(len(locker_items)) + ' items'!r}, got {str(_lk)!r}"
_exp = [_i for _i in locker_items if query.lower() in _i["description"].lower()]
assert _lk(query) == _exp, f"locker({query!r}) should return the same as locker.find({query!r})"''',
                "tips": [
                    "`__len__` returns `len(self.items)`; `__iter__` returns `iter(self.items)`; `__call__` returns `self.find(query)`; `__str__` returns `f\"{self.name}: {len(self.items)} items\"`.",
                    '`__contains__`: `if isinstance(item, str): return any(i["tag"] == item for i in self.items)`, otherwise `return item in self.items`. `__getitem__`: ints and slices go to `self.items[key]`; for a string, loop and return the match, then `raise KeyError(key)`.',
                ],
                "reveal": "The locker now feels like a built-in list. The detectives stop complaining. Well, about that.",
            },
            {
                "question": "Run the audit with the new syntax. Store in `missing` the tags from `checklist` that are **not** in the locker (checklist order), and in `matches` the tags of the items that `locker(query)` returns. Print the locker with `print(locker)`.",
                "starter": _LOCKER_BASE + _LOCKER_DUNDERS + r'''
locker = Locker(locker_name)
for item in locker_items:
    locker.add(item)

missing = ...
matches = ...
print(locker)
print("missing:", missing)
print("matches:", matches)
''',
                "solution": _LOCKER_BASE + _LOCKER_DUNDERS + r'''
locker = Locker(locker_name)
for item in locker_items:
    locker.add(item)

missing = [tag for tag in checklist if tag not in locker]
matches = [item["tag"] for item in locker(query)]
print(locker)
print("missing:", missing)
print("matches:", matches)
''',
                "tests": r'''_tags = [_i["tag"] for _i in locker_items]
_miss = [_t for _t in checklist if _t not in _tags]
assert missing == _miss, f"the checklist tags not in the locker are {_miss}, got {missing!r}"
_m = [_i["tag"] for _i in locker_items if query.lower() in _i["description"].lower()]
assert matches == _m, f"locker({query!r}) matches the tags {_m}, got {matches!r}"
assert f"{locker_name}: {len(locker_items)} items" in __output__, "print(locker) should show the str() version, like 'Locker 7: 5 items'"''',
                "tips": [
                    "`tag not in locker` calls your `__contains__`, so a comprehension does it: `[tag for tag in checklist if tag not in locker]`.",
                    '`locker(query)` calls `__call__` and returns item dicts: `matches = [item["tag"] for item in locker(query)]`.',
                ],
                "reveal": "Items on the checklist are not in the locker. The auditor's ten minutes alone suddenly look very interesting.",
            },
        ],
        "closing": "Case closed. The missing items turned up in the auditor's briefcase. A locker that answers `in` honestly is hard to fool.",
    },
    # ================================================================== 7 (Q17)
    {
        "id": "bail-calculator",
        "tier": "medium",
        "title": "The Bail Calculator",
        "teaser": "Every charge has its own bail rule. One function must add them all up.",
        "skills": ["functional", "classes", "inheritance"],
        "story": "Night court is jammed. The judge has a pile of charges and a calculator that only does addition. She asks the Bureau for a program.\n\nThe charges are in `docket`, a dict from suspect name to a list of `(kind, amount)` pairs. The bail rules:\n- **Theft**: ₹5,000 flat, whatever was stolen.\n- **Fraud**: ₹10,000 plus 10% of the amount (`amount // 10`).\n- **Vandalism**: free if the damage is under ₹5,000, otherwise ₹2,000.\n- **ArmedRobbery**: a kind of Theft, so Theft's bail **plus** a ₹25,000 deposit.\n\nThe judge's one condition: no `isinstance` checks. Each charge must know its own bail.",
        "suspects": [
            {"name": "the defendants", "note": "All want to go home tonight."},
        ],
        "variants": [
            'docket = {\n    "Raj Malhotra": [("Theft", 12000), ("Vandalism", 3000)],\n    "Lena Fischer": [("Fraud", 400000)],\n    "Kofi Mensah": [("ArmedRobbery", 50000), ("Vandalism", 8000)],\n}\n',
            'docket = {\n    "Ananya Iyer": [("Fraud", 90000), ("Theft", 2000)],\n    "Diego Santos": [("ArmedRobbery", 10000), ("ArmedRobbery", 5000)],\n    "Mei Lin": [("Vandalism", 5000), ("Theft", 700)],\n}\n',
            'docket = {\n    "Sameer Khan": [("Vandalism", 4999), ("Vandalism", 12000), ("Theft", 400)],\n    "Olga Petrova": [("Fraud", 120000)],\n    "Tunde Bello": [("Theft", 9000), ("Fraud", 30000)],\n}\n',
        ],
        "steps": [
            {
                "question": "Write the subclasses `Theft`, `Fraud`, `Vandalism` and `ArmedRobbery` (a subclass of **Theft**), each with its own `bail()`. Then write `calculate_total(charges)` that adds up the bail of a list of charges, with **no** `isinstance`.",
                "starter": r'''from abc import ABC, abstractmethod

class Charge(ABC):
    def __init__(self, amount):
        self.amount = amount

    @abstractmethod
    def bail(self): ...

class Theft(Charge):
    ...

class Fraud(Charge):
    ...

class Vandalism(Charge):
    ...

class ArmedRobbery(Theft):
    ...

def calculate_total(charges):
    ...

KINDS = {"Theft": Theft, "Fraud": Fraud, "Vandalism": Vandalism, "ArmedRobbery": ArmedRobbery}
for name in docket:
    charges = [KINDS[kind](amount) for kind, amount in docket[name]]
    print(name, calculate_total(charges))
''',
                "solution": _BAIL + r'''
for name in docket:
    charges = [KINDS[kind](amount) for kind, amount in docket[name]]
    print(name, calculate_total(charges))
''',
                "tests": r'''def _bail(kind, amount):
    if kind == "Theft":
        return 5000
    if kind == "Fraud":
        return 10000 + amount // 10
    if kind == "Vandalism":
        return 0 if amount < 5000 else 2000
    return 5000 + 25000
assert issubclass(ArmedRobbery, Theft), "ArmedRobbery should inherit from Theft: class ArmedRobbery(Theft)"
assert "isinstance" not in __source__, "no isinstance checks: each class answers bail() for itself"
_classes = {"Theft": Theft, "Fraud": Fraud, "Vandalism": Vandalism, "ArmedRobbery": ArmedRobbery}
_all = []
for _name in docket:
    for _kind, _amt in docket[_name]:
        _c = _classes[_kind](_amt)
        _all.append(_c)
        assert _c.bail() == _bail(_kind, _amt), f"{_kind}({_amt}).bail() should be {_bail(_kind, _amt)}, got {_c.bail()!r}"
assert Vandalism(4999).bail() == 0 and Vandalism(5000).bail() == 2000, "Vandalism: free under 5000, otherwise 2000"
_exp = sum(_bail(_k, _a) for _n in docket for _k, _a in docket[_n])
assert calculate_total(_all) == _exp, f"calculate_total of every charge should be {_exp}, got {calculate_total(_all)!r}"
assert calculate_total([]) == 0, "calculate_total([]) should be 0"''',
                "tips": [
                    "Each subclass only needs `def bail(self): return ...`. Theft returns 5000; Fraud returns `10000 + self.amount // 10`; Vandalism uses an `if` on `self.amount < 5000`.",
                    "`ArmedRobbery.bail` returns `super().bail() + 25000`. `calculate_total` is `return sum(charge.bail() for charge in charges)`.",
                ],
                "reveal": "Four rules, one function, zero `isinstance`. The judge's calculator gets a well-earned rest.",
            },
            {
                "question": "For every suspect in `docket`, compute their total bail. Store the results in `bail_by_suspect` (name → total), and in `highest` the name of the suspect with the highest bail.",
                "starter": _BAIL + r'''
bail_by_suspect = {}
# fill it in here

highest = ...
print(bail_by_suspect)
print("Highest bail:", highest)
''',
                "solution": _BAIL + r'''
bail_by_suspect = {}
for name in docket:
    charges = [KINDS[kind](amount) for kind, amount in docket[name]]
    bail_by_suspect[name] = calculate_total(charges)

highest = max(bail_by_suspect, key=lambda name: bail_by_suspect[name])
print(bail_by_suspect)
print("Highest bail:", highest)
''',
                "tests": r'''def _bail(kind, amount):
    if kind == "Theft":
        return 5000
    if kind == "Fraud":
        return 10000 + amount // 10
    if kind == "Vandalism":
        return 0 if amount < 5000 else 2000
    return 5000 + 25000
_exp = {_n: sum(_bail(_k, _a) for _k, _a in docket[_n]) for _n in docket}
assert bail_by_suspect == _exp, f"bail_by_suspect should be {_exp}, got {bail_by_suspect!r}"
_top = max(_exp, key=lambda n: _exp[n])
assert highest == _top, f"the highest bail belongs to {_top!r}, got {highest!r}"''',
                "tips": [
                    "For each `name in docket`, turn the pairs into objects: `charges = [KINDS[kind](amount) for kind, amount in docket[name]]`.",
                    "`bail_by_suspect[name] = calculate_total(charges)`, then `highest = max(bail_by_suspect, key=lambda name: bail_by_suspect[name])`.",
                ],
                "reveal": "The judge reads the numbers out. The suspect with the highest bail asks for a lawyer, and a loan.",
            },
        ],
        "closing": "Case closed. Night court finishes before midnight for the first time in years. Polymorphism: each charge knows its own rule.",
    },
    # ================================================================== 8 (Q18)
    {
        "id": "forensics-pipeline",
        "tier": "medium",
        "title": "The Forensics Pipeline",
        "teaser": "Messy witness statements go in, clean evidence comes out, with an audit trail.",
        "skills": ["collections", "functional"],
        "story": "Witness statements arrive from the street in terrible shape: random capitals, stray spaces, \"um\" and \"uh\" everywhere, and some are just blank. The lab wants a **pipeline**: a list of small functions applied one after another, so each cleaning step can be tested and swapped on its own.\n\nThe statements are in `statements`. A helper `drop_fillers(text)` (already written for you where needed) removes the words `um` and `uh`.",
        "suspects": [
            {"name": "the hurried constable", "note": "Typed the statements on a phone, in the rain."},
        ],
        "variants": [
            'statements = ["  The VAN was RED  ", "   um  ", "I heard uh a  LOUD bang", "  ", "um the driver wore a Blue cap "]\n',
            'statements = ["  ", "She ran towards the STATION", "uh uh", "  Two men, one TALL  ", "the bag was um heavy"]\n',
            'statements = ["um I think it was   MIDNIGHT", "The dog barked TWICE", "   ", "  uh   ", " a green SCOOTER sped off  ", "Nobody screamed"]\n',
        ],
        "steps": [
            {
                "question": "Write `pipeline(funcs)`. It returns a **new function** that takes a value and passes it through every function in `funcs`, left to right.\n\nThen build `clean = pipeline([str.strip, str.lower])` and store `cleaned`: every statement run through `clean`, in order.",
                "starter": r'''def pipeline(funcs):
    ...

clean = pipeline([str.strip, str.lower])
cleaned = ...
for line in cleaned:
    print(repr(line))
''',
                "solution": _PIPELINE + r'''
clean = pipeline([str.strip, str.lower])
cleaned = [clean(s) for s in statements]
for line in cleaned:
    print(repr(line))
''',
                "tests": r'''_p = pipeline([str.strip, str.lower])
assert callable(_p), "pipeline(funcs) should return a function"
for _s in statements:
    assert _p(_s) == _s.strip().lower(), f"strip then lower on {_s!r} should give {_s.strip().lower()!r}, got {_p(_s)!r}"
assert pipeline([])("same") == "same", "with no functions, the pipeline should return the value unchanged"
assert pipeline([lambda x: x + 1, lambda x: x * 10])(2) == 30, "functions run left to right: (2 + 1) * 10 = 30"
assert cleaned == [_s.strip().lower() for _s in statements], f"cleaned should be {[_s.strip().lower() for _s in statements]}, got {cleaned!r}"''',
                "tips": [
                    "Inside `pipeline`, define an inner function `def run(value):` and `return run` at the end. Functions are values.",
                    "`run` loops: `for f in funcs: value = f(value)`, then `return value`. Then `cleaned = [clean(s) for s in statements]`.",
                ],
                "reveal": "One function made of smaller functions. The statements are already easier to read.",
            },
            {
                "question": "Write `pipeline_filter(funcs, predicate)`. It returns a function that takes a **list** of values and runs each one through the stages. After **each** stage it checks `predicate(value)`; as soon as that is False the value is dropped and **later stages are not run on it**. It returns the list of values that made it through.\n\nThen store `useful = pipeline_filter([str.strip, str.lower, drop_fillers], lambda s: s != \"\")(statements)`.",
                "starter": _DROP_FILLERS + "\n" + _PIPELINE + r'''
def pipeline_filter(funcs, predicate):
    ...

useful = pipeline_filter([str.strip, str.lower, drop_fillers], lambda s: s != "")(statements)
print(useful)
''',
                "solution": _DROP_FILLERS + "\n" + _PIPELINE + "\n" + _PIPELINE_FILTER + r'''
useful = pipeline_filter([str.strip, str.lower, drop_fillers], lambda s: s != "")(statements)
print(useful)
''',
                "tests": r'''def _drop(text):
    return " ".join([w for w in text.split() if w not in ("um", "uh")])
_exp = []
for _s in statements:
    _v = _drop(_s.strip().lower())
    if _v != "":
        _exp.append(_v)
assert useful == _exp, f"useful should be {_exp}, got {useful!r}"
_short = pipeline_filter([str.strip, str.upper], lambda s: len(s) <= 5)
assert _short(["  abc ", " toolong ", "hi"]) == ["ABC", "HI"], "values that fail the predicate should be dropped"
try:
    _r = pipeline_filter([str.strip, lambda s: 10 // len(s)], lambda s: s != "")(["  ", "ab"])
except ZeroDivisionError:
    raise AssertionError("drop a value as soon as the predicate is False: do not run the later stages on it")
assert _r == [5], f"pipeline_filter([str.strip, 10 // len], ...) on ['  ', 'ab'] should give [5], got {_r!r}"''',
                "tips": [
                    "Return an inner `run(items)` that builds a `results` list. For each value, loop over `funcs`; after `value = f(value)`, `if not predicate(value): break`.",
                    "Use the loop's `else:`: it runs only when the inner `for` finished without `break`, so put `results.append(value)` there.",
                ],
                "reveal": "Blank statements and pure \"um\" are gone. What is left is what the witnesses actually saw.",
            },
            {
                "question": "Write `pipeline_with_logging(funcs, log_fn)`. It works like `pipeline`, but after **each** stage it calls `log_fn(stage_name, before, after)`, where `stage_name` is `f.__name__`.\n\nThen make `audit = []` and a `log_fn` that appends `(stage, before, after)` tuples to it. Run every statement through `pipeline_with_logging([str.strip, str.lower, drop_fillers], log_fn)`. Store in `changes` how many audit entries actually changed the text (`before != after`).",
                "starter": _DROP_FILLERS + "\n" + _PIPELINE + r'''
def pipeline_with_logging(funcs, log_fn):
    ...

audit = []
# write log_fn, build the logging pipeline and run every statement

changes = ...
print(len(audit), "stages logged,", changes, "changed the text")
''',
                "solution": _DROP_FILLERS + "\n" + _PIPELINE + r'''
def pipeline_with_logging(funcs, log_fn):
    def run(value):
        for f in funcs:
            before = value
            value = f(value)
            log_fn(f.__name__, before, value)
        return value
    return run

audit = []

def log_fn(stage, before, after):
    audit.append((stage, before, after))

run = pipeline_with_logging([str.strip, str.lower, drop_fillers], log_fn)
for s in statements:
    run(s)

changes = len([entry for entry in audit if entry[1] != entry[2]])
print(len(audit), "stages logged,", changes, "changed the text")
''',
                "tests": r'''def _drop(text):
    return " ".join([w for w in text.split() if w not in ("um", "uh")])
_log = []
_run = pipeline_with_logging([str.strip, str.lower], lambda *entry: _log.append(entry))
assert _run("  HI ") == "hi", "pipeline_with_logging should still return the final value"
assert _log == [(str.strip.__name__, "  HI ", "HI"), (str.lower.__name__, "HI", "hi")], f"log_fn should be called as log_fn(f.__name__, before, after) after each stage, got {_log}"
_exp = []
for _s in statements:
    _v = _s
    for _f in (str.strip, str.lower, _drop):
        _b, _v = _v, _f(_v)
        _exp.append((_f.__name__ if _f is not _drop else "drop_fillers", _b, _v))
assert len(audit) == len(_exp), f"audit should have {len(_exp)} entries (3 stages for each of {len(statements)} statements), got {len(audit)}"
assert [tuple(_e) for _e in audit] == _exp, "each audit entry should be (stage, before, after), in the order they happened"
_ch = len([_e for _e in _exp if _e[1] != _e[2]])
assert changes == _ch, f"{_ch} stages changed the text, changes is {changes!r}"''',
                "tips": [
                    "Same shape as `pipeline`, but inside the loop keep `before = value`, then `value = f(value)`, then `log_fn(f.__name__, before, value)`.",
                    "`def log_fn(stage, before, after): audit.append((stage, before, after))`. After running every statement: `changes = len([e for e in audit if e[1] != e[2]])`.",
                ],
                "reveal": "The audit trail shows exactly what each stage did to each statement. The defence can't claim the lab rewrote anything.",
            },
        ],
        "closing": "Case closed. Small, testable stages, chained together, with a log of every change: the lab adopts the pipeline for every case.",
    },
    # ================================================================== 9 (Q19)
    {
        "id": "records-office",
        "tier": "medium",
        "title": "The Records Office",
        "teaser": "Suspects, vehicles, and a filing system that files itself.",
        "skills": ["errors", "function-craft", "functional", "classes", "inheritance"],
        "story": "The Records Office keeps cards for suspects and vehicles. Every card type has its own list of **fields**, and every new card must go into the right drawer automatically.\n\nYou will build a base class `Record`. Any subclass just declares `fields = (...)` and gets: keyword construction that checks the fields, `to_dict()`, `from_dict()`, and its **own** registry with `all()` and `filter(**kw)`.\n\nThe cards are in `suspect_rows` and `vehicle_rows` (lists of dicts). A witness saw the getaway car: its colour is `witness_colour` and its make is `witness_make`.",
        "suspects": [
            {"name": "the registered owners", "note": "One of them was driving."},
        ],
        "variants": [
            'suspect_rows = [\n    {"name": "Arjun Rao", "gang": "Night Owls", "city": "Pune"},\n    {"name": "Sofia Marino", "gang": "Silver Fox", "city": "Mumbai"},\n    {"name": "Vikram Shetty", "gang": "Night Owls", "city": "Mumbai"},\n    {"name": "Hana Sato", "gang": "Silver Fox", "city": "Pune"},\n]\nvehicle_rows = [\n    {"plate": "MH12 AB 4411", "colour": "white", "make": "Maruti", "owner": "Arjun Rao"},\n    {"plate": "MH01 ZX 9001", "colour": "white", "make": "Toyota", "owner": "Hana Sato"},\n    {"plate": "MH14 QQ 1234", "colour": "black", "make": "Toyota", "owner": "Vikram Shetty"},\n    {"plate": "MH02 KL 7777", "colour": "white", "make": "Honda", "owner": "Sofia Marino", "notes": "dented door"},\n]\nwitness_colour = "white"\nwitness_make = "Toyota"\n',
            'suspect_rows = [\n    {"name": "Kabir Malik", "gang": "Iron Gate", "city": "Delhi"},\n    {"name": "Elena Novak", "gang": "Blue Heron", "city": "Delhi"},\n    {"name": "Musa Diallo", "gang": "Iron Gate", "city": "Noida"},\n]\nvehicle_rows = [\n    {"plate": "DL3C 0001", "colour": "red", "make": "Hyundai", "owner": "Elena Novak"},\n    {"plate": "DL8 AB 2222", "colour": "red", "make": "Tata", "owner": "Kabir Malik"},\n    {"plate": "UP16 X 3434", "colour": "red", "make": "Hyundai", "colr": "maroon", "owner": "Musa Diallo"},\n    {"plate": "DL1 ZZ 9898", "colour": "silver", "make": "Hyundai", "owner": "Musa Diallo"},\n]\nwitness_colour = "red"\nwitness_make = "Hyundai"\n',
            'suspect_rows = [\n    {"name": "Priya Nair", "gang": "Harbour Rats", "city": "Kochi"},\n    {"name": "Liam Byrne", "gang": "Harbour Rats", "city": "Chennai"},\n    {"name": "Chen Wei", "gang": "Jade Ring", "city": "Kochi"},\n    {"name": "Rohan Das", "gang": "Jade Ring", "city": "Chennai"},\n    {"name": "Aisha Bello", "gang": "Harbour Rats", "city": "Kochi"},\n]\nvehicle_rows = [\n    {"plate": "KL07 A 1111", "colour": "blue", "make": "Mahindra", "owner": "Priya Nair"},\n    {"plate": "TN09 B 2222", "colour": "blue", "make": "Tata", "owner": "Rohan Das"},\n    {"plate": "KL01 C 3333", "colour": "green", "make": "Tata", "owner": "Chen Wei"},\n    {"plate": "TN10 D 4444", "colour": "blue", "owner": "Liam Byrne"},\n    {"plate": "KL05 E 5555", "colour": "white", "make": "Tata", "owner": "Aisha Bello"},\n]\nwitness_colour = "blue"\nwitness_make = "Tata"\n',
        ],
        "steps": [
            {
                "question": "Write the base class `Record`:\n\n- `__init_subclass__(cls, **kwargs)` gives **each** subclass its own empty list `cls._registry`.\n- `__init__(self, **kwargs)` raises `TypeError` if a field is missing or unknown; otherwise it stores each field with `setattr(self, name, value)` and adds the object to `type(self)._registry`.\n- `to_dict()` returns `{field: value}`; `from_dict(cls, data)` is a class method that returns `cls(**data)`.\n- Class methods `all()` (a list of every record of that class) and `filter(**criteria)` (records where every given field matches).",
                "starter": r'''class Record:
    fields = ()
    # __init_subclass__, __init__, to_dict, from_dict, all, filter

''' + _RECORD_SUBCLASSES + r'''
for row in suspect_rows:
    Suspect.from_dict(row)
print(len(Suspect.all()), "suspect cards on file")
print(Suspect.filter(city=suspect_rows[0]["city"]))
''',
                "solution": _RECORD + "\n" + _RECORD_SUBCLASSES + r'''
for row in suspect_rows:
    Suspect.from_dict(row)
print(len(Suspect.all()), "suspect cards on file")
print([s.name for s in Suspect.filter(city=suspect_rows[0]["city"])])
''',
                "tests": r'''class _Card(Record):
    fields = ("name", "gang", "city")

class _Other(Record):
    fields = ("plate",)

_made = [_Card(**_r) for _r in suspect_rows]
_Other(plate="TEST 1")
assert _Card.all() == _made, "all() should return every record created for that class, in order"
assert len(_Other.all()) == 1, "each subclass needs its own registry: set cls._registry = [] in __init_subclass__"
_r0 = suspect_rows[0]
assert _made[0].name == _r0["name"] and _made[0].gang == _r0["gang"], "store each field as an attribute: setattr(self, name, kwargs[name])"
assert _made[0].to_dict() == _r0, f"to_dict() should give {_r0}, got {_made[0].to_dict()!r}"
_fd = _Card.from_dict(suspect_rows[-1])
assert isinstance(_fd, _Card) and _Card.all()[-1] is _fd, "from_dict should build the record with cls(**data), and it is registered too"
_g = _r0["gang"]
_exp = [_c for _c in _Card.all() if _c.gang == _g]
assert _Card.filter(gang=_g) == _exp, f"filter(gang={_g!r}) should return {len(_exp)} records"
_exp2 = [_c for _c in _Card.all() if _c.gang == _g and _c.city == _r0["city"]]
assert _Card.filter(gang=_g, city=_r0["city"]) == _exp2, "filter with two criteria should match both"
assert _Card.filter(gang="Nobody") == [], "filter with no matches should return []"
for _bad in ({"name": "X"}, {"name": "X", "gang": "Y", "city": "Z", "age": 40}):
    try:
        _Card(**_bad)
        raise AssertionError(f"a card with fields {sorted(_bad)} should raise TypeError (missing or unknown fields)")
    except TypeError:
        pass''',
                "tips": [
                    "`def __init_subclass__(cls, **kwargs): super().__init_subclass__(**kwargs); cls._registry = []`. In `__init__`, `unknown = set(kwargs) - set(self.fields)` and `missing = set(self.fields) - set(kwargs)`; raise `TypeError` if either is non-empty.",
                    "`all` returns `list(cls._registry)`. `filter` returns `[r for r in cls._registry if all(getattr(r, k) == v for k, v in criteria.items())]`. Mark `from_dict`, `all` and `filter` with `@classmethod`.",
                ],
                "reveal": "Every subclass now files itself in its own drawer. The Records Office has never been so tidy.",
            },
            {
                "question": "Load the cards. Create a `Suspect` for every row of `suspect_rows`, and a `Vehicle` for every row of `vehicle_rows`, but **skip** rows that raise `TypeError` and count them in `rejected`.\n\nThen find the getaway car with `Vehicle.filter(...)` using the witness's colour and make. Store its owner in `driver`, and the driver's gang (from `Suspect.filter`) in `gang`.",
                "starter": _RECORD + "\n" + _RECORD_SUBCLASSES + r'''
rejected = 0
# load suspects and vehicles here

driver = ...
gang = ...
print(rejected, "bad cards;", driver, "of", gang)
''',
                "solution": _RECORD + "\n" + _RECORD_SUBCLASSES + r'''
rejected = 0
for row in suspect_rows:
    Suspect.from_dict(row)
for row in vehicle_rows:
    try:
        Vehicle.from_dict(row)
    except TypeError:
        rejected += 1

car = Vehicle.filter(colour=witness_colour, make=witness_make)[0]
driver = car.owner
gang = Suspect.filter(name=driver)[0].gang
print(rejected, "bad cards;", driver, "of", gang)
''',
                "tests": r'''_vf = ("plate", "colour", "make", "owner")
_good = [_r for _r in vehicle_rows if sorted(_r) == sorted(_vf)]
_rej = len(vehicle_rows) - len(_good)
assert rejected == _rej, f"{_rej} vehicle card(s) have missing or unknown fields, rejected is {rejected!r}"
assert len(Suspect.all()) == len(suspect_rows), f"load every suspect: expected {len(suspect_rows)}, found {len(Suspect.all())}"
assert len(Vehicle.all()) == len(_good), f"load every good vehicle card: expected {len(_good)}, found {len(Vehicle.all())}"
_car = [_r for _r in _good if _r["colour"] == witness_colour and _r["make"] == witness_make][0]
_gang = [_r for _r in suspect_rows if _r["name"] == _car["owner"]][0]["gang"]
assert driver == _car["owner"], f"the {witness_colour} {witness_make} belongs to {_car['owner']!r}, got {driver!r}"
assert gang == _gang, f"{_car['owner']} is in the gang {_gang!r}, got {gang!r}"''',
                "tips": [
                    "Wrap `Vehicle.from_dict(row)` in `try:` and add 1 to `rejected` in `except TypeError:`. Suspects all load cleanly.",
                    "`car = Vehicle.filter(colour=witness_colour, make=witness_make)[0]`, `driver = car.owner`, then `gang = Suspect.filter(name=driver)[0].gang`.",
                ],
                "reveal": "One car matches the witness. Its owner's card points straight to a gang the Bureau knows well.",
            },
        ],
        "closing": "Case closed. A base class that registers its own subclasses: write the filing rules once, and every new card type just works.",
    },
    # ================================================================== 10 (Q20)
    {
        "id": "criminal-database",
        "tier": "medium",
        "title": "The Criminal Database",
        "teaser": "Search the city's most wanted by name, gang, year and status.",
        "skills": ["functional", "dunders", "dataclasses"],
        "story": "The Bureau's criminal records live in a spreadsheet that only one person knows how to filter. The Chief wants a proper search engine.\n\nEvery record is a `Criminal` dataclass (already written for you), built from the tuples in `criminal_rows`: `(crim_id, name, gang, year, bounty, status)`. `year` is the year of first arrest; `status` is `\"at large\"` or `\"in custody\"`.\n\nAn informant has sent a `tip`: a dict of search filters that should narrow things down.",
        "suspects": [
            {"name": "everyone still at large", "note": "Somewhere in the city."},
        ],
        "variants": [
            'criminal_rows = [\n    ("C1", "Bobby Fernandes", "Red Lotus", 2015, 50000, "at large"),\n    ("C2", "Nadia Petrova", "Black Kite", 2019, 120000, "at large"),\n    ("C3", "Rocky Bhatia", "Red Lotus", 2021, 30000, "in custody"),\n    ("C4", "Lucas Moreno", "Black Kite", 2012, 80000, "in custody"),\n    ("C5", "Ritu Bose", "Red Lotus", 2018, 95000, "at large"),\n    ("C6", "Sam Okoro", "Grey Wolves", 2020, 60000, "at large"),\n    ("C7", "Tara Bose", "Grey Wolves", 2016, 45000, "at large"),\n]\ntip = {"gang": "Red Lotus", "min_year": 2016, "status": "at large"}\n',
            'criminal_rows = [\n    ("G-01", "Imran Sheikh", "Desert Kings", 2010, 200000, "at large"),\n    ("G-02", "Carla Mendes", "Night Market", 2017, 75000, "at large"),\n    ("G-03", "Ajay Verma", "Desert Kings", 2014, 90000, "in custody"),\n    ("G-04", "Yuki Mori", "Night Market", 2022, 40000, "at large"),\n    ("G-05", "Pedro Alves", "Night Market", 2019, 65000, "at large"),\n    ("G-06", "Neha Kulkarni", "Desert Kings", 2021, 55000, "at large"),\n]\ntip = {"gang": "Night Market", "max_year": 2020, "status": "at large"}\n',
            'criminal_rows = [\n    ("Z9", "Victor Hale", "Tin Men", 2008, 35000, "in custody"),\n    ("Z8", "Farida Hussain", "Velvet Hand", 2016, 150000, "at large"),\n    ("Z7", "Kiran Joshi", "Tin Men", 2019, 70000, "at large"),\n    ("Z6", "Oscar Lund", "Velvet Hand", 2013, 110000, "in custody"),\n    ("Z5", "Deepa Rao", "Velvet Hand", 2020, 85000, "at large"),\n    ("Z4", "Kim Hyun", "Tin Men", 2018, 25000, "at large"),\n    ("Z3", "Joseph Mathew", "Tin Men", 2011, 99000, "at large"),\n]\ntip = {"gang": "Tin Men", "min_year": 2010, "max_year": 2019, "status": "at large"}\n',
        ],
        "steps": [
            {
                "question": "Write `CriminalDB`:\n\n- `add(criminal)`.\n- `search(query=None, *, gang=None, min_year=None, max_year=None, status=None)`: any combination of filters, written as **one list comprehension**. `query` matches part of the name, ignoring case. A filter that is `None` is ignored.\n- `top_wanted(n=3)`: the `n` criminals with the highest bounty, highest first.\n- `group_by(attr)`: a dict from each value of that attribute to the list of criminals with it.\n- `__iter__` (every criminal, in the order added) and `__getitem__` by `crim_id`.",
                "starter": _CRIMINAL + r'''
class CriminalDB:
    ...  # your code here

db = CriminalDB()
for c in CRIMINALS:
    db.add(c)
print([c.name for c in db.top_wanted(3)])
''',
                "solution": _CRIMINAL + "\n" + _CRIMINAL_DB + r'''
db = CriminalDB()
for c in CRIMINALS:
    db.add(c)
print([c.name for c in db.top_wanted(3)])
''',
                "tests": _CRIMINAL_TEST_DB + r'''_r0, _r1 = criminal_rows[0], criminal_rows[1]
_q = _r0[1].split()[-1][:4].upper()
assert _ids(_db.search(_q)) == _expect(query=_q), f"search({_q!r}) should match names containing {_q!r}, ignoring case: {_expect(query=_q)}"
assert _ids(_db.search(gang=_r1[2])) == _expect(gang=_r1[2]), f"search(gang={_r1[2]!r}) should give {_expect(gang=_r1[2])}"
_years = sorted(_r[3] for _r in criminal_rows)
_lo, _hi = _years[1], _years[-2]
assert _ids(_db.search(min_year=_lo, max_year=_hi)) == _expect(min_year=_lo, max_year=_hi), f"search(min_year={_lo}, max_year={_hi}) should give {_expect(min_year=_lo, max_year=_hi)} (both ends included)"
assert _ids(_db.search(gang=_r0[2], status="at large")) == _expect(gang=_r0[2], status="at large"), f"search(gang={_r0[2]!r}, status='at large') should give {_expect(gang=_r0[2], status='at large')}"
assert len(_db.search()) == len(criminal_rows), "search() with no filters should return everyone"
_top = [_c.crim_id for _c in sorted(_crims, key=lambda c: c.bounty, reverse=True)]
assert _ids(_db.top_wanted(3)) == _top[:3], f"top_wanted(3) should give {_top[:3]} (highest bounty first)"
assert _ids(_db.top_wanted(1)) == _top[:1], "top_wanted(1) should give just the most wanted"
_groups = _db.group_by("gang")
_gangs = sorted(set(_c.gang for _c in _crims))
assert sorted(_groups) == _gangs, f"group_by('gang') should have the keys {_gangs}, got {sorted(_groups)}"
for _g in _gangs:
    assert _ids(_groups[_g]) == [_c.crim_id for _c in _crims if _c.gang == _g], f"group_by('gang')[{_g!r}] has the wrong criminals"
assert [_c.crim_id for _c in _db] == [_c.crim_id for _c in _crims], "`for c in db` should give every criminal in the order added"
assert _db[_r1[0]].name == _r1[1], f"db[{_r1[0]!r}] should be {_r1[1]}"''',
                "tips": [
                    "Keep the records in a dict keyed by `crim_id`, so `__getitem__` is `return self._records[crim_id]` and `__iter__` is `return iter(self._records.values())`.",
                    "In `search`, every filter has the form `(gang is None or c.gang == gang)`; join them with `and` inside `[c for c in self._records.values() if ...]`. `top_wanted`: `sorted(..., key=lambda c: c.bounty, reverse=True)[:n]`. `group_by`: `groups.setdefault(getattr(c, attr), []).append(c)`.",
                ],
                "reveal": "The spreadsheet is retired. Any detective can now ask the database a question in one line.",
            },
            {
                "question": "Use the database. Store:\n\n- `leads`: the names of the criminals that match the informant's `tip` (pass it with `db.search(**tip)`).\n- `most_wanted`: the name of the criminal with the highest bounty.\n- `gang_sizes`: a dict from each gang to how many members it has.",
                "starter": _CRIMINAL + "\n" + _CRIMINAL_DB + r'''
db = CriminalDB()
for c in CRIMINALS:
    db.add(c)

leads = ...
most_wanted = ...
gang_sizes = ...
print(leads, most_wanted, gang_sizes)
''',
                "solution": _CRIMINAL + "\n" + _CRIMINAL_DB + r'''
db = CriminalDB()
for c in CRIMINALS:
    db.add(c)

leads = [c.name for c in db.search(**tip)]
most_wanted = db.top_wanted(1)[0].name
gang_sizes = {gang: len(members) for gang, members in db.group_by("gang").items()}
print(leads, most_wanted, gang_sizes)
''',
                "tests": r'''_rows = criminal_rows
_exp = [_r[1] for _r in _rows
        if _r[2] == tip.get("gang", _r[2])
        and _r[3] >= tip.get("min_year", _r[3])
        and _r[3] <= tip.get("max_year", _r[3])
        and _r[5] == tip.get("status", _r[5])]
assert leads == _exp, f"the tip {tip} matches {_exp}, got {leads!r}"
_mw = sorted(_rows, key=lambda r: r[4], reverse=True)[0][1]
assert most_wanted == _mw, f"the highest bounty belongs to {_mw!r}, got {most_wanted!r}"
_sizes = {}
for _r in _rows:
    _sizes[_r[2]] = _sizes.get(_r[2], 0) + 1
assert gang_sizes == _sizes, f"gang_sizes should be {_sizes}, got {gang_sizes!r}"''',
                "tips": [
                    "`db.search(**tip)` unpacks the dict into keyword arguments. Take `.name` of each result with a list comprehension.",
                    "`most_wanted = db.top_wanted(1)[0].name` and `gang_sizes = {gang: len(members) for gang, members in db.group_by(\"gang\").items()}`.",
                ],
                "reveal": "The tip narrows the city down to a handful of names. A squad car is already on its way.",
            },
        ],
        "closing": "Case closed. Filters that combine freely, a ranking and a grouping: the database answers in seconds what used to take an afternoon.",
    },
    # ================================================================== 11 (Q15)
    {
        "id": "witness-protection",
        "tier": "medium",
        "title": "Witness Protection",
        "teaser": "Safehouses, check-ins, overdue stays, and errors that mean something.",
        "skills": ["errors", "toolkit", "classes", "dataclasses"],
        "story": "The Witness Protection unit moves witnesses between safehouses. The log book is full of crossings-out, and last month two witnesses were sent to the same house on the same night.\n\nThe Bureau wants a `Program` that refuses impossible moves with **clear errors**: an unknown safehouse, an unknown witness, a house that is already occupied, or a check-out from an empty house.\n\nThe evidence: `safehouses` (ids), `witnesses` (`(witness_id, name)` pairs), the unit's `events` in date order, the date `today`, and `watch_id`, a witness the Chief is worried about. Dates are `datetime.date` objects.",
        "suspects": [
            {"name": "the duty officer", "note": "Signed every move in the old log book."},
            {"name": "the leak", "note": "Someone knows where the witnesses are."},
        ],
        "variants": [
            'from datetime import date\nsafehouses = ["SH-Alpha", "SH-Bravo", "SH-Charlie"]\nwitnesses = [("W1", "Meera Pillai"), ("W2", "Tomasz Nowak"), ("W3", "Grace Mensah"), ("W4", "Imran Qureshi")]\nevents = [\n    {"action": "in", "house": "SH-Alpha", "witness": "W1", "on": date(2026, 3, 1), "nights": 5},\n    {"action": "in", "house": "SH-Bravo", "witness": "W2", "on": date(2026, 3, 2), "nights": 10},\n    {"action": "in", "house": "SH-Alpha", "witness": "W3", "on": date(2026, 3, 3), "nights": 4},\n    {"action": "out", "house": "SH-Alpha", "on": date(2026, 3, 6)},\n    {"action": "in", "house": "SH-Charlie", "witness": "W3", "on": date(2026, 3, 7), "nights": 3},\n    {"action": "in", "house": "SH-Alpha", "witness": "W1", "on": date(2026, 3, 8), "nights": 14},\n    {"action": "in", "house": "SH-Delta", "witness": "W4", "on": date(2026, 3, 9), "nights": 2},\n    {"action": "out", "house": "SH-Charlie", "on": date(2026, 3, 9)},\n    {"action": "out", "house": "SH-Charlie", "on": date(2026, 3, 11)},\n]\ntoday = date(2026, 3, 15)\nwatch_id = "W1"\n',
            'from datetime import date\nsafehouses = ["Blue Door", "Green Gate"]\nwitnesses = [("A7", "Kavya Menon"), ("B3", "Oliver Brandt"), ("C9", "Amara Obi")]\nevents = [\n    {"action": "in", "house": "Blue Door", "witness": "A7", "on": date(2026, 5, 10), "nights": 7},\n    {"action": "in", "house": "Green Gate", "witness": "Z1", "on": date(2026, 5, 10), "nights": 3},\n    {"action": "in", "house": "Green Gate", "witness": "B3", "on": date(2026, 5, 11), "nights": 2},\n    {"action": "out", "house": "Green Gate", "on": date(2026, 5, 12)},\n    {"action": "in", "house": "Green Gate", "witness": "C9", "on": date(2026, 5, 13), "nights": 3},\n    {"action": "in", "house": "Blue Door", "witness": "B3", "on": date(2026, 5, 14), "nights": 4},\n    {"action": "out", "house": "Blue Door", "on": date(2026, 5, 15)},\n    {"action": "in", "house": "Blue Door", "witness": "B3", "on": date(2026, 5, 15), "nights": 1},\n]\ntoday = date(2026, 5, 20)\nwatch_id = "B3"\n',
            'from datetime import date\nsafehouses = ["Nest-1", "Nest-2", "Nest-3"]\nwitnesses = [("X1", "Farah Siddiqui"), ("X2", "Jonas Weber"), ("X3", "Lucia Romero")]\nevents = [\n    {"action": "in", "house": "Nest-2", "witness": "X2", "on": date(2026, 7, 1), "nights": 2},\n    {"action": "out", "house": "Nest-1", "on": date(2026, 7, 2)},\n    {"action": "out", "house": "Nest-2", "on": date(2026, 7, 3)},\n    {"action": "in", "house": "Nest-1", "witness": "X3", "on": date(2026, 7, 4), "nights": 10},\n    {"action": "in", "house": "Nest-3", "witness": "X1", "on": date(2026, 7, 5), "nights": 3},\n    {"action": "in", "house": "Nest-2", "witness": "X2", "on": date(2026, 7, 6), "nights": 1},\n    {"action": "out", "house": "Nest-2", "on": date(2026, 7, 7)},\n]\ntoday = date(2026, 7, 9)\nwatch_id = "X2"\n',
        ],
        "steps": [
            {
                "question": "Write two `Program` methods:\n\n- `check_in(safehouse_id, witness_id, on, nights=7)`: check, **in this order**, that the safehouse exists (`UnknownSafehouseError`), the witness exists (`UnknownWitnessError`) and the house is free (`SafehouseOccupiedError`). Then create a `Stay` with `due_out = on + timedelta(days=nights)`, add it to `self.stays`, mark the house as not free and return the stay.\n- `check_out(safehouse_id, on)`: unknown house → `UnknownSafehouseError`; find the open stay (`checked_out is None`) in that house, set `checked_out = on`, free the house and return the stay. No open stay → `NoOpenStayError`.",
                "starter": _WITNESS_SETUP + r'''
    def check_in(self, safehouse_id, witness_id, on, nights=7):
        ...

    def check_out(self, safehouse_id, on):
        ...

''' + _WITNESS_REPLAY + r'''
for e in events:
    try:
        if e["action"] == "in":
            stay = program.check_in(e["house"], e["witness"], e["on"], e["nights"])
            print("IN ", stay.witness_id, "->", stay.safehouse_id, "until", stay.due_out)
        else:
            stay = program.check_out(e["house"], e["on"])
            print("OUT", stay.witness_id, "<-", stay.safehouse_id)
    except ProgramError as err:
        print("REFUSED:", type(err).__name__, err)
''',
                "solution": _WITNESS_SETUP + _WITNESS_CHECK + "\n" + _WITNESS_REPLAY + r'''
for e in events:
    try:
        if e["action"] == "in":
            stay = program.check_in(e["house"], e["witness"], e["on"], e["nights"])
            print("IN ", stay.witness_id, "->", stay.safehouse_id, "until", stay.due_out)
        else:
            stay = program.check_out(e["house"], e["on"])
            print("OUT", stay.witness_id, "<-", stay.safehouse_id)
    except ProgramError as err:
        print("REFUSED:", type(err).__name__, err)
''',
                "tests": _WITNESS_TEST_PROGRAM + r'''_s = _p.check_in(_h0, _w0, _day, nights=4)
assert isinstance(_s, Stay), f"check_in should return a Stay, got {_s!r}"
assert _s.safehouse_id == _h0 and _s.witness_id == _w0 and _s.checked_in == _day, "the Stay should hold the safehouse, the witness and the check-in date"
assert _s.due_out == _day + _td(days=4), f"with nights=4, due_out should be {_day + _td(days=4)}, got {_s.due_out}"
assert _s.checked_out is None, "a new stay is still open: checked_out should be None"
assert _p.free[_h0] is False, "after check_in the safehouse is no longer free"
assert _p.stays == [_s], "check_in should add the stay to self.stays"
_s2 = _p.check_in(_h1, _w1, _day)
assert _s2.due_out == _day + _td(days=7), "nights should default to 7"
for _args, _err in (((_h0, witnesses[-1][0]), "SafehouseOccupiedError"), (("NO-SUCH-HOUSE", _w0), "UnknownSafehouseError"), ((_h0, "NO-SUCH-WITNESS"), "UnknownWitnessError")):
    try:
        _p.check_in(_args[0], _args[1], _day)
        raise AssertionError(f"check_in{_args} should raise {_err}")
    except ProgramError as _e:
        assert type(_e).__name__ == _err, f"check_in{_args} should raise {_err}, but it raised {type(_e).__name__}"
_out = _p.check_out(_h1, _day + _td(days=2))
assert _out is _s2 and _s2.checked_out == _day + _td(days=2), "check_out should close the open stay (set checked_out) and return it"
assert _p.free[_h1] is True, "after check_out the safehouse is free again"
for _args, _err in (((_h1,), "NoOpenStayError"), (("NO-SUCH-HOUSE",), "UnknownSafehouseError")):
    try:
        _p.check_out(_args[0], _day)
        raise AssertionError(f"check_out({_args[0]!r}) should raise {_err}")
    except ProgramError as _e:
        assert type(_e).__name__ == _err, f"check_out({_args[0]!r}) should raise {_err}, but it raised {type(_e).__name__}"''',
                "tips": [
                    "Three `if` checks, each with `raise`: `if safehouse_id not in self.free: raise UnknownSafehouseError(safehouse_id)`, then the witness (`self.witnesses`), then `if not self.free[safehouse_id]: raise SafehouseOccupiedError(...)`.",
                    "Create `stay = Stay(safehouse_id, witness_id, on, on + timedelta(days=nights))`, append it, set `self.free[safehouse_id] = False`, return it. In `check_out`, loop over `self.stays` for `stay.safehouse_id == safehouse_id and stay.checked_out is None`; if the loop ends without a match, `raise NoOpenStayError(...)`.",
                ],
                "reveal": "Impossible moves bounce off with errors that say exactly what went wrong. No more double-booked safehouses.",
            },
            {
                "question": "Add two more methods:\n\n- `overdue(today)`: the open stays whose `due_out` is before `today`, in `self.stays` order.\n- `history(witness_id)`: all of that witness's stays, **oldest check-in first**. Unknown witness → `UnknownWitnessError`.\n\nThen replay `events` (catch `ProgramError` and count the refusals in `refused`). Store `overdue_names` (the names of the overdue witnesses on `today`) and `trail` (the safehouse ids from `history(watch_id)`).",
                "starter": _WITNESS_SETUP + _WITNESS_CHECK + r'''
    def overdue(self, today):
        ...

    def history(self, witness_id):
        ...

''' + _WITNESS_REPLAY + r'''
refused = 0
# replay the events here

overdue_names = ...
trail = ...
print(refused, overdue_names, trail)
''',
                "solution": _WITNESS_SETUP + _WITNESS_CHECK + r'''
    def overdue(self, today):
        return [s for s in self.stays if s.checked_out is None and s.due_out < today]

    def history(self, witness_id):
        if witness_id not in self.witnesses:
            raise UnknownWitnessError(witness_id)
        mine = [s for s in self.stays if s.witness_id == witness_id]
        return sorted(mine, key=lambda s: s.checked_in)

''' + _WITNESS_REPLAY + r'''
refused = 0
for e in events:
    try:
        if e["action"] == "in":
            program.check_in(e["house"], e["witness"], e["on"], e["nights"])
        else:
            program.check_out(e["house"], e["on"])
    except ProgramError:
        refused += 1

overdue_names = [program.witnesses[s.witness_id].name for s in program.overdue(today)]
trail = [s.safehouse_id for s in program.history(watch_id)]
print(refused, overdue_names, trail)
''',
                "tests": _WITNESS_TEST_PROGRAM + r'''_a = _p.check_in(_h0, _w0, _day + _td(days=5), nights=1)
_b = _p.check_in(_h1, _w0, _day, nights=30)
assert [_x.safehouse_id for _x in _p.history(_w0)] == [_h1, _h0], "history should be sorted by checked_in, oldest first"
assert _p.overdue(_day + _td(days=10)) == [_a], "overdue(today) should return the open stays with due_out before today"
_p.check_out(_h0, _day + _td(days=6))
assert _p.overdue(_day + _td(days=10)) == [], "a checked-out stay is never overdue"
try:
    _p.history("NO-SUCH-WITNESS")
    raise AssertionError("history of an unknown witness should raise UnknownWitnessError")
except ProgramError as _e:
    assert type(_e).__name__ == "UnknownWitnessError", f"history of an unknown witness should raise UnknownWitnessError, not {type(_e).__name__}"
_free = {_h: True for _h in safehouses}
_names = dict(witnesses)
_stays = []
_ref = 0
for _e in events:
    _h = _e["house"]
    if _e["action"] == "in":
        if _h not in _free or _e["witness"] not in _names or not _free[_h]:
            _ref += 1
            continue
        _stays.append([_h, _e["witness"], _e["on"], _e["on"] + _td(days=_e["nights"]), None])
        _free[_h] = False
    else:
        _open = [_x for _x in _stays if _x[0] == _h and _x[4] is None]
        if _h not in _free or not _open:
            _ref += 1
            continue
        _open[0][4] = _e["on"]
        _free[_h] = True
assert refused == _ref, f"{_ref} events should be refused, refused is {refused!r}"
_over = [_names[_x[1]] for _x in _stays if _x[4] is None and _x[3] < today]
assert overdue_names == _over, f"on {today} the overdue witnesses are {_over}, got {overdue_names!r}"
_tr = [_x[0] for _x in sorted([_x for _x in _stays if _x[1] == watch_id], key=lambda x: x[2])]
assert trail == _tr, f"the safehouse trail of {watch_id} is {_tr}, got {trail!r}"''',
                "tips": [
                    "`overdue`: `[s for s in self.stays if s.checked_out is None and s.due_out < today]`. `history`: raise if the witness is unknown, then `sorted([...], key=lambda s: s.checked_in)`.",
                    "Replay with `try:` around the check-in or check-out call, and `except ProgramError: refused += 1`. Then `overdue_names = [program.witnesses[s.witness_id].name for s in program.overdue(today)]`.",
                ],
                "reveal": "The overdue list lands on the Chief's desk. One of those witnesses should have moved days ago, and nobody noticed.",
            },
        ],
        "closing": "Case closed. Clear rules, clear errors, and an honest history of every stay. The leak can't hide in a messy log book any more.",
    },
    # ================================================================== 12 (original)
    {
        "id": "coded-postcards",
        "tier": "medium",
        "title": "The Coded Postcards",
        "teaser": "Innocent holiday postcards, every letter shifted. Where and when is the meeting?",
        "skills": ["records", "forensic-text", "functional"],
        "story": "A gang has been sending each other holiday postcards that make no sense: *\"wkh sodfh lv...\"*. The lab recognised the trick at once: a **Caesar cipher**. Every letter is moved forward in the alphabet by a fixed number of places, the **shift**. With a shift of 3, `a` becomes `d` and `x` wraps round to `a`.\n\nThe postcards are in `postcards`, a list of dicts with `from`, `shift` and `text`. Each card says its own shift (the gang thinks a stamp hides it). `ALPHABET` holds the 26 lower-case letters. Spaces, digits and punctuation are not shifted.\n\nTo **decode**, move every letter **back** by the shift.",
        "suspects": [
            {"name": "the sender", "note": "Signs every card 'X'."},
            {"name": "the receiver", "note": "Collects the post at a box office."},
        ],
        "variants": [
            _postcards([
                ("Lisbon", 3, "greetings from the coast, wish you were here"),
                ("Goa", 11, "the place is the old lighthouse"),
                ("Cairo", 19, "the time is half past nine"),
                ("Oslo", 7, "burn this card after reading"),
            ]),
            _postcards([
                ("Kyoto", 24, "the time is ten to midnight"),
                ("Shimla", 5, "the weather is lovely, x"),
                ("Lagos", 13, "the place is platform seven"),
            ]),
            _postcards([
                ("Bruges", 1, "the chocolate here is excellent"),
                ("Jaipur", 22, "bring the blue suitcase"),
                ("Hanoi", 9, "the place is the fish market"),
                ("Quito", 16, "the time is six sharp"),
            ]),
        ],
        "steps": [
            {
                "question": "Write `decode(text, shift)`. Build a dict `table` that maps every letter of `ALPHABET` to the letter `shift` places **before** it (use `% 26` to wrap round), then translate the text one character at a time. Characters that are not in the table stay as they are.",
                "starter": r'''def decode(text, shift):
    ...

first = postcards[0]
print(decode(first["text"], first["shift"]))
''',
                "solution": _DECODE + r'''
first = postcards[0]
print(decode(first["text"], first["shift"]))
''',
                "tests": _DECODE_TEST + r'''assert decode("khoor, zruog!", 3) == "hello, world!", f"decode('khoor, zruog!', 3) should be 'hello, world!', got {decode('khoor, zruog!', 3)!r}"
assert decode("abc", 1) == "zab", "letters must wrap round: with shift 1, 'a' decodes to 'z'"
for _c, _m in zip(postcards, _msgs):
    _got = decode(_c["text"], _c["shift"])
    assert _got == _m, f"the card from {_c['from']} should decode to {_m!r}, got {_got!r}"''',
                "tips": [
                    "A dict comprehension builds the table: `{ALPHABET[i]: ALPHABET[(i - shift) % 26] for i in range(26)}`. `% 26` turns -1 into 25, so `a` wraps to `z`.",
                    "Translate with `table.get(ch, ch)` (the second `ch` is the fallback for spaces and punctuation): `return \"\".join([table.get(ch, ch) for ch in text])`.",
                ],
                "reveal": "The first card decodes cleanly. It's a real message, hiding behind a stamp.",
            },
            {
                "question": "Decode every card with **one list comprehension**: store the results in `messages`, in the same order as `postcards`.",
                "starter": _DECODE + r'''
messages = ...
for m in messages:
    print(m)
''',
                "solution": _DECODE + r'''
messages = [decode(card["text"], card["shift"]) for card in postcards]
for m in messages:
    print(m)
''',
                "tests": _DECODE_TEST + r'''assert messages == _msgs, f"messages should be {_msgs}, got {messages!r}"''',
                "tips": [
                    "The shape is `[expression for card in postcards]`.",
                    "`messages = [decode(card[\"text\"], card[\"shift\"]) for card in postcards]`",
                ],
                "reveal": "Most of the cards are small talk. Two of them are not.",
            },
            {
                "question": "One message starts with `\"the place is \"` and another with `\"the time is \"`. Store what comes **after** those words in `meeting_place` and `meeting_time`, and print `Meeting: <place> at <time>`.",
                "starter": _DECODE + r'''
messages = [decode(card["text"], card["shift"]) for card in postcards]

meeting_place = None
meeting_time = None
# look through messages here

print(f"Meeting: {meeting_place} at {meeting_time}")
''',
                "solution": _DECODE + r'''
messages = [decode(card["text"], card["shift"]) for card in postcards]

meeting_place = None
meeting_time = None
for m in messages:
    if m.startswith("the place is "):
        meeting_place = m[len("the place is "):]
    if m.startswith("the time is "):
        meeting_time = m[len("the time is "):]

print(f"Meeting: {meeting_place} at {meeting_time}")
''',
                "tests": _DECODE_TEST + r'''_place = [_m[13:] for _m in _msgs if _m.startswith("the place is ")][0]
_time = [_m[12:] for _m in _msgs if _m.startswith("the time is ")][0]
assert meeting_place == _place, f"the place is {_place!r}, got {meeting_place!r}"
assert meeting_time == _time, f"the time is {_time!r}, got {meeting_time!r}"
assert f"Meeting: {_place} at {_time}" in __output__, "print the line: Meeting: <place> at <time>"''',
                "tips": [
                    "`m.startswith(\"the place is \")` tells you which message it is. A slice drops the first words: `m[len(\"the place is \"):]`.",
                    "Inside `for m in messages:` write two `if` checks, one for the place and one for the time, each storing its slice.",
                ],
                "reveal": "A place and a time. The Bureau will be there first, with very good seats.",
            },
        ],
        "closing": "Case closed. The gang turned up to their secret meeting and found a welcome committee. Shifting letters is not encryption, it's a puzzle.",
    },
    # ================================================================== 13 (original)
    {
        "id": "timeline-reconstruction",
        "tier": "medium",
        "title": "Timeline Reconstruction",
        "teaser": "The statements are out of order. Rebuild the night, minute by minute.",
        "skills": ["toolkit", "forensic-text", "functional"],
        "story": "Something was stolen during the night, but the statements were collected in random order. Each one is a tuple `(timestamp, person, action)` in the list `events`, with timestamps written as `\"YYYY-MM-DD HH:MM\"`.\n\nThe theft happened during the **longest silence**: the biggest gap between two events in a row. Whoever acted right after that silence has some explaining to do.\n\nCareful: some nights cross midnight, so the date matters as much as the clock.",
        "suspects": [
            {"name": "everyone in the log", "note": "All of them say they saw nothing."},
        ],
        "variants": [
            'events = [\n    ("2026-07-04 22:10", "Guard Ramesh", "started the night round"),\n    ("2026-07-05 01:55", "Curator Adeyemi", "switched off the alarm"),\n    ("2026-07-04 21:30", "Cleaner Sofia", "mopped the main hall"),\n    ("2026-07-04 23:05", "Guard Ramesh", "checked the back door"),\n    ("2026-07-05 02:20", "Driver Kenji", "parked at the loading bay"),\n    ("2026-07-04 22:45", "Intern Zara", "left through the side gate"),\n]\n',
            'events = [\n    ("2026-02-11 09:15", "Clerk Anjali", "opened the bank"),\n    ("2026-02-11 12:40", "Teller Marcus", "counted the vault cash"),\n    ("2026-02-11 09:50", "Manager Rossi", "signed the ledger"),\n    ("2026-02-11 10:05", "Courier Bilal", "dropped off a parcel"),\n    ("2026-02-11 13:00", "Clerk Anjali", "went to lunch"),\n    ("2026-02-11 10:30", "Teller Marcus", "took a long phone call"),\n]\n',
            'events = [\n    ("2026-12-31 23:50", "Chef Dimitri", "lit the fireworks"),\n    ("2026-12-31 18:20", "Host Leela", "greeted the first guest"),\n    ("2026-12-31 19:00", "Waiter Joao", "served the soup"),\n    ("2027-01-01 00:10", "Guest Nkechi", "noticed the empty display case"),\n    ("2026-12-31 21:45", "Host Leela", "gave a speech"),\n    ("2026-12-31 22:05", "Waiter Joao", "cleared the tables"),\n    ("2026-12-31 19:30", "DJ Arvind", "started the music"),\n]\n',
        ],
        "steps": [
            {
                "question": "Write `to_time(stamp)` that turns `\"2026-07-04 22:10\"` into a `datetime`: split off the date and the clock, split those again, convert each piece with `int()`, and call `datetime(year, month, day, hour, minute)`.\n\nThen store `ordered`: the events sorted by time, using `sorted` with a `key`.",
                "starter": r'''from datetime import datetime

def to_time(stamp):
    ...

ordered = ...
for stamp, person, action in ordered:
    print(stamp, person, action)
''',
                "solution": _TO_TIME + r'''
ordered = sorted(events, key=lambda e: to_time(e[0]))
for stamp, person, action in ordered:
    print(stamp, person, action)
''',
                "tests": _TIMELINE_TEST + r'''for _e in events:
    _got = to_time(_e[0])
    assert _got == _t(_e[0]), f"to_time({_e[0]!r}) should be {_t(_e[0])!r}, got {_got!r}"
assert ordered == _ord, f"ordered should start with {_ord[0]} and end with {_ord[-1]}, got {ordered[:1]} ... {ordered[-1:]}"''',
                "tips": [
                    "`day, clock = stamp.split(\" \")`, then `year, month, date_num = day.split(\"-\")` and `hour, minute = clock.split(\":\")`. Wrap each in `int()` inside `datetime(...)`.",
                    "`ordered = sorted(events, key=lambda e: to_time(e[0]))`: the key turns each event into its time, and `sorted` does the rest.",
                ],
                "reveal": "For the first time, the night reads like a story: one event after another, in order.",
            },
            {
                "question": "Find the longest silence. Walk through `ordered` two events at a time. Subtracting two `datetime`s gives a `timedelta`; `int(gap.total_seconds() // 60)` turns it into minutes.\n\nStore the longest gap in `gap_minutes`, and in `after_gap` the person in the event right **after** it. Print both.",
                "starter": _TO_TIME + r'''
ordered = sorted(events, key=lambda e: to_time(e[0]))

gap_minutes = 0
after_gap = None
# compare each event with the next one

print(gap_minutes, "minutes of silence, then", after_gap)
''',
                "solution": _TO_TIME + r'''
ordered = sorted(events, key=lambda e: to_time(e[0]))

gap_minutes = 0
after_gap = None
for i in range(len(ordered) - 1):
    gap = to_time(ordered[i + 1][0]) - to_time(ordered[i][0])
    minutes = int(gap.total_seconds() // 60)
    if minutes > gap_minutes:
        gap_minutes = minutes
        after_gap = ordered[i + 1][1]

print(gap_minutes, "minutes of silence, then", after_gap)
''',
                "tests": _TIMELINE_TEST + r'''_best, _who = 0, None
for _i in range(len(_ord) - 1):
    _m = int((_t(_ord[_i + 1][0]) - _t(_ord[_i][0])).total_seconds() // 60)
    if _m > _best:
        _best, _who = _m, _ord[_i + 1][1]
assert gap_minutes == _best, f"the longest silence lasts {_best} minutes, got {gap_minutes!r}"
assert after_gap == _who, f"the person right after the longest silence is {_who!r}, got {after_gap!r}"''',
                "tips": [
                    "`for i in range(len(ordered) - 1):` lets you compare `ordered[i]` with `ordered[i + 1]`. The gap is `to_time(ordered[i + 1][0]) - to_time(ordered[i][0])`.",
                    "Keep the biggest so far: `if minutes > gap_minutes:` then store `gap_minutes = minutes` and `after_gap = ordered[i + 1][1]`.",
                ],
                "reveal": "A long silence, and then one person suddenly busy. Their statement leaves out what they did before it.",
            },
        ],
        "closing": "Case closed. Sorted times and one careful subtraction found the hole in the night, and the person who filled it.",
    },
]

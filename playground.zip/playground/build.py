"""Build (and check) a BookVault Playground page for one training day.

Usage:
    python build.py day1            # check lessons with CPython, then write day1.html
    python build.py day1 --no-check # skip the CPython check

Lesson content lives in <day>_lessons.py (see day1_lessons.py for the format).
The page runs Python in the browser with Brython, so lessons must not touch files or the network.
"""
import contextlib
import importlib
import io
import json
import sys
from pathlib import Path

HERE = Path(__file__).parent


def _run(src, ns, quiet=True):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(io.StringIO()):
        exec(src, ns)
    ns["__output__"] = buf.getvalue()   # mirrors the page runner: tests can read printed text
    ns["__source__"] = src
    return buf.getvalue()


def check(lessons):
    problems = []
    for L in lessons:
        if L.get("code"):
            try:
                _run(L["code"], {"__name__": "__main__"})
            except Exception as e:
                problems.append(f"{L['id']}: demo raised {type(e).__name__}: {e}")
        for q in L.get("quiz", []) + ([L["predict"]] if L.get("predict") else []):
            if not 0 <= q["answer"] < len(q["options"]):
                problems.append(f"{L['id']}: quiz answer index out of range: {q['q'][:40]}")
        if L.get("code") and not L.get("walkthrough"):
            problems.append(f"{L['id']}: demo has no line-by-line walkthrough")
        C = L.get("challenge")
        if not C:
            continue
        if not C.get("hints"):
            problems.append(f"{L['id']}: challenge has no hints")
        prelude = L["code"] if C.get("needs_demo") else ""
        # the reference solution must pass
        ns = {"__name__": "__main__"}
        try:
            if prelude:
                _run(prelude, ns)
            _run(C["solution"], ns)
            _run(C["tests"], ns)
        except Exception as e:
            problems.append(f"{L['id']}: solution failed {type(e).__name__}: {e}")
        # the untouched starter must NOT pass
        ns = {"__name__": "__main__"}
        try:
            if prelude:
                _run(prelude, ns)
            _run(C["starter"], ns)
            _run(C["tests"], ns)
            problems.append(f"{L['id']}: starter already passes the tests")
        except Exception:
            pass
    return problems


def build(day, do_check=True):
    mod = importlib.import_module(f"{day}_lessons")
    if do_check:
        problems = check(mod.LESSONS)
        for p in problems:
            print("PROBLEM:", p)
        if problems:
            sys.exit(1)
        print(f"Checked {len(mod.LESSONS)} lessons with CPython {sys.version.split()[0]}: all good.")

    def js(obj):
        return json.dumps(obj, ensure_ascii=False).replace("</", "<\\/")

    html = (HERE / "template.html").read_text(encoding="utf-8")
    html = (html.replace("/*__DAY_JSON__*/", js(mod.DAY))
                .replace("/*__PARTS_JSON__*/", js(mod.PARTS))
                .replace("/*__LESSONS_JSON__*/", js(mod.LESSONS))
                .replace("__DAYTITLE__", mod.DAY["title"])
                .replace("__DAY__", str(mod.DAY["number"])))
    out = HERE / f"{day}.html"
    out.write_text(html, encoding="utf-8")
    print(f"Wrote {out} ({len(html) // 1024} KB)")


if __name__ == "__main__":
    sys.path.insert(0, str(HERE))
    build(sys.argv[1] if len(sys.argv) > 1 else "day1", "--no-check" not in sys.argv)
